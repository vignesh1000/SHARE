#include <Hermes_Interface.h>
#include <config.h>
#include <hpl_init.h>
#include <PDFWUpdate.h>


#define NVIC_SystemReset            NVIC_SystemReset

#define REGDW(x)                        (*((unsigned int volatile *)(x)))      /* 32 bit register access*/



extern const volatile UINT32 FixedApplication;   // Application vector address symbol from the linker configuration file
extern const volatile UINT32 UpdatedApplication;   // Application vector address symbol from the linker configuration file
extern const volatile UINT32 FixedApplicationSignature;   // Application vector address symbol from the linker configuration file
extern const volatile UINT32 UpdatedApplicationSignature;   // Application vector address symbol from the linker configuration file
extern UINT8 u8FlashUpdateDone;   


/*
 * SAMD20J16B 
 *      Flash:                  0x00000000 - 0x00010000 (64 KB)
 *      Bootloader:             0x00000000 - 0x00000FFF (4 KB)
 *      FixedApplication:       0x00001000 - 0x00005FFF (20 KB)
 *      UpdateApplication:       0x00005FFF - 0x00010000 (40 KB)
 */

volatile UINT32 pFixedApplicationPtr =0;
volatile UINT32 pUpdatedApplicationPtr =0;
volatile UINT32 pFixedApplicationSignature =0;
volatile UINT32 pUpdatedApplicationSignature =0;

volatile UINT8 u8CurrentMemory;

/* Pointer to the Application Section */
void (*pfnApplicationCodeEntry)(void);


/*Main function*/
void main()
{
   
    /*Get Symbols from Linker file*/
    pFixedApplicationPtr          = (UINT32 )&FixedApplication;
    pUpdatedApplicationPtr        = (UINT32 )&UpdatedApplication;
    pFixedApplicationSignature    = (UINT32 )&FixedApplicationSignature;
    pUpdatedApplicationSignature  = (UINT32 )&UpdatedApplicationSignature;

    /*Verify Updatable application signature which is the first priotity*/ 
    if((REGB(pUpdatedApplicationSignature) == '2')&&
    ((REGB((pUpdatedApplicationSignature)+1)) == 'D')&&
    ((REGB((pUpdatedApplicationSignature)+2)) == 'F')&&
    ((REGB((pUpdatedApplicationSignature)+3)) == 'U'))
    {

        /* Rebase the Stack Pointer */
        __set_MSP(*(UINT32 *) pUpdatedApplicationPtr);

        /* Rebase the vector table base address */
        SCB->VTOR = ((UINT32) pUpdatedApplicationPtr & SCB_VTOR_TBLOFF_Msk);

        /* Load the Reset Handler address of the application */
        pfnApplicationCodeEntry = (void (*)(void))(unsigned *)(*(unsigned *)(pUpdatedApplicationPtr + 4));

        /* Jump to user Reset Handler in the application */
        pfnApplicationCodeEntry();

    }
    /*Verify Fixed application signature which is the first priotity*/ 
    else if((REGB(pFixedApplicationSignature) == '2')&&
    ((REGB((pFixedApplicationSignature)+1)) == 'D')&&
    ((REGB((pFixedApplicationSignature)+2)) == 'F')&&
    ((REGB((pFixedApplicationSignature)+3)) == 'U'))
    {	
        /* Rebase the Stack Pointer */
        __set_MSP(*(UINT32 *) pFixedApplicationPtr);

        /* Rebase the vector table base address */
        SCB->VTOR = ((UINT32) pFixedApplicationPtr & SCB_VTOR_TBLOFF_Msk);

        /* Load the Reset Handler address of the application */
        pfnApplicationCodeEntry = (void (*)(void))(unsigned *)(*(unsigned *)(pFixedApplicationPtr + 4));

        /* Jump to user Reset Handler in the application */
        pfnApplicationCodeEntry();

    }

    else
    {
        /*Clock Init- File name to be changed*/
        MCU_Init();
        
        /*Set the current memory as bootloader*/
        u8CurrentMemory = PD_FW_IMAGE_BANK_BOOTLOADER;
        
        /*TODO: Init Most of the global variables here*/
        
        /*Hermes Interface Init*/
        Hermes_InterfaceInit(); 

        while(TRUE)
        {
            /* Hermes request from I2C slave*/  
            if(Hermes_IfConnectionRequest())
            {  
                Hermes_ProcessMasterPacket();
            }
            if(u8FlashUpdateDone)
            {
                u8FlashUpdateDone=0;

                NVIC_SystemReset();

            }   
        }/*While End*/
    }
    
}
