/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */
#if 0
#ifndef DRIVER_INIT_INCLUDED
#define DRIVER_INIT_INCLUDED
#if 0
#include "atmel_start_pins.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <hal_atomic.h>
#include <hal_delay.h>
#include <hal_gpio.h>
#include <hal_init.h>
#include <hal_io.h>
#include <hal_sleep.h>
#include <stdinc.h>
#include <hal_spi_m_sync.h>
#include <hal_ext_irq.h>
#include <hal_timer.h>
#include <hal_usart_sync.h>

 

#define SERCOM_SEL_OFFSET  0x400  /**< \brief (SERCOM0) APB Base Address */
#define SERCOM0REG           ((Sercom   *)0x42000800UL) /**< \brief (SERCOM0) APB Base Address */
#define SERCOM(x)           (SERCOM0REG+((x)*(SERCOM_SEL_OFFSET)))  
  
 /*GCLK defined*/
#define GCLKCTLREG              ((Gclk     *)0x40000C02UL) /**< \brief (GCLK) APB Base Address */
#define APBCMASK_OFFSET  0x20 
#define PMREG               0x40000400UL /**< \brief (PM) APB Base Address */
#define APBCREG (PMREG + APBCMASK_OFFSET)
  
#define GCLK_REG_ADDR (GCLK+GCLK_CLKCTRL_OFFSET) 
#endif
extern struct spi_m_sync_descriptor SPI_0;

typedef union {
  struct {
    UINT32 CHSIZE:3;         /*!< bit:  0.. 2  Character Size                     */
    UINT32 :3;               /*!< bit:  3.. 5  Reserved                           */
    UINT32 PLOADEN:1;        /*!< bit:      6  Slave Data Preload Enable          */
    UINT32 :7;               /*!< bit:  7..13  Reserved                           */
    UINT32 AMODE:2;          /*!< bit: 14..15  Address Mode                       */
    UINT32 :1;               /*!< bit:     16  Reserved                           */
    UINT32 RXEN:1;           /*!< bit:     17  Receiver Enable                    */
    UINT32 :14;              /*!< bit: 18..31  Reserved                           */
  } bit;                       /*!< Structure used for bit  access                  */
  UINT32 reg;                /*!< Type      used for register access              */
} SERCOM_SPI_CTRLB_Reg;

typedef union {
  struct {
    UINT16 :2;               /*!< bit:  0.. 1  Reserved                           */
    UINT16 BUFOVF:1;         /*!< bit:      2  Buffer Overflow                    */
    UINT16 :12;              /*!< bit:  3..14  Reserved                           */
    UINT16 SYNCBUSY:1;       /*!< bit:     15  Synchronization Busy               */
  } bit;                       /*!< Structure used for bit  access                  */
  UINT16 reg;                /*!< Type      used for register access              */
} SERCOM_SPI_STATUS_Reg;

typedef union { // __I to avoid read-modify-write on write-to-clear register
  struct {
    UINT8  DRE:1;            /*!< bit:      0  Data Register Empty                */
    UINT8  TXC:1;            /*!< bit:      1  Transmit Complete                  */
    UINT8  RXC:1;            /*!< bit:      2  Receive Complete                   */
    UINT8  :5;               /*!< bit:  3.. 7  Reserved                           */
  } bit;                       /*!< Structure used for bit  access                  */
  UINT8 reg;                 /*!< Type      used for register access              */
} SERCOM_SPI_INTFLAG_Reg;

typedef union {
  struct {
    UINT8  BAUD:8;           /*!< bit:  0.. 7  Baud Register                      */
  } bit;                       /*!< Structure used for bit  access                  */
  UINT8 reg;                 /*!< Type      used for register access              */
} SERCOM_SPI_BAUD_Reg;

typedef union {
  struct {
    UINT8  DRE:1;            /*!< bit:      0  Data Register Empty Interrupt Enable */
    UINT8  TXC:1;            /*!< bit:      1  Transmit Complete Interrupt Enable */
    UINT8  RXC:1;            /*!< bit:      2  Receive Complete Interrupt Enable  */
    UINT8  :5;               /*!< bit:  3.. 7  Reserved                           */
  } bit;                       /*!< Structure used for bit  access                  */
  UINT8 reg;                 /*!< Type      used for register access              */
} SERCOM_SPI_INTENCLR_Reg;

typedef union {
  struct {
    UINT8  DRE:1;            /*!< bit:      0  Data Register Empty Interrupt Enable */
    UINT8  TXC:1;            /*!< bit:      1  Transmit Complete Interrupt Enable */
    UINT8  RXC:1;            /*!< bit:      2  Receive Complete Interrupt Enable  */
    UINT8  :5;               /*!< bit:  3.. 7  Reserved                           */
  } bit;                       /*!< Structure used for bit  access                  */
  UINT8 reg;                 /*!< Type      used for register access              */
} SERCOM_SPI_INTENSET_Reg;

typedef union {
  struct {
    UINT32 ADDR:8;           /*!< bit:  0.. 7  Address                            */
    UINT32 :8;               /*!< bit:  8..15  Reserved                           */
    UINT32 ADDRMASK:8;       /*!< bit: 16..23  Address Mask                       */
    UINT32 :8;               /*!< bit: 24..31  Reserved                           */
  } bit;                       /*!< Structure used for bit  access                  */
  UINT32 reg;                /*!< Type      used for register access              */
} SERCOM_SPI_ADDR_Reg;

typedef union {
  struct {
    UINT16 DATA:9;           /*!< bit:  0.. 8  Data                               */
    UINT16 :7;              /*!< bit:  9..15  Reserved                           */
  } bit;                       /*!< Structure used for bit  access                  */
  UINT16 reg;                /*!< Type      used for register access              */
} SERCOM_SPI_DATA_Reg;


typedef union {
  struct {
    UINT16 ID:6;             /*!< bit:  0.. 5  Generic Clock Selection ID         */
    UINT16 :2;               /*!< bit:  6.. 7  Reserved                           */
    UINT16 GEN:4;            /*!< bit:  8..11  Generic Clock Generator            */
    UINT16 :2;               /*!< bit: 12..13  Reserved                           */
    UINT16 CLKEN:1;          /*!< bit:     14  Clock Enable                       */
    UINT16 WRTLOCK:1;        /*!< bit:     15  Write Lock                         */
  } bit;                       /*!< Structure used for bit  access                  */
  UINT16 reg;                /*!< Type      used for register access              */
} GCLK_CLKCTRL_Reg;

void SPI_0_PORT_init(void);
void SPI_0_CLOCK_init(void);
void SPI_0_init(void);

void EXTERNAL_IRQ_0_init(void);

void Reset_UPD350_Thru_MCU_GPIO_Init();
void Reset_UPD350_Thru_MCU_GPIO ();

#ifdef SPI_READ_STRESS_TEST
UINT8 RegisterReadStressWrite();
#endif

void HW_SPI_ChipSelect_High (UINT8 u8Portnum);
void HW_SPI_ChipSelect_Low (UINT8 u8Portnum);
void HW_SPI_Write_Txr (UINT8 *u8data, UINT16 u16length);
void HW_SPI_Read_Txr (UINT8 *u8readData, UINT16 u16readLength);
void Userdef_MCU_Exit_Critical();
void Userdef_MCU_Enter_Critical();
uint8_t TIMER_0_init(void);
void UPDInterrupt_Init();
extern struct timer_descriptor TIMER_0;

extern struct usart_sync_descriptor USART_0;

void USART_0_PORT_init(void);
void USART_0_CLOCK_init(void);
void USART_0_init(void);

void InitTypeCGlobaldata();



#ifdef __cplusplus
}
#endif
#endif // DRIVER_INIT_INCLUDED
#endif