

#ifndef _PD_FW_UPDATE_H_
#define _PD_FW_UPDATE_H_
#include <generic_defs.h>
#include <Hermes_Interface.h>
typedef struct _PD_FW_UPDATE_REQ
{
    UINT8   u8ProtocolVersion;
    UINT8   u8MessageType;
    UINT16  u16DataBlockIndex;
} PD_FW_REQ_HEADER;
#pragma pack(1)
typedef struct _GET_FW_ID_RESPONSE
{
    UINT8   u8Status;
    UINT16  u16VID;
    UINT16  u16PID;
    UINT8   u8HWVersion;
    UINT8   u8SiVersion;
    UINT16  u16FWVersion1;
    UINT16  u16FWVersion2;
    UINT16  u16FWVersion3;
    UINT16  u16FWVersion4;
    UINT8   u8ImageBank;
    UINT8   u8Flags1;
    UINT8   u8Flags2;
    UINT8   u8Flags3;
    UINT8   u8Flags4;
} PD_FW_GET_FW_ID;
#define PD_FW_PROTOCOL_REV              0x01
#define PD_FW_GET_FW_ID_REQ             0x81
#define PD_FW_PDFU_INTIATE_REQ          0x82
#define PD_FW_PDFU_DATA_REQ             0x83
#define PD_FW_VENDOR_SPECIFIC_REQ       0xFF
#define PD_FW_GET_FW_ID_RES             0x01
#define PD_FW_PDFU_INTIATE_RES          0x02
#define PD_FW_PDFU_DATA_RES             0x03
#define PD_FW_VENDOR_SPECIFIC_RES       0x7F
#define PD_FW_RES_STATUS_OK             0x00
#define PD_FW_MICROCHIP_VENDOR_ID       0x0424
#define PD_FW_CURRENT_FW_VERSION        SYSTEM_FW_REV
#define PD_FW_IMAGE_BANK_BOOTLOADER     0x01
#define PD_FW_IMAGE_BANK_FIXED_APP      0x02
#define PD_FW_IMAGE_BANK_UPDATABLE_APP  0x03
#define PD_FW_RDY_TO_INITIATE_FW_UPDATE 0x00
#define PD_FW_BUFFER_SIZE               260
UINT8   PDFW_ProcessRequestPacket
        (
            UINT8   *u8RequestBuffer,
            UINT16  u16RequestLength,
            UINT8   *u8ResponseBuffer,
            UINT16  *u16ResponseLength
        );
UINT16  PDFW_ProcessRxRequestPacket
        (
            UINT8   *u8ResponseBuffer,
            UINT16  *u16ResLength
        );
UINT16  PDFW_ProcessPDFUInitateRequest(UINT8 *u8RespnseBuffer);
UINT16  PDFW_ProcessGetFWIDRequest(UINT8 *u8RespnseBuffer);
#endif
