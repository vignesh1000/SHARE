/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include <Hermes_Interface.h>
#include <config.h>
#include <hpl_init.h>
#include <PDFWUpdate.h>
#include "Config_Globals.h"
#include "Internal_Globals.h"
#include "upd_access.h"
#include "SERCOM_Spi.h"
/****************Defines for Bootselect Strap******************************/
/** 1) For 200K PD- Stay In Bootloader for new Reflash operation */
#define BOOTSEL_EXECUTE_BOOTLOADER    0x00u
/** 2) For 200K PU- Execute Application as Normal */
#define BOOTSEL_EXECUTE_APPLICATION     0x01u
/**************************************************************************/

/****************Macros related to UPD350 Reset Startup Delay calculations********/
#define SYSTEM_CLOCK_MHZ                48u
#define NUM_NOP_INSTRUCTIONS            3u
#define WAIT_REQUIRED_US                10000
#define WAIT_COUNT                  ((SYSTEM_CLOCK_MHZ * WAIT_REQUIRED_US)+1)/(NUM_NOP_INSTRUCTIONS +5)

/**************************************************************************/

/**********Static Functions in this file**********************************/
/** Function which carries out Bootloader operations*/
static void    Bootloader_main(void);
/**************************************************************************/

/* Pointer to the Application Section */
void (*pfnApplicationCodeEntry) (void);

/* */
void main(void)
{
    UINT8   u8BootSelStrap = BOOTSEL_EXECUTE_BOOTLOADER;
    
    
    /**Initialize the Global variables **/
    CfgGlobals_Initialize();
    
    /*********** Identify the BootSelect Starp value ***********************/
    /**1) Set the Strap GPIO in Input Mode**/
    GPIO_SetDirection( PIN_PA00, GPIO_SETDIRECTION_IN);
    /**2) Disable the Internal PULL Up/Down Options*/
    GPIOStrap_SetTristate(PIN_PA00);
    
    /**3) Read the GPIO Value**/
    u8BootSelStrap = GPIOStrap_GetInputLevel(PIN_PA00);
    
    /**If 200K PD Applied in the Bootselect Strap - STAY in Bootloader*/
    if(BOOTSEL_EXECUTE_BOOTLOADER != u8BootSelStrap)
    {   /**If 200K PU Applied in the Bootselect Strap-Execute Application*/
      
        /*Verify Updatable application signature which is the first priotity*/
        if
        (
            (REGB(pUpdatedApplicationSignature) == '2')
        &&  ((REGB((pUpdatedApplicationSignature) + 1)) == 'D')
        &&  ((REGB((pUpdatedApplicationSignature) + 2)) == 'F')
        &&  ((REGB((pUpdatedApplicationSignature) + 3)) == 'U')
        )
        {
            /*Set the current memory as Updatable App*/
            gu8CurrentMemory = PD_FW_IMAGE_BANK_UPDATABLE_APP;

            /* Rebase the Stack Pointer */
            __set_MSP(*(UINT32 *) pUpdatedApplicationPtr);

            /* Rebase the vector table base address */
            SCB->VTOR = ((UINT32) pUpdatedApplicationPtr & SCB_VTOR_TBLOFF_Msk);

            /* Load the Reset Handler address of the application */
            pfnApplicationCodeEntry = (void(*) (void)) ((UINT32 *) (*(UINT32 *) (pUpdatedApplicationPtr + 4)));

            /* Jump to user Reset Handler in the application */
            pfnApplicationCodeEntry();
        }

        /*Verify Fixed application signature which is the first priotity*/
        else
        if
        (
            (REGB(pFixedApplicationSignature) == '2')
        &&  ((REGB((pFixedApplicationSignature) + 1)) == 'D')
        &&  ((REGB((pFixedApplicationSignature) + 2)) == 'F')
        &&  ((REGB((pFixedApplicationSignature) + 3)) == 'U')
        )
        {
            /*Set the current memory as Fixed App*/
            gu8CurrentMemory = PD_FW_IMAGE_BANK_FIXED_APP;

            /* Rebase the Stack Pointer */
            __set_MSP(*(UINT32 *) pFixedApplicationPtr);

            /* Rebase the vector table base address */
            SCB->VTOR = ((UINT32) pFixedApplicationPtr & SCB_VTOR_TBLOFF_Msk);

            /* Load the Reset Handler address of the application */
            pfnApplicationCodeEntry = (void(*) (void)) ((UINT32 *) (*(UINT32 *) (pFixedApplicationPtr + 4)));

            /* Jump to user Reset Handler in the application */
            pfnApplicationCodeEntry();
        }
        else
        {
            /* Enter boot loader*/
        }
    }
    else
    {
        /**
        If, for Staying in Bootloader 200K PD have been applied,
        Release the UPD350 from Reset.
        As the BootSel Strap is implemented using UPD350 Reset Pin,
        Setting the Pin to High is necessary for UPD350 to go into normal state from Reset State
        **/
        GPIO_SetDirection ( PIN_PA00, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinLevel (PIN_PA00, TRUE);
    }
 
    
    /**
    For the control to reach here,
    1) Application Signature verification Failed
    2) BootSelect Strap is 200K PD
    */
    /** To perform the Bootloader Core Operations */
    Bootloader_main();
}

/* */
static void Bootloader_main(void)
{
    UINT8 u8UpdReadyRetryCount = 0x05;
    UINT8 u8ReadData[4] = {0x00u,0x00u,0x00u,0x00u};
    volatile UINT16 u16DelayCounter;
    /*Clock Init- File name to be changed*/
    MCU_Init();

    /*Set the current memory as bootloader*/
    gu8CurrentMemory = PD_FW_IMAGE_BANK_BOOTLOADER;
    
    /**Initializing SPI module*/
    SPI_Init();
    
    while (u8UpdReadyRetryCount > 0)
    {
        /**Delay for 10ms, to confirm UPD350 is ready*/
        for(u16DelayCounter = 0u; u16DelayCounter <(WAIT_COUNT);u16DelayCounter++)
        {
            __asm volatile("nop");
            __asm volatile("nop");
            __asm volatile("nop");
        }
        
            /*Read SPI_TEST register*/
        UPD_RegisterRead(UPD_PORT_0, (UINT16)UPD_SPI_TEST, u8ReadData, 4);

        /*Check the SPI_TEST register value is 0x02*/
        if (u8ReadData[0] == UPD_SPI_TEST_VAL)
        {
            /*Read VID & PID register*/
            UPD_RegisterRead(UPD_PORT_0, (UINT16)UPD_VID, u8ReadData, 4);
     
            /*Verify the default values*/
            if((u8ReadData[0] == UPD_VID_LSB) && (u8ReadData[1] == UPD_VID_MSB) && \
              (u8ReadData[2] == UPD_PID_LSB) && (u8ReadData[3] == UPD_PID_MSB))
            {  
                /*Value read from this port is right, Internal Upd350 is now alive*/
                gu8SlaveAddr = 0x00u;
                break;

            }
            else
            {
              /** Internal UPD350 is dead, so assign default address*/
                gu8SlaveAddr = 0x78;
            }
        }
        else
        {
                      /** Internal UPD350 is dead, so assign default address*/
                gu8SlaveAddr = 0x78;
        }
        
        u8UpdReadyRetryCount--;
    }
   
    /*Hermes Interface Init*/
    Hermes_InterfaceInit();
    
    while(TRUE)
    {
        /* Hermes request from I2C slave*/
        if(Hermes_IfConnectionRequest())
        {
            (void) Hermes_ProcessMasterPacket();
        }
    }   /*While End*/
}
