#ifndef _INCLUDES_H_
#define _INCLUDES_H_
#include <GPIO.h>
#include <Hermes_Interface.h>
#include <Interrupts.h>
#include <SERCOM_I2CSlave.h>
#include <SERCOM_Spi.h>
#include <Timers.h>
#endif
