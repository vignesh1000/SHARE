/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#include "generic_defs.h"
#include "nvm.h"

/* Variables to hold NVM parameters ,declared as static so that other modules will not get chance to update mistakenly*/
#include "Config_Globals.h"
#include "Internal_Globals.h"
#define NVM_PAGESIZE \
        ( \
            8 << \
                ( \
                    ((*((UINT32 *) (NVM_PARAM_REG))) & NVM_PARAM_PSZ_MSK) >> \
                    NVM_PARAM_PSZ_POS \
                ) \
        )
#define NVM_NUMBEROFPAGES \
        ( \
            ((*((UINT32 *) (NVM_PARAM_REG))) & NVM_PARAM_NVMP_MSK) >> \
                NVM_PARAM_NVMP_POS \
        )
#define NVM_MANUALPAGEWRITE NVM_FEATURE_DISBALE

/******************************************************************************
 * Function:        UINT8 NVM_STATUS NVM_SetConfiguration(const struct nvm_config *const config)
 * Input:           NVM configuration
 * Output:          UINT8  status code				
 * Overview:        This routine set the NVM configuration like No of pages, Page size,wait states			
 * Note:            
 *****************************************************************************/
UINT8 NVM_Init(void)
{
    /* Turn on the digital interface clock */
    REGDW(NVM_APBBMASK_REG) |= APBBMASK_NVMCTRL;

    /* Clear error flags */
    REGW(NVM_STATUS_REG) = NVM_STATUS_MASK;

    /* Check if the module is busy */
    if(!(REGB(NVM_INTFLAG_REG) & NVM_INTFLAG_READY))
    {
        return NVM_STATUS_BUSY;
    }

    /* Writing configuration to the CTRLB register */
    REGDW(NVM_CTRLB_REG) = NVMCTRL_CTRLB_SLEEPPRM(NVM_SLEEP_POWER_MODE_WAKEONACCESS) | ((NVM_FEATURE_DISBALE) << NVM_CTRLB_MANW_POS) | NVMCTRL_CTRLB_RWS(NVM_WAIT_STATES) |
    ((NVM_FEATURE_DISBALE) << NVM_CTRLB_CACHEDIS_POS) |
    NVMCTRL_CTRLB_READMODE(NVM_CACHE_READMODE_NO_MISS_PENALTY);

    /* Read the NVM information */
    return NVM_STATUS_OK;
}

/******************************************************************************
 * Function:        UINT8 NVM_ExecuteCommand(UINT8 u8NVMCommand,const UINT32 address,const UINT32 parameter)
 * Input:           Command, address and parameters
 * Output:          UINT8 status code				
 * Overview:        This routine executes the NVM commands 			
 * Note:            
 *****************************************************************************/
UINT8 NVM_ExecuteCommand(
    UINT8           u8NVMCommand,   /* */
    const UINT32    u32Address,     /* */
    const UINT32    u32Parameter)   /* */
{
    UINT32  u32CopyCTRLBReg;

    /* Check that the address given is valid  */
    if(u32Address > ((UINT32) NVM_PAGESIZE * NVM_NUMBEROFPAGES))
    {
        return NVM_STATUS_ERR_BAD_ADDRESS;
    }

    /* Turn off cache before issuing flash commands */
    u32CopyCTRLBReg = REGDW(NVM_CTRLB_REG);
    REGDW(NVM_CTRLB_REG) = u32CopyCTRLBReg | NVM_CTRLB_CACHEDIS;

    /* Clear error flags */
    REGW(NVM_STATUS_REG) = NVMCTRL_STATUS_MASK;

    /* Check if the module is busy */
    if(!(REGB(NVM_INTFLAG_REG) & NVM_INTFLAG_READY))
    {
        /* Restore the setting */
        REGDW(NVM_CTRLB_REG) = u32CopyCTRLBReg;
        return NVM_STATUS_BUSY;
    }

    switch(u8NVMCommand)
    {
    /* Commands requiring address (unprotected) */
    case NVM_COMMAND_ERASE_ROW:
    case NVM_COMMAND_WRITE_PAGE:
        /* Set address, command will be issued elsewhere */
        REGDW(NVM_ADDR_REG) = (UINT32)(&NVM_MEMORY[u32Address / 4]);
        break;

    /* Commands not requiring address */
    case NVM_COMMAND_PAGE_BUFFER_CLEAR:
    case NVM_COMMAND_SET_SECURITY_BIT:
    case NVM_COMMAND_ENTER_LOW_POWER_MODE:
    case NVM_COMMAND_EXIT_LOW_POWER_MODE:
        break;

    default:
        /* Restore the setting */
        REGDW(NVM_CTRLB_REG) = u32CopyCTRLBReg;
        return NVM_STATUS_ERR_INVALID_ARG;
    }

    /* Set command */
    REGDW(NVM_CTRLA_REG) = u8NVMCommand | NVM_CTRLA_CMDEX_KEY;

    /* Wait for the NVM controller to become ready */
    while(!(REGB(NVM_INTFLAG_REG) & NVM_INTFLAG_READY));

    /* Restore the setting */
    REGDW(NVM_CTRLB_REG) = u32CopyCTRLBReg;
    return NVM_STATUS_OK;
}

/******************************************************************************
 * Function:        UINT8 NVM_STATUS NVM_UpdateBuffer(const UINT32 u32DestinationAddress,
                    UINT8 *const pu8Buffer,UINT16 u16Offset,UINT16 u16Length)
 * Input:           buffer , length and destination address
 * Output:          UINT8 Status code				
 * Overview:        This routine copy NVM data to buffer			
 * Note:            
 *****************************************************************************/
UINT8 NVM_UpdateBuffer(
    const UINT32    u32DestinationAddress,  /* */
    UINT8 *const    pu8Buffer,  /* */
    UINT16          u16Offset,  /* */
    UINT16          u16Length)  /* */
{
    UINT8   u8ErrorCode = NVM_STATUS_OK;
    UINT8   u8RowBuffer[NVMCTRL_ROWPAGES][NVMCTRL_PAGESIZE];

    /* Ensure the read does not overflow the page size */
    if((u16Offset + u16Length) > NVM_PAGESIZE)
    {
        return NVM_STATUS_ERR_INVALID_ARG;
    }

    /* Calculate the starting row address of the page to update */
    UINT32  u32RowStartAddress = u32DestinationAddress &((UINT32)(~
        (UINT32)((UINT32)(NVM_PAGESIZE * NVMCTRL_ROWPAGES) - (UINT32)0x1UL)));

    /* Read in the current row contents */
    for(UINT32 i = 0; i < NVMCTRL_ROWPAGES; i++)
    {
        do
        {
            u8ErrorCode = NVM_ReadBuffer
                (
                    u32RowStartAddress + (i * NVM_PAGESIZE),
                    u8RowBuffer[i],
                    NVM_PAGESIZE
                );
        } while(u8ErrorCode == NVM_STATUS_BUSY);
        if(u8ErrorCode != NVM_STATUS_OK)
        {
            return u8ErrorCode;
        }
    }

    /* Calculate the starting page in the row that is to be updated */
    UINT8   u8PageInRow =(UINT8)(
        (UINT32)(
            u32DestinationAddress %
            ((UINT32)(NVM_PAGESIZE * NVMCTRL_ROWPAGES))
        ) /
        (UINT32)NVM_PAGESIZE);

    /* Update the specified bytes in the page buffer */
    for(UINT32 i = 0; i < u16Length; i++)
    {
        u8RowBuffer[u8PageInRow][u16Offset + i] = pu8Buffer[i];
    }

    /* Erase the row */
    do
    {
        u8ErrorCode = NVM_EraseRow(u32RowStartAddress);
    } while(u8ErrorCode == NVM_STATUS_BUSY);
    if(u8ErrorCode != NVM_STATUS_OK)
    {
        return u8ErrorCode;
    }

    /* Write the updated row contents to the erased row */
    for(UINT32 i = 0; i < NVMCTRL_ROWPAGES; i++)
    {
        do
        {
            u8ErrorCode = NVM_WriteBuffer
                (
                    u32RowStartAddress + (i * NVM_PAGESIZE),
                    u8RowBuffer[i],
                    NVM_PAGESIZE
                );
        } while(u8ErrorCode == NVM_STATUS_BUSY);
        if(u8ErrorCode != NVM_STATUS_OK)
        {
            return u8ErrorCode;
        }
    }

    return u8ErrorCode;
}

/******************************************************************************
 * Function:        UINT8 NVM_STATUS NVM_WriteBuffer(const UINT32 u32DestinationAddress,const UINT8 *u8Buffer,UINT16 u16length)
 * Input:           NVM address to be written, Input buffer, length
 * Output:          NVM status code				
 * Overview:        This routine writes buffer content to NVM destination address			
 * Note:            
 *****************************************************************************/
UINT8 NVM_WriteBuffer(
    const UINT32    u32DestinationAddress,  /* */
    const UINT8     *pu8Buffer, /* */
    UINT16          u16length)  /* */
{
    UINT32  u32NVMAddress;

    /* Check if the destination address is valid */
    if(u32DestinationAddress > ((UINT32) NVM_PAGESIZE * NVM_NUMBEROFPAGES))
    {
        return NVM_STATUS_ERR_BAD_ADDRESS;
    }

    /* Check if the write address not aligned to the start of a page */
    if(u32DestinationAddress & (NVM_PAGESIZE - 1))
    {
        return NVM_STATUS_ERR_BAD_ADDRESS;
    }

    /* Check if the write length is longer than an NVM page */
    if(u16length > NVM_PAGESIZE)
    {
        return NVM_STATUS_ERR_INVALID_ARG;
    }

    /* Check if the module is busy */
    if(!(REGB(NVM_INTFLAG_REG) & NVM_INTFLAG_READY))
    {
        return NVM_STATUS_BUSY;
    }

    /* Erase the page buffer before buffering new data */
    REGDW(NVM_CTRLA_REG) = NVM_COMMAND_PAGE_BUFFER_CLEAR | NVM_CTRLA_CMDEX_KEY;

    /* Check if the module is busy Force-wait for the buffer clear to complete */
    while(!(REGB(NVM_INTFLAG_REG) & NVM_INTFLAG_READY));

    /* Clear error flags */
    REGW(NVM_STATUS_REG) = NVM_STATUS_MASK;
    u32NVMAddress = u32DestinationAddress / 2;

    /* NVM _must_ be accessed as a series of 16-bit words, perform manual copy to ensure alignment */
    for(UINT16 i = 0; i < u16length; i += 2)
    {
        UINT16  u16data;

        /* Copy first byte of the 16-bit chunk to the temporary buffer */
        u16data = pu8Buffer[i];

        /* If we are not at the end of a write request with an odd byte count,
		 * store the next byte of data as well */

        //if (i < (u16length - 1))
        //{
        u16data |= (pu8Buffer[i + 1] << 8);

        //}

        /* Store next 16-bit chunk to the NVM memory space */
        NVM_MEMORY[u32NVMAddress++] = u16data;
    }

    /* perform a manual NVM write when the length of data to be programmed is less than page size*/
#if (NVM_MANUALPAGEWRITE == NVM_FEATURE_DISBALE)
    if
    (        
    u16length < NVMCTRL_PAGESIZE
    )
    {
        return NVM_ExecuteCommand
            (
                NVM_COMMAND_WRITE_PAGE,
                u32DestinationAddress,
                0
            );
    }
#endif
    return NVM_STATUS_OK;
}

/******************************************************************************
 * Function:        UINT8 NVM_ReadBuffer(const UINT32 u32SourceAddress,UINT8 *const pu8buffer,UINT16 u16Length)
 * Input:           NVM address , buffer to read, Length
 * Output:          UINT8 status code				
 * Overview:        This routine Reads the NVM memory content to buffer			
 * Note:            
 *****************************************************************************/
UINT8 NVM_ReadBuffer(
    const UINT32    u32SourceAddress,   /* */
    UINT8 *const    pu8buffer,          /* */
    UINT16          u16Length)          /* */
{
    /* Check if the source address is valid */
    if(u32SourceAddress > ((UINT32) NVM_PAGESIZE * NVM_NUMBEROFPAGES))
    {
        return NVM_STATUS_ERR_BAD_ADDRESS;
    }

    /* Check if the read address is not aligned to the start of a page */
    if(u32SourceAddress & (NVM_PAGESIZE - 1))
    {
        return NVM_STATUS_ERR_BAD_ADDRESS;
    }

    /* Check if the write length is longer than an NVM page */
    if(u16Length > NVM_PAGESIZE)
    {
        return NVM_STATUS_ERR_INVALID_ARG;
    }

    /* Check if the module is busy */
    if(!(REGB(NVM_INTFLAG_REG) & NVM_INTFLAG_READY))
    {
        return NVM_STATUS_BUSY;
    }

    /* Clear error flags */
    REGW(NVM_STATUS_REG) = NVM_STATUS_MASK;

    UINT32  u32PageAddress = u32SourceAddress / 2;

    /* NVM _must_ be accessed as a series of 16-bit words, perform manual copy to ensure alignment */
    for(UINT16 i = 0; i < u16Length; i += 2)
    {
        /* Fetch next 16-bit chunk from the NVM memory space */
        UINT16  u16Data = NVM_MEMORY[u32PageAddress++];

        /* Copy first byte of the 16-bit chunk to the destination buffer */
        pu8buffer[i] = (u16Data & 0xFF);

        /* If we are not at the end of a read request with an odd byte count store the next byte of data as well */

        //if (i < (u16Length - 1))
        {
            pu8buffer[i + 1] = (u16Data >> 8);
        }
    }

    return NVM_STATUS_OK;
}

/******************************************************************************
 * Function:        UINT8 NVM_EraseRow(const UINT32 u32RowAddress)
 * Input:           Row address
 * Output:          UINT8 status code				
 * Overview:        This routine erases the Row(256	bytes)
 * Note:            
 *****************************************************************************/
UINT8 NVM_EraseRow(
    const UINT32    u32RowAddress)  /* */
{
    /* Check if the row address is valid */
    if(u32RowAddress > ((UINT32) NVM_PAGESIZE * NVM_NUMBEROFPAGES))
    {
        return NVM_STATUS_ERR_BAD_ADDRESS;
    }

    /* Check if the address to erase is not aligned to the start of a row */
    if(u32RowAddress & ((NVM_PAGESIZE * NVMCTRL_ROWPAGES) - 1))
    {
        return NVM_STATUS_ERR_BAD_ADDRESS;
    }

    /* Check if the module is busy */
    if(!(REGB(NVM_INTFLAG_REG) & NVM_INTFLAG_READY))
    {
        return NVM_STATUS_BUSY;
    }

    /* Clear error flags */
    REGW(NVM_STATUS_REG) = NVM_STATUS_MASK;

    /* Set address and command */
    REGDW(NVM_ADDR_REG) = (UINT32) & NVM_MEMORY[u32RowAddress / 4];

    /* Erase the page buffer before buffering new data */
    REGDW(NVM_CTRLA_REG) = NVM_COMMAND_ERASE_ROW | NVM_CTRLA_CMDEX_KEY;
    while(!(REGB(NVM_INTFLAG_REG) & NVM_INTFLAG_READY));

    /* There existed error in NVM erase operation */
    if((UINT8) (REGW(NVM_STATUS_REG) & NVM_ERRORS_MASK) != NVM_ERROR_NONE)
    {
        return NVM_STATUS_ABORTED;
    }

    return NVM_STATUS_OK;
}

/******************************************************************************
 * Function:        UINT8 NVM_ProgramMemory( UINT32 u32ProgAddr , UINT8 *pu8Buffer, UINT16 u16Length)
 * Input:           NVM address, data buffer to be programmed, length
 * Output:          UINT8 status					
 * Overview:        This routine writes the NVM Memory				
 * Note:            
 *****************************************************************************/
UINT8 NVM_ProgramMemory(
    UINT32  u32ProgAddr,    /* */
    UINT8   *pu8Buffer,     /* */
    UINT16  u16Length)      /* */
{
    UINT8   u8Status = 0;

    /* Check if length is greater than Flash page size */
    if(u16Length > NVMCTRL_PAGESIZE)
    {
        UINT16  u16Offset = 0;
        while(u16Length > NVMCTRL_PAGESIZE)
        {
            /* Check if it is first page of a row */
            if((u32ProgAddr & 0xFF) == 0)
            {
                /* Erase row */
                u8Status = NVM_EraseRow(u32ProgAddr);

                /* If Erase row is not successful, then return the error code */
                if(NVM_STATUS_OK != u8Status)
                {
                    return u8Status;
                }
            }

            /* Write one page data to flash */
            u8Status = NVM_WriteBuffer
                (
                    u32ProgAddr,
                    pu8Buffer + u16Offset,
                    NVMCTRL_PAGESIZE
                );
            if(NVM_ERROR_NONE != u8Status)
            {
                return u8Status;
            }

            /* Increment the address to be programmed */
            u32ProgAddr += NVMCTRL_PAGESIZE;

            /* Increment the offset of the buffer containing data */
            u16Offset += NVMCTRL_PAGESIZE;

            /* Decrement the length */
            u16Length -= NVMCTRL_PAGESIZE;
        }

        /* Check if there is data remaining to be programmed*/
        if(u16Length > 0)
        {
            /* Write the data to flash */
            u8Status = NVM_WriteBuffer
                (
                    u32ProgAddr,
                    pu8Buffer + u16Offset,
                    u16Length
                );
            if(NVM_ERROR_NONE != u8Status)
            {
                return u8Status;
            }
        }
    }
    else
    {
        /* Check if it is first page of a row) */
        if((u32ProgAddr & 0xFF) == 0)
        {
            /* Erase row */
            u8Status = NVM_EraseRow(u32ProgAddr);

            /* If Erase row is not successful, then return the error code */
            if(NVM_STATUS_OK != u8Status)
            {
                return u8Status;
            }
        }

        /* Write the data to flash */
        u8Status = NVM_WriteBuffer(u32ProgAddr, pu8Buffer, u16Length);
        if(NVM_ERROR_NONE != u8Status)
        {
            return u8Status;
        }
    }

    return u8Status;
}

/******************************************************************************
 * Function:        UINT8 NVM_ReadMemory( UINT32 u32ProgAddr , UINT8 *puBuffer, UINT16 u16Length)
 * Input:           NVM address , buffer to read, length
 * Output:          UINT8 Status					
 * Overview:        This routine Reads the NVM Memory to buffer				
 * Note:            
 *****************************************************************************/
UINT8 NVM_ReadMemory(
    UINT32  u32ProgAddr,    /* */
    UINT8   *puBuffer,      /* */
    UINT16  u16Length)      /* */
{
    UINT8   u8Status = 0;

    /* Check if length is greater than Flash page size */
    if(u16Length > NVMCTRL_PAGESIZE)
    {
        UINT16  u16Offset = 0;
        while(u16Length > NVMCTRL_PAGESIZE)
        {
            /* Write one page data to flash */
            u8Status = NVM_ReadBuffer
                (
                    u32ProgAddr,
                    puBuffer + u16Offset,
                    NVMCTRL_PAGESIZE
                );
            if(NVM_ERROR_NONE != u8Status)
            {
                return u8Status;
            }

            /* Increment the address to be programmed */
            u32ProgAddr += NVMCTRL_PAGESIZE;

            /* Increment the offset of the buffer containing data */
            u16Offset += NVMCTRL_PAGESIZE;

            /* Decrement the length */
            u16Length -= NVMCTRL_PAGESIZE;
        }

        /* Check if there is data remaining to be programmed*/
        if(u16Length > 0)
        {
            /* Write the data to flash */
            u8Status = NVM_ReadBuffer
                (
                    u32ProgAddr,
                    puBuffer + u16Offset,
                    u16Length
                );
            if(NVM_ERROR_NONE != u8Status)
            {
                return u8Status;
            }
        }
    }
    else
    {
        /* Write the data to flash */
        u8Status = NVM_ReadBuffer(u32ProgAddr, puBuffer, u16Length);
        if(NVM_ERROR_NONE != u8Status)
        {
            return u8Status;
        }
    }

    return u8Status;
}
