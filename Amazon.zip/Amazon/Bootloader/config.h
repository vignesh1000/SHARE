
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _CONFIG_H_
#define _CONFIG_H_

#include <stdbool.h>
#include <atmel_start_pins.h>
#include <driver_init.h>
#include <Hermes_Interface.h>
#include <GPIO.h>
#include <hal_atomic.h>
#ifdef MCHP_TRACE
	#include <uart_trace\trace.h>
#endif

/******************CONFIGURATION PARAMETERS**********************************/

/******************MCU FIRMWARE CONFIGURATION*****************************************/
/*Struture packing to align the bytes in data memory based on the compiler*/
/* E,g: #define STRUCT_PACKED_START   __attribute__((__packed__)) */
#define CONFIG_STRUCT_PACKED_START

/*Struture packing to align the bytes in data memory based on the compiler*/
#define CONFIG_STRUCT_PACKED_END

/*ENDIANESS; UPD301 is little endian*/
#define CONFIG_BIG_ENDIAN				0

/**********************Hook Configuration************************************/
#define CONFIG_HOOK_POLICY_ENGINE_PRE_PROCESS 			0

#define CONFIG_HOOK_POLICY_ENGINE_POST_PROCESS 			0

#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS 	0

#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_POST_PROCESS 	0

#define CONFIG_HOOK_TYPE_C_MANANGEMENT_PRE_PROCESS		0

#define CONFIG_HOOK_TYPE_C_MANANGEMENT_POST_PROCESS		0

#define CONFIG_HOOK_UPD_TX_MSG_PRE_PROCESS				0

#define CONFIG_HOOK_UPD_TX_MSG_POST_PROCESS				0

#define CONFIG_HOOK_UPD_RX_MSG_PRE_PROCESS				0

#define CONFIG_HOOK_UPD_RX_MSG_POST_PROCESS				0

#define CONFIG_HOOK_UPD_ALERT_ISR_ALL_PORT				0

/***************** DEBUG MESSAGES ****************************************************/


#ifdef CONFIG_HOOK_DEBUG_MSG
	#define HOOK_INIT_DEBUG()				                                HookInitDebug()
	#define HOOK_DEBUG_STRING(_str_)		                                HookDebugString(_str_)
	#define HOOK_DEBUG_CHAR(_char_)			                                HookDebugChar(_char_)
	#define HOOK_DEBUG_UINT8(_u8Val_)		                                HookDebugUint8(_u8Val_)
	#define HOOK_DEBUG_UINT16(_u16Val_)		                                HookDebugUint16(_u16Val_)
	#define HOOK_DEBUG_UINT32(_u32Val_)		                                HookDebugUint32(_u32Val_)
    #define HOOK_DEBUG_INT32(_i32Val_)		                                HookDebugInt32(_i32Val_)
#else
	#define HOOK_INIT_DEBUG()				
	#define HOOK_DEBUG_STRING(_str_)		
	#define HOOK_DEBUG_CHAR(_char_)			
	#define HOOK_DEBUG_UINT8(_u8Val_)		
	#define HOOK_DEBUG_UINT16(_u16Val_)			
	#define HOOK_DEBUG_UINT32(_u32Val_)
    #define HOOK_DEBUG_INT32(_i32Val_)	
#endif


/***********************Timer************************************************/


/*Frequency of interrupt from PD MCU Timer */
/* Eg:# define CONFIG_PDTIMER_INTERRUPT_RATE 1000  , 1000 interrupts per seconnd, with interrupt interval of 1ms */
#define CONFIG_PDTIMER_INTERRUPT_RATE	1000  

/*Data Type of the Timeout variable in PD Software Timer*/
/* Eg: #define CONFIG_16_BIT_PDTIMEOUT 1 , will make timeout variable unsigned 16bit */
#define CONFIG_16_BIT_PDTIMEOUT

/* Number of ports that are going to be handled by the PD stack */
#define CONFIG_PD_PORT_COUNT			1

/*High level enable define for each port*/
#define CONF_PD_PORT0_ENABLE            1
#define CONF_PD_PORT1_ENABLE            0
#define CONF_PD_PORT2_ENABLE            0
#define CONF_PD_PORT3_ENABLE            0

/*******************Port Configuration data**********************************/

#define  CONFIG_PORT_0_POWER_ROLE           1           				/* 0- PD_ROLE_SINK , 1- PD_ROLE_SOURCE */

#define  CONFIG_PORT_0_DATA_ROLE            0          				    /* 0- PD_ROLE_DFP , 1- PD_ROLE_UFP */

#define  CONFIG_PORT_0_RP_CURRENT_VALUE     1         		            /* 0- RP_DISABLED(To be set for Sink), 1- DEFAULT_CURRENT ,2- CURRENT_15 ,3- CURRENT_30 */

#define  CONFIG_PORT_1_POWER_ROLE           0           		

#define  CONFIG_PORT_1_DATA_ROLE            1          			

#define  CONFIG_PORT_1_RP_CURRENT_VALUE     0  



/*****************INCLUDE/EXCLUDE AT COMPILE TIME*****************************/
/*Following flags are applicable for all CONFIG_PD_PORT_COUNT*/
/*If any of the port from CONFIG_PD_PORT_COUNT requires following features then enable it to 
handle in the code otherwise disable it to exclude the part of the code for the corresponding feature*/

/* Support for USB PD alternate mode */
#define INCLUDE_PD_ALT_MODE		0

/* Define if this board can act as a dual-role PD port (source and sink) */
#define INCLUDE_PD_DUAL_ROLE	0

/* Support of Fast Role Swap */
#define INCLUDE_PD_FRS			0

/*Support for electronically marked cable */
#define INCLUDE_PD_E_MARKER		0

/* Support for PD specification 3.0 otherwise PD 2.0 specification will be followed */
#define INCLUDE_PD_3_0			0

/* Source only */
#define INCLUDE_PD_SOURCE_ONLY  1

/* Sink Only */
#define INCLUDE_PD_SINK_ONLY    1



/* tCC Debounce to read match register */
#define TYPEC_TCCDEBOUNCE_TIMEOUT			150
#define TYPEC_TPDEBOUNCE_TIMEOUT			10
#define TYPEC_VBUSDEBOUNCE_TIMEOUT			10
#define TYPEC_ERROR_RECOVERY_TIMEOUT        25

/*TODO: To be changed once the actual time for VCONN Discharge  is found*/
#define TYPEC_VCONN_DISCHARGE_TIMEOUT       35      

/*********************** Functions to be defined by User**************************************/

/*Initialization function of PD Hardware Timer*/
//#define HW_PDTIMER_INIT()	                TIMER_0_init()			      
#define HW_PDTIMER_INIT()	                Timer_Init()
/*Initialization function for configuration of External UPD Interrupts*/
#define UPDINTERRUPT_INIT()			UPDInterrupt_Init()

/* VBUS drive function for set voltage in VBUS */
#define VBUS_DRIVE_VOLTAGE(PortNum, VBUS_Volatge)	PWRCTRL_SetPortPower (PortNum, VBUS_Volatge)

/*Call back function for external Device policy manager to notify PD events */
#define DPM_NOTIFY_STATUSCHANGE_CB(PortNum, PDEvent)
#define TYPEC_ATTACH_EVENT                  1
#define TYPEC_DETACH_EVENT                  0

/******************MCU INTERRUPT CONFIGURATION*****************************************/

/*Disable Global Interrupts,E,g: #define  DISABLE_GLOBAL_INTERRUPT   {(GIE)=0;}*/
#define DISABLE_GLOBAL_INTERRUPT()                  CRITICAL_SECTION_ENTER()            

/*Enable Global Interrupts,E,g: #define  ENABLE_GLOBAL_INTERRUPT   {(GIE)=1;}*/
#define ENABLE_GLOBAL_INTERRUPT()                   CRITICAL_SECTION_LEAVE()

/*Reset UPD350 through MCU GPIO*/ 
#define RESET_UPD350_THRU_MCU_GPIO()                    Reset_UPD350_Thru_MCU_GPIO()

/*Reset UPD350 through MCU GPIO initialization*/ 
#define RESET_UPD350_THRU_MCU_GPIO_INIT()               IRQ_ResetUPD350ThruGPIOInit()

#define SETUP_UPD_INTERRUPT()                           IRQ_ExtIrqInit()
/******************SPI INTERFACE CONFIGURATION*****************************************/
//#define HW_SPI_INIT()                                                   SPI_0_init()
#define HW_SPI_INIT()                                                   SPI_Init()
#define HW_SPI_CS_LOW(_port_num_)                                       SPI_ChipSelectLow(_port_num_)
#define HW_SPI_CS_HIGH(_port_num_)                                      SPI_ChipSelectHigh(_port_num_)
#define HW_SPI_WRITE_TRANSFER(_write_buf_,_write_len)                   SPI_Write (_write_buf_, _write_len) 
#define HW_SPI_READ_TRANSFER(_read_buf_, _read_len)                     SPI_Read (_read_buf_, _read_len)

/******************I2C Slave INTERFACE CONFIGURATION*****************************************/
#define HW_HERMES_INIT()                                                  Hermes_InterfaceInit()













/* TRUE/FALSE defines */
#define FALSE                                     0
#define TRUE                                      1

/* Boolean */
#define BOOL                                      unsigned char

/* Unsigned integers */
#define UINT8                                     unsigned char
#define UINT16                                    unsigned short
#define UINT32                                    unsigned long


/* Signed Integer */
#define INT8                                      char
#define INT16                                     short
#define INT32                                     long

/* Signed character */
#define CHAR                                      char

/* Unsigned character */
#define UCHAR                                     unsigned char

/* Size of operator */
#define SIZEOF(x)                                 sizeof(x)

#define BIT(x)                                    (1 << x)

/* Data Size */ 
#define BYTE_LEN_1			        			1
#define BYTE_LEN_2			        			2
#define BYTE_LEN_3			        			3
#define BYTE_LEN_4			        			4
#define BYTE_LEN_10                 			10
#define BYTE_LEN_16			        			16

#define BYTE_0									0
#define BYTE_1									1
   			
#define GCLK_GENERATOR_1 1
#define GCLK_GENERATOR_0 0
#define REG_PM_CPUSEL              (0x40000408) /**< \brief (PM) CPU Clock Select */
#define REG_PM_APBASEL             (0x40000409) /**< \brief (PM) APBA Clock Select */
#define REG_PM_APBBSEL             (0x4000040A) /**< \brief (PM) APBB Clock Select */
#define REG_PM_APBCSEL             (0x4000040B) /**< \brief (PM) APBC Clock Select */
#define REG_GCLK_GENCTRL           (0x40000C04) /**< \brief (GCLK) Generic Clock Generator Control */
#define REG_GCLK_GENDIV            (0x40000C08) /**< \brief (GCLK) Generic Clock Generator Division */
#define REG_SYSCTRL_OSC8M          (0x40000820) /**< \brief (SYSCTRL) OSC8M Control A */
#define REG_GCLK_STATUS            (0x40000C01) /**< \brief (GCLK) Status */
#define REG_GCLK_CLKCTRL           (0x40000C02) /**< \brief (GCLK) Generic Clock Control */
#define REG_NVMCTRL_CTRLB          (0x41004004) /**< \brief (NVMCTRL) Control B */
#define PM_APBCSEL_APBCDIV_Pos      0            /**< \brief (PM_APBCSEL) APBC Prescaler Selection */
#define PM_APBCSEL_APBCDIV_Msk      (_U_(0x7) << PM_APBCSEL_APBCDIV_Pos)
#define PM_APBCSEL_APBCDIV(value)   (PM_APBCSEL_APBCDIV_Msk & ((value) << PM_APBCSEL_APBCDIV_Pos))

#define PM_APBBSEL_APBBDIV_Pos      0            /**< \brief (PM_APBBSEL) APBB Prescaler Selection */
#define PM_APBBSEL_APBBDIV_Msk      (_U_(0x7) << PM_APBBSEL_APBBDIV_Pos)
#define PM_APBBSEL_APBBDIV(value)   (PM_APBBSEL_APBBDIV_Msk & ((value) << PM_APBBSEL_APBBDIV_Pos))

#define PM_APBASEL_APBADIV_Pos      0            /**< \brief (PM_APBASEL) APBA Prescaler Selection */
#define PM_APBASEL_APBADIV_Msk      (_U_(0x7) << PM_APBASEL_APBADIV_Pos)
#define PM_APBASEL_APBADIV(value)   (PM_APBASEL_APBADIV_Msk & ((value) << PM_APBASEL_APBADIV_Pos))

#define SYSCTRL_OSC8M_ONDEMAND_Pos  7            /**< \brief (SYSCTRL_OSC8M) Enable on Demand */
#define SYSCTRL_OSC8M_ONDEMAND      (_U_(0x1) << SYSCTRL_OSC8M_ONDEMAND_Pos)

#define SYSCTRL_OSC8M_RUNSTDBY_Pos  6            /**< \brief (SYSCTRL_OSC8M) Run during Standby */
#define SYSCTRL_OSC8M_RUNSTDBY      (_U_(0x1) << SYSCTRL_OSC8M_RUNSTDBY_Pos)

#define GCLKGENDIV_ID_Pos          0            /**< \brief (GCLK_GENDIV) Generic Clock Generator Selection */
#define GCLKGENDIV_ID(value)       ((value) << GCLKGENDIV_ID_Pos)

#define GCLKGENDIV_DIV_Pos         8            /**< \brief (GCLK_GENDIV) Division Factor */
#define GCLKGENDIV_DIV(value)      ((value) << GCLKGENDIV_DIV_Pos)


#define GCLKGENCTRL_ID_Pos         0            /**< \brief (GCLK_GENCTRL) Generic Clock Generator Selection */

#define GCLKGENCTRL_ID(value)      ((value) << GCLK_GENCTRL_ID_Pos)

#define GCLKGENCTRL_GENEN_Pos      16           /**< \brief (GCLK_GENCTRL) Generic Clock Generator Enable */
#define GCLKGENCTRL_GENEN          ((0x1) << GCLKGENCTRL_GENEN_Pos)
#define GCLKGENCTRL_IDC_Pos        17           /**< \brief (GCLK_GENCTRL) Improve Duty Cycle */
#define GCLKGENCTRL_IDC            ((0x1) << GCLKGENCTRL_IDC_Pos)
#define GCLKGENCTRL_OOV_Pos        18           /**< \brief (GCLK_GENCTRL) Output Off Value */
#define GCLKGENCTRL_OOV_OFF            ((0x0) << GCLKGENCTRL_OOV_Pos)
#define GCLKGENCTRL_OOV_ON            ((0x1) << GCLKGENCTRL_OOV_Pos)
#define GCLKGENCTRL_OE_Pos         19           /**< \brief (GCLK_GENCTRL) Output Enable */
#define GCLKGENCTRL_OE_OFF             ((0x0) << GCLKGENCTRL_OE_Pos)
#define GCLKGENCTRL_OE_ON             ((0x1) << GCLKGENCTRL_OE_Pos)
#define GCLKGENCTRL_DIVSEL_Pos     20           /**< \brief (GCLK_GENCTRL) Divide Selection */
#define GCLKGENCTRL_DIVSEL_OFF         ((0x0) << GCLKGENCTRL_DIVSEL_Pos)
#define GCLKGENCTRL_DIVSEL_ON         ((0x1) << GCLKGENCTRL_DIVSEL_Pos)
#define GCLKGENCTRL_RUNSTDBY_Pos   21           /**< \brief (GCLK_GENCTRL) Run in Standby */
#define GCLKGENCTRL_RUNSTDBY_OFF       ((0x0) << GCLKGENCTRL_RUNSTDBY_Pos)
#define GCLKGENCTRL_RUNSTDBY_ON       ((0x1) << GCLKGENCTRL_RUNSTDBY_Pos)

#define GCLKGENCTRL_SRC(value)     ((value) << GCLKGENCTRL_SRC_Pos)
#define GCLKSOURCE_OSC8M           6 
#define GCLKSOURCE_DFLL48M         7    
#define GCLKGENCTRL_SRC_Pos        8            /**< \brief (GCLK_GENCTRL) Source Select */

#define GCLKSTATUS_SYNCBUSY_Pos    7            /**< \brief (GCLK_STATUS) Synchronization Busy Status */
#define GCLKSTATUS_SYNCBUSY        ((0x1) << GCLKSTATUS_SYNCBUSY_Pos)

#define NVMCTRLCTRLB_RWS_Pos       1            /**< \brief (NVMCTRL_CTRLB) NVM Read Wait States */
#define NVMCTRLCTRLB_RWS(value)    ((value) << NVMCTRLCTRLB_RWS_Pos)

#define GCLKCLKCTRL_CLKEN_Pos      14           /**< \brief (GCLK_CLKCTRL) Clock Enable */
#define GCLKCLKCTRL_CLKEN          ((0x1) << GCLKCLKCTRL_CLKEN_Pos)
#define GCLK_CLKCTRL_WRTLOCK_Pos    15           /**< \brief (GCLK_CLKCTRL) Write Lock */
#define GCLK_CLKCTRL_WRTLOCK_OFF        ((0x0) << GCLK_CLKCTRL_WRTLOCK_Pos)
#define GCLK_CLKCTRL_WRTLOCK_ON        ((0x1) << GCLK_CLKCTRL_WRTLOCK_Pos)
#define GCLK_CLKCTRL_GEN_Pos        8            /**< \brief (GCLK_CLKCTRL) Generic Clock Generator */
#define GCLK_CLKCTRL_GEN_Msk        (_U_(0xF) << GCLK_CLKCTRL_GEN_Pos)
#define GCLKCLKCTRL_GEN(value)     (GCLK_CLKCTRL_GEN_Msk & ((value) << GCLK_CLKCTRL_GEN_Pos))

#define GCLK_CLKCTRL_ID_Pos         0            /**< \brief (GCLK_CLKCTRL) Generic Clock Selection ID */
#define GCLK_CLKCTRL_ID_Msk         (_U_(0x3F) << GCLK_CLKCTRL_ID_Pos)
#define GCLK_CLKCTRL_ID(value)      (GCLK_CLKCTRL_ID_Msk & ((value) << GCLK_CLKCTRL_ID_Pos))

#define REGSYSCTRL_PCLKSR         (0x4000080C) /**< \brief (SYSCTRL) Power and Clocks Status */
#define SYSCTRL_PCLKSR_DFLLRDY_Pos  4            /**< \brief (SYSCTRL_PCLKSR) DFLL Ready */
#define SYSCTRL_PCLKSR_DFLLRDY      ((0x1) << SYSCTRL_PCLKSR_DFLLRDY_Pos)

#define REG_SYSCTRL_DFLLCTRL       (0x40000824) /**< \brief (SYSCTRL) DFLL Config */
#define REG_SYSCTRL_DFLLVAL        (0x40000828) /**< \brief (SYSCTRL) DFLL Calibration Value */
#define REG_SYSCTRL_DFLLMUL        (0x4000082C) /**< \brief (SYSCTRL) DFLL Multiplier */

#define SYSCTRL_DFLLMUL_MUL_Pos     0            /**< \brief (SYSCTRL_DFLLMUL) Multiplication Value */
#define SYSCTRL_DFLLMUL_MUL_Msk     (_U_(0xFFFF) << SYSCTRL_DFLLMUL_MUL_Pos)
#define SYSCTRL_DFLLMUL_MUL(value)  (SYSCTRL_DFLLMUL_MUL_Msk & ((value) << SYSCTRL_DFLLMUL_MUL_Pos))
#define SYSCTRL_DFLLMUL_FSTEP_Pos   16           /**< \brief (SYSCTRL_DFLLMUL) Maximum Fine Step Size */
#define SYSCTRL_DFLLMUL_FSTEP_Msk   (_U_(0x3FF) << SYSCTRL_DFLLMUL_FSTEP_Pos)
#define SYSCTRL_DFLLMUL_FSTEP(value) (SYSCTRL_DFLLMUL_FSTEP_Msk & ((value) << SYSCTRL_DFLLMUL_FSTEP_Pos))
#define SYSCTRL_DFLLMUL_CSTEP_Pos   26           /**< \brief (SYSCTRL_DFLLMUL) Maximum Coarse Step Size */
#define SYSCTRL_DFLLMUL_CSTEP_Msk   (_U_(0x3F) << SYSCTRL_DFLLMUL_CSTEP_Pos)
#define SYSCTRL_DFLLMUL_CSTEP(value) (SYSCTRL_DFLLMUL_CSTEP_Msk & ((value) << SYSCTRL_DFLLMUL_CSTEP_Pos))


#define SYSCTRL_DFLLVAL_FINE_Pos    0            /**< \brief (SYSCTRL_DFLLVAL) Fine Calibration Value */
#define SYSCTRL_DFLLVAL_FINE_Msk    (_U_(0x3FF) << SYSCTRL_DFLLVAL_FINE_Pos)
#define SYSCTRL_DFLLVAL_FINE(value) (SYSCTRL_DFLLVAL_FINE_Msk & ((value) << SYSCTRL_DFLLVAL_FINE_Pos))
#define SYSCTRL_DFLLVAL_COARSE_Pos  10           /**< \brief (SYSCTRL_DFLLVAL) Coarse Calibration Value */
#define SYSCTRL_DFLLVAL_COARSE_Msk  (_U_(0x3F) << SYSCTRL_DFLLVAL_COARSE_Pos)
#define SYSCTRL_DFLLVAL_COARSE(value) (SYSCTRL_DFLLVAL_COARSE_Msk & ((value) << SYSCTRL_DFLLVAL_COARSE_Pos))
#define SYSCTRL_DFLLVAL_DIFF_Pos    16           /**< \brief (SYSCTRL_DFLLVAL) Multiplication Ratio Difference */
#define SYSCTRL_DFLLVAL_DIFF_Msk    (_U_(0xFFFF) << SYSCTRL_DFLLVAL_DIFF_Pos)
#define SYSCTRL_DFLLVAL_DIFF(value) (SYSCTRL_DFLLVAL_DIFF_Msk & ((value) << SYSCTRL_DFLLVAL_DIFF_Pos))

#define SYSCTRL_PCLKSR_DFLLLCKF_Pos 6            /**< \brief (SYSCTRL_PCLKSR) DFLL Lock Fine */
#define SYSCTRL_PCLKSR_DFLLLCKF     ((0x1) << SYSCTRL_PCLKSR_DFLLLCKF_Pos)

#define SYSCTRL_DFLLCTRL_ENABLE_Pos 1            /**< \brief (SYSCTRL_DFLLCTRL) Enable */
#define SYSCTRL_DFLLCTRL_ENABLE_OFF     ((0x0) << SYSCTRL_DFLLCTRL_ENABLE_Pos)
#define SYSCTRL_DFLLCTRL_ENABLE_ON     ((0x1) << SYSCTRL_DFLLCTRL_ENABLE_Pos)
#define SYSCTRL_DFLLCTRL_MODE_Pos   2            /**< \brief (SYSCTRL_DFLLCTRL) Mode Selection */
#define SYSCTRL_DFLLCTRL_MODE       ((0x1) << SYSCTRL_DFLLCTRL_MODE_Pos)
#define SYSCTRL_DFLLCTRL_STABLE_Pos 3            /**< \brief (SYSCTRL_DFLLCTRL) Stable Frequency */
#define SYSCTRL_DFLLCTRL_STABLE_OFF     ((0x0) << SYSCTRL_DFLLCTRL_STABLE_Pos)
#define SYSCTRL_DFLLCTRL_LLAW_Pos   4            /**< \brief (SYSCTRL_DFLLCTRL) Lose Lock After Wake */
#define SYSCTRL_DFLLCTRL_LLAW_OFF       ((0x0) << SYSCTRL_DFLLCTRL_LLAW_Pos)
#define SYSCTRL_DFLLCTRL_RUNSTDBY_Pos 6            /**< \brief (SYSCTRL_DFLLCTRL) Run during Standby */
#define SYSCTRL_DFLLCTRL_RUNSTDBY_OFF   ((0x0) << SYSCTRL_DFLLCTRL_RUNSTDBY_Pos)
#define SYSCTRL_DFLLCTRL_ONDEMAND_Pos 7            /**< \brief (SYSCTRL_DFLLCTRL) Enable on Demand */
#define SYSCTRL_DFLLCTRL_ONDEMAND_OFF   ((0x0) << SYSCTRL_DFLLCTRL_ONDEMAND_Pos)
#define SYSCTRL_DFLLCTRL_ONDEMAND_ON   ((0x1) << SYSCTRL_DFLLCTRL_ONDEMAND_Pos)
#define SYSCTRL_DFLLCTRL_CCDIS_Pos  8            /**< \brief (SYSCTRL_DFLLCTRL) Chill Cycle Disable */
#define SYSCTRL_DFLLCTRL_CCDIS_OFF      ((0x0) << SYSCTRL_DFLLCTRL_CCDIS_Pos)
#define SYSCTRL_DFLLCTRL_QLDIS_Pos  9            /**< \brief (SYSCTRL_DFLLCTRL) Quick Lock Disable */
#define SYSCTRL_DFLLCTRL_QLDIS      ((0x1) << SYSCTRL_DFLLCTRL_QLDIS_Pos)

#define SYSCTRL_GCLK_ID_DFLL48      0 


#define MY_SYSCTRL_OSC8M_MASK  (0xCFFF0002ul)
#endif