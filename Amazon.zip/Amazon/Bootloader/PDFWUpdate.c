/**
 * Copyright (c) 2017 Microchip Technology Inc. All rights reserved.
 * Microchip licenses to you the right to use, modify, copy and distribute
 * Software only when embedded on a Microchip microcontroller or digital
 * signal controller that is integrated into your product or third party
 * product (pursuant to the sublicense terms in the accompanying license
 * agreement). You should refer to the license agreement accompanying this
 * Software for additional information regarding your rights and obligations.
 * SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A
 * PARTICULAR PURPOSE. IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE
 * OR OBLIGATED UNDER CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION,
 * BREACH OF WARRANTY, OR OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT
 * DAMAGES OR EXPENSES INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL,
 * INDIRECT, PUNITIVE OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA,
 * COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY
 * CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE
 * THEREOF), OR OTHER SIMILAR COSTS.
 */
#include <PDFWUpdate.h>
#include <string.h>
#include "Config_Globals.h"
#include "Internal_Globals.h"

/**
 ===============================================================================
 *
 ===============================================================================
 */
UINT16 PDFW_ProcessGetFWIDRequest(
    UINT8   *u8RespnseBuffer)   /* */
{
    /*~~~~~~~~~~~~~~~~~~*/
    PD_FW_GET_FW_ID stGetFWID;
    UINT16          u16Length = 0;

    /*~~~~~~~~~~~~~~~~~~*/
    u8RespnseBuffer[0] = PD_FW_PROTOCOL_REV;
    u8RespnseBuffer[1] = PD_FW_GET_FW_ID_RES;

    /* Hard code to PD FW update error code OK */
    stGetFWID.u8Status = PD_FW_RES_STATUS_OK;
    stGetFWID.u16VID = PD_FW_MICROCHIP_VENDOR_ID;

    /* Marked as TBD in Hermes interface */
    stGetFWID.u16PID = 0x301A;

    /* Set HW revision to 1 as mentioned UDID section of Hermes Interface */
    stGetFWID.u8HWVersion = 0x01;

    /**
	 * Set Silicon revision to 1;
	 * To be requested to Richard
	 */
    stGetFWID.u8SiVersion = 0x01;

    /* Firmware Revision */
    stGetFWID.u16FWVersion1 = 0x00;
    stGetFWID.u16FWVersion2 = 0x00;
    stGetFWID.u16FWVersion3 = 0x00;
    stGetFWID.u16FWVersion4 = ((UINT16) (PD_FW_CURRENT_FW_VERSION >> 8)) | (PD_FW_CURRENT_FW_VERSION & 0xff);

    /* Current image bank, u8CurrentMemory was stored when booting */
    stGetFWID.u8ImageBank = gu8CurrentMemory;

    /* Flags only applies to PD FW Update Spec, Hence fill it as Zero */
    stGetFWID.u8Flags1 = 0x00;
    stGetFWID.u8Flags2 = 0x00;
    stGetFWID.u8Flags3 = 0x00;
    stGetFWID.u8Flags4 = 0x00;
    u16Length = sizeof(PD_FW_GET_FW_ID);

    /**
	 * Copy to PDFW Buffer: Tested with Own MemCpy , the difference was
	 * around only 10 bytes
	 */
    (void)Hermes_MemCpy(&u8RespnseBuffer[2], (UINT8 *) &stGetFWID, u16Length);

    /* Add Response Header Length */
    u16Length = u16Length + 2;
    return u16Length;
}

/**
 ===============================================================================
 *
 ===============================================================================
 */
UINT16 PDFW_ProcessPDFUInitateRequest(
    UINT8   *u8RespnseBuffer)   /* */
{
    /*~~~~~~~~~~~~~~~~~~*/
    UINT16  u16Length = 0;

    /*~~~~~~~~~~~~~~~~~~*/
    u8RespnseBuffer[u16Length++] = PD_FW_PROTOCOL_REV;
    u8RespnseBuffer[u16Length++] = PD_FW_PDFU_INTIATE_RES;

    /* Hard code to PD FW update error code OK */
    u8RespnseBuffer[u16Length++] = PD_FW_RES_STATUS_OK;

    /**
	 * Wait Time Hard code to zero ;
	 * A value of 0 indicates that the PDFU Responder is ready to initiate
	 * firmware update
	 */
    u8RespnseBuffer[u16Length++] = PD_FW_RDY_TO_INITIATE_FW_UPDATE;

    /**
	 * Bits 19:0 Maximum firmware image length in bytes that PDFU Responder
	 * can receive ;
	 * As per Section 5 of PD FW Update spec, Multi-byte fields that contain
	 * numerical values are formatted at consecutive offsets, and shall be
	 * formatted with the LSB at the lower offset and the MSB at the higher
	 * offse
	 */
    u8RespnseBuffer[u16Length++] = 0x00;
    u8RespnseBuffer[u16Length++] = (PD_FW_BUFFER_SIZE & 0xff);
    u8RespnseBuffer[u16Length++] = ((UINT16) (PD_FW_BUFFER_SIZE >> 8)) & 0xff;
    return u16Length;
}

/**
 ===============================================================================
 *
 ===============================================================================
 */
UINT8 PDFW_ProcessRequestPacket(
    UINT8   *u8RequestBuffer,   /* */
    UINT16  u16RequestLength,   /* */
    UINT8   *u8ResponseBuffer,  /* */
    UINT16  *u16ResponseLength) /* */
{
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    UINT8   u8Status = HERMES_HRESP_INVALID;

    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

    /* u8RequestBuffer[2] is Protocol revision */
    switch(u8RequestBuffer[3])
    {
    case PD_FW_GET_FW_ID_REQ:
        {
            /* Fill relevant data's in response buffer */
            *u16ResponseLength = PDFW_ProcessGetFWIDRequest(&u8ResponseBuffer[0]);

            /* Set the status as OK */
            u8Status = HERMES_HRESP_OK;
            break;
        }

    case PD_FW_PDFU_INTIATE_REQ:
        {
            /* Fill relevant data's in response buffer */
            *u16ResponseLength = PDFW_ProcessPDFUInitateRequest(&u8ResponseBuffer[0]);

            /* Set the status as OK */
            u8Status = HERMES_HRESP_OK;
            break;
        }

    case PD_FW_PDFU_DATA_REQ:
        {
            /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
            UINT16  u16DataBlock = u8RequestBuffer[4];
            UINT32  u32ProgAddr;
            UINT16  i;

            /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

            /**
			 * Always start from Fixed Application ptr if the current memory
			 * is bootloader or updatable app
			 */
            if
            (
                (gu8CurrentMemory == PD_FW_IMAGE_BANK_BOOTLOADER)
            ||  (gu8CurrentMemory == PD_FW_IMAGE_BANK_UPDATABLE_APP)
            )
            {
                u32ProgAddr = (pFixedApplicationPtr + (256u * u16DataBlock));
            }
            else
            {
                u32ProgAddr = (pUpdatedApplicationPtr + (256u * u16DataBlock));
            }

            (void)NVM_ProgramMemory(u32ProgAddr, &u8RequestBuffer[6u], 256u);

            /* Read NVM Flash with same address and length */
            (void)NVM_ReadMemory(u32ProgAddr, &u8ResponseBuffer[0u], 256u);
            u8Status = HERMES_HRESP_OK;
            *u16ResponseLength = 0x01;
            //I2C_SlaveTriggerIRQ();
            for(i = 0u; i < 256; i++)
            {
                if(u8RequestBuffer[6 + i] != u8ResponseBuffer[i])
                {
                    u8Status = HERMES_HRESP_INVALID;
                    break;
                }
            }
            break;
        }

    default:
        {
            break;
        }
    }

    return u8Status;
}
