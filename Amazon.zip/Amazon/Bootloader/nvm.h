/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _NVM_H_
#define _NVM_H_
#include <generic_defs.h>
#include "parts.h"
#include <GPIO.h>

/* NVM Control Registers*/
#define NVM_APBBMASK_REG    0x4000041CUL
#define NVM_PARAM_REG       0x41004008UL
#define NVM_STATUS_REG      0x41004018UL
#define NVM_ADDR_REG        0x4100401CUL
#define NVM_CTRLA_REG       0x41004000UL
#define NVM_CTRLB_REG       0x41004004UL

/* NVM Error mask value*/
#define NVM_ERRORS_MASK (NVMCTRL_STATUS_PROGE | NVMCTRL_STATUS_LOCKE | NVMCTRL_STATUS_NVME)

/* NVM page size*/
#define NVMCTRL_PAGESIZE       64U
#define NVMCTRL_ROWPAGES       4U
#define APBBMASK_NVMCTRL_Pos    2U
#define APBBMASK_NVMCTRL        ((0x1UL) << APBBMASK_NVMCTRL_Pos)

/* APBB Mask offset */
#define APBBMASK_OFFSET 0x1CUL

/*NVM Status Reg offset */
#define NVMCTRL_STATUS_OFFSET   0x18

/*STATUS MASK Register */
#define NVM_STATUS_MASK (0x011F)

/*NVM Int flag register*/
#define NVM_INTFLAG_REG         0x41004014UL
#define NVM_INTFLAG_READY_POS   0
#define NVM_INTFLAG_READY       ((0x1) << NVM_INTFLAG_READY_POS)

/*Power Reduction Mode during Sleep */
#define NVM_CTRLB_SLEEPPRM_POS  8
#define NVM_CTRLB_SLEEPPRM_MSK  ((0x3) << NVM_CTRLB_SLEEPPRM_POS)
#define NVM_CTRLB_SLEEPPRM(value) \
        (NVM_CTRLB_SLEEPPRM_MSK & ((value) << NVM_CTRLB_SLEEPPRM_POS))

/*NVM block enters low-power mode when entering sleep.NVM block exits low-power mode upon first access. */
#define NVM_CTRLB_SLEEPPRM_WAKEONACCESS_VAL (0x0)

/*NVMCTRL Manual Write */
#define NVM_CTRLB_MANW_POS  7
#define NVM_CTRLB_MANW      ((0x0) << NVM_CTRLB_MANW_POS)

/*NVMCTRL Cache Disable */
#define NVM_CTRLB_CACHEDIS_POS  18
#define NVM_CTRLB_CACHEDIS      ((0x0) << NVM_CTRLB_CACHEDIS_POS)

/* NVMCTRL Read Mode */
#define NVM_CTRLB_READMODE_POS  16
#define NVM_CTRLB_READMODE_MSK  ((0x3) << NVM_CTRLB_READMODE_POS)
#define NVM_CTRLB_READMODE(value) \
        (NVM_CTRLB_READMODE_MSK & ((value) << NVM_CTRLB_READMODE_POS))

/*NVMCTRL security Bit Status */
#define NVM_STATUS_SB_POS       8
#define NVM_STATUS_SB           ((0x1) << NVM_STATUS_SB_POS)
#define NVM_MANUAL_PAGEWRITE_EN 0x0

/*NVM Page Position */
#define NVM_PARAM_NVMP_POS  0
#define NVM_PARAM_NVMP_MSK  ((0xFFFF) << NVM_PARAM_NVMP_POS)

/*NVM Page Size */
#define NVM_PARAM_PSZ_POS       16
#define NVM_PARAM_PSZ_MSK       ((0x7) << NVM_PARAM_PSZ_POS)
#define NVM_CTRLA_CMD_ER_VAL    (0x2)
#define NVM_CTRLA_CMD_POS       0
#define NVM_CTRLA_CMD_ER        (NVM_CTRLA_CMD_ER_VAL << NVM_CTRLA_CMD_POS)

/*NVM Ctrl Command Execution */
#define NVM_CTRLA_CMDEX_POS 8

/*NVM CTRLA Command Execution Key */
#define NVM_CTRLA_CMDEX_KEY_VAL (0xA5)
#define NVM_CTRLA_CMDEX_KEY     (NVM_CTRLA_CMDEX_KEY_VAL << NVM_CTRLA_CMDEX_POS)

/*does not insert wait states on a cache miss. Gives the best system performance*/
#define NVM_CACHE_READMODE_NO_MISS_PENALTY  0x0

/*Reduces power consumption of the cache system, but inserts a wait state each time there is a cache miss */
#define NVM_CACHE_READMODE_LOW_POWER    0x1

/*The cache system ensures that a cache hit or miss takes the same amount of time, determined by the 
number of programmed flash wait states*/
#define NVM_CACHE_READMODE_DETERMINISTIC    0x2
#define NVM_SLEEP_POWER_MODE_WAKEONACCESS   0x0

/* NVM controller exits low-power mode when the device exits sleep mode */
#define NVM_SLEEP_POWER_MODE_WAKEUPINSTANT  0x1

/* Power reduction mode in the NVM controller disabled */
#define NVM_SLEEP_POWER_MODE_ALWAYS_AWAKE   0x3

/* Erases the addressed memory row */
#define NVM_COMMAND_ERASE_ROW   0x2

/* Write the contents of the page buffer to the addressed memory page */
#define NVM_COMMAND_WRITE_PAGE  0x4

/* Locks the addressed memory region, preventing further modifications
	 *  until the region is unlocked or the device is erased*/
#define NVM_COMMAND_LOCK_REGION 0x40

/* Unlocks the addressed memory region, allowing the region contents to be modified*/
#define NVM_COMMAND_UNLOCK_REGION   0x41

/* Clears the page buffer of the NVM controller, resetting the contents to all zero values */
#define NVM_COMMAND_PAGE_BUFFER_CLEAR   0x44

/* Sets the device security bit, disallowing the changing of lock bits and auxiliary row data until a 
    chip erase has been performed */
#define NVM_COMMAND_SET_SECURITY_BIT    0x45

/* Enter power reduction mode in the NVM controller to reduce the power consumption of the system */
#define NVM_COMMAND_ENTER_LOW_POWER_MODE    0x42

/* Exit power reduction mode in the NVM controller to allow other NVM commands to be issued*/
#define NVM_COMMAND_EXIT_LOW_POWER_MODE 0x43

/* Number of Wait states*/
#define NVM_WAIT_STATES 0x1

/*internal Pointer to the NVM MEMORY region start address */
#define NVM_MEMORY          ((volatile UINT16 *) FLASH_ADDR)
#define NVM_ERROR_NONE      0x0
#define NVM_FEATURE_DISBALE 0x00
#define NVM_FEATURE_ENABLE  0x01

/* NVM Error Status category*/
#define NVM_STATUS_CATEGORY_OK      0x00
#define NVM_STATUS_CATEGORY_COMMON  0x10

/* NVM status codes*/
#define NVM_STATUS_OK               (NVM_STATUS_CATEGORY_OK | 0x00)
#define NVM_STATUS_VALID_DATA       (NVM_STATUS_CATEGORY_OK | 0x01)
#define NVM_STATUS_NO_CHANGE        (NVM_STATUS_CATEGORY_OK | 0x02)
#define NVM_STATUS_ABORTED          (NVM_STATUS_CATEGORY_OK | 0x04)
#define NVM_STATUS_BUSY             (NVM_STATUS_CATEGORY_OK | 0x05)
#define NVM_STATUS_SUSPEND          (NVM_STATUS_CATEGORY_OK | 0x06)
#define NVM_STATUS_ERR_IO           (NVM_STATUS_CATEGORY_COMMON | 0x00)
#define NVM_STATUS_ERR_NO_MEMORY    (NVM_STATUS_CATEGORY_COMMON | 0x06)
#define NVM_STATUS_ERR_INVALID_ARG  (NVM_STATUS_CATEGORY_COMMON | 0x07)
#define NVM_STATUS_ERR_BAD_ADDRESS  (NVM_STATUS_CATEGORY_COMMON | 0x08)
#define NVM_STATUS_ERR_BAD_FORMAT   (NVM_STATUS_CATEGORY_COMMON | 0x0A)

/**************************************************************************************************

	Function:
	UINT8 NVM_Init (void)

	Summary:
		To Initialize the NVM configurations

	Description:
		

	Precondition:
		None.

	Parameters:
		None

	Return:
		Requset NVM Status.

	Remarks:
		None
**************************************************************************************************/
UINT8   NVM_Init(void); //__attribute__((section(".ARM.__at_0x00000B40")));

/**************************************************************************************************

	Function:
	UINT8 NVM_WriteBuffer(const UINT32 destination_address,const UINT8 *buffer,
                                 UINT16 length)

	Summary:
		To write to NVM memnory

	Description:
		This function used to write Input buffer content to NVM memory 

	Precondition:
		None.

	Parameters:
		NVM address to be written, buffer, length

	Return:
		Requset NVM Status.

	Remarks:
		None
**************************************************************************************************/
UINT8   NVM_WriteBuffer
        (
            const UINT32    u32destination_address,
            const UINT8     *pu8buffer,
            UINT16          u16length
        );  //__attribute__((section(".ARM.__at_0x00000Bc0")));

/**************************************************************************************************

	Function:
	UINT8 NVM_ReadBuffer(const UINT32 u32SourceAddress,UINT8 *const pu8buffer,UINT16 u16Length)

	Summary:
		To read to NVM memnory to buffer NVM Read function

	Description:
		To read to NVM memnory to buffer  for reading NVM memory contents

	Precondition:
		None.

	Parameters:
		Source Address, buffer, length

	Return:
		Requset NVM Status.

	Remarks:
		None
**************************************************************************************************/
UINT8   NVM_ReadBuffer
        (
            const UINT32    u32SourceAddress,
            UINT8 *const    pu8buffer,
            UINT16          u16Length
        );

/**************************************************************************************************

	Function:
	UINT8 NVM_UpdateBuffer(const UINT32 u32DestinationAddress,UINT8 *const pu8Buffer,
                                  UINT16 u16Offset,UINT16 u16Length)

	Summary:
		To update to NVM memnory to buffer for Emulated EEPROM feature

	Description:
		To update to NVM memnory to buffer for supporting Emulated EEPROM  functions

	Precondition:
		None.

	Parameters:
		Source Address, buffer, length

	Return:
		Requset NVM Status.

	Remarks:
		None
**************************************************************************************************/
UINT8   NVM_UpdateBuffer
        (
            const UINT32    u32DestinationAddress,
            UINT8 *const    pu8Buffer,
            UINT16          u16Offset,
            UINT16          u16Length
        );

/**************************************************************************************************

	Function:
	UINT8 NVM_EraseRow(const UINT32 row_address)

	Summary:
		To erase the complte row in NVM

	Description:
		erase the complete rom content(256 bytes) in NVM memory

	Precondition:
		None.

	Parameters:
		Row Address to be deleted

	Return:
		Requset NVM Status.

	Remarks:
		None
**************************************************************************************************/
UINT8   NVM_EraseRow(const UINT32 row_address); //__attribute__((section(".ARM.__at_0x00000A48")));

/**************************************************************************************************

	Function:
	UINT8 NVM_ExecuteCommand(UINT8 NVMCommand,const UINT32 address,
		const UINT32 parameter)

	Summary:
		To Execute NVM commands

	Description:
		it executes the NVM commands such as read write, erase, etc

	Precondition:
		None.

	Parameters:
		Commands to be executed, address and parameters

	Return:
		Requset NVM Status.

	Remarks:
		None
**************************************************************************************************/
UINT8   NVM_ExecuteCommand
        (
            UINT8           u32NVMCommand,
            const UINT32    u32Address,
            const UINT32    u32Parameter
        );  //__attribute__((section(".ARM.__at_0x00000AA0")));

/**************************************************************************************************

	Function:
	UINT8 NVM_ProgramMemory( UINT32 u32ProgAddr , UINT8 *puBuffer, UINT16 u16Length)

	Summary:
		To Program NVM Flash Memory 

	Description:
		it programs the NVM flash memory Page by page(64 bytes)

	Precondition:
		None.

	Parameters:
		NVM Address to be Written, buffer, length

	Return:
		Requset NVM Status.

	Remarks:
		None
**************************************************************************************************/
UINT8   NVM_ProgramMemory
        (
            UINT32  u32ProgAddr,
            UINT8   *puBuffer,
            UINT16  u16Length
        );  //__attribute__((section(".ARM.__at_0x00000C56")));

/**************************************************************************************************

	Function:
	UINT8 NVM_ReadMemory( UINT32 u32ProgAddr , UINT8 *puBuffer, UINT16 u16Length)

	Summary:
		To Read NVM Flash Memory 

	Description:
		it Reads the NVM flash memory Page by page(64 bytes)

	Precondition:
		None.

	Parameters:
		NVM Address to be Read, buffer, length

	Return:
		Requset NVM Status.

	Remarks:
		None
**************************************************************************************************/
UINT8   NVM_ReadMemory(UINT32 u32ProgAddr, UINT8 *puBuffer, UINT16 u16Length);  //__attribute__((section(".ARM.__at_0x00000DA0")));
#endif
