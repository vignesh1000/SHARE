
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include <Hermes_Interface.h>
//#include <validation.h>
#include <nvm.h>
#include <PDFWUpdate.h>
#include "Config_Globals.h"
#include "Internal_Globals.h"

static UINT8 gu8LatestRequest;
/******************************************************************************
 * Function:        Hermes_MemCpy (const void *pau8Data1, const void *pau8Data2, int len)
 * Input:           Source A Buffer, Source B buffer, legth of copy
 * Output:          void					
 * Overview:        copy the data pointed by source and destination pointers 				
 * Note:            
*****************************************************************************/
void *Hermes_MemCpy (void *pvDst,   /*Destination Buffer Pointer */
                     const void *pvSrc, /*Source Buffer Pointer */
                     UINT16 u16CopyLength)  /* Length of Copy */
{
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    /* Typecast src and dest addresses to (char *) */
    UINT8 *pu8Src = (UINT8 *) pvSrc;
    UINT8 *pu8Dst = (UINT8 *) pvDst;

    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
    UINT16 u16CopyIndex;
    /* Copy contents of src[] to dest[] */
    for (u16CopyIndex = 0; u16CopyIndex < u16CopyLength; u16CopyIndex++)
        pu8Dst[u16CopyIndex] = pu8Src[u16CopyIndex];

    return (void*)pvDst;
}

/******************************************************************************
 * Function:        Hermes_MemCmp (const void *pau8Data1, const void *pau8Data2, int len)
 * Input:           Source A Buffer, Source B buffer, legth of comparission
 * Output:          Logic high on unequality					
 * Overview:        Compares the data pointed by source and destination pointers 
                    and breaks on unequality.				
 * Note:            
 *****************************************************************************/
UINT8 Hermes_MemCmp (const void *pau8Data1, /* Pointer to Buffer 1 */
                     const void *pau8Data2, /* Pointer to Buffer 2 */
                     UINT16 u16CompareLen)  /* Comparission Length */
{

    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
    UINT16 u16CompIndex;
    UINT8 *pu8Obj1 = (UINT8 *) pau8Data1;
    UINT8 *pu8Obj2 = (UINT8 *) pau8Data2;
    UINT8 u8DifferenceValue = FALSE;
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    for (u16CompIndex = 0; u16CompIndex < u16CompareLen; u16CompIndex++)
    {
        if (pu8Obj1[u16CompIndex] != pu8Obj2[u16CompIndex])
            u8DifferenceValue = (pu8Obj1[u16CompIndex] - pu8Obj2[u16CompIndex]);
    }

    return u8DifferenceValue;
}

/******************************************************************************
 * Function:        Hermes_GetLength(UINT8 u8HighByte, UINT8 u8LowByte)
 * Input:           MSB byte of Data length, LSB Byte of Data length
 * Output:          Combined 16bits of length 					
 * Overview:        				
 * Note:            
 *****************************************************************************/
static UINT16 Hermes_GetLength (UINT8 u8HighByte,   /* MSB Byte of Data Length */
                                UINT8 u8LowByte)    /* LSB Byte of Data Length */
{
    /*Get Length from Hermes Buffer */
    return (((UINT16) ((UINT16) u8HighByte) << 8u) | ((UINT16) u8LowByte));
}

/******************************************************************************
 * Function:        Hermes_InterfaceInit(void)
 * Input:           None
 * Output:          None					
 * Overview:        This routine initilizes I2C module				
 * Note:            
 *****************************************************************************/
void Hermes_InterfaceInit (void)
{
    I2C_SlaveInit ();
    (void)NVM_Init ();
}

/******************************************************************************
 * Function:        Hermes_IfConnectionRequest(void)
 * Input:           None
 * Output:          UINT8 u8ReqStatus					
 * Overview:        This routine Checks I2C master transmission request from master				
 * Note:            
 *****************************************************************************/
UINT8 Hermes_IfConnectionRequest (void)
{
    /*~~~~~~~~~~~~~~~~~~~~~~~~ */
    UINT8 u8ReqStatus = FALSE;
    /*~~~~~~~~~~~~~~~~~~~~~~~~ */

    /*Check I2C master transmission request from master */
    u8ReqStatus = I2C_CheckI2CRequest ();

    return u8ReqStatus;
}

/******************************************************************************
 * Function:        Hermes_ProcessMasterRequest(void)
 * Input:           None
 * Output:          UINT8 u8ReqStatus					
 * Overview:        This routine process the request from master				
 * Note:            
 *****************************************************************************/
UINT8 Hermes_ProcessMasterPacket (void)
{
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~ */
    UINT8 u8HermesStatus = TRUE;
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    if ((REGW (I2C_SLAVE_STATUS) & I2C_SLAVE_STATUSDIR))
    {
        /* Read request from Hermes master */
        u8HermesStatus = Hermes_ProcessResponsePacket (gu8RequestType);

        //todo: john to fix this workaround
        gu8RequestType = HERMES_INVALID_REQUEST;
    }
    else
    {
        /* Write request from Hermes master */
        u8HermesStatus = Hermes_ProcessRequestPacket ();
    }

    return u8HermesStatus;
}

/******************************************************************************
 * Function:        Hermes_HandleDiscoveryReq(void)
 * Input:           None
 * Output:          void					
 * Overview:        This routine process the Discovery request from Hermes master				
 * Note:            
 *****************************************************************************/
UINT8 Hermes_HandleDiscoveryReq (void)
{
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
    UINT8 u8HRespCode = HERMES_HRESP_OK;
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
    
    return u8HRespCode;
}

/******************************************************************************
 * Function:        Hermes_HandleDiscoveryResp(void)
 * Input:           None
 * Output:          void					
 * Overview:        This routine process the Discovery response from Hermes master				
 * Note:            
 *****************************************************************************/
UINT16 Hermes_HandleDiscoveryResp (void)
{
    /*~~~~~~~~~~~~~~~~~ */
    UINT16 u16Index = 1;
    /*~~~~~~~~~~~~~~~~~ */

    /*Hermes Major Revision */
    gu8HermesResBuffer[u16Index++] = HERMES_MAJOR_REV;

    /*Hermes Minor Revision */
    gu8HermesResBuffer[u16Index++] = HERMES_MINOR_REV;

    /*Hermes PD System Firmware Major Revision */
    gu8HermesResBuffer[u16Index++] = (HERMES_PD_SYS_FW_REV >> 8);

    /*Hermes PD System Firmware Minor Revision */
    gu8HermesResBuffer[u16Index++] = (HERMES_PD_SYS_FW_REV & 0xff);

    /*Hermes PD System HW Major Revision */
    gu8HermesResBuffer[u16Index++] = (HERMES_PD_SYS_HW_REV >> 8);

    /*Hermes PD System HW Minor Revision */
    gu8HermesResBuffer[u16Index++] = (HERMES_PD_SYS_HW_REV & 0xff);

    /*Hermes- v0.33 User Flags */
    gu8HermesResBuffer[u16Index++] = 0x00;
    gu8HermesResBuffer[u16Index++] = gu8CurrentMemory;

    gu8HermesResBuffer[u16Index++] = HERMES_NUM_OF_CONN_SUPPORTED;

    /* Connection Information block about PDFW_UPDATE */

    /*Index 0 represents Connection_ID */
    gu8HermesResBuffer[u16Index++] = HERMES_CONN_ID_PD_FW_UPDATE;

    /*Index 1 represents Number of bytes following CIB_Length Field */
    gu8HermesResBuffer[u16Index++] = HERMES_NUM_OF_BYTES_CIB_LENGTH;

    /*Protocol ID */
    gu8HermesResBuffer[u16Index++] = HERMES_PROT_PDFWU;

    /*Buffer Size */
    gu8HermesResBuffer[u16Index++] = HERMES_CONN_INFO_BUF_SIZE_256;

    /*Connection Information block about DEBUG */

    /*Index 0 represents Connection_ID */
    gu8HermesResBuffer[u16Index++] = HERMES_CONN_ID_DEBUG;

    /*Index 1 represents Number of bytes following CIB_Length Field */
    gu8HermesResBuffer[u16Index++] = HERMES_NUM_OF_BYTES_CIB_LENGTH;

    /*Protocol ID */
    gu8HermesResBuffer[u16Index++] = HERMES_PROT_PROT_DEBUG;

    /*Buffer Size */
    gu8HermesResBuffer[u16Index] = HERMES_CONN_INFO_BUF_SIZE_256;

    /*Update Byte Count */
    gu8HermesResBuffer[0] = (UINT8)u16Index;

    return u16Index;
}

/******************************************************************************
 * Function:        Hermes_ProcessRequestPacket(void)
 * Input:           None
 * Output:          UINT8 u8ReqStatus					
 * Overview:        This routine process hermes master request packet				
 * Note:            
 *****************************************************************************/
UINT8 Hermes_ProcessRequestPacket (void)
{
    /*~~~~~~~~~~~~~~~~~~~~~ */
    UINT8 u8Status;
    /*~~~~~~~~~~~~~~~~~~~~~ */

    u8Status = I2C_SlaveRead (gu8HermesReqBuffer);

    if (FALSE != u8Status)
    {
        if (HERMES_MIN_REQUEST_LENGTH > gu16Rxcount)
        {
            gu8RequestType = HERMES_INVALID_REQUEST;
            gu8ConnectionID = HERMES_CONN_ID_INVALID;
        }
        else
        {
            gu8RequestType = gu8HermesReqBuffer[HERMES_BUFFER_RQTYP_IDX];
            gu8ConnectionID = gu8HermesReqBuffer[HERMES_BUFFER_CNID_IDX];
        }

        switch (gu8RequestType & UPD_VALIDATION_MASK)
        {
            case HERMES_DISCOVERY_REQUEST:
            {
                /*Process Discovery request */
                gu8LatestRequest = HERMES_DISCOVERY_REQUEST;
                (void) Hermes_HandleDiscoveryReq ();
                break;
            }
#if VALIDATION ==1
            case UPD_SYSTEM_RESET_REQUEST:
            {
                /* process System reset  */
                __DSB ();   /* Ensure all outstanding memory accesses included
                             * buffered write are completed before reset */
                SCB->AIRCR =
                    ((0x5FAUL << SCB_AIRCR_VECTKEY_Pos) |
                     SCB_AIRCR_SYSRESETREQ_Msk);
                __DSB ();   /* Ensure completion of memory access */
                for (;;)    /* wait until reset */
                {
                    __NOP ();
                }
            
                break;
            }
#endif
            case HERMES_CONNECTION_REQUEST:
            {
                gu8LatestRequest = HERMES_CONNECTION_REQUEST;
                /*Process Connection request */
                break;
            }

            case HERMES_CONFIGURATION_REQUEST:
            {
                /*Process Configuration request */
                break;
            }

            case HERMES_PROTOCOL_TX_REQUEST:
            {
                /*Process Protocol Tx request */
                (void) Hermes_HandleProtocolTxReq ();
                break;
            }

            case HERMES_DISCONNECT_REQUEST:
            {
                gu8LatestRequest = HERMES_DISCONNECT_REQUEST;
                /*Process Disconnectrequest */
                break;
            }

#if VALIDATION ==1

            case UPD_VALIDATION_REQUEST:
            {
                /* process Validation Request */
                (void) Validation_ProcessHermesRequest
                    (gu8ConnectionID, gu8RequestType, pu8HermesReqBuffer);
                break;
            }
#endif
            default:
                break;
        }
    }

    return u8Status;
}

/******************************************************************************
 * Function:        Hermes_ProcessDebugRequestPacket(void)
 * Input:           UINT8   u8RequestType - IP : Hermes Message Request Type           
 * Output:          UINT8 u8RetStatus	Status of the Response Transmission.				
 * Overview:        This routine process hermes master Response packets				
 * Note:            
 *****************************************************************************/
UINT8 Hermes_ProcessResponsePacket (UINT8 u8RequestType)    /* Hermes Message Request Type */
{
    /*~~~~~~~~~~~~~~~~~~~~~ */
    UINT16 u16Length = 0u;
    UINT8 u8Status = FALSE;
    /*~~~~~~~~~~~~~~~~~~~~~ */

    switch (u8RequestType & UPD_VALIDATION_MASK)
    {
        case HERMES_DISCOVERY_RESPONSE:
        {
            if (HERMES_DISCOVERY_REQUEST==gu8LatestRequest)
            {
                //Process Discovery request
                u16Length = Hermes_HandleDiscoveryResp ();
                u8Status = I2C_SlaveWrite (gu8HermesResBuffer, u16Length);
                
            }
            else
            {
                gu8HResponseCode = HERMES_HRESP_INVALID;
                /*Send zero length I2C packet, otherwise I2CMaster may hang */
                u8Status = I2C_SlaveWrite
                    (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);                  
            }
            gu8LatestRequest = HERMES_INVALID_REQUEST;

            break;
        }

        case HERMES_PROTOCOL_TX_RESPONSE:
        case HERMES_PROTOCOL_RX_RESPONSE:
        {
            /*gu8HResponseCode is last error occurred in I2C transaction */
            u8Status = I2C_SlaveWrite
                (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);
            break;
        }

        case HERMES_PROTOCOL_RX_REQUEST:
        {
            /*Process Protocol Rx request */
            u16Length = Hermes_GetLength
                (gu8HermesResBuffer[HERMES_HIGH_BYTE_INDEX],
                 gu8HermesResBuffer[HERMES_LOW_BYTE_INDEX]);
            if (u16Length != 0)
            {
                u8Status = I2C_SlaveWrite
                    (&gu8HermesResBuffer[0],
                     (u16Length + HERMES_LENGTH_BYTE_COUNT));

                /*Check return value whether true or false */
                if (u8Status)
                {
                    /*Everything is okay, set error code as OK */
                    gu8HResponseCode = HERMES_HRESP_OK;
                }
                else
                {
                    /*I2C write was failed, set error code as OK */
                    gu8HResponseCode = HERMES_HRESP_INVALID;
                }
            }
            else
            {
                /*Send zero length I2C packet, otherwise I2CMaster may hang */
                u8Status = I2C_SlaveWrite
                    (&gu8HermesResBuffer[0],
                     (u16Length + HERMES_LENGTH_BYTE_COUNT));

                /*Nothing matched the request ID, Hence set the error code as invalid */
                gu8HResponseCode = HERMES_HRESP_NO_ACTION;
            }

            /*Process completed, Invalidate the length here */
            gu8HermesResBuffer[HERMES_HIGH_BYTE_INDEX] = 0;
            gu8HermesResBuffer[HERMES_LOW_BYTE_INDEX] = 0;
            break;
        }
        case HERMES_CONNECTION_RESPONSE:
        {
            if(HERMES_CONNECTION_REQUEST==gu8LatestRequest)
            {
                if ((gu8ConnectionID == HERMES_CONN_ID_PD_FW_UPDATE) || (gu8ConnectionID == HERMES_CONN_ID_DEBUG))
                { /** If the connection request is given to available channel*/         
                    gu8HResponseCode = HERMES_HRESP_OK;
                }
                else
                {/** If the connection request is given to unavailable channel*/ 
                    gu8HResponseCode = HERMES_HRESP_INVALID;
                }
                /*Send zero length I2C packet, otherwise I2CMaster may hang */
                u8Status = I2C_SlaveWrite
                    (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);
            }
            else
            {
                gu8HResponseCode = HERMES_HRESP_INVALID;
                /*Send zero length I2C packet, otherwise I2CMaster may hang */
                u8Status = I2C_SlaveWrite
                    (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);                  
            } 
            gu8LatestRequest = HERMES_INVALID_REQUEST;            
            break;
        }

        case HERMES_DISCONNECT_RESPONSE:
        {
            if(HERMES_DISCONNECT_REQUEST==gu8LatestRequest)
            {
                gu8HResponseCode = HERMES_HRESP_OK;
                /*Send zero length I2C packet, otherwise I2CMaster may hang */
                u8Status = I2C_SlaveWrite
                    (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);
            }
            else
            {
                gu8HResponseCode = HERMES_HRESP_INVALID;
                /*Send zero length I2C packet, otherwise I2CMaster may hang */
                u8Status = I2C_SlaveWrite
                    (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);                  
            }
            gu8LatestRequest = HERMES_INVALID_REQUEST;
            break;            
            
        }
        
        default:
        {
            /**
              
              HERMES_DISCONNECT_RESPONSE
              HERMES_CONFIGURATION_RESPONSE
            */
            gu8HResponseCode = HERMES_HRESP_INVALID;
            /*Send zero length I2C packet, otherwise I2CMaster may hang */
            u8Status = I2C_SlaveWrite
                (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);
            gu8LatestRequest = HERMES_INVALID_REQUEST;                
            break;
        }

#if VALIDATION ==1

        case UPD_VALIDATION_RESPONSE:
        {
            u16Length = Validation_ProcessHermesResponse
                (gu8ConnectionID, u8RequestType, gu8HermesResBuffer);
            u8Status = I2C_SlaveWrite (gu8HermesResBuffer, u16Length);
            break;
        }
#endif
    }

    return u8Status;
}

/******************************************************************************
 * Function:        Hermes_ProcessDebugRequestPacket(void)
 * Input:           UINT8   *u8RequestBuffer,    IP - Pointer to Hermes Request Buffer 
 *                  UINT16  u16RequestLength,    IP - Length of the Hermes request
 *                  UINT8   *u8ResponseBuffer,   IP - Pointer to Hermes Response Buffer
 *                  UINT16  *u16ResponseLength)  OP - Length of the Response           
 * Output:          UINT8 u8RetStatus	Status of the Debug Request.				
 * Overview:        This routine process hermes master Debug requests packet				
 * Note:            
 *****************************************************************************/
UINT8 Hermes_ProcessDebugRequestPacket (UINT8 * u8RequestBuffer,    /* IP - Pointer to Hermes Request Buffer */
                                        UINT16 u16RequestLength,    /* IP - Length of the Hermes request */
                                        UINT8 * u8ResponseBuffer,   /* IP - Pointer to Hermes Response Buffer */
                                        UINT16 * u16ResponseLength) /* OP - Length of the Response */
{

    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
    UINT8 u8Status = HERMES_HRESP_INVALID;
    MEMORY_RW_HEADER stMemReadWrite;
    UINT32 u32MemAddr;

    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    (void) Hermes_MemCpy
        ((UINT8 *) & stMemReadWrite,
         &u8RequestBuffer[2], sizeof (MEMORY_RW_HEADER));

    u32MemAddr = stMemReadWrite.u32MemoryAddr;

    /*u8RequestBuffer[0] & [1] is reserved for length */
    switch (stMemReadWrite.u8CMD)
    {
        case HERMES_COMMAND_SET_FEATURE:
            if(u8RequestBuffer[7] == HERMES_SET_FEATURE_RESET_CMD)
            {
                __DSB();   /* Ensure all outstanding memory accesses included
                              buffered write are completed before reset */
                /*SCB->AIRCR  = ((0x5FAUL << SCB_AIRCR_VECTKEY_Pos) |
                SCB_AIRCR_SYSRESETREQ_Msk);*/

                *((volatile UINT32*)(0xe000ed0c)) = 0x5fa0004;


                __DSB();                                                          /* Ensure completion of memory access */

                for(;;)                                                           /* wait until reset */
                {
                    __NOP();
                }
            }
        break;      
        case HERMES_COMMAND_MEM_WRITE:
        {
            if (u32MemAddr <= 0x0000FFFF)
            {
                (void) NVM_ProgramMemory
                    (u32MemAddr,
                     &u8RequestBuffer[9], stMemReadWrite.u16DataLength);
            }
            else
            {
                //TODO: Valid Address check must be done
                (void) Hermes_MemCpy
                    ((UINT8 *) u32MemAddr,
                     &u8RequestBuffer[9u], stMemReadWrite.u16DataLength);
            }

            *u16ResponseLength = 0u;

            /*Set the status as OK */
            u8Status = HERMES_HRESP_OK;
            break;
        }

        case HERMES_COMMAND_MEM_READ:
        {
            if (u32MemAddr <= 0x0000FFFF)
            {
                /*Read NVM Flash with same address and length */
                (void) NVM_ReadMemory
                    (u32MemAddr,
                     &u8ResponseBuffer[sizeof (MEMORY_RW_HEADER) + 2],
                     stMemReadWrite.u16DataLength);
            }
            else
            {
                (void) Hermes_MemCpy
                    (&u8ResponseBuffer[sizeof (MEMORY_RW_HEADER) + 2],
                     (UINT8 *) u32MemAddr, stMemReadWrite.u16DataLength);
            }

            /*Fill the response buffer */
            (void) Hermes_MemCpy
                (&u8ResponseBuffer[2],
                 (UINT8 *) & stMemReadWrite, sizeof (MEMORY_RW_HEADER));
            *u16ResponseLength = sizeof (MEMORY_RW_HEADER) +
                2 + stMemReadWrite.u16DataLength;

            /*Set the status as OK */
            u8Status = HERMES_HRESP_OK;
            break;
        }

        default:
        {
            break;
        }
    }

    return u8Status;
}

/******************************************************************************
 * Function:        Hermes_HandleProtocolTxReq(void)
 * Input:           None
 * Output:          UINT8 u8ReqStatus					
 * Overview:        This routine process hermes Protocol Tx Request				
 * Note:            
 *****************************************************************************/
void Hermes_HandleProtocolTxReq (void)
{
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    UINT16 u16ReqLength = 0;
    UINT16 u16ResponseLength = 0;

    /*~~~~~~~~~~~~~~~~~~~~~~~~~~ */

    /*Get Length from Hermes Buffer */
    u16ReqLength = Hermes_GetLength
        (gu8HermesReqBuffer[HERMES_BUFFER_SIZEMSB_IDX],
         gu8HermesReqBuffer[HERMES_BUFFER_SIZELSB_IDX]);

    /*Check requested connection ID to check protocol ID */
    if (gu8ConnectionID == HERMES_CONN_ID_PD_FW_UPDATE)
    {
        /*For Request & Response buffer: Ignore length indexes and process from index 2 and so 
         * length would be length - 2 */
        gu8HResponseCode = PDFW_ProcessRequestPacket
            (&gu8HermesReqBuffer[HERMES_BUFFER_SIZEMSB_IDX],
             u16ReqLength,
             &gu8HermesResBuffer[HERMES_DATA_PAYLOAD_START_INDEX],
             &u16ResponseLength);
    }
    else if (gu8ConnectionID == HERMES_CONN_ID_DEBUG)
    {
        gu8HResponseCode = Hermes_ProcessDebugRequestPacket
            (&gu8HermesReqBuffer[HERMES_BUFFER_SIZEMSB_IDX],
             u16ReqLength,
             &gu8HermesResBuffer[HERMES_DATA_PAYLOAD_START_INDEX],
             &u16ResponseLength);
    }

    /*Add Else if cases for other connections */
    else
    {
        /*Fill zeroes in response buffer length */
        gu8HermesResBuffer[HERMES_HIGH_BYTE_INDEX] = 0;
        gu8HermesResBuffer[HERMES_LOW_BYTE_INDEX] = 0;

        /*Nothing matched the request ID, Hence set the error code as invalid */
        gu8HResponseCode = HERMES_HRESP_INVALID;
    }

    if (u16ResponseLength != 0)
    {
        /*Assign Length MSB and LSB */
        gu8HermesResBuffer[HERMES_HIGH_BYTE_INDEX] =
            (UINT8) (u16ResponseLength >> 8);
        gu8HermesResBuffer[HERMES_LOW_BYTE_INDEX] = u16ResponseLength & 0xff;
    }
}
