
/**
 * \file
 *
 * \brief SPI related functionality declaration.
 *
 * Copyright (C) 2016 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

#ifndef _SPI_H_INCLUDED
#define _SPI_H_INCLUDED

#include <compiler.h>
#include <stdbool.h>
#include <stdinc.h>
#include <atmel_start_pins.h>

/**
 * \addtogroup SPI driver
 *
 * \section spi_rev Revision History
 * - v0.0.0.1 Initial Commit
 *
 *@{
 */

#ifdef __cplusplus
extern "C" {
#endif

typedef enum SPI_interrupts {
	SPI_INTERRUPT_RXC,
	SPI_INTERRUPT_TXC,
	SPI_INTERRUPT_DRE,
	SPI_INTERRUPT_SST,
	SPI_INTERRUPT_NONBUFFER_IE
} SPI_INTERRUPT_t;

typedef enum SPI_dord { SPI_DATAORDER_MSB, SPI_DATAORDER_LSB } SPI_DORD_t;

/**
 * \brief Initialize spi interface
 * \return Initialization status
 */
int8_t SPI_0_init(void);

#ifdef __cplusplus
}
#endif

#endif /* _SPI_H_INCLUDED */


void HW_SPI_Write_Txr (UINT8 *u8data, UINT16 u16length);
void HW_SPI_Read_Txr (UINT8 *u8readData, UINT16 u16readLength);
void SPI_0_initialization(void);

