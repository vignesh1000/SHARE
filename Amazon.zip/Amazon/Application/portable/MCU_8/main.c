#include <compiler.h>
//#include <clock_config.h>
#include <port.h>
#include <atmel_start_pins.h>
#include <system.h>
#include <clkctrl.h>
#include <spi.h>
#include <stdinc.h>


ISR(PORTB_PORT_vect)
{
    //ACK ATTINY Interrupt
    PORTB.INTFLAGS = PORTB.INTFLAGS;
     
    Interrupt_UPDAlertHandler (0);
  
}
void setup_interrupt(void)
{
	PORTB_PIN0CTRL = 0x0B; // Enable low level interrupt on PB0 low(button 1)
}

ISR(TCA0_OVF_vect)
{
  TCA0.SINGLE.INTFLAGS = 0x01;
  PDTimer_InterruptHandler();
}


void UPDInterrupt_Init()
{
    PORTB_PIN0CTRL = 0x08;
    PORTB_set_pin_dir(0, PORT_DIR_IN);
    
    setup_interrupt();
}
void main()
{
    // Mcu intialisation
    mcu_init();
    
    CLKCTRL_init();
    
    PD_Init();
    
    PD_Run();

}