
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include <spi.h>
#include <tca.h>

/******************CONFIGURATION PARAMETERS**********************************/

/******************MCU FIRMWARE CONFIGURATION*****************************************/
/*Struture packing to align the bytes in data memory based on the compiler*/
/* E,g: #define STRUCT_PACKED_START   __attribute__((__packed__)) */
#define CONFIG_STRUCT_PACKED_START

/*Struture packing to align the bytes in data memory based on the compiler*/
#define CONFIG_STRUCT_PACKED_END

/*ENDIANESS*/
#define CONFIG_BIG_ENDIAN				0

/**********************Hook Configuration************************************/
#define CONFIG_HOOK_POLICY_ENGINE_PRE_PROCESS 			0

#define CONFIG_HOOK_POLICY_ENGINE_POST_PROCESS 			0

#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS 	0

#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_POST_PROCESS 	0

#define CONFIG_HOOK_TYPE_C_MANANGEMENT_PRE_PROCESS		0

#define CONFIG_HOOK_TYPE_C_MANANGEMENT_POST_PROCESS		0

#define CONFIG_HOOK_UPD_TX_MSG_PRE_PROCESS				0

#define CONFIG_HOOK_UPD_TX_MSG_POST_PROCESS				0

#define CONFIG_HOOK_UPD_RX_MSG_PRE_PROCESS				0

#define CONFIG_HOOK_UPD_RX_MSG_POST_PROCESS				0

#define CONFIG_HOOK_UPD_ALERT_ISR_ALL_PORT				0

/***************** DEBUG MESSAGES ****************************************************/

#define CONFIG_HOOK_DEBUG_MSG 							0

#if CONFIG_HOOK_DEBUG_MSG
	#define HOOK_INIT_DEBUG()				HookInitDebug()
	#define HOOK_DEBUG_STRING(_str_)		HookDebugString(_str_)
	#define HOOK_DEBUG_CHAR(_char_)			HookDebugChar(_char_)
	#define HOOK_DEBUG_UINT8(_byVal_)		HookDebugUint8(_byVal_)
	#define HOOK_DEBUG_UINT16(_wVal_)		HookDebugUint16(_wVal_)
	#define HOOK_DEBUG_UINT32(_dwVal_)		HookDebugUint32(_dwVal_)
#else
	#define HOOK_INIT_DEBUG()				
	#define HOOK_DEBUG_STRING(_str_)		
	#define HOOK_DEBUG_CHAR(_char_)			
	#define HOOK_DEBUG_BYTE(_byVal_)		
	#define HOOK_DEBUG_WORD(_wVal_)			
	#define HOOK_DEBUG_DWORD(_dwVal_)		
#endif


/***********************Timer************************************************/


/*Frequency of interrupt from PD MCU Timer */
/* Eg:# define CONFIG_PDTIMER_INTERRUPT_RATE 1000  , 1000 interrupts per seconnd, with interrupt interval of 1ms */
#define CONFIG_PDTIMER_INTERRUPT_RATE	1000  

/*Data Type of the Timeout variable in PD Software Timer*/
/* Eg: #define CONFIG_16_BIT_PDTIMEOUT 1 , will make timeout variable unsigned 16bit */
#define CONFIG_16_BIT_PDTIMEOUT

/* Number of ports that are going to be handled by the PD stack */
#define CONFIG_PD_PORT_COUNT			4
#define NUM_OF_PDO_COUNT                2


/* Port0 PDO0 description*/
#define SRC_PORT0_PDO0_Volt_Watt 5
#define SRC_PORT0_PDO0_Curr  3
#define SRC_PORT0_PDO0_Type  0
/* Port0 PDO1 description*/
#define SRC_PORT0_PDO1_Volt_Watt 12
#define SRC_PORT0_PDO1_Curr  3
#define SRC_PORT0_PDO1_Type  0

/* Port1 PDO description*/
#define SRC_PORT1_PDO0_Volt_Watt 5
#define SRC_PORT1_PDO0_Curr  3
#define SRC_PORT1_PDO0_Type  0
/* Port1 PD1 description*/
#define SRC_PORT1_PDO1_Volt_Watt 12
#define SRC_PORT1_PDO1_Curr  3
#define SRC_PORT1_PDO1_Type  0

/* Port2 PDO description*/
#define SRC_PORT2_PDO0_Volt_Watt 5
#define SRC_PORT2_PDO0_Curr  3
#define SRC_PORT2_PDO0_Type  0
/* Port2 PD1 description*/
#define SRC_PORT2_PDO1_Volt_Watt 12
#define SRC_PORT2_PDO1_Curr  3 
#define SRC_PORT2_PDO1_Type  0

/* Port3 PDO description*/
#define SRC_PORT3_PDO0_Volt_Watt 5
#define SRC_PORT3_PDO0_Curr  3
#define SRC_PORT3_PDO0_Type  0
/* Port3 PD1 description*/
#define SRC_PORT3_PDO1_Volt_Watt 12
#define SRC_PORT3_PDO1_Curr  3
#define SRC_PORT3_PDO1_Type  0

/* Port4 PDO description*/
#define SRC_PORT4_PDO0_Volt_Watt 5
#define SRC_PORT4_PDO0_Curr  3
#define SRC_PORT4_PDO0_Type  0
/* Port4 PD1 description*/
#define SRC_PORT4_PDO1_Volt_Watt 12
#define SRC_PORT4_PDO1_Curr  3
#define SRC_PORT4_PDO1_Type  0




/*****************INCLUDE/EXCLUDE AT COMPILE TIME*****************************/
/*Following flags are applicable for all CONFIG_PD_PORT_COUNT*/
/*If any of the port from CONFIG_PD_PORT_COUNT requires following features then enable it to 
handle in the code otherwise disable it to exclude the part of the code for the corresponding feature*/

/* Support for USB PD alternate mode */
#define INCLUDE_PD_ALT_MODE		0

/* Define if this board can act as a dual-role PD port (source and sink) */
#define INCLUDE_PD_DUAL_ROLE	0

/* Support of Fast Role Swap */
#define INCLUDE_PD_FRS			0

/*Support for electronically marked cable */
#define INCLUDE_PD_E_MARKER		0

/* Support for PD specification 3.0 otherwise PD 2.0 specification will be followed */
#define INCLUDE_PD_3_0			0

/* tCC Debounce to read match register */
#define TYPEC_TCCDEBOUNCE_TIMEOUT			150
#define TYPEC_TPDEBOUNCE_TIMEOUT			10
#define TYPEC_VBUSDEBOUNCE_TIMEOUT			10

/*********************** Functions to be defined by User**************************************/

/*Initialization function of PD Hardware Timer*/
#define HW_PDTIMER_INIT()				TIMER_0_init()       


/*Initialization function for configuration of External UPD Interrupts*/
#define UPDINTERRUPT_INIT()			UPDInterrupt_Init()

/* VBUS drive function for set voltage in VBUS */
#define VBUS_DRIVE_VOLTAGE(PortNum, VBUS_Volatge)	VBUS_Drive(PortNum, VBUS_Volatge)
/******************MCU INTERRUPT CONFIGURATION*****************************************/

/*Disable Global Interrupts,E,g: #define  DISABLE_GLOBAL_INTERRUPT   {(GIE)=0;}*/
#define DISABLE_GLOBAL_INTERRUPT()        cpu_irq_disable()

/*Enable Global Interrupts,E,g: #define  ENABLE_GLOBAL_INTERRUPT   {(GIE)=1;}*/
#define ENABLE_GLOBAL_INTERRUPT()        cpu_irq_enable()


/******************SPI INTERFACE CONFIGURATION*****************************************/
#define HW_SPI_INIT()                                                   SPI_0_initialization();
#define HW_SPI_CS_LOW(SPI_INSTANCE)                                     PA4_set_level(false)
#define HW_SPI_CS_HIGH(SPI_INSTANCE)                                    PA4_set_level(true)
#define HW_SPI_WRITE_TRANSFER(_write_buf_,_write_len)                   HW_SPI_Write_Txr(_write_buf_,_write_len) 
#define HW_SPI_READ_TRANSFER(_read_buf_, _read_len)                     HW_SPI_Read_Txr(_read_buf_, _read_len)
