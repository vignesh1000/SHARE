
/**
 * \file
 *
 * \brief SPI related functionality implementation.
 *
 * Copyright (C) 2016 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

#include <spi.h>
#include <atmel_start_pins.h>
#include <usart_basic.h>

/**
 * \brief Initialize spi interface
 */
int8_t SPI_0_init()
{
	SPI0.CTRLA = 1 << SPI_CLK2X_bp    /* Enable Double Speed: enabled */
	             | 0 << SPI_DORD_bp   /* Data Order Setting: disabled */
	             | 1 << SPI_ENABLE_bp /* Enable Module: enabled */
	             | 1 << SPI_MASTER_bp /* SPI module in master mode */
	             | SPI_PRESC_DIV4_gc; /* System Clock / 4 */

	SPI0.CTRLB = 0 << SPI_BUFEN_bp   /* Buffer Mode Enable: disabled */
	             | 1 << SPI_BUFWR_bp /* Buffer Write Mode: disabled */
	             | SPI_MODE_0_gc     /* SPI Mode 0 */
	             | 1 << SPI_SSD_bp;  /* Slave Select Disable: enabled */

	// SPI0.INTCTRL = 0 << SPI_DREIE_bp /* Data Register Empty Interrupt Enable: disabled */
	//		 | 0 << SPI_IE_bp /* Interrupt Enable: disabled */
	//		 | 0 << SPI_RXCIE_bp /* Receive Complete Interrupt Enable: disabled */
	//		 | 0 << SPI_SSIE_bp /* Slave Select Trigger Interrupt Enable: disabled */
	//		 | 0 << SPI_TXCIE_bp; /* Transfer Complete Interrupt Enable: disabled */

	return 0;
}
/* configure the pins and initialize the registers */
void HookInitDebug(void)
{

	// Set pin direction to input
	PB3_set_dir(PORT_DIR_IN);

	PB3_set_pull_mode(
	    // <y> Pull configuration
	    // <id> pad_pull_config
	    // <PORT_PULL_OFF"> Off
	    // <PORT_PULL_UP"> Pull-up
	    PORT_PULL_OFF);

	// Set pin direction to output
	PB2_set_dir(PORT_DIR_OUT);

	PB2_set_level(
	    // <y> Initial level
	    // <id> pad_initial_level
	    // <false"> Low
	    // <true"> High
	    false);

	USART_0_init();
}
/* configure the pins and initialize the registers */
void SPI_0_initialization(void)
{

	// Set pin direction to input
	PA2_set_dir(PORT_DIR_IN);

	PA2_set_pull_mode(
	    // <y> Pull configuration
	    // <id> pad_pull_config
	    // <PORT_PULL_OFF"> Off
	    // <PORT_PULL_UP"> Pull-up
	    PORT_PULL_OFF);

	// Set pin direction to output
	PA1_set_dir(PORT_DIR_OUT);

	PA1_set_level(
	    // <y> Initial level
	    // <id> pad_initial_level
	    // <false"> Low
	    // <true"> High
	    false);

	// Set pin direction to output
	PA3_set_dir(PORT_DIR_OUT);

	PA3_set_level(
	    // <y> Initial level
	    // <id> pad_initial_level
	    // <false"> Low
	    // <true"> High
	    false);

	// Set pin direction to output
	PA4_set_dir(PORT_DIR_OUT);

	//PA4_set_level(
	    // <y> Initial level
	    // <id> pad_initial_level
	    // <false"> Low
	    // <true"> High
	  //  false);
        PA4_set_level(
	    // <y> Initial level
	    // <id> pad_initial_level
	    // <false"> Low
	    // <true"> High
	    true);

	SPI_0_init();
}

void HW_SPI_Write_Txr ( UINT8 *u8data, UINT16 u16length)
{
      
      for (UINT16 count = 0; count <  u16length; count++)
      {
          SPI0.INTFLAGS = SPI0_INTFLAGS;


          SPI0.DATA = u8data[count];
       
          // Wait for transfer to complete
          while ((SPI0.INTFLAGS & SPI_RXCIF_bm) == 0) {
          }
      }
      
}

void HW_SPI_Read_Txr ( UINT8 *u8readData, UINT16 u16readLength)
{
        
      for (UINT16 count = 0; count <  u16readLength; count++)
      {
          SPI0.INTFLAGS = SPI0_INTFLAGS;
                 
          SPI0.DATA = 0xff;
       
          // Wait for transfer to complete
          while ((SPI0.INTFLAGS & SPI_RXCIF_bm) == 0) {
          }
          
          u8readData[count] = SPI0.DATA;
      }
     
}

