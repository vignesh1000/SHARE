#ifndef _VALIDATION_H_
#define _VALIDATION_H_

#include <stdinc.h>
#include <typeC_controlVal.h>
#include <protocol_layerVal.h>
#include <GPIO_Val.h>
#include <I2C_Val.h>
#include <NVM_Val.h>
#include <SPI_Val.h>
#include <UART_Val.h>

#define TYPEC_API_VALIDATION_REQUEST                        0x80
#define TYPEC_SM_VALIDATION_REQUEST                         0x84
#define TYPEC_API_VALIDATION_RESPONSE                       0x83
#define TYPEC_SM_VALIDATION_RESPONSE                        0x85

#define PRL_VALIDATION_TX_REQUEST						0x90
#define PRL_VALIDATION_TX_RESPONSE						0x91
#define PRL_VALIDATION_RX_REQUEST						0x92
#define PRL_VALIDATION_RX_RESPONSE						0x93

#define SPI_VALIDATION_TX_RESPONSE						0xB0
#define SPI_VALIDATION_TX_REQUEST						0xB0
#define SPI_VALIDATION_RX_REQUEST						0xC0
#define SPI_VALIDATION_RX_RESPONSE						0xC0

#define I2C_VALIDATION_TX_RESPONSE						0xD0
#define I2C_VALIDATION_TX_REQUEST						0xD0
#define I2C_VALIDATION_RX_REQUEST						0xE0
#define I2C_VALIDATION_RX_RESPONSE						0xE0

#define GPIO_VALIDATION_TX_REQUEST						0xF0

#define UART_VALIDATION_REQUEST							0x81
#define UART_VALIDATION_RESPONSE						0x82

#define PDFU_VALIDATION_TX_RESPONSE						0xA2
#define PDFU_VALIDATION_TX_REQUEST					    0xA3

#define PDFU_VALIDATION_RX_RESPONSE						0xA4
#define PDFU_VALIDATION_RX_REQUEST					    0xA5

void Validation_ProcessHermesRequest(UINT8* pu8HermesReqBuffer);
UINT16 Validation_ProcessHermesResponse(UINT8* pu8HermesResBuffer);
void copyPDFUResponse(UINT32 u32Header,UINT8* u8pRespuffer);

void pdfuValidation_ProcessHermesRequest(UINT8* pu8HermesReqBuffer);
UINT16 pdfuValidation_ProcessHermesResponse(UINT8* pu8HermesResBuffer);


#endif