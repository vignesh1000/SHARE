
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#define VALIDATION 1
#if VALIDATION
#include <NVM_Val.h>
#include <stdinc.h>
#include <Hermes_Interface.h>

  
extern UINT8 pu8HermesResBuffer[BUFFER_SIZE];
extern UINT8 gu8HermesReqBuffer[BUFFER_SIZE];

extern NVM_ProgramMemory_cb NVM_ProgramMemoryCB;
extern NVM_ReadMemory_cb NVM_ReadMemoryCB;
UINT8 TempBuff[256]={0};

UINT8 NVMTestStatus =0x1;

/******************************************************************************
 * Function:        UINT8 NVMVal_HandleTxReq()
 * Input:           None
 * Output:          Function return Status for NVM read and write with invalid address					
 * Overview:         
 * Note:            NVM VALIDATION macro must be enabled To validate NVM 
 *****************************************************************************/

UINT8 NVMVal_HandleTxReq(UINT8 *ValidationBuffer)
{
	
    UINT32 Address;
	UINT8 u8TestCaseId = ValidationBuffer[0];
    UINT8 WriteStatus =0x0;
    UINT8 ReadStatus =0x0;
	switch (u8TestCaseId)
    {
		case 0:
		{
            /* Form the address sent from NVM Test file in Hera*/
           Address = (((ValidationBuffer[1] | (ValidationBuffer[2] << 8)) | (ValidationBuffer[3] << 0x10)) | (ValidationBuffer[4] << 0x18));
           /* NVM_STATUS_ERR_BAD_ADDRESS                  (NVM_STATUS_CATEGORY_COMMON(0x10)| 0x08)
             So the return value shoulc be 0x18 to indicate Bad address sent for read or write */
      		WriteStatus = NVM_ProgramMemoryCB( Address , &TempBuff[0], 256); 
            ReadStatus = NVM_ReadMemoryCB( Address , &TempBuff[0], 256); 
            /* If address is not page alligned or invlid address, the response would be same that BadAddress(0x18)*/
            if((0x18 == WriteStatus) && (0x18==ReadStatus))
            {
                NVMTestStatus =0;
            }
            break;
        }      
        
    default:
      break;
    }
			
return 1;			
}



UINT16 NVMVal_HandleRxReq(UINT8* ValidationBufferPtr)
{

    ValidationBufferPtr[0]= NVMTestStatus;

return 1;			
}
#endif


