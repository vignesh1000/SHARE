#ifndef _UART_VAL_H_
#define _UART_VAL_H_

#include <stdinc.h>

#define UARTVAL_SET_BAUD_RATE				0
#define UARTVAL_UPD301_CHAR_LOOPBACK_TEST	1
#define UARTVAL_TX_RX_CHAR_TEST				2
#define UARTVAL_UINT8_TX_TEST				3
#define UARTVAL_UINT16_TX_TEST				4
#define UARTVAL_UINT32_TX_TEST				5
#define UARTVAL_INT32_TX_TEST				6
#define UARTVAL_STRING_TX_TEST				7
#define UARTVAL_TX_RX_STRESS_CHAR_TEST		8
#define UARTVAL_UART_INIT					9

#define UARTVAL_TEST_STATUS_SUCCESS			1
#define UARTVAL_TEST_STATUS_FAILED			0


void UARTVal_HandleRequest (UINT8* pu8HermesReqBuffer);
UINT16 UARTVal_HandleResponse (UINT8* pu8HermesResBuffer);


#endif