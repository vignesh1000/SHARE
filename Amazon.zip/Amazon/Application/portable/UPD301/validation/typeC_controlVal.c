
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/


#include <stdinc.h>
#include <typeC_controlVal.h>
#if VALIDATION

void TypeCVal_APITests(UINT8* pu8HermesReqBuffer)
{

    UINT8 u8PortNum =0;
    UINT8 u8ReadByte =0;
    UINT16 u16ReadWord =0;
    UINT8 u8TestRes = TRUE;
    UINT8 errorcodePos = 2;
    UINT8 errorcnt =0;
    UINT8 u8Data;
    UINT8 u8TestCaseId = pu8HermesReqBuffer[2];
    
    UPD_RegisterReadISR (u8PortNum, UPD_HW_CTL, &u8Data, BYTE_LEN_1);
            
    u8Data |= 0x01; 

    UPD_RegisterWriteISR (u8PortNum, UPD_HW_CTL, &u8Data, BYTE_LEN_1);
    
    WaitUntilSPITestRegister(u8PortNum);    

    u8TestRes = TRUE;

    switch(u8TestCaseId)
    {
        /*Test ID: TYPEC_CCCOMP_ENABLE_CC1CC2*/
        case 1:
        {
            /*Calling the API to set the CC Comparator to sample both CC1 and CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC1_CC2);

            /*Verify that CC Comparator is enabled for both CC1 and CC2*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte = (u8ReadByte & 0xF0);

            if(u8ReadByte != 0x60)
            {                                  
                gu8HermesResBuffer[errorcodePos] = 0x02;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                /*Print CC_CTL1_HIGH(0x0821)*F0 Expected:0x60 Current Value:0x*/
//                CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x0821)*F0 Expected:0x60 Current Value:0x");
//                CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                
                u8TestRes = FALSE;
            }
            break;
        }
        
        /*Test ID: TYPEC_CCCOMP_ENABLE_CC1*/
        case 2:
        {
          
            /*Calling the API to set the CC Comparator to sample only CC1 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC1);

            /*Verify that CC Comparator is enabled only for CC1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0xF0;

            if(u8ReadByte != 0x20)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x03;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
              
//                  /*Print CC_CTL1_HIGH(0x0821)*F0 Expected:0x20 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x0821)*F0 Expected:0x20 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_CCCOMP_ENABLE_CC1_PREVCC1CC2*/
        case 3:
        {
            /*Calling the API to set the CC Comparator to sample both CC1 and CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC1_CC2);

            /*Calling the API to set the CC Comparator to sample only CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC1);

            /*Verify that CC Comparator is enabled only for CC1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0xF0;

            if(u8ReadByte != 0x20)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x03;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//                    
//                  /*Print CC_CTL1_HIGH(0x0821)*F0 Expected:0x20 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x0821)*F0 Expected:0x20 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_CCCOMP_ENABLE_CC1_PREVCC2*/
        case 4:
        {
            /*Calling the API to set the CC Comparator to sample CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC2);

            /*Calling the API to set the CC Comparator to sample only CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC1);

            /*Verify that CC Comparator is enabled only for CC1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0xF0;

            if(u8ReadByte != 0x20)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x03;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//                    
//                  /*Print CC_CTL1_HIGH(0x0821)*F0 Expected:0x20 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x0821)*F0 Expected:0x20 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_CCCOMP_ENABLE_CC2*/
        case 5:
        {
            /*Calling the API to set the CC Comparator to sample only CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC2);

            /*Verify that CC Comparator is enabled only for CC2*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0xF0;

            if(u8ReadByte != 0x40)
            {
               
                gu8HermesResBuffer[errorcodePos] = 0x04;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x0821)*F0 Expected:0x40 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x0821)*F0 Expected:0x40 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_CCCOMP_ENABLE_CC2_PREVCC1CC2*/
        case 6:
        {
            /*Calling the API to set the CC Comparator to sample both CC1 and CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC1_CC2);

            /*Calling the API to set the CC Comparator to sample only CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC2);

            /*Verify that CC Comparator is enabled only for CC2*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0xF0;

            if(u8ReadByte != 0x40)
            {
               
                gu8HermesResBuffer[errorcodePos] = 0x04;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x0821)*F0 Expected:0x40 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x0821)*F0 Expected:0x40 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_CCCOMP_ENABLE_CC2_PREVCC1*/
        case 7:
        {
            /*Calling the API to set the CC Comparator to sample the CC1 pin*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC1);

            /*Calling the API to set the CC Comparator to sample only CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC2);

            /*Verify that CC Comparator is enabled only for CC2*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0xF0;

            if(u8ReadByte != 0x40)
            {
                gu8HermesResBuffer[errorcodePos] = 0x04;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
              /*Print CC_CTL1_HIGH(0x0821)*F0 Expected:0x40 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x0821)*F0 Expected:0x40 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_CCCOMP_DIS_CC1CC2*/
        case 8:
        {
            /*Calling the API to set the CC Comparator to sample both CC1 and CC2 pins*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_CC1_CC2);

            /*Calling the API to set the CC Comparator disable sampling of both CC1 and CC2*/
            TypeC_ConfigCCComp (u8PortNum, TYPEC_CC_COMP_CTL_DIS);

             /*Verify that CC Comparator is disabled*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0xF0;

            if(u8ReadByte != 0x00)
            {
               
                gu8HermesResBuffer[errorcodePos] = 0x05;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x0821)*F0 Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x0821)*F0 Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_VBUSCOMP_ENABLE*/
        case 9:
        {
          
            UINT8 u8SampleEn = (TYPEC_VBUS_VSAFE0V_MATCH | TYPEC_VBUS_THRES0_MATCH | TYPEC_VBUS_THRES1_MATCH);
            
            /*Enabling VBUS sample*/
            UPD_RegWriteByte (u8PortNum, TYPEC_VBUS_SAMP_EN, u8SampleEn);
    
            /*Calling the API to set the VBUS Comparator ON*/
            TypeC_SetVBUSCompONOFF (u8PortNum, TYPEC_VBUSCOMP_ON);

            /*Verify that VBUS Comparator is switched ON*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL1_LOW);

            u8ReadByte &= 0x03;

            if(u8ReadByte != 0x01)
            {
               
                gu8HermesResBuffer[errorcodePos] = 0x06;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_CTL1_LOW(0x0840)*03 Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1_LOW(0x0840)*03 Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_VBUSCOMP_DISABLE*/
        case 10:
        {
             
            UINT8 u8SampleEn = (TYPEC_VBUS_VSAFE0V_MATCH | TYPEC_VBUS_THRES0_MATCH | TYPEC_VBUS_THRES1_MATCH);
            
            /*Enabling VBUS sample*/
            UPD_RegWriteByte (u8PortNum, TYPEC_VBUS_SAMP_EN, u8SampleEn);
            
            /*Calling the API to set the VBUS Comparator ON*/
            TypeC_SetVBUSCompONOFF (u8PortNum, TYPEC_VBUSCOMP_ON);

            /*Calling the API to set the VBUS Comparator OFF*/
            TypeC_SetVBUSCompONOFF (u8PortNum, TYPEC_VBUSCOMP_OFF);

            /*Verify that VBUS Comparator is switched OFF*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL1_LOW);

            u8ReadByte &= 0x03;

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x07;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_CTL1_LOW(0x0840) *03 Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1_LOW(0x0840)*03 Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_UFP_CCTHRES_CC1*/
        case 11:
        {
            /*Calling the API to set the CCDebounce  Variable for UFP*/
            TypeC_SetCCDebounceVariable (u8PortNum, TYPEC_UFP);

            /*Calling the API to set the CCDebounce variable for CC1 Sampling*/
            TypeC_SetCCSampleEnable (u8PortNum, TYPEC_ENABLE_CC1_SAMPLING);

            /*Verify that the CC1_DBCLR_EN is set according to given value */
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u8ReadByte != 0x95)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x08;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//                    
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x15 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x15 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC1_MATCH_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u8ReadByte != 0x95)
            {
               
                gu8HermesResBuffer[errorcodePos] = 0x09;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x15 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x15 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
             /*Verify that only the CC1_SAMP_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u8ReadByte != 0x95)
            {
               
                gu8HermesResBuffer[errorcodePos] = 0x0A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x15 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x15 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            break;
        }
        /*Test ID: TYPEC_UFP_CCTHRES_CC2*/
        case 12:
        {
            /*Calling the API to set the CCDebounce  Variable for UFP*/
            TypeC_SetCCDebounceVariable (u8PortNum, TYPEC_UFP);

            /*Calling the API to set the CCDebounce variable for CC2 Sampling*/
            TypeC_SetCCSampleEnable (u8PortNum, TYPEC_ENABLE_CC2_SAMPLING);

            /*Verify that only the CC2_DBCLR_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC2_DBCLR_EN);

            if(u8ReadByte != 0x95)
            {
               
                gu8HermesResBuffer[errorcodePos] = 0x0B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC2_DBCLR_EN(0x81B)  Expected:0x15 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC2_DBCLR_EN(0x81B)  Expected:0x15 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that only the CC2_MATCH_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC2_MATCH_EN);

            if(u8ReadByte != 0x95)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x0C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC2_MATCH_EN(0x813)  Expected:0x15 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x813)  Expected:0x15 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
             /*Verify that only the CC2_SAMP_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC2_SAMP_EN);

            if(u8ReadByte != 0x95)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x0D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print TYPEC_CC2_SAMP_EN(0x81E)  Expected:0x15 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC2_SAMP_EN(0x81E)  Expected:0x15 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            break;
        }
        /*Test ID: TYPEC_UFP_CCTHRES_CC1CC2*/
        case 13:
        {
            /*Calling the API to set the CCDebounce  Variable for UFP*/
            TypeC_SetCCDebounceVariable (u8PortNum, TYPEC_UFP);

            /*Calling the API to set the CCDebounce variable for both CC1 and CC2 Sampling*/
            TypeC_SetCCSampleEnable (u8PortNum, (TYPEC_ENABLE_CC1_SAMPLING |TYPEC_ENABLE_CC2_SAMPLING));

            /*Verify that both the CC2_DBCLR_EN and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x9595)
            {
               
                gu8HermesResBuffer[errorcodePos] = 0x0E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x1515 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x1515 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that both the CC1_MATCH_EN and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x9595)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x0F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x1515 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x1515 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
             /*Verify that both the CC1_SAMP_EN and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x9595)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x10;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x1515 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x1515 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_DFPDEF_CCTHRES_CC1CC2*/
        case 14:
        {
            /*Calling the API to set the CCDebounce  Variable for DFP_DEFAULT_CURRENT*/
            TypeC_SetCCDebounceVariable (u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

            /*Calling the API to set the CCDebounce variable for both CC1 and CC2 Sampling*/
            TypeC_SetCCSampleEnable (u8PortNum, (TYPEC_ENABLE_CC1_SAMPLING |TYPEC_ENABLE_CC2_SAMPLING));

            /*Verify that both the CC2_DBCLR_EN and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x11;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that only the CC1_MATCH_EN and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x12;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
             /*Verify that only the CC1_SAMP_EN and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x13;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_DFP15_CCTHRES_CC1CC2*/
        case 15:
        {
            /*Calling the API to set the CCDebounce  Variable for DFP_1A5_CURRENT*/
            TypeC_SetCCDebounceVariable (u8PortNum, TYPEC_DFP_1A5_CURRENT);

            /*Calling the API to set the CCDebounce variable for both CC1 and CC2 Sampling*/
            TypeC_SetCCSampleEnable (u8PortNum, (TYPEC_ENABLE_CC1_SAMPLING |TYPEC_ENABLE_CC2_SAMPLING));

            /*Verify that both the CC2_DBCLR_EN and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x14;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verify that only the CC1_MATCH_EN and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x15;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
             /*Verify that only the CC1_SAMP_EN and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x16;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_DFP30_CCTHRES_CC1CC2*/
        case 16:
        {
            /*Calling the API to set the CCDebounce  Variable for DFP_3A0_CURRENT*/
            TypeC_SetCCDebounceVariable (u8PortNum, TYPEC_DFP_3A0_CURRENT);

            /*Calling the API to set the CCDebounce variable for both CC1 and CC2 Sampling*/
            TypeC_SetCCSampleEnable (u8PortNum, (TYPEC_ENABLE_CC1_SAMPLING |TYPEC_ENABLE_CC2_SAMPLING));

            /*Verify that both the CC2_DBCLR_EN and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x17;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that only the CC1_MATCH_EN and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x18;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
             /*Verify that only the CC1_SAMP_EN and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x19;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_VBUSTHRES_SET*/
        case 17:
        {

//                /*Setting VBUS Debounce enable clear register and VBUS Match Enable Register for 0x05 Match */
//                TypeC_SetVBUSSampleEnable (u8PortNum, 0x05);
//
//                /*Verify that VBUS_MATCH_EN is set to 0x05 */
//                u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_MATCH_EN);
//
//                if(u8ReadByte != 0x05)
//                {
//                  /*Print VBUS_MATCH_EN(0x814)  Expected:0x05 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_MATCH_EN(0x814)  Expected:0x05 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
//                  u8TestRes = FALSE;
//
//                }
//
//                /*Verify that the VBUS_DBCLR_EN is set to 0x05*/
//                u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_DBCLR_EN);
//
//                if(u8ReadByte != 0x05)
//                {
//                  /*Print VBUS_DBCLR_EN(0x81C)  Expected:0x05 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_DBCLR_EN(0x81C)  Expected:0x05 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
//                  u8TestRes = FALSE;
//
//                }
//                /*Verify that the VBUS_SAMP_EN is set to 0x05*/
//                u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_SAMP_EN);
//
//                if(u8ReadByte != 0x05)
//                {
//                  /*Print VBUS_SAMP_EN(0x81F)  Expected:0x05 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_SAMP_EN(0x81F)  Expected:0x05 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
//                  u8TestRes = FALSE;
//
//                }
//
//                break;
        }
        /*Test ID: TYPEC_SET_SOURCE_OPENDIS*/
        case 18:
        {

            /*Calling the API to set the Power role as Source with Rp resistors as open disconnect */
            TypeC_SetPowerRole (u8PortNum, TYPEC_ROLE_SOURCE, TYPEC_ROLE_SOURCE_OPEN_DIS);

            /*Verify that the Rp reistors are set as open disconnect*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            break;
        }
        /*Test ID: TYPEC_SET_SOURCE_DEF_CURR*/
        case 19:
        {

            /*Calling the API to set the Power role as Source with Rp resistors as default current */
            TypeC_SetPowerRole (u8PortNum, TYPEC_ROLE_SOURCE, TYPEC_ROLE_SOURCE_DC);

            /*Verify that the Rp reistors are set as default current*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x05)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x05 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F  Expected:0x05 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            break;
        }
         /*Test ID: TYPEC_SET_SOURCE_15_CURR*/
        case 20:
        {

            /*Calling the API to set the Power role as Source with Rp resistors as 1.5A current */
            TypeC_SetPowerRole (u8PortNum, TYPEC_ROLE_SOURCE, TYPEC_ROLE_SOURCE_15);

            /*Verify that the Rp reistors are set as 1.5A current*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x0A)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x0A Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F  Expected:0x0A Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            break;
        }
        /*Test ID: TYPEC_SET_SOURCE_30_CURR*/
        case 21:
        {

            /*Calling the API to set the Power role as Source with Rp resistors as 3.0A current */
            TypeC_SetPowerRole (u8PortNum, TYPEC_ROLE_SOURCE, TYPEC_ROLE_SOURCE_30);

            /*Verify that the Rp reistors are set as 3.0A current*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x0F)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x0F Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F  Expected:0x0F Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

            break;
        }
        /*Test ID: TYPEC_SET_SINK_OPENDIS*/
        case 22:
        {

            /*Calling the API to set the Power role as Sink with pull down resistor set as open disconnect */
            TypeC_SetPowerRole (u8PortNum, TYPEC_ROLE_SINK, TYPEC_ROLE_SINK_OPEN_DIS);

            /*Verify that the with pull down resistor are set as open disconnect*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1);

            if(u8ReadByte != 0x1B)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1(0x820)  Expected:0x1B Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1(0x820)  Expected:0x1B Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            break;
        }
         /*Test ID: TYPEC_SET_SINK_RD*/
        case 23:
        {

            /*Calling the API to set the Power role as Sink with pull down resistor set as Rd resistors */
            TypeC_SetPowerRole (u8PortNum, TYPEC_ROLE_SINK, TYPEC_ROLE_SINK_RD);

            /*Verify that the with pull down resistor set as Rd reistors*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1);

            if(u8ReadByte != 0x09)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1(0x820)  Expected:0x09 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1(0x820)  Expected:0x09 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            break;
        }
         /*Test ID: TYPEC_SET_DFPROLE*/
        case 24:
        {

            /*Calling the API to set the data role as DFP */
            TypeC_SetDataRole (u8PortNum, PD_ROLE_DFP);

            /*Verify that the data role set as DFP*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL);

            u8ReadByte &= 0x04;

            if(u8ReadByte != 0x04)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x20;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_HW_CTL(0x800)*04  Expected:0x04 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL(0x800)*04  Expected:0x04 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            break;
        }
          /*Test ID: TYPEC_SET_UFPROLE*/
        case 25:
        {

            /*Calling the API to set the data role as DFP before checking for UFP Data role Setting*/
            TypeC_SetDataRole (u8PortNum, PD_ROLE_DFP);

            /*Calling the API to set the data role as UFP */
            TypeC_SetDataRole (u8PortNum, PD_ROLE_UFP);

            /*Verify that the data role set as UFP*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL);

            u8ReadByte &= 0x04;

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x21;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_HW_CTL(0x800)*04  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL(0x800)*04  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            break;
        }
        /*Test ID: TYPEC_VCONN_ENABLE_CC1*/
        case 26:
        {
            
            gasPortConfigurationData[u8PortNum].u32CfgData |= PD_ROLE_SOURCE;
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR =1;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR = 0;
            gasTypeCcontrol[u8PortNum].u8PortSts |= TYPEC_PWDCABLE_PRES_MASK;
            
            UINT8 u8CCRead = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);
            u8CCRead |= TYPEC_CC_COM_SEL;            
            UPD_RegWriteByte(u8PortNum,TYPEC_CC_CTL1_HIGH,u8CCRead);
             
            /*Calling the API to set VCONN FET ON on CC1*/
            TypeC_EnabDisVCONN(u8PortNum, TYPEC_VCONN_ENABLE);

            /*Verify that the VCONN is applied on CC1 and OCS Detection is enabled*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL1);

            u8ReadByte &= 0x4C;

            if(u8ReadByte != 0x44)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x22;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_CTL1(0x840)*4C  Expected:0x44 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1(0x840)*4C  Expected:0x44 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
         /*Test ID: TYPEC_VCONN_ENABLE_CC2*/
        case 27:
        {

            gasPortConfigurationData[u8PortNum].u32CfgData |= PD_ROLE_SOURCE;
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR =0;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR = 1;
            gasTypeCcontrol[u8PortNum].u8PortSts |= TYPEC_PWDCABLE_PRES_MASK;
            
            UINT8 u8CCRead = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);
            u8CCRead &= ~TYPEC_CC_COM_SEL;            
            UPD_RegWriteByte(u8PortNum,TYPEC_CC_CTL1_HIGH,u8CCRead);
            
            /*Calling the API to set VCONN FET ON on CC2*/
            TypeC_EnabDisVCONN(u8PortNum, TYPEC_VCONN2_ENABLE);

            /*Verify that the VCONN is applied on CC1 and OCS Detection is enabled*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL1);

            u8ReadByte &= 0x4C;

            if(u8ReadByte != 0x48)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x23;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_CTL1(0x840)*4C  Expected:0x48 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1(0x840)*4C  Expected:0x48 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_VCONN_DISABLE_CC1*/
        case 28:
        {

            /*Calling the API to set VCONN FET ON on CC1*/
            TypeC_EnabDisVCONN(u8PortNum, TYPEC_VCONN_SOURCE_CC1);

            /*Calling the API to disable VCONN FET supply on CC1*/
            TypeC_EnabDisVCONN(u8PortNum, TYPEC_VCONN_DISABLED);

            /*Verify that the VCONN and OCS Detection is disabled*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL1);

            u8ReadByte &= 0x4C;

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x24;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_CTL1(0x840)*4C  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1(0x840)*4C  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_VCONN_DISABLE_CC2*/
        case 29:
        {

            /*Calling the API to set VCONN FET ON on CC2*/
            TypeC_EnabDisVCONN(u8PortNum, TYPEC_VCONN_SOURCE_CC2);

            /*Calling the API to disable VCONN FET supply on CC1*/
            TypeC_EnabDisVCONN(u8PortNum, TYPEC_VCONN_DISABLED);

            /*Verify that the VCONN and OCS Detection is disabled*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL1);

            u8ReadByte &= 0x4C;

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x24;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_CTL1(0x840)*4C  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1(0x840)*4C  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_CA_SINKTXNG_PC_CC1*/
        case 32:
        {

            /*Setting the TYPEC_PWDCABLE_PRES_MASK  bit as 1 to indicate the powered cable presence*/
            gasTypeCcontrol[u8PortNum].u8PortSts |= TYPEC_PWDCABLE_PRES_MASK;

            /*Setting CC1 Match register variable < CC2 Match register Variable to set the sink
            presence in CC1*/
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = 0;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR =1;
            
            gasTypeCcontrol[u8PortNum].u8IntStsISR &= ~TYPEC_VCONN_SOURCE_MASK;
            gasTypeCcontrol[u8PortNum].u8IntStsISR |= TYPEC_VCONN_SOURCE_CC2;

            /*Calling the API to set the source resistor as per TYPEC_SINK_TXNG */
            TypeC_SetRpCollAvoidance (u8PortNum, TYPEC_SINK_TXNG);

            /*Verify that the sampling is set only for CC1 line in which sink is present*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x6F;

            if(u8ReadByte != 0x2A)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x25;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821) *6F Expected:0x2A Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821) *6F Expected:0x2A Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC1_DBCLR_EN is set according to given value */
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC1_DBCLR_EN);

             if(u8ReadByte != 0x22)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x26;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x22 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x22 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC1_MATCH_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u8ReadByte != 0x22)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x27;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x22 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x22 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
             /*Verify that only the CC1_SAMP_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u8ReadByte != 0x22)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x28;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x22 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x22 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }


            /*UnSetting the Type C Variable changed for this Test case*/
            gasTypeCcontrol[u8PortNum].u8PortSts &= ~TYPEC_PWDCABLE_PRES_MASK;

            /*Setting CC1 Match register variable and CC2 Match register back to 0*/
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = 0;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR =0;

            break;
        }
         /*Test ID: TYPEC_CA_SINKTXNG_PC_CC2*/
        case 33:
        {

            /*Setting the TYPEC_PWDCABLE_PRES_MASK  bit as 1 to indicate the powered cable presence*/
            gasTypeCcontrol[u8PortNum].u8PortSts |= TYPEC_PWDCABLE_PRES_MASK;

            /*Setting CC1 Match register variable > CC2 Match register Variable to set the sink is
            present in CC2*/
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = 1;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR =0;
            
            gasTypeCcontrol[u8PortNum].u8IntStsISR &= ~TYPEC_VCONN_SOURCE_MASK;
            gasTypeCcontrol[u8PortNum].u8IntStsISR |= TYPEC_VCONN_SOURCE_CC1;

            /*Calling the API to set the source resistor as per TYPEC_SINK_TXNG */
            TypeC_SetRpCollAvoidance (u8PortNum, TYPEC_SINK_TXNG);

            /*Verify that the sampling is set only for CC2 line inn which source is present*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x6F;

            if(u8ReadByte != 0x4A)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x29;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821) *6F Expected:0x4A Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821) *6F Expected:0x4A Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that only the CC2_DBCLR_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC2_DBCLR_EN);

            if(u8ReadByte != 0x22)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x2A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC2_DBCLR_EN(0x81B)  Expected:0x22 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC2_DBCLR_EN(0x81B)  Expected:0x22 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that only the CC2_MATCH_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC2_MATCH_EN);

            if(u8ReadByte != 0x22)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x2B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC2_MATCH_EN(0x813)  Expected:0x22 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC2_MATCH_EN(0x813)  Expected:0x22 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
             /*Verify that only the CC2_SAMP_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC2_SAMP_EN);

            if(u8ReadByte != 0x22)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x2C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print TYPEC_CC2_SAMP_EN(0x81E)  Expected:0x22 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC2_SAMP_EN(0x81E)  Expected:0x22 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*UnSetting the Type C Variable changed for this Test case*/
            gasTypeCcontrol[u8PortNum].u8PortSts &= ~TYPEC_PWDCABLE_PRES_MASK;

            /*Setting CC1 Match register variable and CC2 Match register back to 0*/
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = 0;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR =0;

            break;
        }
         /*Test ID: TYPEC_CA_SINKTXNG_PC_ABS*/
        case 34:
        {

            /*Setting the TYPEC_PWDCABLE_PRES_MASK  bit as 0 to indicate the powered cable absence*/
            gasTypeCcontrol[u8PortNum].u8PortSts &= ~TYPEC_PWDCABLE_PRES_MASK;
            
             gasTypeCcontrol[u8PortNum].u8IntStsISR &= ~TYPEC_VCONN_SOURCE_MASK;

            /*Calling the API to set the source resistor as per TYPEC_SINK_TXNG */
            TypeC_SetRpCollAvoidance (u8PortNum, TYPEC_SINK_TXNG);

            /*Verify that the sampling is set for both CC1 and CC2 line*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x6F;

            if(u8ReadByte != 0x6A)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x2D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//                    
//                  /*Print CC_CTL1_HIGH(0x821) *6F Expected:0x6A Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821) *6F Expected:0x6A Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC1_DBCLR_EN is set and CC2_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x14;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

              /*Print CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x*/
              CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x");
              CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC2_MATCH_EN is set and CC1_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x15;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

              /*Print CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x*/
              CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x");
              CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
             /*Verify that the CC2_SAMP_EN is set and CC1_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x16;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
              /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x*/
              CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x");
              CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            break;
        }
        /*Test ID: TYPEC_CA_SINK_TXOK_PC_CC2*/
        case 35:
        {

            /*Setting the TYPEC_PWDCABLE_PRES_MASK  bit as 1 to indicate the powered cable presence*/
            gasTypeCcontrol[u8PortNum].u8PortSts |= TYPEC_PWDCABLE_PRES_MASK;
            
            gasTypeCcontrol[u8PortNum].u8IntStsISR &= ~TYPEC_VCONN_SOURCE_MASK;
            gasTypeCcontrol[u8PortNum].u8IntStsISR |= TYPEC_VCONN_SOURCE_CC2;

            /*Setting CC1 Match register variable < CC2 Match register Variable to set that the sink
            is attached in CC1*/
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = 0;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR =1;

            /*Calling the API to set the source resistor as per TYPEC_SINK_TXOK */
            TypeC_SetRpCollAvoidance (u8PortNum, TYPEC_SINK_TXOK);

            /*Verify that the sampling is set only for CC1 line in which sink is present*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x6F;

            if(u8ReadByte != 0x2F)
            {                 
              
                gu8HermesResBuffer[errorcodePos] = 0x2E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821) *6F Expected:0x2F Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821) *6F Expected:0x2F Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

             /*Verify that the CC1_DBCLR_EN is set according to given value */
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC1_DBCLR_EN);

             if(u8ReadByte != 0x48)
            {
              
              
                gu8HermesResBuffer[errorcodePos] = 0x2F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//                    
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x48 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x48 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC1_MATCH_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u8ReadByte != 0x48)
            {                 
              
                gu8HermesResBuffer[errorcodePos] = 0x30;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x48 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x48 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
             /*Verify that only the CC1_SAMP_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u8ReadByte != 0x48)
            {                  
              
                gu8HermesResBuffer[errorcodePos] = 0x31;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//                    
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x48 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x48 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*UnSetting the Type C Variable changed for this Test case*/
            gasTypeCcontrol[u8PortNum].u8PortSts &= ~TYPEC_PWDCABLE_PRES_MASK;

            /*Setting CC1 Match register variable and CC2 Match register back to 0*/
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = 0;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR =0;

            break;
        }
         /*Test ID: TYPEC_CA_SINK_TXOK_PC_CC1*/
        case 36:
        {

            /*Setting the TYPEC_PWDCABLE_PRES_MASK  bit as 1 to indicate the powered cable presence*/
            gasTypeCcontrol[u8PortNum].u8PortSts |= TYPEC_PWDCABLE_PRES_MASK;
            
             gasTypeCcontrol[u8PortNum].u8IntStsISR &= ~TYPEC_VCONN_SOURCE_MASK;
            gasTypeCcontrol[u8PortNum].u8IntStsISR |= TYPEC_VCONN_SOURCE_CC1;

            /*Setting CC1 Match register variable > CC2 Match register Variable to set that the sink
            is attached in CC2*/
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = 1;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR =0;

            /*Calling the API to set the source resistor as per TYPEC_SINK_TXNG */
            TypeC_SetRpCollAvoidance (u8PortNum, TYPEC_SINK_TXOK);

            /*Verify that the sampling is set only for CC2 line inn which sink is present*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x6F;

            if(u8ReadByte != 0x4F)
            {
              
              
                gu8HermesResBuffer[errorcodePos] = 0x32;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821) *6F Expected:0x4F Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821) *6F Expected:0x4F Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

             /*Verify that only the CC2_DBCLR_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC2_DBCLR_EN);

            if(u8ReadByte != 0x48)
            {
              
               gu8HermesResBuffer[errorcodePos] = 0x33;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC2_DBCLR_EN(0x81B)  Expected:0x48 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC2_DBCLR_EN(0x81B)  Expected:0x48 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

            /*Verify that only the CC2_MATCH_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC2_MATCH_EN);

            if(u8ReadByte != 0x48)
            {
              
               gu8HermesResBuffer[errorcodePos] = 0x34;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC2_MATCH_EN(0x813)  Expected:0x48 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x813)  Expected:0x48 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }
             /*Verify that only the CC2_SAMP_EN is set according to given value*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC2_SAMP_EN);

            if(u8ReadByte != 0x48)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x35;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print TYPEC_CC2_SAMP_EN(0x81E)  Expected:0x48 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC2_SAMP_EN(0x81E)  Expected:0x48 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

            /*UnSetting the Type C Variable changed for this Test case*/
            gasTypeCcontrol[u8PortNum].u8PortSts &= ~TYPEC_PWDCABLE_PRES_MASK;

            /*Setting CC1 Match register variable and CC2 Match register back to 0*/
            gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = 0;
            gasTypeCcontrol[u8PortNum].u8CC2_MatchISR =0;

            break;
        }
         /*Test ID: TYPEC_CA_SINK_TXOK_PC_ABS*/
        case 37:
        {

            /*Setting the TYPEC_PWDCABLE_PRES_MASK  bit as 0 to indicate the powered cable absence*/
            gasTypeCcontrol[u8PortNum].u8PortSts &= ~TYPEC_PWDCABLE_PRES_MASK;
            
            gasTypeCcontrol[u8PortNum].u8IntStsISR &= ~TYPEC_VCONN_SOURCE_MASK;

            /*Calling the API to set the source resistor as per TYPEC_SINK_TXNG */
            TypeC_SetRpCollAvoidance (u8PortNum, TYPEC_SINK_TXOK);

            /*Verify that the sampling is set for both CC1 and CC2 line*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x6F;

            if(u8ReadByte != 0x6F)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x36;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821) *6F Expected:0x6F Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821) *6F Expected:0x6F Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC1_DBCLR_EN is set and CC2_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x17;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC2_MATCH_EN is set and CC1_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x18;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
             /*Verify that the CC2_SAMP_EN is set and CC1_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x19;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_DEFRP_SRCDEF*/
        case 38:
        {
           
            /*Setting the Source with Default current configuration*/ 
            gasPortConfigurationData[u8PortNum].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[u8PortNum].u32CfgData |= PD_ROLE_SOURCE;
            gasPortConfigurationData[u8PortNum].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
            gasPortConfigurationData[0].u32CfgData |= (TYPEC_RP_DEFAULT_CURRENT << TYPEC_PORT_RPVAL_POS);

           /*Calling this API to set the User given Rp value*/
           TypeC_SetDefaultRpValue (u8PortNum);

           /*Verify that the Rp resistor is set as Default current*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x05)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x05 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F Expected:0x05 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC2_DBCLR_EN is set and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x11;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC1_MATCH_EN is set and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x12;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
             /*Verify that the CC1_SAMP_EN is set and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x13;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_DEFRP_SRC15A*/
        case 39:
        {
           
            /*Setting the Source with Default current configuration*/
            gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
            gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
            gasPortConfigurationData[0].u32CfgData |= (RP_VAL_1P5A << TYPEC_PORT_RPVAL_POS);

           /*Calling this API to set the User given Rp value*/
           TypeC_SetDefaultRpValue (u8PortNum);

           /*Verify that the Rp resistor is set as Default current*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x0A)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
              
//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x0A Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F Expected:0x0A Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC2_DBCLR_EN is set and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x14;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC1_MATCH_EN is set and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x2222)
            {
                
                gu8HermesResBuffer[errorcodePos] = 0x15;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
             /*Verify that the CC1_SAMP_EN is set and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x16;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_DEFRP_SRC30A*/
        case 40:
        {

           /*Setting the User given input configuration for Rp as TYPEC_RP_CURRENT_30*/
            gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
            gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
            gasPortConfigurationData[0].u32CfgData |= (RP_VAL_3A << TYPEC_PORT_RPVAL_POS);
           

           /*Calling this API to set the User given Rp value*/
           TypeC_SetDefaultRpValue (u8PortNum);

           /*Verify that the Rp resistor is set as Default current*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x0F)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x0F Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F Expected:0x0F Current Value:0x0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC2_DBCLR_EN is set and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x17;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC1_MATCH_EN is set and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x18;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
             /*Verify that the CC1_SAMP_EN is set and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x19;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_VCONNDIS_DEFRP_SRCDEF*/
        case 41:
        {

           /*Setting the VCONN Power Supply ON on CC1*/
           TypeC_EnabDisVCONN (u8PortNum, TYPEC_VCONN_SOURCE_CC1);


           /*Setting the User given input configuration for Rp as TYPEC_RP_DEFAULT_CURRENT*/
            gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
            gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
            gasPortConfigurationData[0].u32CfgData |= (TYPEC_RP_DEFAULT_CURRENT << TYPEC_PORT_RPVAL_POS);

           /*Calling this API to reset the configuration set during VCONN discharge to user given
           one*/
           TypeC_Reset_VCONNDIS_Settings (u8PortNum);

           /*Verify that the Rp resistor is set as Default current*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x05)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x05 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F Expected:0x05 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC2_DBCLR_EN is set and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x11;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC1_MATCH_EN is set and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x12;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
             /*Verify that the CC1_SAMP_EN is set and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x13;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verify that CC Threshold 0 register to reset to default value*/
             u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_THR0);

            if(u8ReadByte != 0x37)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x37;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print CC_THR0(0x822) Expected:0x37 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR0(0x822) Expected:0x37 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
         /*Test ID: TYPEC_VCONNDIS_DEFRP_SRC15A*/
        case 42:
        {

           /*Setting the VCONN Power Supply ON on CC1*/
           TypeC_EnabDisVCONN (u8PortNum, TYPEC_VCONN_SOURCE_CC1);

           /*Setting the User given input configuration for Rp as TYPEC_RP_CURRENT_15*/
            gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
            gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
            gasPortConfigurationData[0].u32CfgData |= (RP_VAL_1P5A << TYPEC_PORT_RPVAL_POS);

           /*Calling this API to reset the configuration set during VCONN discharge to user given
           one*/
           TypeC_Reset_VCONNDIS_Settings (u8PortNum);

           /*Verify that the Rp resistor is set as Default current*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x0A)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x2E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x0A Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F Expected:0x0A Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

            /*Verify that the CC2_DBCLR_EN is set and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x14;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC1_MATCH_EN is set and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x15;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
             /*Verify that the CC1_SAMP_EN is set and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x16;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that CC Threshold 0 register to reset to default value*/
             u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_THR0);

            if(u8ReadByte != 0x37)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x37;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_THR0(0x822) Expected:0x37 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR0(0x822) Expected:0x37 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
         /*Test ID: TYPEC_VCONNDIS_DEFRP_SRC30A*/
        case 43:
        {

           /*Setting the VCONN Power Supply ON on CC1*/
           TypeC_EnabDisVCONN (u8PortNum, TYPEC_VCONN_SOURCE_CC1);

           /*Setting the User given input configuration for Rp as TYPEC_RP_CURRENT_30*/
            gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
            gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
            gasPortConfigurationData[0].u32CfgData |= (RP_VAL_3A << TYPEC_PORT_RPVAL_POS);

           /*Calling this API to reset the configuration set during VCONN discharge to user given
           one*/
           TypeC_Reset_VCONNDIS_Settings (u8PortNum);

           /*Verify that the Rp resistor is set as Default current*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_CTL1_HIGH);

            u8ReadByte &= 0x0F;

            if(u8ReadByte != 0x0F)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x1D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_CTL1_HIGH(0x821)*0F  Expected:0x0F Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL1_HIGH(0x821)*0F Expected:0x0F Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC2_DBCLR_EN is set and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x17;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that the CC1_MATCH_EN is set and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x18;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC1_MATCH_EN(0x812)  Expected:4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
             /*Verify that the CC1_SAMP_EN is set and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x19;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that CC Threshold 0 register to reset to default value*/
             u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_THR0);

            if(u8ReadByte != 0x37)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x37;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_THR0(0x822) Expected:37 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR0(0x822) Expected:0x37 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            break;
        }
        /*Test ID: TYPEC_INIT_SOURCE_DEF_CURR*/
        case 44:
        {

            /*Setting the u8PortCfgData variable to 5 to indicate the default setting as
            Source Default Current*/
            gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
            gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
            gasPortConfigurationData[0].u32CfgData |= (TYPEC_RP_DEFAULT_CURRENT << TYPEC_PORT_RPVAL_POS);

           /*Calling the TypeC_InitPort API to do Type C Port initilization*/
           TypeC_InitPort (u8PortNum);

           /*Verify that CC Comparator is enabled on both CC1 and CC2
            Pull Down and Pull up resistors are set as per given input*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_CTL1);

            if(u16ReadWord != 0x651B)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x38;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_CTL(0x0820) Expected:0x651B Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL(0x0820) Expected:0x651B Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that VBUS Comparator is enabled.
            VBUS Debouncer Units is set as 1*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_CTL1);

            u16ReadWord &= 0x4001;

            if(u16ReadWord != 0x4001)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x39;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print VBUS_CTL1(0x0820)*4001 Expected:0x4001 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1(0x0820)*4001 Expected:0x4001 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            /*Verify the VCONN Debounce register whether set as 2*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VCONN_DEB);

            if(u8ReadByte != 0x02)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VCONN_DEB(0x819) Expected:0x02 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VCONN_DEB(0x819) Expected:0x02  Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

             /*Verify that VBUS_MATCH_EN is set to 0x05 */
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_MATCH_EN);

            if(u8ReadByte !=0x7D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print VBUS_MATCH_EN(0x814)  Expected:0x3D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_MATCH_EN(0x814)  Expected:0x3D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the VBUS_DBCLR_EN is set to 0x05*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_DBCLR_EN);

            if(u8ReadByte !=0x7D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print VBUS_DBCLR_EN(0x81C)  Expected:0x3D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_DBCLR_EN(0x81C)  Expected:0x3D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verify that the VBUS_SAMP_EN is set to 0x01*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_SAMP_EN);

            if(u8ReadByte !=0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print VBUS_SAMP_EN(0x81F)  Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_SAMP_EN(0x81F)  Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that both the CC2_DBCLR_EN and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x11;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that only the CC1_MATCH_EN and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x12;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            /*Verify that only the CC1_SAMP_EN and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x2121)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x13;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2121 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2121 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that the VBUS Debounce units is set as 4*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_DEB);

             if(u8ReadByte != 0x14)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print VBUS_DEB(0x84A)  Expected:0x14 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_DEB(0x84A)  Expected:0x14 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verifying that mode is set as Companion and role as DFP*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL);

            u8ReadByte &= 05;

             if(u8ReadByte !=0x04)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;


//                  /*Print CC_HW_CTL(0x800)*05   Expected:0x04 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL(0x800)*05   Expected:0x04 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verifying that VBUS_DEB_BLK_EN is set*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL2);

            u8ReadByte &= 0x01;

            if(u8ReadByte != 0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x40;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print VBUS_CTL2(0x83F)*01   Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL2(0x83F)*01   Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verifying that VBUS_THR0 is set to default value 0094*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_THR0);

            if(u16ReadWord !=0x96)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x41;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print VBUS_THR0(0x8B0)  Expected:0x00C2 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_THR0(0x8B0)  Expected:0x00C2 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that VBUS_THR1 is set to default value 00DE*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_THR1);

            if(u16ReadWord !=0x00DA)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x42;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print VBUS_THR1(0x8B2)  Expected:0x00DA Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_THR1(0x8B2)  Expected:0x00DA Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR0 is set to default value 0037*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR0);

            if(u16ReadWord != 0x0037)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x43;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_THR0(0x822)  Expected:0x0037 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR0(0x822)  Expected:0x0037 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR1 is set to default value 006D*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR1);

            if(u16ReadWord != 0x006D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x44;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR1(0x824)  Expected:0x006D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR1(0x824)  Expected:0x006D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR2 is set to default value 00B4*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR2);

            if(u16ReadWord != 0x00B4)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x45;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR2(0x826)  Expected:0x00B4 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR2(0x826)  Expected:0x00B4 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR3 is set to default value 00DB*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR3);

            if(u16ReadWord !=0x00DB)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x46;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR3(0x828)  Expected:0x00DB Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR3(0x828)  Expected:0x00DB Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR4 is set to default value 0150*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR4);

            if(u16ReadWord != 0x0150)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x47;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC_THR4(0x82A)  Expected:0x0150 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR4(0x82A)  Expected:0x0150 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR5 is set to default value 01B5*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR5);

            if(u16ReadWord != 0x01B5)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x48;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_THR5(0x82C)  Expected:0x01B5 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR5(0x82C)  Expected:0x01B5 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR6 is set to default value 02C6*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR6);

            if(u16ReadWord != 0x02C6)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x49;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR6(0x82E)  Expected:0x02C6 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR6(0x82E)  Expected:0x02C6 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR7 is set to default value 0334*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR7);

            if(u16ReadWord != 0x0334)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC_THR7(0x830)  Expected:0x0334 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR7(0x830)  Expected:0x0334 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that INT_EN register is set for CC ,PWR , VBUS interrupts*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, UPDINTR_INT_EN);

            u16ReadWord &= 0x0601;

            if(u16ReadWord !=0x0601)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print UPDINTR_INT_EN(0x0014)* 0601  Expected:0x0601 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPDINTR_INT_EN(0x0014)* 0601  Expected:0x0601 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that PWR_INT_EN register is set for VBUS_MATCH_VLD,VCONN Over-Current Error interrupts*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_PWR_INT_EN);

            if(u8ReadByte != 0x81)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//                    
//                  /*Print PWR_INT_EN(0x815)  Expected:0x81 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("PWR_INT_EN(0x815)  Expected:0x81 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_INT_EN register is set for CC_MATCH_VLD,CC1_MATCH_CHG,CC2_MATCH_CHG interrupts*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_INT_EN);

            if(u8ReadByte != 0x83)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_INT_EN(0x811)  Expected:0x83 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_INT_EN(0x811))  Expected:0x83 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that VBUS Sample Clock is set for 20KHZ*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_VBUS_SAMP_CLK);

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print UPD_VBUS_SAMP_CLK(0x1007)  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPD_VBUS_SAMP_CLK(0x1007)  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC Sample Clock is set for 20KHZ*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_CC_SAMP_CLK);

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print UPD_CC_SAMP_CLK(0x1006)  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPD_CC_SAMP_CLK(0x1006)  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that MATCH_DB_UNITS is set as 1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL_HIGH);

            u8ReadByte &= 0x08;

            if(u8ReadByte != 0x08)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x50;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print CC_HW_CTL_HIGH(0x801)*08  Expected:0x08 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL_HIGH(0x801)*08  Expected:0x08 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that PM V2I Enable is set as 1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_TRIM_ZTC_BYTE_3);

            if(u8ReadByte != 0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x51;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print TRIM_ZTC(0x9A)  Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TRIM_ZTC(0x9A)  Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            break;

        }

        /*Test ID: TYPEC_INIT_SOURCE_15A_CURR*/
        case 45:
        {

            /*Setting the u8PortCfgData variable to 11 to indicate the default setting as
            Source 1.5A Current*/
            gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
            gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
            gasPortConfigurationData[0].u32CfgData |= (RP_VAL_1P5A << TYPEC_PORT_RPVAL_POS);

           /*Calling the TypeC_InitPort API to do Type C Port initlization*/
           TypeC_InitPort (u8PortNum);

           /*Verify that CC Comparator is enabled on both CC1 and CC2
            Pull Down and Pull up resistors are set as per given input*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_CTL1);

            if(u16ReadWord != 0x6A1B)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x52;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_CTL(0x0820) Expected:6A1B Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL(0x0820) Expected:6A1B Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that VBUS Comparator is enabled.
            VBUS Debouncer Units is set as 1*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_CTL1);

            u16ReadWord &= 0x4001;

            if(u16ReadWord != 0x4001)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x39;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print VBUS_CTL1(0x0820)*0x4001 Expected:0x4001 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1(0x0820)*0x4001 Expected:0x4001 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            /*Verify the VCONN Debounce register whether set as 2*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VCONN_DEB);

            if(u8ReadByte != 0x02)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;


//                  /*Print VCONN_DEB(0x819) Expected:0x02 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VCONN_DEB(0x819) Expected:0x02  Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

             /*Verify that VBUS_MATCH_EN is set to 0x05 */
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_MATCH_EN);

            if(u8ReadByte !=0x7D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

                
//                  /*Print VBUS_MATCH_EN(0x814)  Expected:0x3D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_MATCH_EN(0x814)  Expected:0x3D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the VBUS_DBCLR_EN is set to 0x05*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_DBCLR_EN);

            if(u8ReadByte !=0x7D)
            {                 
              
                gu8HermesResBuffer[errorcodePos] = 0x3C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print VBUS_DBCLR_EN(0x81C)  Expected:0x3D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_DBCLR_EN(0x81C)  Expected:0x3D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verify that the VBUS_SAMP_EN is set to 0x05*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_SAMP_EN);

            if(u8ReadByte !=0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print VBUS_SAMP_EN(0x81F)  Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_SAMP_EN(0x81F)  Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that both the CC2_DBCLR_EN and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x14;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that only the CC1_MATCH_EN and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x15;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//                    
//                  /*Print CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            /*Verify that only the CC1_SAMP_EN and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x2222)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x16;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:0x2222 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that the VBUS Debounce units is set as 4*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_DEB);

             if(u8ReadByte != 0x14)
            {                  
                
                gu8HermesResBuffer[errorcodePos] = 0x3E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_DEB(0x84A)  Expected:0x14 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_DEB(0x84A)  Expected:0x14 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verifying that mode is set as Companion and role as DFP*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL);

            u8ReadByte &= 05;

             if(u8ReadByte !=0x04)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print CC_HW_CTL(0x800)*05   Expected:0x04 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL(0x800)*05   Expected:0x04 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verifying that VBUS_DEB_BLK_EN is set*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL2);

            u8ReadByte &= 0x01;

            if(u8ReadByte != 0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x40;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_CTL2(0x83F)*01   Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL2(0x83F)*01   Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verifying that VBUS_THR0 is set to default value 0094*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_THR0);

            if(u16ReadWord !=0x0096)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x41;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//                    
//                  /*Print VBUS_THR0(0x8B0)  Expected:0x00C2 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_THR0(0x8B0)  Expected:0x00C2 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that VBUS_THR1 is set to default value 00DE*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_THR1);

            if(u16ReadWord !=0x00DA)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x42;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print VBUS_THR1(0x8B2)  Expected:0x00DA Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_THR1(0x8B2)  Expected:0x00DA Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR0 is set to default value 0037*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR0);

            if(u16ReadWord != 0x0037)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x43;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR0(0x822)  Expected:0x0037 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR0(0x822)  Expected:0x0037 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR1 is set to default value 006D*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR1);

            if(u16ReadWord != 0x006D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x44;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR1(0x824)  Expected:0x006D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR1(0x824)  Expected:0x006D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR2 is set to default value 00B4*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR2);

            if(u16ReadWord != 0x00B4)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x45;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR2(0x826)  Expected:0x00B4 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR2(0x826)  Expected:0x00B4 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR3 is set to default value 00DB*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR3);

            if(u16ReadWord !=0x00DB)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x46;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR3(0x828)  Expected:0x00DB Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR3(0x828)  Expected:0x00DB Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR4 is set to default value 0150*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR4);

            if(u16ReadWord != 0x0150)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x47;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR4(0x82A)  Expected:0x0150 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR4(0x82A)  Expected:0x0150 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;
            }

            /*Verifying that CC_THR5 is set to default value 01B5*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR5);

            if(u16ReadWord != 0x01B5)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x48;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR5(0x82C)  Expected:0x01B5 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR5(0x82C)  Expected:0x01B5 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR6 is set to default value 02C6*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR6);

            if(u16ReadWord != 0x02C6)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x49;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//                    
//                  /*Print CC_THR6(0x82E)  Expected:0x02C6 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR6(0x82E)  Expected:0x02C6 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR7 is set to default value 0334*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR7);

            if(u16ReadWord != 0x0334)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR7(0x830)  Expected:0x0334 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR7(0x830)  Expected:0x0334 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that INT_EN register is set for CC ,PWR , VBUS interrupts*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, UPDINTR_INT_EN);

            u16ReadWord &= 0x0601;

            if(u16ReadWord !=0x0601)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//                    
//                  /*Print UPDINTR_INT_EN(0x0014)* 0601  Expected:0x0601 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPDINTR_INT_EN(0x0014)* 0601  Expected:0x0601 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that PWR_INT_EN register is set for VBUS_MATCH_VLD,VCONN Over-Current Error interrupts*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_PWR_INT_EN);

            if(u8ReadByte != 0x81)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
                
//                  /*Print PWR_INT_EN(0x815)  Expected:0x81 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("PWR_INT_EN(0x815)  Expected:0x81 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_INT_EN register is set for CC_MATCH_VLD,CC1_MATCH_CHG,CC2_MATCH_CHG interrupts*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_INT_EN);

            if(u8ReadByte != 0x83)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
              
//                  /*Print CC_INT_EN(0x811)  Expected:0x83 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_INT_EN(0x811))  Expected:0x83 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that VBUS Sample Clock is set for 20KHZ*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_VBUS_SAMP_CLK);

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print UPD_VBUS_SAMP_CLK(0x1007)  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPD_VBUS_SAMP_CLK(0x1007)  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;
            }

            /*Verifying that CC Sample Clock is set for 20KHZ*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_CC_SAMP_CLK);

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print UPD_CC_SAMP_CLK(0x1006)  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPD_CC_SAMP_CLK(0x1006)  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that MATCH_DB_UNITS is set as 1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL_HIGH);

            u8ReadByte &= 0x08;

            if(u8ReadByte != 0x08)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x50;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print CC_HW_CTL_HIGH(0x801)*08  Expected:0x08 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL_HIGH(0x801)*08  Expected:0x08 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that PM V2I Enable is set as 1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_TRIM_ZTC_BYTE_3);

            if(u8ReadByte != 0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x51;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print TRIM_ZTC(0x9A)  Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TRIM_ZTC(0x9A)  Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            break;

        }
        /*Test ID: TYPEC_INIT_SOURCE_30A_CURR*/
        case 46:
        {

            /*Setting the u8PortCfgData variable to 15 to indicate the default setting as
            Source 3.0A Current*/
            gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
            gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
            gasPortConfigurationData[0].u32CfgData |= (RP_VAL_3A << TYPEC_PORT_RPVAL_POS);

           /*Calling the TypeC_InitPort API to do Type C Port initlization*/
           TypeC_InitPort (u8PortNum);

           /*Verify that CC Comparator is enabled on both CC1 and CC2
            Pull Down and Pull up resistors are set as per given input*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_CTL1);

            if(u16ReadWord != 0x6F1B)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x53;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_CTL(0x0820) Expected:0x6F1B Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL(0x0820) Expected:0x6F1B Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that VBUS Comparator is enabled.
            VBUS Debouncer Units is set as 1*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_CTL1);

            u16ReadWord &= 0x4001;

            if(u16ReadWord != 0x4001)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x39;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print VBUS_CTL1(0x0820)*0x4001 Expected:0x4001 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1(0x0820)*0x4001 Expected:0x4001 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            /*Verify the VCONN Debounce register whether set as 2*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VCONN_DEB);

            if(u8ReadByte != 0x02)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print VCONN_DEB(0x819) Expected:0x02 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VCONN_DEB(0x819) Expected:0x02  Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

             /*Verify that VBUS_MATCH_EN is set to 0x05 */
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_MATCH_EN);

            if(u8ReadByte !=0x7D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_MATCH_EN(0x814)  Expected:0x3D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_MATCH_EN(0x814)  Expected:0x3D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the VBUS_DBCLR_EN is set to 0x05*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_DBCLR_EN);

            if(u8ReadByte !=0x7D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_DBCLR_EN(0x81C)  Expected:0x3D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_DBCLR_EN(0x81C)  Expected:0x3D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verify that the VBUS_SAMP_EN is set to 0x05*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_SAMP_EN);

            if(u8ReadByte !=0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_SAMP_EN(0x81F)  Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_SAMP_EN(0x81F)  Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that both the CC2_DBCLR_EN and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x17;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that only the CC1_MATCH_EN and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x18;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//                    
//                  /*Print CC1_MATCH_EN(0x812)  Expected:4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            /*Verify that only the CC1_SAMP_EN and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x4848)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x19;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:4848 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:4848 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that the VBUS Debounce units is set as 4*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_DEB);

             if(u8ReadByte != 0x14)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print VBUS_DEB(0x84A)  Expected:0x14 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_DEB(0x84A)  Expected:0x14 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verifying that mode is set as Companion and role as DFP*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL);

            u8ReadByte &= 05;

             if(u8ReadByte !=0x04)
            {                 
              
                gu8HermesResBuffer[errorcodePos] = 0x3F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print CC_HW_CTL(0x800)*05   Expected:0x04 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL(0x800)*05   Expected:0x04 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verifying that VBUS_DEB_BLK_EN is set*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL2);

            u8ReadByte &= 0x01;

            if(u8ReadByte != 0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x40;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print VBUS_CTL2(0x83F)*01   Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL2(0x83F)*01   Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verifying that VBUS_THR0 is set to default value 0094*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_THR0);

            if(u16ReadWord !=0x0096)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x41;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print VBUS_THR0(0x8B0)  Expected:0x00C2 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_THR0(0x8B0)  Expected:0x00C2 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verifying that VBUS_THR1 is set to default value 00DE*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_THR1);

            if(u16ReadWord !=0x00DA)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x42;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print VBUS_THR1(0x8B2)  Expected:0x00DA Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_THR1(0x8B2)  Expected:0x00DA Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR0 is set to default value 0037*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR0);

            if(u16ReadWord != 0x0037)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x43;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC_THR0(0x822)  Expected:0x0037 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR0(0x822)  Expected:0x0037 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR1 is set to default value 006D*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR1);

            if(u16ReadWord != 0x006D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x44;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_THR1(0x824)  Expected:0x006D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR1(0x824)  Expected:0x006D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR2 is set to default value 00B4*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR2);

            if(u16ReadWord != 0x00B4)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x45;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_THR2(0x826)  Expected:0x00B4 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR2(0x826)  Expected:0x00B4 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR3 is set to default value 00DB*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR3);

            if(u16ReadWord !=0x00DB)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x46;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_THR3(0x828)  Expected:0x00DB Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR3(0x828)  Expected:0x00DB Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR4 is set to default value 0150*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR4);

            if(u16ReadWord != 0x0150)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x47;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC_THR4(0x82A)  Expected:0x0150 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR4(0x82A)  Expected:0x0150 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR5 is set to default value 01B5*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR5);

            if(u16ReadWord != 0x01B5)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x48;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_THR5(0x82C)  Expected:0x01B5 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR5(0x82C)  Expected:0x01B5 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR6 is set to default value 02C6*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR6);

            if(u16ReadWord != 0x02C6)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x49;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_THR6(0x82E)  Expected:0x02C6 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR6(0x82E)  Expected:0x02C6 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR7 is set to default value 0334*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR7);

            if(u16ReadWord != 0x0334)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC_THR7(0x830)  Expected:0x0334 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR7(0x830)  Expected:0x0334 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that INT_EN register is set for CC ,PWR , VBUS interrupts*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, UPDINTR_INT_EN);

            u16ReadWord &= 0x0601;

            if(u16ReadWord !=0x0601)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print UPDINTR_INT_EN(0x0014)* 0601  Expected:0x0601 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPDINTR_INT_EN(0x0014)* 0601  Expected:0x0601 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that PWR_INT_EN register is set for VBUS_MATCH_VLD,VCONN Over-Current Error interrupts*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_PWR_INT_EN);

            if(u8ReadByte != 0x81)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print PWR_INT_EN(0x815)  Expected:0x81 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("PWR_INT_EN(0x815)  Expected:0x81 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_INT_EN register is set for CC_MATCH_VLD,CC1_MATCH_CHG,CC2_MATCH_CHG interrupts*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_INT_EN);

            if(u8ReadByte != 0x83)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
              
//                  /*Print CC_INT_EN(0x811)  Expected:0x83 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_INT_EN(0x811))  Expected:0x83 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that VBUS Sample Clock is set for 20KHZ*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_VBUS_SAMP_CLK);

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print UPD_VBUS_SAMP_CLK(0x1007)  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPD_VBUS_SAMP_CLK(0x1007)  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;
            }

            /*Verifying that CC Sample Clock is set for 20KHZ*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_CC_SAMP_CLK);

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print UPD_CC_SAMP_CLK(0x1006)  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPD_CC_SAMP_CLK(0x1006)  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

             /*Verifying that MATCH_DB_UNITS is set as 1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL_HIGH);

            u8ReadByte &= 0x08;

            if(u8ReadByte != 0x08)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x50;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print CC_HW_CTL_HIGH(0x801)*08  Expected:0x08 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL_HIGH(0x801)*08  Expected:0x08 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that PM V2I Enable is set as 1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_TRIM_ZTC_BYTE_3);

            if(u8ReadByte != 0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x51;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//                    
//                  /*Print TRIM_ZTC(0x9A)  Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TRIM_ZTC(0x9A)  Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            break;
        }

        /*Test ID: TYPEC_INIT_SINK*/
        case 47:
        {

            /*Setting the u8PortCfgData variable to 00 to indicate the default setting as
            Sink*/
            gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
            gasPortConfigurationData[0].u32CfgData  |= PD_ROLE_SINK;
             gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
             gasPortConfigurationData[0].u32CfgData  |= (RP_VAL_RD << TYPEC_PORT_RPVAL_POS);

           /*Calling the TypeC_InitPort API to do Type C Port initlization*/
           TypeC_InitPort (u8PortNum);

           /*Verify that CC Comparator is enabled on both CC1 and CC2
            Pull Down and Pull up resistors are set as per given input*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_CTL1);

            if(u16ReadWord != 0x6009)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x54;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_CTL(0x0820) Expected:6009 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_CTL(0x0820) Expected:6009 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that VBUS Comparator is enabled.
            VBUS Debouncer Units is set as 1*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_CTL1);

            u16ReadWord &= 0x4001;

            if(u16ReadWord != 0x4001)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x39;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print VBUS_CTL1(0x0820)*0x4001 Expected:0x4001 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL1(0x0820)*0x4001 Expected:0x4001 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }
            /*Verify the VCONN Debounce register whether set as 2*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VCONN_DEB);

            if(u8ReadByte != 0x02)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print VCONN_DEB(0x819) Expected:0x02 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VCONN_DEB(0x819) Expected:0x02  Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

             /*Verify that VBUS_MATCH_EN is set to 0x05 */
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_MATCH_EN);

            if(u8ReadByte !=0x7D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print VBUS_MATCH_EN(0x814)  Expected:0x3D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_MATCH_EN(0x814)  Expected:0x3D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that the VBUS_DBCLR_EN is set to 0x05*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_DBCLR_EN);

            if(u8ReadByte !=0x7D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print VBUS_DBCLR_EN(0x81C)  Expected:0x3D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_DBCLR_EN(0x81C)  Expected:0x3D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verify that the VBUS_SAMP_EN is set to 0x05*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_SAMP_EN);

            if(u8ReadByte !=0x0D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print VBUS_SAMP_EN(0x81F)  Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_SAMP_EN(0x81F)  Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }

            /*Verify that both the CC2_DBCLR_EN and CC1_DBCLR_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_DBCLR_EN);

            if(u16ReadWord != 0x9595)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x0E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC1_DBCLR_EN(0x81A)  Expected:1515 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_DBCLR_EN(0x81A)  Expected:1515 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verify that only the CC1_MATCH_EN and CC2_MATCH_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_MATCH_EN);

            if(u16ReadWord != 0x9595)
            {
                                  
                gu8HermesResBuffer[errorcodePos] = 0x0F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
                
//                  /*Print CC1_MATCH_EN(0x812)  Expected:1515 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC1_MATCH_EN(0x812)  Expected:1515 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }
            /*Verify that only the CC1_SAMP_EN and CC2_SAMP_EN is set */
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC1_SAMP_EN);

            if(u16ReadWord != 0x9595)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x10;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print TYPEC_CC1_SAMP_EN(0x81D)  Expected:1515 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TYPEC_CC1_SAMP_EN(0x81D)  Expected:1515 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verifying that the VBUS Debounce units is set as 4*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_DEB);

             if(u8ReadByte != 0x14)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x3E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print VBUS_DEB(0x84A)  Expected:0x14 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_DEB(0x84A)  Expected:0x14 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }
            /*Verifying that mode is set as Companion and role as DFP*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL);

            u8ReadByte &= 05;

             if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x54;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print CC_HW_CTL(0x800)*05   Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL(0x800)*05   Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;

            }
            /*Verifying that VBUS_DEB_BLK_EN is set*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_VBUS_CTL2);

            u8ReadByte &= 0x01;

            if(u8ReadByte != 0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x40;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print VBUS_CTL2(0x83F)*01   Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_CTL2(0x83F)*01   Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;

            }

            /*Verifying that VBUS_THR0 is set to default value 0094*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_THR0);

            if(u16ReadWord !=0x0096)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x41;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print VBUS_THR0(0x8B0)  Expected:0x00C2 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_THR0(0x8B0)  Expected:0x00C2 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verifying that VBUS_THR1 is set to default value 00DE*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_VBUS_THR1);

            if(u16ReadWord !=0x00C2)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x42;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print VBUS_THR1(0x8B2)  Expected:0x00DA Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("VBUS_THR1(0x8B2)  Expected:0x00DA Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR0 is set to default value 0037*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR0);

            if(u16ReadWord != 0x0037)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x43;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC_THR0(0x822)  Expected:0x0037 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR0(0x822)  Expected:0x0037 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;

            }

            /*Verifying that CC_THR1 is set to default value 006D*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR1);

            if(u16ReadWord != 0x006D)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x44;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC_THR1(0x824)  Expected:0x006D Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR1(0x824)  Expected:0x006D Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;

            }

            /*Verifying that CC_THR2 is set to default value 00B4*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR2);

            if(u16ReadWord != 0x00B4)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x45;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_THR2(0x826)  Expected:0x00B4 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR2(0x826)  Expected:0x00B4 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;
            }

            /*Verifying that CC_THR3 is set to default value 00DB*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR3);

            if(u16ReadWord !=0x00DB)
            {
                               
                gu8HermesResBuffer[errorcodePos] = 0x46;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC_THR3(0x828)  Expected:0x00DB Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR3(0x828)  Expected:0x00DB Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;
            }

            /*Verifying that CC_THR4 is set to default value 0150*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR4);

            if(u16ReadWord != 0x0150)
            {
                               
                gu8HermesResBuffer[errorcodePos] = 0x47;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//                    
//                  /*Print CC_THR4(0x82A)  Expected:0x0150 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR4(0x82A)  Expected:0x0150 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;
            }

            /*Verifying that CC_THR5 is set to default value 01B5*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR5);

            if(u16ReadWord != 0x01B5)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x48;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC_THR5(0x82C)  Expected:0x01B5 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR5(0x82C)  Expected:0x01B5 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
              u8TestRes = FALSE;
            }

            /*Verifying that CC_THR6 is set to default value 02C6*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR6);

            if(u16ReadWord != 0x02C6)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x49;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;
//
//                  /*Print CC_THR6(0x82E)  Expected:0x02C6 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR6(0x82E)  Expected:0x02C6 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that CC_THR7 is set to default value 0334*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, TYPEC_CC_THR7);

            if(u16ReadWord != 0x0334)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4A;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print CC_THR7(0x830)  Expected:0x0334 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_THR7(0x830)  Expected:0x0334 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that INT_EN register is set for CC ,PWR , VBUS interrupts*/
            u16ReadWord = UPD_RegReadWord (u8PortNum, UPDINTR_INT_EN);

            u16ReadWord &= 0x0601;

            if(u16ReadWord !=0x0601)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4B;
                gu8HermesResBuffer[errorcodePos + 1] = 0x02;
                gu8HermesResBuffer[errorcodePos + 2] = LOBYTE(u16ReadWord);
                gu8HermesResBuffer[errorcodePos + 3] = HIBYTE(u16ReadWord);
                errorcodePos += 4;
                errorcnt++;

//                  /*Print UPDINTR_INT_EN(0x0014)* 0601  Expected:0x0601 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPDINTR_INT_EN(0x0014)* 0601  Expected:0x0601 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT16(u16ReadWord); 
                u8TestRes = FALSE;
            }

            /*Verifying that PWR_INT_EN register is set for VBUS_MATCH_VLD,VCONN Over-Current Error interrupts*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_PWR_INT_EN);

            if(u8ReadByte != 0x81)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4C;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;

//                  /*Print PWR_INT_EN(0x815)  Expected:0x81 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("PWR_INT_EN(0x815)  Expected:0x81 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;
            }

            /*Verifying that CC_INT_EN register is set for CC_MATCH_VLD,CC1_MATCH_CHG,CC2_MATCH_CHG interrupts*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_INT_EN);

            if(u8ReadByte != 0x83)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4D;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print CC_INT_EN(0x811)  Expected:0x83 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_INT_EN(0x811))  Expected:0x83 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;
            }

            /*Verifying that VBUS Sample Clock is set for 20KHZ*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_VBUS_SAMP_CLK);

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4E;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print UPD_VBUS_SAMP_CLK(0x1007)  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPD_VBUS_SAMP_CLK(0x1007)  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
              u8TestRes = FALSE;
            }

            /*Verifying that CC Sample Clock is set for 20KHZ*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_CC_SAMP_CLK);

            if(u8ReadByte != 0x00)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x4F;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print UPD_CC_SAMP_CLK(0x1006)  Expected:0x00 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("UPD_CC_SAMP_CLK(0x1006)  Expected:0x00 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

             /*Verifying that MATCH_DB_UNITS is set as 1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, TYPEC_CC_HW_CTL_HIGH);

            u8ReadByte &= 0x08;

            if(u8ReadByte != 0x08)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x50;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
//
//                  /*Print CC_HW_CTL_HIGH(0x801)*08  Expected:0x08 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("CC_HW_CTL_HIGH(0x801)*08  Expected:0x08 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            /*Verifying that PM V2I Enable is set as 1*/
            u8ReadByte = UPD_RegReadByte (u8PortNum, UPD_TRIM_ZTC_BYTE_3);

            if(u8ReadByte != 0x01)
            {
              
                gu8HermesResBuffer[errorcodePos] = 0x51;
                gu8HermesResBuffer[errorcodePos + 1] = 0x01;
                gu8HermesResBuffer[errorcodePos + 2] = u8ReadByte;
                errorcodePos += 3;
                errorcnt++;
                
//                  /*Print TRIM_ZTC(0x9A)  Expected:0x01 Current Value:0x*/
//                  CONFIG_HOOK_DEBUG_STRING("TRIM_ZTC(0x9A)  Expected:0x01 Current Value:0x");
//                  CONFIG_HOOK_DEBUG_UINT8(u8ReadByte); 
                u8TestRes = FALSE;
            }

            break;
        }

    }
    
    /*Update the 0th byte of buffer for test results*/
    gu8HermesResBuffer[0] = u8TestRes ;
        
    /*Update the 1st byte of buffer for number of error counts*/
    gu8HermesResBuffer[1] = errorcnt ;
#ifndef _IDEAL_    
    I2C_SlaveIRQdrive (0);
#endif
}


void TypeCVal_SMTests(UINT8* pu8HermesReqBuffer)
{

    UINT8 u8PortNum =0;
    UINT8 u8Data = 0;
    UINT8 u8TestCaseId = gu8HermesReqBuffer[2]; 
    
    UPD_RegisterReadISR (u8PortNum, UPD_HW_CTL, &u8Data, BYTE_LEN_1);
            
    u8Data |= 0x01; 

    UPD_RegisterWriteISR (u8PortNum, UPD_HW_CTL, &u8Data, BYTE_LEN_1);
    
    WaitUntilSPITestRegister(u8PortNum); 
    
    gasTypeCcontrol[u8PortNum].u8PortSts = 0x00;
    
    CONFIG_HOOK_HW_PORTPWR_INIT();
    
     /*Drive VBus for vSafe0V to get the power module in intial state*/
    CONFIG_HOOK_PORTPWR_DRIVE_VBUS (u8PortNum, PWRCTRL_VBUS_0V);

    switch(u8TestCaseId)
    {

        /*Test ID: TYPEC_SRCDEF_SINKATT_CC1*/
        case 1:
        {
            /*Setting typeC variable to Source  default current configuration*/
            TypeCVal_SetPortConfigSrcDefault(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC1*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }

        /*Test ID: TYPEC_SRCDEF_SINKATT_CC2*/
        case 2:
        {
            /*Setting typeC variable to Source  default current configuration*/
            TypeCVal_SetPortConfigSrcDefault(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC2*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }

        /*Test ID: TYPEC_SRC15A_SINKATT_CC1*/
        case 3:
        {
            /*Setting typeC variable to Source  1.5A current configuration*/
            TypeCVal_SetPortConfigSrc15A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC1*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);

            /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }

        /*Test ID: TYPEC_SRC15A_SINKATT_CC2*/
        case 4:
        {
             /*Setting typeC variable to Source  1.5A current configuration*/
            TypeCVal_SetPortConfigSrc15A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC2*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);

            /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
            
             TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }
        /*Test ID: TYPEC_SRC30A_SINKATT_CC1*/
        case 5:
        {
            /*Setting typeC variable to Source  3.0A current configuration*/
            TypeCVal_SetPortConfigSrc30A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC1*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);

            /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
            
             TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }

        /*Test ID: TYPEC_SRC30A_SINKATT_CC2*/
        case 6:
        {
            /*Setting typeC variable to Source  3.0A current configuration*/
            TypeCVal_SetPortConfigSrc30A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC2*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);

            /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }

        /*Test ID: TYPEC_SRCDEF_ATT_SINKCC1_PCCC2*/
        case 7:
        {
            
            /*Setting typeC variable to Source default current configuration*/
            TypeCVal_SetPortConfigSrcDefault(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC1*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting type C Variable to indicate powered cable attachment in CC2*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);
            
            TypeCVal_SetVConnOnStatus(u8PortNum, TYPECVAL_CC2PIN);

            break;

        }

        /*Test ID: TYPEC_SRCDEF_ATT_SINKCC2_PCCC1*/
        case 8:
        {
            /*Setting typeC variable to Source  default current configuration*/
            TypeCVal_SetPortConfigSrcDefault(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting type C Variable to indicate powered cable attachment in CC1*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);
            
            /*Setting the Type C Variable to indicate sink attachment in CC2*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);
            
             TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);
    
            TypeCVal_SetVConnOnStatus(u8PortNum, TYPECVAL_CC1PIN);
            break;

        }

        /*Test ID: TYPEC_SRC15A_ATT_SINKCC1_PCCC2*/
        case 9:
        {
            /*Setting typeC variable to Source  1.5A current configuration*/
            TypeCVal_SetPortConfigSrc15A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC1*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);

            /*Setting type C Variable to indicate powered cable attachment in CC2*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);
            
            TypeCVal_SetVConnOnStatus(u8PortNum, TYPECVAL_CC2PIN);

            break;

        }

        /*Test ID: TYPEC_SRC15A_ATT_SINKCC2_PCCC1*/
        case 10:
        {
             /*Setting typeC variable to Source  1.5A current configuration*/
            TypeCVal_SetPortConfigSrc15A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC2*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);

            /*Setting type C Variable to indicate powered cable attachment in CC1*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);
            
            TypeCVal_SetVConnOnStatus(u8PortNum, TYPECVAL_CC1PIN);

            break;

        }
        /*Test ID: TYPEC_SRC30A_ATT_SINKCC1_PCCC2*/
        case 11:
        {
            /*Setting typeC variable to Source  3.0A current configuration*/
            TypeCVal_SetPortConfigSrc30A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC1*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);

             /*Setting type C Variable to indicate powered cable attachment in CC2*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);
            
            TypeCVal_SetVConnOnStatus(u8PortNum, TYPECVAL_CC2PIN);

            break;

        }

        /*Test ID: TYPEC_SRC30A_ATT_SINKCC2_PCCC1*/
        case 12:
        {
            /*Setting typeC variable to Source  3.0A current configuration*/
            TypeCVal_SetPortConfigSrc30A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate sink attachment in CC2*/
            TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);

             /*Setting type C Variable to indicate powered cable attachment in CC1*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);
            
            TypeCVal_SetVConnOnStatus(u8PortNum, TYPECVAL_CC1PIN);

            break;

        }
        /*Test ID: TYPEC_SRCDEF_PCATT_CC2*/
        case 13:
        {
            /*Setting typeC variable to Source  default current configuration*/
            TypeCVal_SetPortConfigSrcDefault(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

            /*Setting type C Variable to indicate powered cable attachment in CC2*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);
            
             TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);
            
            TypeCVal_SetVConnOnStatus(u8PortNum, 2);

            break;

        }

        /*Test ID: TYPEC_SRCDEF_PCATT_CC1*/
        case 14:
        {
            /*Setting typeC variable to Source  default current configuration*/
            TypeCVal_SetPortConfigSrcDefault(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

            /*Setting type C Variable to indicate powered cable attachment in CC1*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);
            
             TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);
            
            TypeCVal_SetVConnOnStatus(u8PortNum, 2);

            break;

        }

        /*Test ID: TYPEC_SRC15A_PCATT_CC2*/
        case 15:
        {
            /*Setting typeC variable to Source  1.5A current configuration*/
            TypeCVal_SetPortConfigSrc15A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

            /*Setting type C Variable to indicate powered cable attachment in CC2*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }

        /*Test ID: TYPEC_SRC15A_PCATT_CC1*/
        case 16:
        {
             /*Setting typeC variable to Source  1.5A current configuration*/
            TypeCVal_SetPortConfigSrc15A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

            /*Setting type C Variable to indicate powered cable attachment in CC1*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }
        /*Test ID: TYPEC_SRC30A_PCATT_CC2*/
        case 17:
        {
            /*Setting typeC variable to Source  3.0A current configuration*/
            TypeCVal_SetPortConfigSrc30A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

             /*Setting type C Variable to indicate powered cable attachment in CC2*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }

        /*Test ID: TYPEC_SRC30A_PCATT_CC1*/
        case 18:
        {
            /*Setting typeC variable to Source  3.0A current configuration*/
            TypeCVal_SetPortConfigSrc30A(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

             /*Setting type C Variable to indicate powered cable attachment in CC1*/
            TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);
            
            TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            break;

        }

        /*Below Test cases are implemented as Sub test cases to simulate the time deley between
        test steps.Time Delay is coded in Validation Tool*/


        /*Test ID: TYPEC_SRCDEF_SINKDET_CC1*/
        case 19:
        {
            switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink device attachment in CC1*/
                case 0:
                {
                    /*Setting typeC variable to Source  default current configuration*/
                    TypeCVal_SetPortConfigSrcDefault(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC1*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
                    
                     TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink device detachment in CC1*/
                case 1:
                {
                    /*Setting the CC1 register to 00 to indicate sink detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

            }
            break;
        }

        /*Test ID: TYPEC_SRCDEF_SINKDET_CC2*/
        case 20:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink device attachment in CC2*/
                case 0:
                {
                    /*Setting typeC variable to Source  default current configuration*/
                    TypeCVal_SetPortConfigSrcDefault(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC2*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
                    
                     TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink device detachment in CC2*/
                case 1:
                {
                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;
        }

        /*Test ID: TYPEC_SRC15A_SINKDET_CC1*/
        case 21:
        {

             switch(pu8HermesReqBuffer[3])
            {
                /*Case 0 Simulates a sink device attachment in CC1*/
                case 0:
                {
                    /*Setting typeC variable to Source  1.5A current configuration*/
                    TypeCVal_SetPortConfigSrc15A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC1*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);

                    /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink device detachment in CC1*/
                case 1:
                {
                    /*Setting the CC1 register to 00 to indicate sink detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;

        }

        /*Test ID: TYPEC_SRC15A_SINKDET_CC2*/
        case 22:
        {
            switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink device attachment in CC2*/
                case 0:
                {
                     /*Setting typeC variable to Source  1.5A current configuration*/
                    TypeCVal_SetPortConfigSrc15A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC2*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);

                    /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink device detachment in CC2*/
                case 1:
                {
                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;
        }
        /*Test ID: TYPEC_SRC30A_SINKDET_CC1*/
        case 23:
        {
              switch(pu8HermesReqBuffer[3])
            {
                /*Case 0 Simulates a sink device attachment in CC1*/
                case 0:
                {
                    /*Setting typeC variable to Source  3.0A current configuration*/
                    TypeCVal_SetPortConfigSrc30A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC1*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);

                    /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink device detachment in CC1*/
                case 1:
                {
                    /*Setting the CC1 register to 00 to indicate sink detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;
        }

        /*Test ID: TYPEC_SRC30A_SINKDET_CC2*/
        case 24:
        {

            switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink device attachment in CC2*/
                case 0:
                {
                    /*Setting typeC variable to Source  3.0A current configuration*/
                    TypeCVal_SetPortConfigSrc30A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC2*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);

                    /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink device detachment in CC2*/
                case 1:
                {
                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;
        }

        /*Test ID: TYPEC_SRCDEF_DET_SINKCC1_PCCC2*/
        case 25:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC1 and CC2*/
                case 0:
                {
                    /*Setting typeC variable to Source  default current configuration*/
                    TypeCVal_SetPortConfigSrcDefault(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC1*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting type C Variable to indicate powered cable attachment in CC2*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink and powered cable device detachment in CC1 and CC2*/
                case 1:
                {

                    /*Setting the CC1 register to 00 to indicate sink detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the CC2 register to 00 to indicate poweredcable detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;

        }

        /*Test ID: TYPEC_SRCDEF_DET_SINKCC2_PCCC1*/
        case 26:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC2 and CC1*/
                case 0:
                {
                     /*Setting typeC variable to Source  default current configuration*/
                    TypeCVal_SetPortConfigSrcDefault(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC2*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting type C Variable to indicate powered cable attachment in CC1*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);
                    
                     TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink and powered cable device detachment in CC2 and CC1*/
                case 1:
                {

                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the CC1 register to 00 to indicate poweredcable detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;

        }

        /*Test ID: TYPEC_SRC15A_DET_SINKCC1_PCCC2*/
        case 27:
        {

             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC1 and CC2*/
                case 0:
                {
                     /*Setting typeC variable to Source  1.5A current configuration*/
                    TypeCVal_SetPortConfigSrc15A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC1*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);

                    /*Setting type C Variable to indicate powered cable attachment in CC2*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink and powered cable device detachment in CC1 and CC2*/
                case 1:
                {

                    /*Setting the CC1 register to 00 to indicate sink detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the CC2 register to 00 to indicate poweredcable detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;

        }

        /*Test ID: TYPEC_SRC15A_DET_SINKCC2_PCCC1*/
        case 28:
        {
              switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC2 and CC1*/
                case 0:
                {
                     /*Setting typeC variable to Source  1.5A current configuration*/
                    TypeCVal_SetPortConfigSrc15A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC2*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);

                    /*Setting type C Variable to indicate powered cable attachment in CC1*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink and powered cable device detachment in CC2 and CC1*/
                case 1:
                {

                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the CC1 register to 00 to indicate poweredcable detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;
        }

        /*Test ID: TYPEC_SRC30A_DET_SINKCC1_PCCC2*/
        case 29:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC1 and CC2*/
                case 0:
                {
                     /*Setting typeC variable to Source  3.0A current configuration*/
                    TypeCVal_SetPortConfigSrc30A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC1*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);

                     /*Setting type C Variable to indicate powered cable attachment in CC2*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink and powered cable device detachment in CC1 and CC2*/
                case 1:
                {

                    /*Setting the CC1 register to 00 to indicate sink detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the CC2 register to 00 to indicate poweredcable detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }

        /*Test ID: TYPEC_SRC30A_DET_SINKCC2_PCCC1*/
        case 30:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC2 and CC1*/
                case 0:
                {
                    /*Setting typeC variable to Source  3.0A current configuration*/
                    TypeCVal_SetPortConfigSrc30A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC2*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);

                     /*Setting type C Variable to indicate powered cable attachment in CC1*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink and powered cable device detachment in CC2 and CC1*/
                case 1:
                {

                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the CC1 register to 00 to indicate poweredcable detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;
        }

        /*Test ID: TYPEC_SRCDEF_DET_SINKCC1_ATT_PCCC2*/
        case 31:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC1 and CC2*/
                case 0:
                {
                     /*Setting typeC variable to Source  default current configuration*/
                    TypeCVal_SetPortConfigSrcDefault(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC1*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting type C Variable to indicate powered cable attachment in CC2*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);
                    
                     TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink detachment in CC1*/
                case 1:
                {

                    /*Setting the CC1 register to 00 to indicate sink detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }

        /*Test ID: TYPEC_SRCDEF_DET_SINKCC2_ATT_PCCC1*/
        case 32:
        {
            switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC2 and CC1*/
                case 0:
                {
                   /*Setting typeC variable to Source  default current configuration*/
                    TypeCVal_SetPortConfigSrcDefault(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC2*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting type C Variable to indicate powered cable attachment in CC1*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);
                    
                     TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink detachment in CC2*/
                case 1:
                {

                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }

        /*Test ID: TYPEC_SRC15A_DET_SINKCC1_ATT_PCCC2*/
        case 33:
        {

            switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC1 and CC2*/
                case 0:
                {
                     /*Setting typeC variable to Source  1.5A current configuration*/
                    TypeCVal_SetPortConfigSrc15A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC1*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);

                    /*Setting type C Variable to indicate powered cable attachment in CC2*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink detachment in CC1*/
                case 1:
                {

                    /*Setting the CC1 register to 00 to indicate sink detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }

        /*Test ID: TYPEC_SRC15A_DET_SINKCC2_ATT_PCCC1*/
        case 34:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC2 and CC1*/
                case 0:
                {
                   /*Setting typeC variable to Source  1.5A current configuration*/
                    TypeCVal_SetPortConfigSrc15A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC2*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);

                    /*Setting type C Variable to indicate powered cable attachment in CC1*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_1A5_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink detachment in CC2*/
                case 1:
                {

                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }
        /*Test ID: TYPEC_SRC30A_DET_SINKCC1_ATT_PCCC2*/
        case 35:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC1 and CC2*/
                case 0:
                {
                     /*Setting typeC variable to Source  3.0A current configuration*/
                    TypeCVal_SetPortConfigSrc30A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC1*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);

                     /*Setting type C Variable to indicate powered cable attachment in CC2*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink detachment in CC1*/
                case 1:
                {

                    /*Setting the CC1 register to 00 to indicate sink detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }

        /*Test ID: TYPEC_SRC30A_DET_SINKCC2_ATT_PCCC1*/
        case 36:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a sink and powered cable device attachment in CC2 and CC1*/
                case 0:
                {
                   /*Setting typeC variable to Source  3.0A current configuration*/
                    TypeCVal_SetPortConfigSrc30A(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);

                    /*Setting the Type C Variable to indicate sink attachment in CC2*/
                    TypeCVal_SetSinkAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);

                     /*Setting type C Variable to indicate powered cable attachment in CC1*/
                    TypeCVal_SetPwdCableAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);
                    
                    TypeC_SetCCDebounceVariable(u8PortNum, TYPEC_DFP_3A0_CURRENT);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }

                 /*Case 1 Simulates a sink detachment in CC2*/
                case 1:
                {

                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;

        }

         /*Test ID: TYPEC_SINK_SRCDEF_ATT_CC1*/
        case 37:
        {
            /*Setting typeC variable to sink configuration*/
            TypeCVal_SetPortConfigSink(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate Source Default current attachment in CC1*/
            TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);
            
            /* Setting VBUS status to Vsafe5V drive */
            TypeCVal_SetVBusStatus(u8PortNum);
            break;

        }

        /*Test ID: TYPEC_SINK_SRCDEF_ATT_CC2*/
        case 38:
        {
            /*Setting typeC variable to sink configuration*/
            TypeCVal_SetPortConfigSink(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate Source Default current attachment in CC2*/
            TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);

            /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            /* Setting VBUS status to Vsafe5V drive */
            TypeCVal_SetVBusStatus(u8PortNum);
            break;

        }

        /*Test ID: TYPEC_SINK_SRC15A_ATT_CC1*/
        case 39:
        {
            /*Setting typeC variable to sink configuration*/
            TypeCVal_SetPortConfigSink(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate Source 1.5A current attachment in CC1*/
            TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);

            /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            /* Setting VBUS status to Vsafe5V drive */
            TypeCVal_SetVBusStatus(u8PortNum);
            break;

        }

        /*Test ID: TYPEC_SINK_SRC15A_ATT_CC2*/
        case 40:
        {

             /*Setting typeC variable to sink configuration*/
            TypeCVal_SetPortConfigSink(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate Source 1.5A current attachment in CC2*/
            TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);

            /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            /* Setting VBUS status to Vsafe5V drive */
            TypeCVal_SetVBusStatus(u8PortNum);
            break;

        }
        /*Test ID: TYPEC_SINK_SRC30A_ATT_CC1*/
        case 41:
        {
            /*Setting typeC variable to sink configuration*/
            TypeCVal_SetPortConfigSink(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate Source 3.0A current attachment in CC1*/
            TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);

            /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            /* Setting VBUS status to Vsafe5V drive */
            TypeCVal_SetVBusStatus(u8PortNum);
            break;

        }

        /*Test ID: TYPEC_SINK_SRC30A_ATT_CC2*/
        case 42:
        {
             /*Setting typeC variable to sink configuration*/
            TypeCVal_SetPortConfigSink(u8PortNum);

            /*Calling the TypeC Config API to initialize the Port*/
            TypeC_InitPort (u8PortNum);
            
            PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

            /*Setting the Type C Variable to indicate Source 3.0A current attachment in CC2*/
            TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);

            /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
            TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

            /*Setting the Type C CC interrupt status bit to process the attach event*/
            TypeCVal_SetCCInterruptStatus(u8PortNum);

            /* Setting VBUS status to Vsafe5V drive */
            TypeCVal_SetVBusStatus(u8PortNum);
            break;

        }

         /*Test ID: TYPEC_SINK_SRCDEF_DET_CC1*/
        case 43:
        {

             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a Source Default current attachment in CC1*/
                case 0:
                {
                    /*Setting typeC variable to sink configuration*/
                    TypeCVal_SetPortConfigSink(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);
                    
                    PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

                    /*Setting the Type C Variable to indicate Source Default current attachment in CC1*/
                    TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
                    
                    TypeCVal_SetVConnOnStatus( u8PortNum, 3);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);
                    
                    /* Setting VBUS status to Vsafe5V drive */
                    TypeCVal_SetVBusStatus(u8PortNum);
                   
                    break;
                }

                /*Case 1 Simulates a Source Default current detachment in CC1*/
                case 1:
                {

                    /*Setting the CC1 register to 00 to indicate source detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
                    
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
                    
                    /*Drive VBus for vSafe0V to simulate for the detach from source*/
                    CONFIG_HOOK_PORTPWR_DRIVE_VBUS (u8PortNum, PWRCTRL_VBUS_0V);
                    
                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);
                    
                    /* Setting VBUS status to Vsafe0V drive */
                    TypeCVal_ClearVBusStatus(u8PortNum);

                    break;
                }
            }
            break;

        }

        /*Test ID: TYPEC_SINK_SRCDEF_DET_CC2*/
        case 44:
        {
             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a Source Default current attachment in CC2*/
                case 0:
                {
                    /*Setting typeC variable to sink configuration*/
                    TypeCVal_SetPortConfigSink(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);
                    
                    PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

                    /*Setting the Type C Variable to indicate Source Default current attachment in CC2*/
                    TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_DEFAULT_CURRENT);

                    /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
                    
                    TypeCVal_SetVConnOnStatus( u8PortNum, 3);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    /* Setting VBUS status to Vsafe5V drive */
                    TypeCVal_SetVBusStatus(u8PortNum);
                    
                    break;
                }

                /*Case 0 Simulates a Source Default current detachment in CC2*/
                case 1:
                {

                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
                    
                    /* Setting VBUS status to Vsafe0V drive */
                    TypeCVal_ClearVBusStatus(u8PortNum);
                    
                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }
            break;

        }

        /*Test ID: TYPEC_SINK_SRC15A_DET_CC1*/
        case 45:
        {

             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a Source 1.5A current attachment in CC1*/
                case 0:
                {
                     /*Setting typeC variable to sink configuration*/
                    TypeCVal_SetPortConfigSink(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);
                    
                    PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

                    /*Setting the Type C Variable to indicate Source 1.5A current attachment in CC1*/
                    TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_1A5_CURRENT);

                    /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    /* Setting VBUS status to Vsafe5V drive */
                    TypeCVal_SetVBusStatus(u8PortNum);

                    break;
                }

                /*Case 1 Simulates a Source 1.5A current detachment in CC1*/
                case 1:
                {

                    /*Setting the CC1 register to 00 to indicate source detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
                    
                    /* Setting VBUS status to Vsafe0V drive */
                    TypeCVal_ClearVBusStatus(u8PortNum);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }

        /*Test ID: TYPEC_SINK_SRC15A_DET_CC2*/
        case 46:
        {

             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a Source 1.5AA current attachment in CC2*/
                case 0:
                {
                     /*Setting typeC variable to sink configuration*/
                    TypeCVal_SetPortConfigSink(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);
                    
                    PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

                    /*Setting the Type C Variable to indicate Source 1.5A current attachment in CC2*/
                    TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_1A5_CURRENT);

                    /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    /* Setting VBUS status to Vsafe5V drive */
                    TypeCVal_SetVBusStatus(u8PortNum);
                    
                    break;
                }

                /*Case 0 Simulates a Source 1.5A current detachment in CC2*/
                case 1:
                {

                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
                    
                    /* Setting VBUS status to Vsafe0V drive */
                    TypeCVal_ClearVBusStatus(u8PortNum);
                    
                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }
        /*Test ID: TYPEC_SINK_SRC30A_DET_CC1*/
        case 47:
        {

              switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a Source 3.0A current attachment in CC1*/
                case 0:
                {
                    /*Setting typeC variable to sink configuration*/
                    TypeCVal_SetPortConfigSink(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);
                    
                    PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

                    /*Setting the Type C Variable to indicate Source 3.0A current attachment in CC1*/
                    TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC1PIN , TYPEC_DFP_3A0_CURRENT);

                    /*Setting the CC2 register to 00 to indicate no attachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);
                    
                    /* Setting VBUS status to Vsafe5V drive */
                    TypeCVal_SetVBusStatus(u8PortNum);
                    
                    break;
                }

                /*Case 1 Simulates a Source 3.0A current detachment in CC1*/
                case 1:
                {

                    /*Setting the CC1 register to 00 to indicate source detachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);
                    
                    /* Setting VBUS status to Vsafe0V drive */
                     TypeCVal_ClearVBusStatus(u8PortNum);
                     
                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }

        /*Test ID: TYPEC_SINK_SRC30A_DET_CC2*/
        case 48:
        {

             switch(pu8HermesReqBuffer[3])
            {

                /*Case 0 Simulates a Source 3.0A current attachment in CC2*/
                case 0:
                {
                     /*Setting typeC variable to sink configuration*/
                    TypeCVal_SetPortConfigSink(u8PortNum);

                    /*Calling the TypeC Config API to initialize the Port*/
                    TypeC_InitPort (u8PortNum);
                    
                    PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(50));

                    /*Setting the Type C Variable to indicate Source 3.0A current attachment in CC2*/
                    TypeCVal_SetSourceAttach (u8PortNum, TYPECVAL_CC2PIN , TYPEC_DFP_3A0_CURRENT);

                    /*Setting the CC1 register to 00 to indicate no attachment in CC1*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC1PIN);

                    /*Setting the Type C CC interrupt status bit to process the attach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    /* Setting VBUS status to Vsafe5V drive */
                    TypeCVal_SetVBusStatus(u8PortNum);
                    
                    break;
                }

                /*Case 0 Simulates a Source 3.0A current detachment in CC2*/
                case 1:
                {

                    /*Setting the CC2 register to 00 to indicate sink detachment in CC2*/
                    TypeCVal_ClearCCPin (u8PortNum, TYPECVAL_CC2PIN);
                    
                    /* Setting VBUS status to Vsafe0V drive */
                    TypeCVal_ClearVBusStatus(u8PortNum);

                    /*Setting the Type C CC interrupt status bit to process the detach event*/
                    TypeCVal_SetCCInterruptStatus(u8PortNum);

                    break;
                }
            }

            break;

        }

    }

}


void TypeCVal_SMTestReadReq(UINT8* pu8HermesResBuffer)
{

    /*As of now we read only the Type C State and Sub State variable to verify the state transitions
    .So  the length will always to 2*/
    pu8HermesResBuffer[0] =  gasTypeCcontrol[0].u8TypeCState;
    pu8HermesResBuffer[1] =  gasTypeCcontrol[0].u8TypeCSubState;
    pu8HermesResBuffer[2] =  ((gasTypeCcontrol[0].u8IntStsISR & TYPEC_VCONN_SOURCE_MASK) >> TYPEC_VCONN_SOURCE_POS);
}



/*Below APIs are used to set the TypeC Control Module Variables
.The Changes in Type C Control's variables will directly affect these APIs*/

void TypeCVal_SetPortConfigSrcDefault(UINT8 u8PortNum)
{
    /*Setting the Source with Default current configuration*/  
        gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
        gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
        gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
        gasPortConfigurationData[0].u32CfgData |= (TYPEC_UFP_DFP_DEF << TYPEC_PORT_RPVAL_POS);

}

void TypeCVal_SetPortConfigSrc15A(UINT8 u8PortNum)
{
    /*Setting the Source with 1.5A current configuration*/ 
   gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
    gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
    gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
    gasPortConfigurationData[0].u32CfgData |= (RP_VAL_1P5A << TYPEC_PORT_RPVAL_POS);

}

void TypeCVal_SetPortConfigSrc30A(UINT8 u8PortNum)
{
    /*Setting the Source with 3.0A current configuration*/
    gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
    gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SOURCE;
    gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
    gasPortConfigurationData[0].u32CfgData |= (RP_VAL_3A << TYPEC_PORT_RPVAL_POS);

}

void TypeCVal_SetPortConfigSink(UINT8 u8PortNum)
{
    /*Setting the Source with 3.0A current configuration*/
    gasPortConfigurationData[0].u32CfgData &= ~TYPEC_PORT_TYPE_MASK;
    gasPortConfigurationData[0].u32CfgData |= PD_ROLE_SINK;
    gasPortConfigurationData[0].u32CfgData &= ~(TYPEC_PORT_RPVAL_MASK);
    gasPortConfigurationData[0].u32CfgData |= (RP_VAL_RD << TYPEC_PORT_RPVAL_POS);

}

void TypeCVal_SetSinkAttach(UINT8 u8PortNum, UINT8 u8CC1orCC2 , UINT8 u8SrcType)
{
    UINT8 u8Value =0;

    switch(u8SrcType)
    {
        case TYPEC_DFP_DEFAULT_CURRENT:
        {
            u8Value = TYPEC_UFP_ATT_DEF;
            break;
        }
        case TYPEC_DFP_1A5_CURRENT:
        {
            u8Value = TYPEC_UFP_ATT_DEF;
            break;
        }
        case TYPEC_DFP_3A0_CURRENT:
        {
            u8Value = TYPEC_UFP_ATT_3A0;
            break;
        }
    }

    if(u8CC1orCC2 == TYPECVAL_CC1PIN)
    {
        gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = u8Value;

    }
    else
    {
        gasTypeCcontrol[u8PortNum].u8CC2_MatchISR = u8Value;
    }

}

void TypeCVal_SetPwdCableAttach(UINT8 u8PortNum, UINT8 u8CC1orCC2 , UINT8 u8SrcType)
{
    UINT8 u8Value =0;

    switch(u8SrcType)
    {
        case TYPEC_DFP_DEFAULT_CURRENT:
        {
            u8Value = 0x21;
            break;
        }
        case TYPEC_DFP_1A5_CURRENT:
        {
            u8Value = 0x21;
            break;
        }
        case TYPEC_DFP_3A0_CURRENT:
        {
            u8Value = 0x48;
            break;
        }
    }

    if(u8CC1orCC2 == TYPECVAL_CC1PIN)
    {
        gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = u8Value;

    }
    else
    {
        gasTypeCcontrol[u8PortNum].u8CC2_MatchISR = u8Value;
    }

    /*Setting the TYPEC_PWDCABLE_PRES_MASK  bit as 1 to indicate the powered cable presence*/
    gasTypeCcontrol[u8PortNum].u8PortSts |= TYPEC_PWDCABLE_PRES_MASK;

}

void TypeCVal_SetSourceAttach(UINT8 u8PortNum, UINT8 u8CC1orCC2 , UINT8 u8SrcType)
{
    UINT8 u8Value =0;

    switch(u8SrcType)
    {
        case TYPEC_DFP_DEFAULT_CURRENT:
        {
            u8Value = TYPEC_DFP_DEF_ATT;
            break;
        }
        case TYPEC_DFP_1A5_CURRENT:
        {
            u8Value = TYPEC_DFP_1A5_ATT;
            break;
        }
        case TYPEC_DFP_3A0_CURRENT:
        {
            u8Value = TYPEC_DFP_3A0_ATT;
            break;
        }
    }

    if(u8CC1orCC2 == TYPECVAL_CC1PIN)
    {
        gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = u8Value;

    }
    else
    {
        gasTypeCcontrol[u8PortNum].u8CC2_MatchISR = u8Value;
    }

}

void TypeCVal_ClearCCPin(UINT8 u8PortNum, UINT8 u8CC1orCC2)
{

     if(u8CC1orCC2 == TYPECVAL_CC1PIN)
    {
        gasTypeCcontrol[u8PortNum].u8CC1_MatchISR = 00;

    }
    else
    {
        gasTypeCcontrol[u8PortNum].u8CC2_MatchISR = 00;
    }

}

void TypeCVal_SetCCInterruptStatus(UINT8 u8PortNum)
{
    gasTypeCcontrol[u8PortNum].u8IntStsISR |= TYPEC_CCINT_STATUS_MASK;
}

void TypeCVal_SetVConnOnStatus(UINT8 u8PortNum, UINT8 u8CC1orCC2)
{
    gasTypeCcontrol[u8PortNum].u8IntStsISR &= ~(TYPEC_VCONN_SOURCE_CC2 | TYPEC_VCONN_SOURCE_CC1);
  
    if(u8CC1orCC2 == TYPECVAL_CC2PIN)
    {
        gasTypeCcontrol[u8PortNum].u8IntStsISR |= TYPEC_VCONN_SOURCE_CC2;
    }
    
    else if(u8CC1orCC2 == TYPECVAL_CC1PIN)
    {
       gasTypeCcontrol[u8PortNum].u8IntStsISR |= TYPEC_VCONN_SOURCE_CC1;
    }
    
    else
    {
      
    }
}

void TypeCVal_ClearVBusStatus(UINT8 u8PortNum)
{
    gasTypeCcontrol[u8PortNum].u8IntStsISR &= ~TYPEC_VBUS_PRESENCE_MASK;
}

void TypeCVal_SetVBusStatus(UINT8 u8PortNum)
{
    gasTypeCcontrol[u8PortNum].u8IntStsISR &= ~TYPEC_VBUS_PRESENCE_MASK;
    gasTypeCcontrol[u8PortNum].u8IntStsISR |= TYPEC_VBUS_5V;
  
}

void WaitUntilSPITestRegister(UINT8 u8PortNum)
{ 
    UINT8 u8ReadData[4];
    UINT8 u8Loopin = 0x01;
    
    do
    {   
        /*Read SPI_TEST register*/
        UPD_RegisterRead(u8PortNum, (UINT16)UPD_SPI_TEST, u8ReadData, 1);
    
    }while(u8ReadData[0] == 0x00);
    
    do
    {
        /*Read VID & PID register*/
        UPD_RegisterRead(u8PortNum, (UINT16)UPD_VID, u8ReadData, 4);          

        /*Verify the default values*/
        if((u8ReadData[0] == UPD_VID_LSB) && (u8ReadData[1] == UPD_VID_MSB) && \
          (u8ReadData[2] == UPD_PID_LSB) && (u8ReadData[3] == UPD_PID_MSB))
        {
        
            u8Loopin = 0;
        }
    
    }while(u8Loopin == 0x01);      

}

#endif
