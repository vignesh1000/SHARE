#ifndef _I2C_VAL_H_
#define _I2C_VAL_H_

#include <stdinc.h>


UINT8 I2CVal_HandleTxReq(UINT8* ValidationBufferPtr);
UINT16 I2CVal_HandleRxReq(UINT8* ValidationBufferPtr);


#endif