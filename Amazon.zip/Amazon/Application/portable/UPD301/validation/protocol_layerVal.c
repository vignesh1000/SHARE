
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include <stdinc.h>
#include <protocol_layerVal.h>

#if defined(PDFU_VALIDATION) || defined(VALIDATION)
UINT8 gabyPRLValTxResponse[2];
UINT8 gabyPRLValRxMsgRes[266];
UINT8 gu8PRLPEdisable = 0;

void PRLVal_ProcessValTxRequest (UINT8 gu8ConnectionID, UINT8* pu8HermesReqBuffer)
{
  
    /* gu8ConnectionID is used as Port number here*/
	UINT8 u8TestCaseId = pu8HermesReqBuffer[2], u8Returnval, u8PortNum = gu8ConnectionID;
    
    /* Request buffer received format
    * I2C slave address
    * 0 - Connection ID - Here Connection ID field is used for Port number
    * 1 - Request/Response Code - PRL Tx/Rx Request/Response code
    * 2 - Packet Length - MSB
    * 3 - Packet Length - LSB
    * 4 - Testcase ID
    * 5 - Buffer data
    */
    
    /* For PRLVal_ProcessValTxRequest API,
        the global request buffer will be passed from index 2
        The received pu8HermesReqBuffer will have
        0 - Packet Length - MSB
        1 - Packet Length - LSB
        2 - Test Case ID
        Incase of PRLVAL_TRANSMIT_MESSAGE test ID
        3 - SOP Type
        4,5 - Message Header
        6,7 - Extended Header
        8 - Message Data
    */
  
    switch (u8TestCaseId)
    {
		case PRLVAL_TRANSMIT_MESSAGE:
		{
		  	u8Returnval = PRL_TransmitMsg (u8PortNum, pu8HermesReqBuffer[3],
								MAKE_UINT32_FROM_BYTES(pu8HermesReqBuffer[4],pu8HermesReqBuffer[5],
														pu8HermesReqBuffer[6],pu8HermesReqBuffer[7]),
							 			&pu8HermesReqBuffer[8], PRLVal_TXCallback, gu8ConnectionID);
            
            gabyPRLValTxResponse [0] = gu8ConnectionID; /*portnumber*/
			if(u8Returnval == PRL_RET_TX_MSG_DISCARD_ON_RCV)
			{
				gabyPRLValTxResponse [1] = PRLVAL_STATUS_TX_DISCARD_ON_RECV;			/* Discard code*/
			}
            else if (u8Returnval == PRL_RET_TX_MSG_BUFFERED)
            {
                gabyPRLValTxResponse [1] = PRLVAL_STATUS_TX_BUFFERED_ON_CA;			/* Discard code*/
            }
			else if ((u8Returnval!= PRL_RET_TX_MSG_TRANSMITTED_ON_LINE) && (u8Returnval != PRL_RET_TX_MSG_CHUNKING_ENABLED))
			{
				
				gabyPRLValTxResponse [1] = PRLVAL_STATUS_TX_FAILED;	/* Error Code*/
			}
			break;
		}

		case PRLVAL_SOP_HEADER_FORM:
		{
		  	UINT16 u16Header = PRL_FormSOPTypeMsgHeader (u8PortNum, pu8HermesReqBuffer[3],pu8HermesReqBuffer[4], pu8HermesReqBuffer[5]);
			gabyPRLValTxResponse [0] = LOBYTE(u16Header);
			gabyPRLValTxResponse [1] = HIBYTE(u16Header);
			break;
		}

		case PRLVAL_NON_SOP_HEADER_FORM:
		{
		  	UINT16 u16Header =  PRL_FormNonSOPTypeMsgHeader (u8PortNum, pu8HermesReqBuffer[3],pu8HermesReqBuffer[4], pu8HermesReqBuffer[5]);
			gabyPRLValTxResponse [0] = LOBYTE(u16Header);
			gabyPRLValTxResponse [1] = HIBYTE(u16Header);
			break;
		}

		case PRLVAL_TX_DISCARDING_ON_SOP_RCV:
		{
		  	//PRL_TX_DISCARDING_SOP_RCV
			gu8PRLPEdisable = pu8HermesReqBuffer[3];
			break;
		}
        
        case PRLVAL_CURRENT_CONFIG:
        {
            gabyPRLValRxMsgRes[0] = u8PortNum;
            gabyPRLValRxMsgRes[1] = 0x6;
            gabyPRLValRxMsgRes[2] = 0;
            gabyPRLValRxMsgRes[3] = DPM_GET_CURRENT_POWER_ROLE(u8PortNum);
            gabyPRLValRxMsgRes[4] = DPM_GET_CURRENT_DATA_ROLE(u8PortNum);
            gabyPRLValRxMsgRes[5] = DPM_GET_CURRENT_PD_SPEC_REV(u8PortNum);
            break;
        }
        
        case PRLVAL_DEFAULT_CONFIG:
        {
           /* Set spec revision to default spec revision in every detach */
           gasDPM[u8PortNum].u8DPM_Status &= ~DPM_CURR_PD_SPEC_REV_MASK;
           gasDPM[u8PortNum].u8DPM_Status |= (CONFIG_PD_DEFAULT_SPEC_REV << DPM_CURR_PD_SPEC_REV_POS);
           gu8PRLPEdisable = 0;
           PRL_SetCollisionAvoidance (u8PortNum, TYPEC_SINK_TXOK);
        }
            
		case PRLVAL_EN_DIS_CA:
		 {
			  PRL_SetCollisionAvoidance (u8PortNum, pu8HermesReqBuffer[3]);
			  break;
		 }
         
		case PRLVAL_SINK_AMS_TRANSMIT:
		{
            PRL_SinkIntAMS (u8PortNum);
			break;
		}

		case PRL_SET_ABORT_FLAG:
        {
            gasChunkSM [u8PortNum].u8AbortFlag = TRUE;
            break;
        }

		case PRLVAL_SEND_HARD_RESET:
		{
		  	// hard Reset
			PRL_SendCableorHardReset (u8PortNum, PRL_SEND_HARD_RESET,  PRLVal_TXCallback, gu8ConnectionID);
			break;
		}

		case PRLVAL_PRL_RESET:
		{
			PRL_ProtocolResetAllSOPs(u8PortNum);
			break;
		}

		case PRLVAL_PRL_INIT:
		 {
		   gabyPRLValTxResponse [0] = gu8ConnectionID; /*Connection ID*/
		   gabyPRLValTxResponse [1] = PRLVAL_STATUS_INIT_VALIDATED_SUCCESS;			/* pass code*/
           
           UINT16 u16addr[] = {0x1A0B,  0x1A0C, 0x1A07, 0x1A08,0x1A06,0x1A00,0x1A42,0x1A43,0x1A46,0x1A49,
		   						0x1AA0,0x1AA1,0x1AA2,0x1AA3,0x1AA4,0x1AA5,0x1AA6,0x1AA7,0x1AA8,0x1AA9,
								0x1AB0,0x1AB1,0x2802,0x2810,0x2812,0x2814,0x2816,0x2818,0x281A,
								0x281C,0x281E,0x2820,0x2822,0x2824,0x2826,0x2830,0x2832,0x2834,0x2836,
								0x2838,0x283A,0x283C,0x283E,0x2840,0x2842,0x2844,0x2846,0x2804,0x1A41,
								0x1A87,0x2400,0x1A89};
		   UINT16 u16data[] = {60,30,159,50,64,0x54,128,196,100,94,206,115,206,115,114,30,114,30,101,
		   						23,159,200,0x01,0,57,115,172,230,287,345,402,460,517,574,631,631,574,
								517,460,402,345,287,230,172,115,57,0,0x10,0x1E,0x88,0x01,0x04};
	
            UINT16  u16ReadData;


		   for (int i=0; i<(sizeof(u16data)/2); i++)
		   {
             if (u16data[i] > 0xFF)
             {
               u16ReadData = UPD_RegReadWord (u8PortNum, u16addr[i]);
             }
             else
             {
               u16ReadData = UPD_RegReadByte (u8PortNum, u16addr[i]);
             }
             
			 if(u16data[i]!=u16ReadData)
			 {
				gabyPRLValTxResponse [0] = gu8ConnectionID; /*Connection ID*/
				gabyPRLValTxResponse [1] = PRLVAL_STATUS_INIT_VALIDATED_FAILED;			/*  code*/
				break;
			 }

		   }
		   break;
		 }


		default:
		{
			break;
		}
	}
}



UINT16 PRLVal_HandleTxResponseReq (UINT8 gu8ConnectionID, UINT8* pu8HermesResBuffer)
{

	for (int i = 0x00; i < 2; i++)
	{
		pu8HermesResBuffer[i] = gabyPRLValTxResponse[i];
	}

	return 2;
}


UINT16 PRLVal_HandleRxResponseReq (UINT8 gu8ConnectionID, UINT8* pu8HermesResBuffer)
{
	UINT16 u16Length = (MAKE_UINT16(gabyPRLValRxMsgRes[2],gabyPRLValRxMsgRes[1]));

	for (UINT16 u16DataSize = 0; \
		  u16DataSize <= u16Length; u16DataSize++)
	{
		pu8HermesResBuffer[u16DataSize] = gabyPRLValRxMsgRes[u16DataSize];
	}
	gabyPRLValRxMsgRes[1] = HIBYTE(u16Length);
	gabyPRLValRxMsgRes[2] = LOBYTE(u16Length);

#ifndef _IDEAL_
	I2C_SlaveIRQdrive (1);
#endif
	return (u16Length + 1);
}

void PRLVAL_DPMStateMachine (UINT8 u8PortNum)
{
	while(1)
  	{
	  	 /* Hermes request from I2C slave*/
        if(Hermes_IfConnectionRequest())
        {
            Hermes_ProcessMasterPacket();
        }

		for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
  		{
			if (PORT_STATUS_ENABLED == gau8PortDisable[u8PortNum])
			{
				TypeC_RunStateMachine (u8PortNum);

				PRLVAL_PEStatemachine (u8PortNum);
			}
		}


	}
}


void PRLVAL_PEStatemachine(UINT8 u8PortNum)
{
	if (gu8PRLPEdisable)
	{
	  return;
	}
  	PRL_RunChunkStateMachine (u8PortNum);

	/* If Msg received pass it to Receive Handler */
	UINT8 u8ReturnVal = PRL_ReceiveMsg(u8PortNum, &gabyPRLValRxMsgRes[3],
											(UINT32 *)&gabyPRLValRxMsgRes[4],
											&gabyPRLValRxMsgRes[8], NULL);
	if(u8ReturnVal & PRL_RET_MSG_RCVD)
	{
		gabyPRLValRxMsgRes[0] = u8PortNum;
		gabyPRLValRxMsgRes[1] = (PRL_MSG_HEADER_SIZE_IN_BYTES + PRL_EXTN_MSG_HEADER_SIZE_IN_BYTES +
					((PRL_GET_OBJECT_COUNT(MAKE_UINT16(gabyPRLValRxMsgRes[5],gabyPRLValRxMsgRes[4]))) *
					 PRL_SINGLE_DATAOBJ_SIZE_IN_BYTES) + 3); /*SOP type & MSB & LSB*/
		gabyPRLValRxMsgRes[2] = 0;
#ifndef _IDEAL_
		I2C_SlaveIRQdrive (0);
#endif
	}
	else if (u8ReturnVal & PRL_RET_EXT_MSG_RCVD)
	{
		gabyPRLValRxMsgRes[0] = u8PortNum; /* To send connection ID*/
		UINT16 u16Length = (PRL_MSG_HEADER_SIZE_IN_BYTES + PRL_EXTN_MSG_HEADER_SIZE_IN_BYTES
							+ PRL_GET_DATA_SIZE(MAKE_UINT16(gabyPRLValRxMsgRes[7],gabyPRLValRxMsgRes[6])) + 3);
		gabyPRLValRxMsgRes[1] = LOBYTE(u16Length);
		gabyPRLValRxMsgRes[2] = HIBYTE(u16Length);
#ifndef _IDEAL_
		I2C_SlaveIRQdrive (0);
#endif
	}

}


void PRLVal_TXCallback (UINT8 u8PortNum, UINT8 u8DummyVariable1, UINT8 u8DummyVariable2, UINT8 u8DummyVariable3, UINT8 u8DummyVariable4)
{
  	gabyPRLValTxResponse[0] = u8PortNum; /* ConnectionID passed*/

	if ((gasPRL[u8PortNum].u8TxStateISR == PRL_TX_DONE_ST) || (gasPRL[u8PortNum].u8TxStateISR == PRL_TX_EOP_ST))
	{
		gabyPRLValTxResponse[1] = PRLVAL_STATUS_GOODCRC_RECEIVED;
	}
	else if (gasPRL[u8PortNum].u8TxStateISR == PRL_TX_FAILED_ST)
	{
		gabyPRLValTxResponse [1] = PRLVAL_STATUS_TX_FAILED;
	}
	else if (gasPRL[u8PortNum].u8TxStateISR == PRL_TX_ABORTED_ST)
	{
		gabyPRLValTxResponse [1] = PRLVAL_STATUS_TX_ABORTED;
	}
#ifndef _IDEAL_
    if(GPIO_GetPinLevel(PIN_PA06))
        I2C_SlaveIRQdrive(0);
    else
        I2C_SlaveIRQdrive(1);
#endif
}

#endif
