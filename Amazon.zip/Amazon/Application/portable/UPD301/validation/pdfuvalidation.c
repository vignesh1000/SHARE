
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

//#define VALIDATION 1

#include <stdinc.h>
#include <pdfuvalidation.h>
#include <Shared_Globals.h>
#include <protocol_layerVal.h>
#ifdef PDFU_VALIDATION
extern UINT8 gu8HResponseCode;
UINT8 gu8TemporaryBuffer[264];
UINT8 gu8TxResOrRxResp = 0x00;


void getPDFUResponse(void);

void pdfuValidation_ProcessHermesRequest(UINT8* pu8HermesReqBuffer)
{
    switch(gu8RequestType)
    {
        case PDFU_VALIDATION_TX_REQUEST:
        {
            gu8TxResOrRxResp = 0x00;
#ifndef _IDEAL_
            I2C_SlaveIRQdrive(1);
#endif
		  	(void)PRL_TransmitMsg (PRLVAL_PORT1, 0x00/**SOP Type*/,
								MAKE_UINT32_FROM_BYTES(pu8HermesReqBuffer[4],pu8HermesReqBuffer[5],
														pu8HermesReqBuffer[6],pu8HermesReqBuffer[7]),
							 			&pu8HermesReqBuffer[8], PRLVal_TXCallback, gu8ConnectionID);
            break;
        }
        case PDFU_VALIDATION_RX_REQUEST:
        {
            getPDFUResponse();
            break;
        }
    }
}

/***************************************************************************************************/

UINT16 pdfuValidation_ProcessHermesResponse(UINT8* pu8HermesResBuffer)
{
     UINT16 u16Reslength = 0;

    switch(gu8RequestType)
    { 
        case PDFU_VALIDATION_TX_RESPONSE:

            u16Reslength = PRLVal_HandleTxResponseReq (gu8ConnectionID, pu8HermesResBuffer);
            if(gu8TxResOrRxResp!= 2)
            {
#ifndef _IDEAL_
              I2C_SlaveIRQdrive(1);
#endif
            }
            break;
            
        case PDFU_VALIDATION_RX_RESPONSE:
            if(gu8TxResOrRxResp!= 2)
            {
              u16Reslength=0;
            }else{
#ifndef _IDEAL_
            I2C_SlaveIRQdrive(1);
#endif
            getPDFUResponse();
            u16Reslength = 262;
            gu8TxResOrRxResp = 0x00;
            }
        break;

    }


    return u16Reslength;


}


void copyPDFUResponse(UINT32 u32Header,UINT8* u8pRespuffer)
{
    UINT16 u16loop;
    gu8TxResOrRxResp = 0x02;
    UINT16 u16length = PRL_GET_DATA_SIZE(PRL_GET_EXTENDED_MSG_HEADER(u32Header));
    gu8TemporaryBuffer[0] = u16length >>8;
    gu8TemporaryBuffer[1] = (UINT8)u16length;
    *((UINT16*)&gu8TemporaryBuffer[2]) = PRL_GET_MSG_HEADER(u32Header);
    *((UINT16*)&gu8TemporaryBuffer[4]) = PRL_GET_EXTENDED_MSG_HEADER(u32Header);

    for (u16loop = 0;u16loop < 256;u16loop++)
    {
        gu8TemporaryBuffer[6 + u16loop] = u8pRespuffer[u16loop];
    }
}

void getPDFUResponse(void)
{
    UINT16 u16loop;

    for (u16loop = 0;u16loop < 262;u16loop++)
    {
        gu8HermesResBuffer[u16loop] = gu8TemporaryBuffer[u16loop];
    }

}

/***************************************************************************************************/
#endif