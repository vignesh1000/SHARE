
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
//#define VALIDATION 1

#include <stdinc.h>
#include <Hermes_Interface.h>
#include <SERCOM_Spi.h>
#include <GPIO.h>
#if VALIDATION
/* SPI_VALIDATION define used to test SPI communication, this Macro shall be enabled for validation */


/* As of now pu8I2CReqBuffer filled with test bytes, actual use case will be I2C Slave receive buffer bytes*/

#define BUFFER_SIZE                                     275
extern UINT8 pu8HermesResBuffer[BUFFER_SIZE];
extern UINT8 pu8HermesReqBuffer[BUFFER_SIZE];
UINT8 ValidationRxBuff[15]={0};
UINT8 u8GPIOLowTestSt =0;
UINT8 u8GPIOHighTestSt =0;
/******************************************************************************
 * Function:        UINT8 RunSpiValidationTest()
 * Input:           None
 * Output:          Function return TRUE If SPI validation executed successfully
 * Overview:
 * Note:            SPI_VALIDATION macro must be enabled To validate SPI
 *****************************************************************************/

UINT8 GPIOVal_HandleTxReq(UINT8*ValidationBufferPtr)
{
	UINT8 U8GPIOPin,U8GPIOlevel,U8GPIOPullMode;
    UINT8 u8TestCaseId = ValidationBufferPtr[0];
	switch (u8TestCaseId)
    {
		case 0:
		{
            U8GPIOPin = ValidationBufferPtr[1];
            U8GPIOlevel = ValidationBufferPtr[2];
            GPIO_SetDirection(U8GPIOPin, GPIO_SETDIRECTION_OUT);
            GPIO_SetPinFunction(U8GPIOPin, GPIO_PIN_FUNC_OFF);
            GPIO_SetPinLevel(U8GPIOPin, U8GPIOlevel);
            break;
        }

        case 1:
          {

         U8GPIOPin = ValidationBufferPtr[1];
            U8GPIOlevel = ValidationBufferPtr[2];
            GPIO_SetDirection(U8GPIOPin, GPIO_SETDIRECTION_OUT);
            GPIO_SetPinFunction(U8GPIOPin, GPIO_PIN_FUNC_OFF);
            GPIO_SetPinLevel(U8GPIOPin, GPIO_DRIVELOW);
            break;
        }
        /* This test verifies the pull mode and manually need to verify the register*/
        case 2:
		{
            U8GPIOPin = ValidationBufferPtr[1];
            U8GPIOPullMode = ValidationBufferPtr[2];
            GPIO_SetPullMode(U8GPIOPin,U8GPIOPullMode);

        break;
        }
        /* This test set the GPIO and read the GPIO for High*/
        case 3:
		{
            GPIO_SetDirection(U8GPIOPin, GPIO_SETDIRECTION_OUT);
            GPIO_SetPinFunction(U8GPIOPin, GPIO_PIN_FUNC_OFF);
            GPIO_SetPinLevel(U8GPIOPin, 1);
            if(GPIOStrap_GetInputLevel(U8GPIOPin))
            {
                u8GPIOHighTestSt=1;
            }

        break;
        }
        /* This test set the GPIO and read the GPIO for Low*/
        case 4:
		{
            GPIO_SetDirection(U8GPIOPin, GPIO_SETDIRECTION_OUT);
            GPIO_SetPinFunction(U8GPIOPin, GPIO_PIN_FUNC_OFF);
            GPIO_SetPinLevel(U8GPIOPin, 0);
            if(!GPIOStrap_GetInputLevel(U8GPIOPin))
            {
                u8GPIOLowTestSt=1;
            }

        break;
        }


    default:
      break;
    }

return 1;
}



UINT16 GPIOVal_HandleRxReq(UINT8*ValidationBufferPtr)
{
	UINT8 SPIModeSelTestStatus =1;
	UINT8 u8TestCaseId = ValidationBufferPtr[0];
    UINT16 u16length=0;
	switch (u8TestCaseId)
    {
		case 0:
		{
          u16length = ((pu8HermesReqBuffer[1] <<8)||(pu8HermesReqBuffer[2]));
            for (UINT16 i=0 ; i< u16length ; i++)
            {
              ValidationBufferPtr[i]= pu8HermesReqBuffer[i+3];
            }
            return u16length;
		break;
        }

        case 1:
		{

    //        UPD_RegisterRead(0, (UINT16)0x0030, pu8HermesResBuffer, 10);
            break;
        }

        case 2:
		{
      //      UPD_RegisterRead(0, (UINT16)0x0030, pu8HermesResBuffer, 10);
            break;
        }

        case 3:
		{
            ValidationBufferPtr[0]= u8GPIOHighTestSt;
            break;
        }
        case 4:
		{
            ValidationBufferPtr[0]= u8GPIOLowTestSt;
            break;
        }

    default:
      break;
    }

return SPIModeSelTestStatus;
}
#endif

