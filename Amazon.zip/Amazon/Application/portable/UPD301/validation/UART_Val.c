
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#ifdef VALIDATION
#include <stdinc.h>
#include <UART_Val.h>

UINT8 gu8UARTvalStatus;



void UARTVal_HandleRequest (UINT8* pu8HermesReqBuffer)
{
  	UINT8 u8TestCaseId = pu8HermesReqBuffer[0];
	UINT32 u32BaudRate;
	UINT32 u32ReadValue;
	INT32 i32ReadValue; 
	char readstring[0xFF];
	
	


	switch (u8TestCaseId)
	{
	  	case UARTVAL_SET_BAUD_RATE:
		{
		  	u32BaudRate = MAKE_UINT32_FROM_BYTES(pu8HermesReqBuffer[1],	
												  pu8HermesReqBuffer[2],
												   pu8HermesReqBuffer[3],
												   pu8HermesReqBuffer[4]);
			
			//Loword - Hiword
			REGDW(SERCOM_UART_CTRLA_REG) &= ~SERCOM_UART_CTRLA_ENABLE;
			
			while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);
			
		  	REGW(SERCOM_UART_BAUD_REG) = SERCOM_UART_BAUD_REG_VALUE(u32BaudRate);
			
			while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);
			
			REGDW(SERCOM_UART_CTRLA_REG) |= SERCOM_UART_CTRLA_ENABLE;
			
			while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);
			
			break;
		}
		
			
		case UARTVAL_UPD301_CHAR_LOOPBACK_TEST:
		{
		  	SERCOMUART_Init();
            gu8UARTvalStatus = UARTVAL_TEST_STATUS_SUCCESS;
            for (UINT8 u8iteration = 2; u8iteration < pu8HermesReqBuffer[1]; u8iteration++)
			{
		  		SERCOMUART_WriteChar (pu8HermesReqBuffer[u8iteration]);
                if (pu8HermesReqBuffer[u8iteration] != SERCOMUART_ReadChar())
                {
                    gu8UARTvalStatus = UARTVAL_TEST_STATUS_FAILED;
                    break;
                }
                
			}
			break;
		}
		
		case UARTVAL_TX_RX_CHAR_TEST:
		{
		  	u32ReadValue = SERCOMUART_ReadChar();
		  	SERCOMUART_WriteChar (u32ReadValue);
			break;
		}
		
		case UARTVAL_TX_RX_STRESS_CHAR_TEST:
		{
			for (UINT8 u8iteration = 0; u8iteration < pu8HermesReqBuffer[1]; u8iteration++)
			{
		  		u32ReadValue = SERCOMUART_ReadChar();
		  		SERCOMUART_WriteChar (u32ReadValue);
			}
			break;
		}
		
		case UARTVAL_UINT8_TX_TEST:
		{
			u32ReadValue = SERCOMUART_ReadChar();
			SERCOMUART_WriteUINT8 (u32ReadValue);
			break;
		}
		case UARTVAL_UINT16_TX_TEST:
		{
			u32ReadValue = SERCOMUART_ReadChar();
			u32ReadValue |= (SERCOMUART_ReadChar() << 8);
		  	SERCOMUART_WriteUINT16 (u32ReadValue);
			break;
		}
		case UARTVAL_UINT32_TX_TEST:
		{
			u32ReadValue = SERCOMUART_ReadChar();
			u32ReadValue |= (SERCOMUART_ReadChar() << 8);
			u32ReadValue |= (SERCOMUART_ReadChar() << 16);
			u32ReadValue |= (SERCOMUART_ReadChar() << 24);
			SERCOMUART_WriteUINT32 (u32ReadValue);
			break;
		}
		
		case UARTVAL_INT32_TX_TEST:
		{
			i32ReadValue = SERCOMUART_ReadChar();
			i32ReadValue |= (SERCOMUART_ReadChar() << 8);
			i32ReadValue |= (SERCOMUART_ReadChar() << 16);
			i32ReadValue |= (SERCOMUART_ReadChar() << 24);
			SERCOMUART_WriteINT32 (i32ReadValue);
			break;
		}
		
		case UARTVAL_STRING_TX_TEST:
		{
			for (UINT8 i =0 ; i < pu8HermesReqBuffer[1]; i++)
			{
                readstring[i] = SERCOMUART_ReadChar();
			}
            readstring[pu8HermesReqBuffer[1]] = NULL;
			SERCOMUART_WriteString(readstring);
			break;
		}
		
		case UARTVAL_UART_INIT:
		{
			SERCOMUART_Init();
			break;
		}
	  
	}
}

UINT16 UARTVal_HandleResponse (UINT8* pu8HermesResBuffer)
{
	pu8HermesResBuffer[0] = gu8UARTvalStatus;
	return 1;
}


	


#endif

