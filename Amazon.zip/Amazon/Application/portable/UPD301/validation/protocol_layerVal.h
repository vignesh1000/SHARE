#ifndef _PROTOCOL_LAYERVAL_H_
#define _PROTOCOL_LAYERVAL_H_

#include <stdinc.h>


#define PRLVAL_PORT0					0
#define PRLVAL_PORT1					1



#define PRLVAL_STATUS_GOODCRC_RECEIVED		0x04
#define PRLVAL_STATUS_TX_FAILED				0x05
#define PRLVAL_STATUS_TX_ABORTED			0x06
#define PRLVAL_STATUS_TX_DISCARD_ON_RECV	0x07
#define PRLVAL_STATUS_TX_BUFFERED_ON_CA     0x08
#define PRLVAL_STATUS_INIT_VALIDATED_SUCCESS 0x09
#define PRLVAL_STATUS_INIT_VALIDATED_FAILED 0x0A


#define PRLVAL_TRANSMIT_MESSAGE		        0
#define PRLVAL_SOP_HEADER_FORM              1
#define PRLVAL_NON_SOP_HEADER_FORM          2
#define PRLVAL_TX_DISCARDING_ON_SOP_RCV     3
#define PRLVAL_CURRENT_CONFIG               4
#define PRLVAL_DEFAULT_CONFIG               5
#define PRLVAL_EN_DIS_CA                    6
#define PRL_SET_ABORT_FLAG                  7
#define PRLVAL_SINK_AMS_TRANSMIT            8
#define PRLVAL_SEND_HARD_RESET              10
#define PRLVAL_PRL_RESET                    11
#define PRLVAL_PRL_INIT                     12





extern UINT8 gabyPRLValTxResponse[2];

extern UINT8 gabyPRLValRxMsgRes[266];

extern UINT8 gu8PRLPEdisable;

void PRLVAL_PEStatemachine (UINT8 u8PortNum);
void PRLVAL_DPMStateMachine (UINT8 u8PortNum);

void PRLVal_ProcessValTxRequest (UINT8 gu8ConnectionID, UINT8* pu8HermesReqBuffer);

void PRLVal_TXCallback (UINT8 u8PortNum, UINT8 u8DummyVariable1, UINT8 u8DummyVariable2, UINT8 u8DummyVariable3, UINT8 u8DummyVariable4);

UINT16 PRLVal_HandleTxResponseReq (UINT8 gu8ConnectionID, UINT8* pu8HermesResBuffer);

UINT16 PRLVal_HandleRxResponseReq (UINT8 gu8ConnectionID, UINT8* pu8HermesResBuffer);



#endif







































