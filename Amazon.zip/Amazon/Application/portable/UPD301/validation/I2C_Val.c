
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
//#define VALIDATION 1
#if VALIDATION
#include <stdinc.h>
#include <Hermes_Interface.h>

/* SPI_VALIDATION define used to test SPI communication, this Macro shall be enabled for validation */

/* As of now pu8I2CReqBuffer filled with test bytes, actual use case will be I2C Slave receive buffer bytes*/

#define BUFFER_SIZE                                     275
extern UINT8 pu8HermesResBuffer[BUFFER_SIZE];
extern UINT8 gu8HermesReqBuffer[BUFFER_SIZE];

/******************************************************************************
 * Function:        UINT8 RunSpiValidationTest()
 * Input:           None
 * Output:          Function return TRUE If SPI validation executed successfully
 * Overview:
 * Note:            SPI_VALIDATION macro must be enabled To validate SPI
 *****************************************************************************/

UINT8 I2CVal_HandleTxReq(UINT8*ValidationBufferPtr)
{


	UINT8 u8TestCaseId = ValidationBufferPtr[0];
	switch (u8TestCaseId)
    {
		case 0:
		{
          /* recevied the bytes and handle return the bytes in Rx function

      		*/
            break;
        }

        case 1:
          {

         //   UPD_RegisterWrite(0, (UINT16)0x0030, &ValidationBufferPtr[4], ValidationBufferPtr[3]);
            break;
        }

        case 2:
		{

	//	UPD_RegisterWrite(0, (UINT16)0x0030, &ValidationBufferPtr[4], ValidationBufferPtr[3]);

        break;
        }

    default:
      break;
    }

return 1;
}



UINT16 I2CVal_HandleRxRes(UINT8* ValidationBufferPtr)
{
	UINT8 SPIModeSelTestStatus =1;
	UINT8 u8TestCaseId = ValidationBufferPtr[0];
    UINT16 u16length=0;
	switch (u8TestCaseId)
    {
		case 0:
		{
          u16length = ((gu8HermesReqBuffer[1] <<8)|(gu8HermesReqBuffer[2]));
            for (UINT16 i=0 ; i< u16length ; i++)
            {
              ValidationBufferPtr[i]= gu8HermesReqBuffer[i+3];
            }
            return u16length;
		break;
        }

        case 1:
		{

    //        UPD_RegisterRead(0, (UINT16)0x0030, pu8HermesResBuffer, 10);
            break;
        }

        case 2:
		{
      //      UPD_RegisterRead(0, (UINT16)0x0030, pu8HermesResBuffer, 10);
            break;
        }


    default:
      break;
    }

return SPIModeSelTestStatus;
}
#endif


