
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
//#define VALIDATION 1
#if VALIDATION
#include <stdinc.h>
#include <Hermes_Interface.h>
/* SPI_VALIDATION define used to test SPI communication, this Macro shall be enabled for validation */



extern UINT8 pu8HermesResBuffer[BUFFER_SIZE];

extern UINT8 gu8HResponseCode;
UINT8 gu8ValResponseCode =1;
/******************************************************************************
 * Function:        UINT8 RunSpiValidationTest()
 * Input:           None
 * Output:          Function return TRUE If SPI validation executed successfully
 * Overview:
 * Note:            SPI_VALIDATION macro must be enabled To validate SPI
 *****************************************************************************/

UINT8 SPIVal_HandleTxReq(UINT8* ValidationBufferPtr)
{
	UINT16 RegAdd=0,length =0;
	UINT8 u8TestCaseId = ValidationBufferPtr[0];
    UINT8 ReadBuffer[1]={0};
	switch (u8TestCaseId)
    {
		case 0:
		{
          for (UINT16 j=0 ; j< 1000 ;j++)
          {
           RegAdd= ((ValidationBufferPtr[1]<<8) || (ValidationBufferPtr[2]));
           length= ((ValidationBufferPtr[3]<<8) || (ValidationBufferPtr[4]));
           UPD_RegisterWrite(0, (UINT16)RegAdd, &ValidationBufferPtr[5], length);

            UPD_RegisterRead(0, (UINT16)RegAdd, ReadBuffer, length);
            if(ValidationBufferPtr[5] == ReadBuffer[0])
            {
              gu8HResponseCode =1;
                      break;
             }

          }

            gu8HResponseCode=0;
                break;
        }

        case 1:
          {
            for (UINT16 j=0 ; j< 65535 ;j++)
            {
               RegAdd= ((ValidationBufferPtr[1]<<8) || (ValidationBufferPtr[2]));
               length= ((ValidationBufferPtr[3]<<8) || (ValidationBufferPtr[4]));
               UPD_RegisterWrite(0, (UINT16)RegAdd, &ValidationBufferPtr[5], length);
            //   UPD_RegisterWrite(0, (UINT16)RegAdd, tempbuff, length);
                UPD_RegisterRead(0, (UINT16)RegAdd, ReadBuffer, length);

                    if(ValidationBufferPtr[5] != ReadBuffer[0])
                    {

                      //   status |= 0;
                      gu8HResponseCode =1;
                      break;
                    }

                    gu8HResponseCode=0;
                break;
        }
          }
        case 2:
		{

		//UPD_RegisterWrite(0, (UINT16)0x0030, &ValidationBufferPtr[4], ValidationBufferPtr[3]);

        break;
        }

        default:
        break;
    }

return 1;
}


#endif

