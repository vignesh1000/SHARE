#ifndef _GPIO_VAL_H_
#define _GPIO_VAL_H_

#include <stdinc.h>
#include <UPD301_App.h>

UINT8 GPIOVal_HandleTxReq(UINT8*ValidationBufferPtr);
UINT16 GPIOVal_HandleRxReq(UINT8*ValidationBufferPtr);

#endif