
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

//#define VALIDATION 1

#include <stdinc.h>
#include <validation.h>
#include <Shared_Globals.h>

#if VALIDATION
extern UINT8 gu8HResponseCode;


void Validation_ProcessHermesRequest(UINT8* pu8HermesReqBuffer)
{
    switch(gu8RequestType)
    {
        case TYPEC_API_VALIDATION_REQUEST:
        {
            TypeCVal_APITests(gu8HermesReqBuffer);
            break;
        }
        
        case TYPEC_SM_VALIDATION_REQUEST:
        {
            TypeCVal_SMTests(gu8HermesReqBuffer);
            break;
        }
        
		case PRL_VALIDATION_TX_REQUEST:
        {
		  	PRLVal_ProcessValTxRequest (gu8ConnectionID, pu8HermesReqBuffer);
            break;
        }

		case PRL_VALIDATION_RX_REQUEST:
		{
			break;
		}
        case SPI_VALIDATION_RX_REQUEST:
		{
		//  u16Reslength = SPIVal_HandleRxReq (pu8HermesReqBuffer);
          	break;
		}
        case I2C_VALIDATION_RX_REQUEST:
		{
	//	  u16Reslength = I2CVal_HandleRxReq (pu8HermesReqBuffer);
          	break;
		}
        case SPI_VALIDATION_TX_REQUEST:
		{
		  	(void) SPIVal_HandleTxReq (pu8HermesReqBuffer);
          	break;
		}
        case I2C_VALIDATION_TX_REQUEST:
		{
		  	(void) I2CVal_HandleTxReq (pu8HermesReqBuffer);
          	break;
		}

         case GPIO_VALIDATION_TX_REQUEST:
		{
		  	(void) GPIOVal_HandleTxReq (pu8HermesReqBuffer);
          	break;
		}

		case UART_VALIDATION_REQUEST:
		{
		  	UARTVal_HandleRequest(pu8HermesReqBuffer);
			break;
		}


    }
}

/***************************************************************************************************/

UINT16 Validation_ProcessHermesResponse(UINT8* pu8HermesResBuffer)
{
     UINT16 u16Reslength = 0;

    switch(gu8RequestType)
    {
        case TYPEC_API_VALIDATION_RESPONSE:
        {
            /*Return the Max buffer length*/
            /*gu8HermesResBuffer buffer is already filled during the Validation_ProcessHermesRequest 
            API call*/
            u16Reslength = (BUFFER_SIZE-5);
#ifndef _IDEAL_
            I2C_SlaveIRQdrive (1);
#endif
            break;
        }
        
        case TYPEC_SM_VALIDATION_RESPONSE:
        {
            TypeCVal_SMTestReadReq(pu8HermesResBuffer);
            u16Reslength = 3;
            break;
        }

		case PRL_VALIDATION_TX_RESPONSE:
		{
			u16Reslength = PRLVal_HandleTxResponseReq (gu8ConnectionID, pu8HermesResBuffer);
            break;
		}

		case PRL_VALIDATION_RX_RESPONSE:
		{
			u16Reslength = PRLVal_HandleRxResponseReq (gu8ConnectionID, pu8HermesResBuffer);
          	break;
		}

        case SPI_VALIDATION_RX_RESPONSE:
		{
		//  u16Reslength = SPIVal_HandleRxReq (pu8HermesResBuffer);
          	break;
		}

        case SPI_VALIDATION_TX_RESPONSE:
		{
          	pu8HermesResBuffer[0]= gu8HResponseCode;
          	return 1;
		 	// u16Reslength = SPIVal_HandleTxReq (pu8HermesResBuffer);
          	break;
		}
        case I2C_VALIDATION_TX_RESPONSE:
		{
		  	u16Reslength = I2CVal_HandleTxReq (pu8HermesResBuffer);
          	break;
		}
    	case I2C_VALIDATION_RX_RESPONSE:
      	{
		  	u16Reslength = I2CVal_HandleRxRes (pu8HermesResBuffer);
		  	break;
      	}
		case UART_VALIDATION_RESPONSE:
		{
		  	u16Reslength =  UARTVal_HandleResponse (pu8HermesResBuffer);
			break;
		}
        


    }


    return u16Reslength;


}




/***************************************************************************************************/
#endif