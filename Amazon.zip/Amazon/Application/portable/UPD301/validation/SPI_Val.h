#ifndef _SPI_VAL_H_
#define _SPI_VAL_H_

#include <stdinc.h>


UINT8 SPIVal_HandleTxReq(UINT8* ValidationBufferPtr);
//UINT8 SPIVal_HandleRxReq(UINT8*ValidationBufferPtr);




//#if SPI_VALIDATION 
//UINT8 RunSpiValidationTest(void);
#endif