#ifndef _TYPECCONTROLVAL_H_
#define _TYPECCONTROLVAL_H_

#include <stdinc.h>

#define TYPECVAL_CC1PIN 0
#define TYPECVAL_CC2PIN 1

void TypeCVal_RunValidation();

void TypeCVal_APITests(UINT8* pu8HermesReqBuffer);

void TypeCVal_SMTests(UINT8* pu8HermesReqBuffer);

void TypeCVal_SMTestReadReq(UINT8* pu8HermesResBuffer);

void TypeCVal_SetPortConfigSrcDefault(UINT8 u8PortNum);

void TypeCVal_SetPortConfigSrc15A(UINT8 u8PortNum);

void TypeCVal_SetPortConfigSrc30A(UINT8 u8PortNum);

void TypeCVal_SetPortConfigSink(UINT8 u8PortNum);

void TypeCVal_SetSinkAttach(UINT8 u8PortNum, UINT8 u8CC1orCC2 , UINT8 u8SrcType);

void TypeCVal_SetSourceAttach(UINT8 u8PortNum, UINT8 u8CC1orCC2 , UINT8 u8SrcType);

void TypeCVal_SetPwdCableAttach(UINT8 u8PortNum, UINT8 u8CC1orCC2 , UINT8 u8SrcType);

void TypeCVal_ClearCCPin(UINT8 u8PortNum, UINT8 u8CC1orCC2);

void TypeCVal_SetCCInterruptStatus(UINT8 u8PortNum);

void TypeCVal_SetVConnOnStatus(UINT8 u8PortNum, UINT8 u8CC1orCC2);

void TypeCVal_ClearVBusStatus(UINT8 u8PortNum);

void TypeCVal_SetVBusStatus(UINT8 u8PortNum);

void WaitUntilSPITestRegister(UINT8 u8PortNum);

#endif







































