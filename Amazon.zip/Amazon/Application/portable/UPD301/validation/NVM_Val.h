#ifndef _NVM_VAL_H_
#define _NVM_VAL_H_

#include <stdinc.h>


UINT8 NVMVal_HandleTxReq(UINT8*ValidationBufferPtr);
UINT16 NVMVal_HandleRxReq(UINT8*ValidationBufferPtr);

#endif