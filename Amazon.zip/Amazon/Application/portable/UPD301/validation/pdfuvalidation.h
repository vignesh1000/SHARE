#ifndef _VALIDATION_H_
#define _VALIDATION_H_

#include <stdinc.h>

#define PDFU_VALIDATION_TX_RESPONSE						0xA2
#define PDFU_VALIDATION_TX_REQUEST					    0xA3

#define PDFU_VALIDATION_RX_RESPONSE						0xA4
#define PDFU_VALIDATION_RX_REQUEST					    0xA5

void copyPDFUResponse(UINT32 u32Header,UINT8* u8pRespuffer);
void pdfuValidation_ProcessHermesRequest(UINT8* pu8HermesReqBuffer);
UINT16 pdfuValidation_ProcessHermesResponse(UINT8* pu8HermesResBuffer);


#endif