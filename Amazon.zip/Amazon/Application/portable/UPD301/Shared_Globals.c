/*
 * Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
 *
 * Microchip licenses to you the right to use, modify, copy and distribute
 * Software only when embedded on a Microchip microcontroller or digital signal
 * controller that is integrated into your product or third party product
 * (pursuant to the sublicense terms in the accompanying license agreement).
 *
 * You should refer to the license agreement accompanying this Software for
 * additional information regarding your rights and obligations.
 *
 * SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
 * CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
 * OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
 * INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
 * SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
 * (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 */
/** Scope of the file:

    This file contains,
    1) Shared Buffers
    2) Fixed Location Configurable Variables
    3) Fixed Location Volatile constants,

**/
#include <generic_defs.h>

#include "Hermes_Interface.h"
#include "Shared_Globals.h"
/** Hermes Buffers for storing data */
UINT8 gu8HermesReqBuffer[BUFFER_SIZE] = { 0 };
UINT8 gu8HermesResBuffer[BUFFER_SIZE] = { 0 };

UINT8 gu8HermesPdfuActive = 0x00u;
UINT8 gu8AlertRespBuffer[4] @0x20000FFC = {0};
/**
Success/Error code after processing Hermes Request
stored in this variable
*/

UINT8 gu8HResponseCode = HERMES_HRESP_INVALID;

/**
I2C Number of bytes received
Why Volatile? This variable can updated from fixed application also
*/
UINT16 gu16Rxcount @0x20000ff4;// = 0x00u;

/**
Hermes Protocol request type Storing variable
Why Volatile? This variable can updated from fixed application also
*/
volatile UINT8 gu8RequestType @0x20000ff0;//  = HERMES_INVALID_REQUEST;
/**
Hermes Protocol Connection ID Storing variable
Why Volatile? This variable can updated from fixed application also
*/
volatile UINT8 gu8ConnectionID;// = HERMES_CONN_ID_INVALID;
/**
This variable stores Which Image is currently executing
0 - Bootloader
1- Fixed App
2- Updateable App
Why Volatile? This variable can updated from fixed application also
*/
volatile UINT8 gu8CurrentMemory @0x200000bc;


/** Requires fixing Memory in "ROM" 
    Manifestation state Shall include the Jump address configuration on NVM**/

/* SAMD20J16B Memory Partition Constants
 *      Flash:                  0x00000000 - 0x00010000 (64 KB)
 *      Bootloader:             0x00000000 - 0x00000FFF (4 KB)
 *      FixedApplication:       0x00001000 - 0x00005FFF (20 KB)
 *      UpdateApplication:       0x00005FFF - 0x00010000 (40 KB)
*/


volatile UINT32 pFixedApplicationPtr =(UINT32 )&FixedApplication;
volatile UINT32 pUpdatedApplicationPtr =(UINT32 )&UpdatedApplication;
volatile UINT32 pFixedApplicationSignature =(UINT32 )&FixedApplicationSignature;
volatile UINT32 pUpdatedApplicationSignature =(UINT32 )&UpdatedApplicationSignature;

UINT8 gu8SlaveAddr @0x20000ff8 = 0x00u;
UINT8 gu8HermesConnectionActive = FALSE;
void CfgGlobals_Initialize(void)
{
    gu8SlaveAddr = 0x00u;
    
    gu8ConnectionID = HERMES_CONN_ID_INVALID;
    
    gu16Rxcount = 0x00u;
    
    gu8HResponseCode = HERMES_HRESP_INVALID;    
}

