/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include <UPD301_App.h>

void* UPD301_MemCpy(void *dest, const void *src, int n)
{
   // Typecast src and dest addresses to (char *)
   char *csrc = (char *)src;
   char *cdest = (char *)dest;
 
   // Copy contents of src[] to dest[]
   for (int i=0; i<n; i++)
       cdest[i] = csrc[i];
   
   return dest;
}

int UPD301_MemCmp(const void *pau8Data1, const void *pau8Data2, int len)
{
	int i;
    UINT8 *pu8Obj1 = (UINT8 *)pau8Data2;
    UINT8 *pu8Obj2 = (UINT8 *)pau8Data2;
	
	for (i = 0; i < len; i++)
    {
    	if (pu8Obj1[i] != pu8Obj2[i])
            return (pu8Obj1[i] - pu8Obj2[i]);            	
	}
    
	return 0;
}


void GPIOStrap_SetTristate(UINT8 u8pin)
{
      UINT32 u32mask = (UINT32)((1u) << (GPIOPIN(u8pin)));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN | (u32mask & GPIO_MASK_LOWWORD));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_HWSEL | GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN |((u32mask & GPIO_MASK_HIGHWORD) >> GPIO_MASK_OFFSET));
}

UINT8 GPIOStrap_GetInputLevel(UINT8 u8pin)
{
    UINT32 u32mask = (UINT32)((1u) << (GPIOPIN(u8pin)));
     
    return ((UINT8)((REGDW(GPIO_IN_REG_ADDR) & u32mask) > 0) ? 1 : 0);
}

/* Starps Read for Port Role Set */
void STRAPS_PowerRole_Set(PORT_CONFIG_DATA *PortConfigData)
{
    UINT16 u16Data = 0;
    UINT32 u32CfgData = 0;
       
    GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_IN);
    GPIO_SetPullMode(PIN_PA28,GPIO_PULLOFF);
    
    if(GPIOStrap_GetInputLevel(PIN_PA28))
    {
        /* Port Role Source */
        u32CfgData |= PD_ROLE_SOURCE;
        u32CfgData |= (RP_VAL_3A << TYPEC_PORT_RPVAL_POS);
        DecodePDPStrapCap( 0, PD_ROLE_SOURCE, PortConfigData);
    }
    
    else
    {
        /* Port Role Sink */
        u32CfgData |= PD_ROLE_SINK;
        u32CfgData |= (RP_VAL_RD << TYPEC_PORT_RPVAL_POS);
        DecodePDPStrapCap( 0, PD_ROLE_SINK, PortConfigData);
    }
    
    PortConfigData[0].u32CfgData = u32CfgData;
    
    u32CfgData = 0;
    
    u16Data = UPD_RegReadWord ( 1, EXTERNAL_UPD350_PIO_STS);
    
    if(u16Data & EXTERNAL_UPD350_PIO2_MASK)
    {
        /* Port Role Source */
        u32CfgData |= PD_ROLE_SOURCE;
        u32CfgData |= (RP_VAL_3A << TYPEC_PORT_RPVAL_POS);
        DecodePDPStrapCap( 1, PD_ROLE_SOURCE, PortConfigData);
    }
    
    else
    {
        /* Port Role Sink */
        u32CfgData &= (~TYPEC_PORT_TYPE_MASK);
        u32CfgData |= (RP_VAL_RD << TYPEC_PORT_RPVAL_POS);
        DecodePDPStrapCap( 1, PD_ROLE_SINK, PortConfigData);
    }
    
        PortConfigData[1].u32CfgData = u32CfgData;
}

void DecodePDPStrapCap(UINT8 u8PortNum, UINT8 u8PortRole, PORT_CONFIG_DATA *PortConfigData)
{
    UINT8 u8Strapvalue = 0;
    UINT8 u8PinVal = 0;
    
    /*PA04: PDP_SEL0_S*/
    /*PA05: PDP_SEL1_S*/
   
    //Tested:200K Pull-up,200K Pull-down,4K7 Pull-down,4K7O Pull-up,10Q pull down,10Q pull up
    
    //CONFIG1->0x0A,CONFIG2->0x0B,CONFIG3->0x00,CONFIG4->0x1F,CONFIG5->0x00,CONFIG6->0x1F
  
    if(u8PortNum == 0)
    {
        u8PinVal = PIN_PA04;
    }
    
    else
    {
        u8PinVal = PIN_PA05;
    }
    
    
    /*Step1:Setting Input enable,Setting pull down*/
    GPIO_SetDirection(u8PinVal, GPIO_SETDIRECTION_IN);
  
    GPIO_SetPullMode(u8PinVal,GPIO_PULLDOWN); 
    
    /*Delay*/
     PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(5));
    
       
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {
    
        u8Strapvalue |= BIT(4);
    }
   
    
    /*Step2: Setting Pull up*/
    GPIO_SetPullMode(u8PinVal,GPIO_PULLUP); 
    
    /*Temporary delay*/
    PDTimer_WaitforTicks( MILLISECONDS_TO_TICKS(5));
    
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {
    
        u8Strapvalue |= BIT(3);
    }
    
    /*Step3:Drive the pin as low.Enable Output.*/
    GPIO_SetDirection(u8PinVal, GPIO_SETDIRECTION_OUT); 
    GPIO_SetPinLevel(u8PinVal, GPIO_DRIVELOW); 
    GPIOStrap_SetTristate(u8PinVal);
    
    /*Temporary delay*/
    PDTimer_WaitforTicks( MILLISECONDS_TO_TICKS(5));
    
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {
    
        u8Strapvalue |= BIT(2);
    }
    
    /*Step4:Drive the pin as high.*/
    
    GPIO_SetDirection(u8PinVal, GPIO_SETDIRECTION_OUT);
    GPIO_SetPinLevel(u8PinVal, GPIO_DRIVEHIGH);
    GPIOStrap_SetTristate(u8PinVal);
    
    /*Temporary delay*/
    PDTimer_WaitforTicks( MILLISECONDS_TO_TICKS(5));
    
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {
    
        u8Strapvalue |= BIT(1);
    }
    
    /*Step5:Disable the output*. TODO:Hoow to enable GPIO_SET_TRISTATE*/
    /*Disable the output by enabling the input*/
    GPIO_SetDirection(u8PinVal, GPIO_SETDIRECTION_IN);
    GPIO_SetPullMode(u8PinVal,GPIO_PULLOFF); 
    GPIOStrap_SetTristate(u8PinVal);
    
    /*Temporary delay*/
    PDTimer_WaitforTicks( MILLISECONDS_TO_TICKS(5));
    
        
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {    
        u8Strapvalue |= BIT(0);
    }
    
    UINT32 u32PDOs[4] = {0};
    UINT8 u8PDOCnt = 0;
    
    switch(u8Strapvalue)
    {
        case CONFIG1:
        {
            if(PD_ROLE_SOURCE == u8PortRole)
            {
                u8PDOCnt = CONFIG1_PDO_COUNT;
                u32PDOs[0] = SRC_CAP_5V_1P5A;
                PortConfigData[u8PortNum].u32CfgData &= ~TYPEC_PORT_RPVAL_MASK;
                PortConfigData[u8PortNum].u32CfgData |= (RP_VAL_1P5A << TYPEC_PORT_RPVAL_POS);
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_1P5A;
                u8PDOCnt = CONFIG1_PDO_COUNT;             
            }
            break;  
        }
        case CONFIG2:
        {
            if((UINT8)PD_ROLE_SOURCE == u8PortRole)
            {
                u32PDOs[0] =  SRC_CAP_5V_3A;
                u8PDOCnt = CONFIG2_PDO_COUNT;
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_3A_LOW;
                u8PDOCnt = CONFIG2_PDO_COUNT;             
            }
            break;  
        }
        case CONFIG3:
        {
            if(u8PortRole == PD_ROLE_SOURCE)
            {
                u32PDOs[0] =  SRC_CAP_5V_3A;
                u32PDOs[1] =  SRC_CAP_9V_3A;
                u8PDOCnt = CONFIG3_PDO_COUNT;
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_3A;
                u32PDOs[1] =  SNK_CAP_9V_3A;
                u8PDOCnt = CONFIG3_PDO_COUNT;             
            }
            break;  
        }
        case CONFIG4:
        {
            if(u8PortRole == PD_ROLE_SOURCE)
            {
                u32PDOs[0] =  SRC_CAP_5V_3A;
                u32PDOs[1] =  SRC_CAP_9V_3A;
                u32PDOs[2] =  SRC_CAP_15V_3A;
                u8PDOCnt = CONFIG4_PDO_COUNT;
            }            
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_3A;
                u32PDOs[1] =  SNK_CAP_9V_3A;
                u32PDOs[2] =  SNK_CAP_15V_3A;
                u8PDOCnt = CONFIG4_PDO_COUNT;
            }
            break;  
        }
        case CONFIG5:
        {
            if(u8PortRole == PD_ROLE_SOURCE)
            {
                u32PDOs[0] =  SRC_CAP_5V_3A;
                u32PDOs[1] =  SRC_CAP_9V_3A;
                u32PDOs[2] =  SRC_CAP_15V_3A;
                u32PDOs[3] =  SRC_CAP_20V_3A;
                u8PDOCnt = CONFIG5_PDO_COUNT;
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_3A;
                u32PDOs[1] =  SNK_CAP_9V_3A;
                u32PDOs[2] =  SNK_CAP_15V_3A;
                u32PDOs[3] =  SNK_CAP_20V_3A;
                u8PDOCnt = CONFIG5_PDO_COUNT;            
            }
            break;  
        }
        case CONFIG6:
        {
            if(u8PortRole == PD_ROLE_SOURCE)
            {
                u32PDOs[0] =  SRC_CAP_5V_5A;
                u32PDOs[1] =  SRC_CAP_9V_5A;
                u32PDOs[2] =  SRC_CAP_15V_5A;
                u32PDOs[3] =  SRC_CAP_20V_5A;
                u8PDOCnt = CONFIG6_PDO_COUNT;
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_5A;
                u32PDOs[1] =  SNK_CAP_9V_5A;
                u32PDOs[2] =  SNK_CAP_15V_5A;
                u32PDOs[3] =  SNK_CAP_20V_5A;
                u8PDOCnt = CONFIG6_PDO_COUNT;              
            }
            break;  
        }      
    }
    
    UINT8 u8Loop = 0;
    if(u8PortRole == PD_ROLE_SOURCE)
    {
        PortConfigData[u8PortNum].u8SrcCnt = u8PDOCnt;
        
        for(u8Loop = 0; u8Loop < u8PDOCnt; u8Loop++)
        {
            PortConfigData[u8PortNum].u32SrcCap[u8Loop] = u32PDOs[u8Loop];
        }
    }
    
    else
    {
        PortConfigData[u8PortNum].u8SinkCnt = u8PDOCnt;
        
        for(u8Loop = 0; u8Loop < u8PDOCnt; u8Loop++)
        {
            PortConfigData[u8PortNum].u32SinkCap[u8Loop] = u32PDOs[u8Loop];
        }        
    }

}

void InitOrientationPins()
{

    GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_OUT);
    GPIO_SetPinLevel(PIN_PA28, GPIO_DRIVELOW);
    
    UPD_GPIOEnableDisable(1,UPD_PIO2,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(1,UPD_PIO2,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(1,UPD_PIO2,UPD_GPIO_SETBUF_PUSHPULL);

}

void PDStack_Events(UINT8 u8PortNum, UINT8 u8PDEvent)
{

    if((TYPEC_CC1_ORIENTATION == u8PDEvent) || (TYPEC_DETACH_EVENT == u8PDEvent))
    {
        if(0 == u8PortNum)
        {
            GPIO_SetPinLevel(PIN_PA28, GPIO_DRIVELOW);
        }
        else
        {
             UPD_GPIOSetClearOutput(1,UPD_PIO2,UPD_GPIO_CLEAR);
        }
          
    }
    else if(TYPEC_CC2_ORIENTATION == u8PDEvent)
    {
        if(0 == u8PortNum)
        {
            GPIO_SetPinLevel(PIN_PA28, GPIO_DRIVEHIGH);
        }
        else
        {
             UPD_GPIOSetClearOutput(1,UPD_PIO2,UPD_GPIO_SET);
        }
    
    }

}
