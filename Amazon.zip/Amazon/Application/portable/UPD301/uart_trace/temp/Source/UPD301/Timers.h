/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _TIMERS_H_
#define _TIMERS_H_

#include <ZeusStackConfig.h>
/* ========== Register definition for TC0 peripheral ========== */
#define TC0_REG_ADDR            (0x42002000)
#define TC0_CTRLA              (0x42002000) /**< \brief (TC0) Control A */
#define TC0_READREQ            (0x42002002) /**< \brief (TC0) Read Request */
#define TC0_CTRLBCLR           (0x42002004) /**< \brief (TC0) Control B Clear */
#define TC0_CTRLBSET           (0x42002005) /**< \brief (TC0) Control B Set */
#define TC0_CTRLC              (0x42002006) /**< \brief (TC0) Control C */
#define TC0_DBGCTRL            (0x42002008) /**< \brief (TC0) Debug Control */
#define TC0_EVCTRL             (0x4200200A) /**< \brief (TC0) Event Control */
#define TC0_INTENCLR           (0x4200200C) /**< \brief (TC0) Interrupt Enable Clear */
#define TC0_INTENSET           (0x4200200D) /**< \brief (TC0) Interrupt Enable Set */
#define TC0_INTFLAG            (0x4200200E) /**< \brief (TC0) Interrupt Flag Status and Clear */
#define TC0_STATUS             (0x4200200F) /**< \brief (TC0) Status */
#define TC0_COUNT16_COUNT      (0x42002010) /**< \brief (TC0) COUNT16 Counter Value */
#define TC0_COUNT16_CC0        (0x42002018) /**< \brief (TC0) COUNT16 Compare/Capture 0 */
#define TC0_COUNT16_CC1        (0x4200201A) /**< \brief (TC0) COUNT16 Compare/Capture 1 */
#define TC0_COUNT32_COUNT      (0x42002010) /**< \brief (TC0) COUNT32 Counter Value */
#define TC0_COUNT32_CC0        (0x42002018) /**< \brief (TC0) COUNT32 Compare/Capture 0 */
#define TC0_COUNT32_CC1        (0x4200201C) /**< \brief (TC0) COUNT32 Compare/Capture 1 */
#define TC0_COUNT8_COUNT       (0x42002010) /**< \brief (TC0) COUNT8 Counter Value */
#define TC0_COUNT8_PER         (0x42002014) /**< \brief (TC0) COUNT8 Period Value */
#define TC0_COUNT8_CC0         (0x42002018) /**< \brief (TC0) COUNT8 Compare/Capture 0 */
#define TC0_COUNT8_CC1         (0x42002019) /**< \brief (TC0) COUNT8 Compare/Capture 1 */

/* ========== Instance parameters for TC0 peripheral ========== */
#define TC0_CC8NUM                      2       
#define TC0_CC16NUM                     2       
#define TC0_CC32NUM                     2       
#define TC0_DITHERINGEXT                0       
#define TC0_GCLKID                      19      
#define TC0_MASTER                      1       
#define TC0_OW_NUM                      2       
#define TC0_PERIODEXT                   0       
#define TC0_SHADOWEXT                   0 
#define TC0_CC1_CC2_VALUE		        0

#define TC0_ENABLE_INTERRUPT                (1 << (UINT8)TC0_IRQn)

#define TC0_INTENSET_OVF_POS                0            /**< \brief (TC_INTENSET) Overflow Interrupt Enable */
#define TC0_INTENSET_OVF                    (0x1 << TC0_INTENSET_OVF_POS)

#define TC0_EVCTRL_MASK                     (0x3137)  /**< \brief (TC_EVCTRL) MASK Register */ 

#define TC0_DBGCTRL_DBGRUN_POS              0            /**< \brief (TC_DBGCTRL) Debug Run Mode */
#define TC0_DBGCTRL_DBGRUN                  (0x1 << TC0_DBGCTRL_DBGRUN_POS)

#define TC0_CTRLA_PRESCSYNC_POS             12           /**< \brief (TC_CTRLA) Prescaler and Counter Synchronization */
#define TC0_CTRLA_PRESCSYNC_MSK             (0x3 << TC0_CTRLA_PRESCSYNC_POS)

#define TC0_CTRLA_RUNSTDBY_POS              11           /**< \brief (TC_CTRLA) Run in Standby */
#define TC0_CTRLA_RUNSTDBY                  (0x1 << TC0_CTRLA_RUNSTDBY_POS)

#define TC0_CTRLA_PRESCALER_DIV256_Val      (0x6)   /**< \brief (TC_CTRLA) GCLK_TC/256 */
#define TC0_CTRLA_PRESCALER_POS             8            /**< \brief (TC_CTRLA) Prescaler */
#define TC0_CTRLA_PRESCALER                 (TC0_CTRLA_PRESCALER_DIV256_Val << TC0_CTRLA_PRESCALER_POS)

#define TC0_CTRLA_WAVEGEN_POS               5            /**< \brief (TC_CTRLA) Waveform Generation Operation */
#define TC0_CTRLA_WAVEGEN_NFRQ              ((0x0)     << TC0_CTRLA_WAVEGEN_POS)  

#define TC0_CTRLA_ENABLE_POS            1            /**< \brief (TC_CTRLA) Enable */
#define TC0_CTRLA_ENABLE                (0x1 << TC0_CTRLA_ENABLE_POS)
#define TC0_CTRLA_MODE_POS                  2            /**< \brief (TC_CTRLA) TC Mode */

#define TC0_CTRLA_MODE_COUNT8_VAL           (0x1)   /**< \brief (TC_CTRLA) Counter in 8-bit mode */
#define TC0_CTRLA_MODE_COUNT8               (TC0_CTRLA_MODE_COUNT8_VAL << TC0_CTRLA_MODE_POS)

#define TC0_ADDR                        (0x42002000UL) /**< \brief (TC0) APB Base Address */
#define TC0_PERIOD_REGISTER_VAL 	        (186000/(CONFIG_PDTIMER_INTERRUPT_RATE))

/* ========== Regiser access Macros ========== */
#define REGB(x)                         (*((unsigned char volatile *)(x)))      /* 8 bit register access*/
#define REGW(x)                         (*((unsigned short int volatile *)(x))) /* 16 bit register access*/
#define REGDW(x)                        (*((unsigned int volatile *)(x)))      /* 32 bit register access*/
#define TC0_CLKCTRL_GEN_GCLK0_VAL           (0x0)   /**< \brief (GCLK_CLKCTRL) Generic clock generator 0 */
#define TC0_CLKCTRL_CLKEN_POS               14           /*Clock Enable */
#define TC0_CLKCTRL_CLKEN                   ((0x1) << TC0_CLKCTRL_CLKEN_POS)
#define TC0_CLKCTRL_GEN_POS                 8
#define TC0_CLKCTRL_GEN                 ((0x0) << TC0_CLKCTRL_GEN_POS)

#define TC0_CLKCTRL_ID_POS                  0          /* Generic Clock Selection ID */
#define TC0_GCLK_ENABLE                 (TC0_GCLKID <<TC0_CLKCTRL_ID_POS)
#define TC0_GCLKCTLREG                      (0x40000C02) /*brief (GCLK) APB Base Address */
#define TC0_APBCMASK_OFFSET                 0x20 
#define PMREG                           (0x40000400) /* brief (PM) APB Base Address */
#define APBCREG                         (PMREG + APBCMASK_OFFSET) 

#define TCSCS_BASE_ADDR                 (0xE000E000)    /*!< System Control Space Base Address */
#define TCSysTick_BASE_ADDR             (TCSCS_BASE_ADDR +  0x0010) /*!< SysTick Base Address */
#define TCNVIC_BASE_ADDR                (TCSCS_BASE_ADDR +  0x0100) 
#define TC0_INTSET_ENABLE_REG_OFFSET    0x000
#define TC0_INTSET_ENABLE_REG           TCNVIC_BASE_ADDR + TC0_INTSET_ENABLE_REG_OFFSET

#define PHERIPHERAL_SEL_MASK            0x0000ff00
#define PHERIPHERAL_SEL_SERCOM          10

UINT8 Timer_Init(void);

#endif