/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#include <stdinc.h>

void PE_Init(UINT8 u8PortNum)
{           
  
    /*Setting the HardResetCounter and CapsCounter to 0 */
    gasPolicy_Engine[u8PortNum].u8HardResetCounter = 0;
    
    /*Setting Port Status Variable to 0 */
    gasPolicy_Engine[u8PortNum].u8PEPortSts = 0;

    /*Setting Timeout State to 0 */
    gasPolicy_Engine[u8PortNum].ePETimeoutState = (ePolicyState) FALSE;
    
    /*Setting Timer ID to Max value */
    gasPolicy_Engine[u8PortNum].u8PETimerID = 255;
            
    if((gasPortConfigurationData[u8PortNum].u32CfgData & TYPEC_PORT_TYPE_MASK) == PD_ROLE_SOURCE)
    {   
        /*Setting the CapsCounter to 0 */
        gasPolicy_Engine[u8PortNum].u8CapsCounter = 0;

        /*Setting Initial Policy Engine States */
        gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_STARTUP;
        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_STARTUP_ENTRY_SS;

        /*Set No Response TimerID to Max Value */
        gasPolicy_Engine[u8PortNum].u8PENoResponseTimerID = 255;
    }   
    else
    {
        /*Setting Initial Policy Engine States */
        gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_STARTUP;
        gasPolicy_Engine[u8PortNum].ePESubState = (ePolicySubState) 0;
    }
}


void PE_RunStateMachine(UINT8 u8PortNum)
{
    
    UINT8 u8DataBuf[260] = {0};     /* Receive Data Buffer */
    UINT8 u8SOPType = 0;            /* Receive Msg Type - SOP SOP' SOP" */
    UINT32 u32Header = 0;           /* Receive Msg Header */
    UINT8 u8RetVal = 0;
    
    /* Protocol layer Chunk State machine must be ran by PE to receive Chunk message if any*/
#ifdef INCLUDE_PD_3_0    
    PRL_RunChunkStateMachine (u8PortNum);    
#endif
    
     CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
    /*Check the HardReset Flag in DPMStatus variable if any hard reset is received*/
    if(gasDPM[u8PortNum].u8DPM_Status & DPM_HARDRESET_RCVD_MASK)
    {
        if(DPM_GET_DEFAULT_POWER_ROLE(u8PortNum) == PD_ROLE_SOURCE)
        {                    
            gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_HARD_RESET_RECEIVED;
            gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_HARD_RESET_RECEIVED_ENTRY_SS;
        }
        else
        {
            gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_TRANSITION_TO_DEFAULT;
            gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_TRANSITION_TO_DEFAULT_ENTRY_SS;
         
        }
        
        gasDPM[u8PortNum].u8DPM_Status &= ~DPM_HARDRESET_RCVD_MASK;    
    }
     CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();
    
      
    
    PE_SetVDMStateActiveFlag(u8PortNum);
	
	 u8RetVal = PRL_ReceiveMsg(u8PortNum, &u8SOPType, &u32Header, u8DataBuf, NULL);
    
    /* If any new Msg is received, pass it to the Receive Handler */
    if((PRL_RET_MSG_RCVD == u8RetVal) || (PRL_RET_EXT_MSG_RCVD == u8RetVal))
    {
        /*Setting the Specification Revision as per section 6.2.1.1.5 from 
        PD Specification 3.0*/
        if (DPM_GET_DEFAULT_PD_SPEC_REV(u8PortNum) > PRL_GET_PD_SPEC_REV(u32Header))
        {
            gasDPM[u8PortNum].u8DPM_Status &= ~DPM_CURR_PD_SPEC_REV_MASK;
            gasDPM[u8PortNum].u8DPM_Status |= ((PRL_GET_PD_SPEC_REV(u32Header)) << DPM_CURR_PD_SPEC_REV_POS);
        }
        else
        {
            
            gasDPM[u8PortNum].u8DPM_Status &= ~DPM_CURR_PD_SPEC_REV_MASK;
            gasDPM[u8PortNum].u8DPM_Status |= ((DPM_GET_DEFAULT_PD_SPEC_REV(u8PortNum)) << DPM_GET_DEFAULT_PD_SPEC_REV(u8PortNum));
        
        }
        
        /* Spec Rev is updated by PRL*/
        PRL_UpdateSpecAndDeviceRoles (u8PortNum);
        
        gasPolicy_Engine[u8PortNum].u32MsgHeader = u32Header;
        PE_ReceiveHandler(u8PortNum, u32Header);
    }
    
    CONFIG_HOOK_POLICY_ENGINE_PRE_PROCESS(u8PortNum, u8DataBuf, u8SOPType,u32Header);
   
    if(DPM_GET_DEFAULT_POWER_ROLE(u8PortNum) == PD_ROLE_SOURCE)
    {
        PE_SrcRunStateMachine(u8PortNum, u8DataBuf, u8SOPType,u32Header);
    }
    else if(DPM_GET_DEFAULT_POWER_ROLE(u8PortNum) == PD_ROLE_SINK)
    {
        PE_SnkRunStateMachine(u8PortNum, u8DataBuf, u8SOPType,u32Header);
    }   
    
    PE_RunCommonStateMachine(u8PortNum, u8DataBuf, u8SOPType,u32Header);

}

UINT8 PE_IsMsgUnsupported(UINT8 u8PortNum, UINT16 u16Header)
{
    UINT8 u8MsgType = FALSE;
    UINT8 u8RetVal = FALSE;
    
    u8MsgType = PRL_GET_MESSAGE_TYPE(u16Header);
    
    if(PRL_IS_EXTENDED_MSG(u16Header))
    {
        if((ePE_EXT_FW_UPDATE_REQUEST != u8MsgType) && (ePE_EXT_FW_UPDATE_RESPONSE != u8MsgType))
        {
            u8RetVal = PE_UNSUPPORTED_MSG;        
        }
    }
    
    else
    {
        if(0 == PRL_GET_OBJECT_COUNT(u16Header))
        {
            if((ePE_CTRL_GOTO_MIN == u8MsgType) || (u8MsgType > ePE_NOT_SUPPORTED)  \
               || ((u8MsgType > ePE_CTRL_SOFT_RESET) && (u8MsgType < ePE_NOT_SUPPORTED)) )
            {
                u8RetVal = PE_UNSUPPORTED_MSG;
            }
            else if((ePE_CTRL_DR_SWAP == u8MsgType) || (ePE_CTRL_PR_SWAP == u8MsgType))
            {
            
                u8RetVal = PE_SEND_REJECT_MSG;
            }
            
            else if((DPM_GET_DEFAULT_DATA_ROLE(u8PortNum) == PD_ROLE_SOURCE) && ((ePE_CTRL_GET_SINK_CAP == u8MsgType) \
                        || ((ePE_CTRL_PING == u8MsgType))))
            {
                u8RetVal = PE_UNSUPPORTED_MSG;
            }
            
            else if((DPM_GET_DEFAULT_DATA_ROLE(u8PortNum) == PD_ROLE_SINK) && ((ePE_CTRL_GET_SOURCE_CAP == u8MsgType)))
            {
                u8RetVal = PE_UNSUPPORTED_MSG; 
            }
        }
        
        else
        {
            if((u8MsgType > ePE_DATA_SINK_CAP) && (u8MsgType != ePE_DATA_VENDOR_DEFINED) )
            {
                u8RetVal = PE_UNSUPPORTED_MSG;
            }
            
            else if((DPM_GET_DEFAULT_DATA_ROLE(u8PortNum) == PD_ROLE_SOURCE) && (ePE_DATA_SOURCE_CAP == u8MsgType))
            {
                u8RetVal = PE_UNSUPPORTED_MSG;
            }
            
            else if((DPM_GET_DEFAULT_DATA_ROLE(u8PortNum) == PD_ROLE_SINK) && ((ePE_DATA_SINK_CAP == u8MsgType) || \
                (ePE_DATA_REQUEST == u8MsgType)))
            {
                u8RetVal = PE_UNSUPPORTED_MSG; 
            }
            
            else
            {
                /* Do Nothing */  
            }
          
        }
      
    }
    
    return u8RetVal;
}

void PE_SendNotSupportedOrRejectMsg(UINT8 u8PortNum)
{  
    if((DPM_GET_CURRENT_PD_SPEC_REV(u8PortNum) == PD_SPEC_REVISION_3_0))
    {
        gasPolicy_Engine[u8PortNum].ePEState = ePE_SEND_NOT_SUPPORTED;
        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SEND_NOT_SUPPORTED_ENTRY_SS;
    }
    else
    {
        gasPolicy_Engine[u8PortNum].ePEState = ePE_SEND_REJECT;
        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SEND_REJECT_ENTRY_SS;
    }       
}

UINT8 PE_ValidateMessage(UINT8 u8PortNum, UINT32 u32Header)
{
    UINT8 u8RetVal = FALSE;
    UINT8 u8IsUnsupported = PE_IsMsgUnsupported(u8PortNum, u32Header);
    
    if((u8IsUnsupported == PE_UNSUPPORTED_MSG) || (u8IsUnsupported == PE_SEND_REJECT_MSG))
    {
        if((ePE_SRC_READY == gasPolicy_Engine[u8PortNum].ePEState) || 
           (ePE_SNK_READY == gasPolicy_Engine[u8PortNum].ePEState))
        {
            
            if(u8IsUnsupported == PE_UNSUPPORTED_MSG)
            {
                PE_SendNotSupportedOrRejectMsg(u8PortNum);
            }
            else if(u8IsUnsupported == PE_SEND_REJECT_MSG)
            {
                gasPolicy_Engine[u8PortNum].ePEState = ePE_SEND_REJECT;
                gasPolicy_Engine[u8PortNum].ePESubState = ePE_SEND_REJECT_ENTRY_SS;
            }
         
            u8RetVal = PE_MSG_HANDLED;
        }       
        else
        {
            /*AMS Type is interruptable*/
            if((gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_AMS_TYPE))
            {
                u8RetVal = PE_PROCESS_MSG;
            } 
            /*AMS Type is Non interruptable*/
            else
            {
                PE_HandleUnExpectedMsg( u8PortNum, u32Header);
            }               
        }     
    }   
    else
    {
        u8RetVal = PE_PROCESS_MSG; 
    }
 
    return u8RetVal;
}

void PE_ExpectedMsg(UINT8 u8PortNum, UINT8 u8NextState)
{
    _trace1(1, main_tr, 0, 0x01, u8PortNum,"PE: Expected Msg received\r\n");
    if(gasPolicy_Engine[u8PortNum].ePETimeoutState == 0)
    {
        gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState)u8NextState;
    }
    
    else
    {
        if(gasPolicy_Engine[u8PortNum].u3TimeoutMsgHeader == gasPolicy_Engine[u8PortNum].u32MsgHeader)
        {
            gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState)u8NextState;
        }
        
        else
        {
            gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState)gasPolicy_Engine[u8PortNum].ePETimeoutState;
        }
    }
}

void PE_HandleUnExpectedMsg(UINT8 u8PortNum, UINT32 u32Header)
{
    if(ePE_SRC_TRANSITION_SUPPLY == gasPolicy_Engine[u8PortNum].ePEState || \
      ePE_SNK_TRANSITION_SINK == gasPolicy_Engine[u8PortNum].ePEState && 
      (DPM_GET_CURRENT_PD_SPEC_REV(u8PortNum) == PD_SPEC_REVISION_3_0))
    {
               
        if(DPM_GET_DEFAULT_POWER_ROLE(u8PortNum) == PD_ROLE_SOURCE)
        {
            gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_HARD_RESET;
            gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_HARD_RESET_ENTRY_SS;
        }
        else
        {
            gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_HARD_RESET;
            gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_HARD_RESET_SEND_SS;       
        }
    }
    
    else
    {
        if(DPM_GET_DEFAULT_POWER_ROLE(u8PortNum) == PD_ROLE_SOURCE)
        {
            gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_SEND_SOFT_RESET;
            gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_SOFT_RESET_SOP_SS; 
        }
        else
        {
            gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_SEND_SOFT_RESET;
            gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_SEND_SOFT_RESET_ENTRY_SS;       
        }
        
        
    }
}


void PE_ReceiveHandler(UINT8 u8PortNum, UINT32 u32Header)
{
    /* Validate Message API */
    if(PE_PROCESS_MSG == PE_ValidateMessage( u8PortNum, u32Header))
    {
        /* Process Message to be added down*/
        if(FALSE != PRL_GET_OBJECT_COUNT(u32Header))
        {
            switch(PRL_GET_MESSAGE_TYPE(u32Header))
            {
                case ePE_DATA_SOURCE_CAP:
                {                 
                     
                    if((ePE_SNK_WAIT_FOR_CAPABILITIES_WAIT_SS == gasPolicy_Engine[u8PortNum].ePESubState)|| \
                      (ePE_SNK_READY_IDLE_SS == gasPolicy_Engine[u8PortNum].ePESubState) || \
                       (gasDPM[u8PortNum].u8DPM_Status & DPM_VDM_STATE_ACTIVE_MASK) )
                    {    
                      
                        if(ePE_SNK_WAIT_FOR_CAPABILITIES_WAIT_SS == gasPolicy_Engine[u8PortNum].ePESubState)
                        {
                            /*Kill the CONFIG_PE_SINK_WAIT_CAP_TIMEOUT since the source capability message 
                            has been received*/
                            PDTimer_Kill(gasPolicy_Engine[u8PortNum].u8PETimerID);
                        
                        }                       

                        gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_EVALUATE_CAPABILITY;                
                    }
                    else
                    {
                         PE_HandleUnExpectedMsg(u8PortNum, u32Header);
                    }
                    
                    break;
                }
                  
                case ePE_DATA_REQUEST:
                {
                    if(ePE_SRC_SEND_CAPABILITIES == gasPolicy_Engine[u8PortNum].ePEState ||
                       ePE_SRC_READY == gasPolicy_Engine[u8PortNum].ePEState)
                    {
                        PE_ExpectedMsg( u8PortNum, ePE_SRC_NEGOTIATE_CAPABILITY);
                        PDTimer_Kill(gasPolicy_Engine[u8PortNum].u8PETimerID);
                        _trace1(2, main_tr, 0, 0x01, u8PortNum,"PE_DATA_REQUEST: SenderResponse Timer Killed\r\n");
                    }
                    
                    else
                    {
                        PE_HandleUnExpectedMsg( u8PortNum, u32Header);
                    }
        
                    break;
                }
                
                case ePE_DATA_BIST:
                {        
                    break;
                }
                
                case ePE_DATA_SINK_CAP:
                {       
                    break;
                }
                
                case ePE_DATA_VENDOR_DEFINED:
                {
                    if((ePE_SNK_READY == gasPolicy_Engine[u8PortNum].ePEState) || \
						(ePE_SRC_READY == gasPolicy_Engine[u8PortNum].ePEState) || \
                         (gasDPM[u8PortNum].u8DPM_Status & DPM_VDM_STATE_ACTIVE_MASK))
                    {
                        
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_VDM_GET_IDENTITY;
                    }
                    
                    else if(ePE_SRC_VDM_IDENTITY_REQUEST == gasPolicy_Engine[u8PortNum].ePEState)
                    {
                        PDTimer_Kill(gasPolicy_Engine[u8PortNum].u8PETimerID);
                        PE_ExpectedMsg( u8PortNum, ePE_SRC_VDM_IDENTITY_ACKED);      
                    }
					
                    break;  
                }
                
                default:
                {                  
                    break;  
                }
            }
        }
            
        else
        {
            switch(PRL_GET_MESSAGE_TYPE (u32Header))
            {
              
                case ePE_CTRL_GOTO_MIN:
                {
                    /*Send Reject or Not supported message*/                    
                    break;
                }

                case ePE_CTRL_ACCEPT:
                {    
                  
                    if(ePE_SNK_SELECT_CAPABILITY_WAIT_FOR_ACCEPT_SS == gasPolicy_Engine[u8PortNum].ePESubState)
                    {                   
                        /*kill the timer CONFIG_PE_SENDER_RESPONSE_TIMEOUTID*/
                        _trace1(3, main_tr, 0, 0x01, u8PortNum,"PE_CTRL_ACCEPT: SenderResponse Timer Killed\r\n");
                        PDTimer_Kill(gasPolicy_Engine[u8PortNum].u8PETimerID);
                        
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_TRANSITION_SINK;
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_TRANSITION_SINK_ENTRY_SS;                     
                    }
                    else if(ePE_SNK_SEND_SOFT_RESET_WAIT_FOR_ACCEPT_SS == gasPolicy_Engine[u8PortNum].ePESubState)
                    {
                        /*kill the timer CONFIG_PE_SENDER_RESPONSE_TIMEOUTID*/
                        PDTimer_Kill(gasPolicy_Engine[u8PortNum].u8PETimerID);
                        
                        PE_Set_States(u8PortNum ,ePE_SNK_WAIT_FOR_CAPABILITIES,ePE_SNK_WAIT_FOR_CAPABILITIES_ENTRY_SS);                   
                    }
                    else if (ePE_SRC_SEND_SOFT_RESET_IDLE_SS == gasPolicy_Engine[u8PortNum].ePESubState)
                    {
                        _trace1(4, main_tr, 0, 0x01, u8PortNum,"PE_CTRL_ACCEPT: SenderResponse Timer Killed\r\n");
                        PDTimer_Kill(gasPolicy_Engine[u8PortNum].u8PETimerID);
                        
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_SEND_CAPABILITIES;
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_CAP_ENTRY_SS;                      
                    }
                    else
                    {                    
                        PE_HandleUnExpectedMsg( u8PortNum, u32Header);
                    }
                    
                    break;
                }
                
                case ePE_CTRL_WAIT:
                case ePE_CTRL_REJECT:
                {
                    if(ePE_SNK_SELECT_CAPABILITY_WAIT_FOR_ACCEPT_SS == gasPolicy_Engine[u8PortNum].ePESubState)
                    {                       
                        if ((gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_PDCONTRACT_MASK) == PE_EXPLICIT_CONTRACT)
                        {                            
                            /*Go to "ePE_SNK_READY" if Wait/Reject message is received and there is an explicit contract present*/                        
                            if ((PRL_GET_MESSAGE_TYPE(u32Header)) == ePE_CTRL_WAIT)
                            {
                                PDTimer_Start(CONFIG_PE_SINKREQUEST_TIMEOUT, &PE_StateChange_TimerCB, u8PortNum, ePE_SNK_SELECT_CAPABILITY);
                                PE_Set_State(u8PortNum, ePE_SNK_READY);
                            }
                            else if ((PRL_GET_MESSAGE_TYPE(u32Header)) == ePE_CTRL_REJECT)
                            {
                                PE_Set_State(u8PortNum, ePE_SNK_READY);
                            }							
                        }
                        /*Go to "ePE_SNK_WAIT_FOR_CAPABILITIES" if Wait/Reject message is received and there is no explicit contract present*/   
                        else
                        {
                            PE_Set_State(u8PortNum, ePE_SNK_WAIT_FOR_CAPABILITIES);
                        }
                    }
                     else
                    {
                    
                        PE_HandleUnExpectedMsg( u8PortNum, u32Header);
                    }
                    break;
                }
                
                case ePE_CTRL_PING:
                {

                    break;
                }
                
                 case ePE_CTRL_PS_RDY:
                {                 
                  
                    if(ePE_SNK_TRANSITION_SINK_WAIT_FOR_PSRDY_SS == gasPolicy_Engine[u8PortNum].ePESubState)
                    {                      
                       
                        /*Kill the timer CONFIG_PE_PSTRANSITION_TIMEOUTID*/
                        PDTimer_Kill(gasPolicy_Engine[u8PortNum].u8PETimerID);
                        
                        PE_Set_States(u8PortNum ,ePE_SNK_READY,ePE_SNK_READY_ENTRY_SS);
                        
                    }
                    else if( ePE_VCS_WAIT_FOR_VCONN_WAIT_FOR_PS_RDY_SS == gasPolicy_Engine[u8PortNum].ePESubState)
                    {
                    
                        /*Kill the timer VCONNON timer*/
                        PDTimer_Kill(gasPolicy_Engine[u8PortNum].u8PETimerID);
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_VCS_TURN_OFF_VCONN;                       
                    }
                    else
                    {
                        PE_HandleUnExpectedMsg( u8PortNum, u32Header);
                    }
                    break;  
                }
                  
                case ePE_CTRL_GET_SOURCE_CAP:
                {
                    if(ePE_SRC_READY == gasPolicy_Engine[u8PortNum].ePEState)
                    {
                        _trace1(5, main_tr, 0, 0x01, u8PortNum,"ePE_CTRL_GET_SOURCE_CAP: Get Source Cap Received\r\n");
                        PE_ExpectedMsg( u8PortNum, ePE_SRC_SEND_CAPABILITIES);
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_CAP_ENTRY_SS;
                    }                    
                    else
                    {
                        PE_HandleUnExpectedMsg( u8PortNum, u32Header);
                    }

                    break;
                }

                case ePE_CTRL_GET_SINK_CAP:
                {                    
                    
                    if((ePE_SNK_READY == gasPolicy_Engine[u8PortNum].ePEState) || \
                      (gasDPM[u8PortNum].u8DPM_Status & DPM_VDM_STATE_ACTIVE_MASK))
                    {                    
                        //Go to "ePE_SNK_GIVE_SINK_CAP" state if GET_SINK_CAP message is received
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_GIVE_SINK_CAP;
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_GIVE_SINK_CAP_ENTRY_SS;
                        
                    }
                    else
                    {
                        PE_HandleUnExpectedMsg( u8PortNum, u32Header);
                    }
                    break;
                }

                case ePE_CTRL_DR_SWAP:
                {
                    /*Send Reject or Not supported message*/
                    break;
                }
                
                 case ePE_CTRL_PR_SWAP:
                {   
                    /*Send Reject or Not supported message*/
                    break;  
                }
                  
                case ePE_CTRL_VCONN_SWAP:
                {
                    if((ePE_SNK_READY == gasPolicy_Engine[u8PortNum].ePEState) || \
						(ePE_SRC_READY == gasPolicy_Engine[u8PortNum].ePEState) || \
                         (gasDPM[u8PortNum].u8DPM_Status & DPM_VDM_STATE_ACTIVE_MASK))
                    {
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_VCS_EVALUATE_SWAP;
                    
                    }
					else
                    {
                        PE_HandleUnExpectedMsg( u8PortNum, u32Header);
                    }
                    break;
                }

                case ePE_CTRL_SOFT_RESET:
                {
                    if(DPM_GET_DEFAULT_POWER_ROLE(u8PortNum) == PD_ROLE_SOURCE)
                    {                    
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_SOFT_RESET;
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SOFT_RESET_ENTRY_SS;
                    }
                    else
                    {
                        //Go to "ePE_SNK_SOFT_RESET" state if SOFT_RESET message is received  
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_SOFT_RESET;
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_SOFT_RESET_SEND_ACCEPT_SS;
                                                           
                    }                   
                    break;
                   
                }
                
                 case ePE_NOT_SUPPORTED:
                {                  
                    break;  
                }
                  
                case ePE_GET_SOURCE_CAP_EXTENDED:
                {
                    break;
                }

                case ePE_GET_STATUS:
                {
                    break;
                }

                case ePE_FR_SWAP:
                {
                    break;
                }
                
                case ePE_GET_PPS_STATUS:
                {
                    break;
                }
                
                case ePE_GET_COUNTRY_CODES:
                {
                    break;
                }                
                default:
                {                  
                    break;  
                }
            }
                           
        }
              
    }

}
                
void PE_RunCommonStateMachine(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header)
{

    UINT8 u8TransmitSOP;
	UINT16 u16Transmit_Header;
	UINT32 *u32pTransmit_DataObj;
	PRLTxCallback Transmit_cb;
	UINT32 u32Transmit_TmrID_TxSt;
	UINT8 u8IsTransmit= FALSE;
     UINT32 u32VDMHeader;
    
     /*Sink Policy Engine State Machine*/
    switch(gasPolicy_Engine[u8PortNum].ePEState)
    {
      
       case ePE_SEND_NOT_SUPPORTED:
       {
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            { 
                case ePE_SEND_NOT_SUPPORTED_ENTRY_SS:
                {
                    _trace1(6, main_tr, 0, 0x01, u8PortNum,"PE_SEND_NOT_SUPPORTED: Enterted the state\r\n");                   
                    
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader (u8PortNum, (UINT8)ePE_NOT_SUPPORTED, \
                                                    0, 0);
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = NULL;        
                    
                    Transmit_cb = PE_StateChange_TransmitCB;
                    
                    if((gasPortConfigurationData[u8PortNum].u32CfgData & TYPEC_PORT_TYPE_MASK) == PD_ROLE_SOURCE)
                    {
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SRC_READY, ePE_SRC_READY_END_AMS_SS, ePE_SRC_SEND_SOFT_RESET,\
                                             ePE_SRC_SEND_SOFT_RESET_SOP_SS);
                    }
                    else
                    {
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY, ePE_SNK_READY_IDLE_SS,\
                                             ePE_SNK_SEND_SOFT_RESET,ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    }
                    
                    u8IsTransmit = TRUE;
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SEND_NOT_SUPPORTED_IDLE_SS;

                    break;
                }
                case ePE_SEND_NOT_SUPPORTED_IDLE_SS:
                {                  
                    break;               
                }
            }
            break;        
       }
       case ePE_SEND_REJECT:
       {
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            { 
                case ePE_SEND_REJECT_ENTRY_SS:
                {
                    _trace1(7, main_tr, 0, 0x01, u8PortNum,"ePE_SEND_REJECT: Enterted the state\r\n");
                    
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader (u8PortNum, (UINT8)ePE_CTRL_REJECT, \
                                                    0, 0);
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = NULL;      
                                          
                    Transmit_cb = PE_StateChange_TransmitCB;
                    
                    if((gasPortConfigurationData[u8PortNum].u32CfgData & TYPEC_PORT_TYPE_MASK) == PD_ROLE_SOURCE)
                    {
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SRC_READY, ePE_SRC_READY_END_AMS_SS, ePE_SRC_SEND_SOFT_RESET,\
                                             ePE_SRC_SEND_SOFT_RESET_SOP_SS);
                    }
                    else
                    {
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY, ePE_SNK_READY_IDLE_SS,\
                                             ePE_SNK_SEND_SOFT_RESET,ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    }
                    
                    u8IsTransmit = TRUE;
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SEND_REJECT_IDLE_SS;

                    break;
                }
                case ePE_SEND_REJECT_IDLE_SS:
                {                  
                    break;               
                }
            }
            break; 
         
       }

        case ePE_VCS_EVALUATE_SWAP:
        {
         
            _trace1(8, main_tr, 0, 0x01, u8PortNum,"PE_VCS_EVALUATE_SWAP: Enterted the state\r\n");
            /*Get Evaluation of VCONN Swap request from DPM*/
            if(DPM_Evaluate_VCONN_Swap(u8PortNum))
            {
                 gasPolicy_Engine[u8PortNum].ePEState = ePE_VCS_ACCEPT_SWAP;
                 gasPolicy_Engine[u8PortNum].ePESubState = ePE_VCS_ACCEPT_SWAP_SEND_ACCEPT_SS;
            }
            else
            { 
                    /*Set SRC or SNK RDY State*/
            }
            break;
          
        }
        case ePE_VCS_ACCEPT_SWAP:
        {
            
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                
                case ePE_VCS_ACCEPT_SWAP_SEND_ACCEPT_SS:
                {
                    _trace1(9, main_tr, 0, 0x01, u8PortNum,"PE_VCS_ACCEPT_SWAP-SEND_ACCEPT_SS: Enterted the SubState \r\n");
                     
                     /*Send Accept message*/
                    /*Set the PD message transmitter API to Send Accept Messsage*/
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, ePE_CTRL_ACCEPT, 0, 0);
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_VCS_ACCEPT_SWAP,ePE_VCS_ACCEPT_SWAP_ACCEPT_SENT_SS,\
                                             0, 0);
                   gasPolicy_Engine[u8PortNum].ePESubState = ePE_VCS_ACCEPT_SWAP_IDLE_SS;
                   u8IsTransmit = TRUE;
            
                    break;
                  
                }
                case ePE_VCS_ACCEPT_SWAP_IDLE_SS:
                {
                    break;
                }
                case ePE_VCS_ACCEPT_SWAP_ACCEPT_SENT_SS:
                {
                    _trace1(10, main_tr, 0, 0x01, u8PortNum,"PE_VCS_ACCEPT_SWAP-ACCEPT_SENT_SS: Enterted the SubState \r\n");
                    if(DPM_IsPort_VCONN_Source(u8PortNum))
                    {
                         gasPolicy_Engine[u8PortNum].ePEState = ePE_VCS_WAIT_FOR_VCONN;
                         gasPolicy_Engine[u8PortNum].ePESubState = ePE_VCS_WAIT_FOR_VCONN_START_TIMER_SS;                     
                    }
                    else
                    {
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_VCS_TURN_ON_VCONN;                   
                    }
                    break;
                }
                
            }                
            break;  
        }
        case ePE_VCS_WAIT_FOR_VCONN:
        {
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_VCS_WAIT_FOR_VCONN_START_TIMER_SS:
                {
                     _trace1(11, main_tr, 0, 0x01, u8PortNum,"PE_VCS_WAIT_FOR_VCONN-START_TIMER_SS: Enterted the SubState \r\n");
                    /*TODO :Muthu  Include code for timer start in relation to source*/
                    if(DPM_GET_DEFAULT_POWER_ROLE(u8PortNum) == PD_ROLE_SOURCE)
                    {
                        gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start(CONFIG_PE_VCONNON_TIMEOUT,\
                                                              &PE_SNK_HardReset_TimeoutCB, u8PortNum, ePE_SRC_HARD_RESET);
                    }
                    
                    else
                    {
                        /*Start VCONN timer*/
                        gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start(CONFIG_PE_VCONNON_TIMEOUT,\
                                                                  &PE_SNK_HardReset_TimeoutCB, u8PortNum, ePE_SNK_HARD_RESET);
                    }
					
					gasPolicy_Engine[u8PortNum].ePESubState = ePE_VCS_WAIT_FOR_VCONN_WAIT_FOR_PS_RDY_SS;
                    break;
                }
                case ePE_VCS_WAIT_FOR_VCONN_WAIT_FOR_PS_RDY_SS:
                {
                    /*Wait for PS_RDY message*/
                    break;
                }
            }           
            break;          
        }
        
        case ePE_VCS_TURN_OFF_VCONN:
        {    
             _trace1(12, main_tr, 0, 0x01, u8PortNum,"PE_VCS_TURN_OFF_VCONN: Enterted the state\r\n");
            /*Turn off VCONN*/
            DPM_VConnOnOff(u8PortNum,0);
            
            if(DPM_GET_DEFAULT_POWER_ROLE(u8PortNum) == PD_ROLE_SOURCE)
            {
                gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_READY;
                gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_READY_END_AMS_SS;  
            }
            
            else
            {
                gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_READY;
                gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_READY_IDLE_SS;
            }
            break;
          
        }
        
        
        case ePE_VCS_TURN_ON_VCONN:
        {
             _trace1(13, main_tr, 0, 0x01, u8PortNum,"PE_VCS_TURN_ON_VCONN: Enterted the state\r\n");
            /*Turn ON VCONN*/
            DPM_VConnOnOff(u8PortNum,1);
            gasPolicy_Engine[u8PortNum].ePEState = ePE_VCS_SEND_PS_RDY;
            gasPolicy_Engine[u8PortNum].ePESubState = ePE_VCS_SEND_PS_RDY_ENTRY_SS;             
            break;
          
          
        }
        case ePE_VCS_SEND_PS_RDY:
        {
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_VCS_SEND_PS_RDY_ENTRY_SS:
                {
                     _trace1(14, main_tr, 0, 0x01, u8PortNum,"ePE_VCS_SEND_PS_RDY-ENTRY_SS: Enterted the SubState \r\n");
                    /*Send PS_RDY message*/
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, ePE_CTRL_PS_RDY, 0, 0);
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    
                    /*TODO: Muthu Handle the transmitter callback in relation to source*/
                    if(DPM_GET_DEFAULT_POWER_ROLE(u8PortNum) == PD_ROLE_SOURCE)
                    {
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SRC_READY,ePE_SRC_READY_END_AMS_SS,\
                                                 ePE_SRC_SEND_SOFT_RESET, ePE_SRC_SEND_SOFT_RESET_SOP_SS);  
                    }
            
                    else
                    {
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY,ePE_SNK_READY_IDLE_SS,\
                                                 ePE_SNK_SEND_SOFT_RESET, ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    }
                    
                    u8IsTransmit = TRUE;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_VCS_SEND_PS_RDY_IDLE;
                    
                     break;
                }
                case ePE_VCS_SEND_PS_RDY_IDLE:
                {                   
                     break;
                }
            }
             break;                
        }
        
        case ePE_VDM_GET_IDENTITY:
        {
          
            _trace1(15, main_tr, 0, 0x01, u8PortNum,"PE_RESP_VDM_GET_IDENTITY: Entered the state\r\n");
			
			UINT32 *u32RecvdVDMHeader = (UINT32 *)u8DataBuf;	
            
            gasDPM[u8PortNum].u16SenderSVID = PE_SVDM_GET_SVID(*u32RecvdVDMHeader);
            
            gasDPM[u8PortNum].u8SenderSVDMObjPos  = PE_SVDM_GET_OBJ_POS(*u32RecvdVDMHeader);
			
            if (PE_GET_VDM_CMD_TYPE(*u32RecvdVDMHeader) == PE_GET_VDM_CMD_TYPE_REQ)
            {
                if (DPM_GET_CURRENT_PD_SPEC_REV(u8PortNum) == PD_SPEC_REVISION_2_0)
                {
                    
                     switch (PE_GET_VDM_CMD(*u32RecvdVDMHeader))
                     {
                         case PE_VDM_DISCOVER_IDENTITY_CMD:
                         {
                            gasPolicy_Engine[u8PortNum].ePEState = ePE_RESP_VDM_GET_IDENTITY_NAK;
                            gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_GET_IDENTITY_NAK_SEND_SS;
                            break;
                         }
                        case PE_VDM_DISCOVER_SVIDS_CMD:
                        {
                            gasPolicy_Engine[u8PortNum].ePEState = ePE_RESP_VDM_GET_SVIDS_NAK;
                            gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_GET_SVIDS_NAK_SEND_SS;
                            break;
                        }
                        case PE_VDM_DISCOVER_MODES_CMD:
                        {
                            gasPolicy_Engine[u8PortNum].ePEState = ePE_RESP_VDM_GET_MODES_NAK;
                            gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_GET_MODES_NAK_SEND_SS;
                            break;
                        }
                        case PE_VDM_ENTER_MODE_CMD:
                        {
                            gasPolicy_Engine[u8PortNum].ePEState = ePE_RESP_VDM_ENTER_MODE_NAK;
                            gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_ENTER_MODE_NAK_SEND_SS;
                            break;
                        } 
                        case PE_VDM_EXIT_MODE_CMD:
                        {
                            gasPolicy_Engine[u8PortNum].ePEState = ePE_RESP_VDM_EXIT_MODE_NACK;
                            gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_EXIT_MODE_NACK_SEND_SS;
                            break;
                        }
                     }                    
                }
                else                
                {
                    
                    gasPolicy_Engine[u8PortNum].ePEState = ePE_SEND_NOT_SUPPORTED;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SEND_NOT_SUPPORTED_ENTRY_SS;														
                }                                            
            }				
            break;          
        }
        case ePE_RESP_VDM_GET_IDENTITY_NAK:
        {            
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_RESP_VDM_GET_IDENTITY_NAK_SEND_SS:
                {
                    _trace1(16, main_tr, 0, 0x01, u8PortNum,"PE_RESP_VDM_GET_IDENTITY_NAK-SEND_SS: Enterted the SubState \r\n");
                    /*Send Discover Identity NACK message*/
                    UINT32 *u32RecvdVDMHeader = (UINT32 *)u8DataBuf;
                    
                    if(PE_GET_VDM_VERSION(*u32RecvdVDMHeader) == 00)
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_IDEN_NACK_LOW ;
                    }
                    else
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_IDEN_NACK_HIGH ;
                    }
                    
                    u32VDMHeader &= ~PE_SVDM_SVID_MASK;
                    u32VDMHeader |= ((gasDPM[u8PortNum].u16SenderSVID << PE_SVDM_SVID_POS));                    
                    
                    u32pTransmit_DataObj = &u32VDMHeader;
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, (UINT8)ePE_DATA_VENDOR_DEFINED, 1, 0);
                    Transmit_cb = PE_StateChange_TransmitCB;
                    
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY,ePE_SNK_READY_IDLE_SS,\
                                             ePE_SNK_SEND_SOFT_RESET,\
                                             ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    
                    u8IsTransmit = TRUE;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_GET_IDENTITY_NAK_IDLE;
                    break;
                    
                }
                case ePE_RESP_VDM_GET_IDENTITY_NAK_IDLE:
                {
                    break;
                }
            }
        }
        case ePE_RESP_VDM_GET_SVIDS_NAK:
        {             
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_RESP_VDM_GET_SVIDS_NAK_SEND_SS:
                {
                   _trace1(17, main_tr, 0, 0x01, u8PortNum,"ePE_RESP_VDM_GET_SVIDS_NAK-SEND_SS: Enterted the SubState \r\n");
                    /*Send Discover SVIDS NACK message*/
                    UINT32 *u32RecvdVDMHeader = (UINT32 *)u8DataBuf;
                    
                    if(PE_GET_VDM_VERSION(*u32RecvdVDMHeader) == 00)
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_SVIDS_NACK_LOW ;
                    }
                    else
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_SVIDS_NACK_HIGH ;
                    }
                    
                    
                    u32VDMHeader &= ~PE_SVDM_SVID_MASK;
                    u32VDMHeader |= ((gasDPM[u8PortNum].u16SenderSVID << PE_SVDM_SVID_POS));
                    
                    u32pTransmit_DataObj = &u32VDMHeader;
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, (UINT8)ePE_DATA_VENDOR_DEFINED, 1, 0);
                    Transmit_cb = PE_StateChange_TransmitCB;
                    
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY,ePE_SNK_READY_IDLE_SS,\
                                             ePE_SNK_SEND_SOFT_RESET,\
                                             ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    
                    u8IsTransmit = TRUE;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_GET_SVIDS_NAK_IDLE;
                    break;
                    
                }
                case ePE_RESP_VDM_GET_SVIDS_NAK_IDLE:
                {
                    break;
                }
            }
        }
        case ePE_RESP_VDM_GET_MODES_NAK:
        {             
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_RESP_VDM_GET_MODES_NAK_SEND_SS:
                {
                    _trace1(18, main_tr, 0, 0x01, u8PortNum,"ePE_RESP_VDM_GET_MODES_NAK-SEND_SS: Enterted the SubState \r\n");
                    /*Send Discover Modes NACK message*/
                    UINT32 *u32RecvdVDMHeader = (UINT32 *)u8DataBuf;
                    
                    if(PE_GET_VDM_VERSION(*u32RecvdVDMHeader) == 00)
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_MODES_NACK_LOW ;
                    }
                    else
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_MODES_NACK_HIGH ;
                    }
                    
                    u32VDMHeader &= ~PE_SVDM_SVID_MASK;
                    u32VDMHeader |= ((gasDPM[u8PortNum].u16SenderSVID << PE_SVDM_SVID_POS));
                    
                    u32pTransmit_DataObj = &u32VDMHeader;
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, (UINT8)ePE_DATA_VENDOR_DEFINED, 1, 0);
                    Transmit_cb = PE_StateChange_TransmitCB;
                    
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY,ePE_SNK_READY_IDLE_SS,\
                                             ePE_SNK_SEND_SOFT_RESET,\
                                             ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    
                    u8IsTransmit = TRUE;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_GET_MODES_NAK_IDLE;
                    break;
                    
                }
                case ePE_RESP_VDM_GET_MODES_NAK_IDLE:
                {
                    break;
                }
            }
        }
         case ePE_RESP_VDM_ENTER_MODE_NAK:
        {             
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_RESP_VDM_ENTER_MODE_NAK_SEND_SS:
                {
                    _trace1(19, main_tr, 0, 0x01, u8PortNum,"ePE_RESP_VDM_ENTER_MODE_NAK-SEND_SS: Enterted the SubState \r\n");
                    /*Send Enter Mode NACK message*/
                    UINT32 *u32RecvdVDMHeader = (UINT32 *)u8DataBuf;
                    
                    if(PE_GET_VDM_VERSION(*u32RecvdVDMHeader) == 00)
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_ENTER_MODE_NACK_LOW ;
                    }
                    else
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_ENTER_MODE_NACK_HIGH ;
                    }
                    
                    u32VDMHeader &= ~PE_SVDM_SVID_MASK;
                    u32VDMHeader |= ((gasDPM[u8PortNum].u16SenderSVID << PE_SVDM_SVID_POS));
                    
                    u32VDMHeader &= ~PE_SVDM_OBJ_POS_MASK;
                    u32VDMHeader |= ((gasDPM[u8PortNum].u8SenderSVDMObjPos << PE_SVDM_OBJ_POS_POS ));
                    
                    u32pTransmit_DataObj = &u32VDMHeader;
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, (UINT8)ePE_DATA_VENDOR_DEFINED, 1, 0);
                    Transmit_cb = PE_StateChange_TransmitCB;
                    
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY,ePE_SNK_READY_IDLE_SS,\
                                             ePE_SNK_SEND_SOFT_RESET,\
                                             ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    
                    u8IsTransmit = TRUE;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_ENTER_MODE_NAK_IDLE;
                    break;
                    
                }
                case ePE_RESP_VDM_ENTER_MODE_NAK_IDLE:
                {
                    break;
                }
            }
        }
         case ePE_RESP_VDM_EXIT_MODE_NACK:
        {             
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_RESP_VDM_EXIT_MODE_NACK_SEND_SS:
                {
                    _trace1(20, main_tr, 0, 0x01, u8PortNum,"ePE_RESP_VDM_EXIT_MODE_NACK-SEND_SS: Enterted the SubState \r\n");
                    /*Send Exit Mode message*/
                    UINT32 *u32RecvdVDMHeader = (UINT32 *)u8DataBuf;
                    
                    if(PE_GET_VDM_VERSION(*u32RecvdVDMHeader) == 00)
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_EXIT_MODE_NACK_LOW ;
                    }
                    else
                    {
                        u32VDMHeader = PE_SEND_DISCOVER_EXIT_MODE_NACK_HIGH ;
                    }
                    
                    u32VDMHeader &= ~PE_SVDM_SVID_MASK;
                    u32VDMHeader |= ((gasDPM[u8PortNum].u16SenderSVID << PE_SVDM_SVID_POS));
                    
                    u32VDMHeader &= ~PE_SVDM_OBJ_POS_MASK;
                    u32VDMHeader |= ((gasDPM[u8PortNum].u8SenderSVDMObjPos << PE_SVDM_OBJ_POS_POS ));
                    
                    u32pTransmit_DataObj = &u32VDMHeader;
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, (UINT8)ePE_DATA_VENDOR_DEFINED, 1, 0);
                    Transmit_cb = PE_StateChange_TransmitCB;
                    
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY,ePE_SNK_READY_IDLE_SS,\
                                             ePE_SNK_SEND_SOFT_RESET,\
                                             ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    
                    u8IsTransmit = TRUE;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_RESP_VDM_EXIT_MODE_NACK_IDLE;
                    break;
                    
                }
                case ePE_RESP_VDM_EXIT_MODE_NACK_IDLE:
                {
                    break;
                }
            }
        }
        break;         
    }
    
    if (u8IsTransmit == TRUE)
	{

		PRL_TransmitMsg(u8PortNum, u8TransmitSOP, u16Transmit_Header, (UINT8 *)u32pTransmit_DataObj, Transmit_cb, u32Transmit_TmrID_TxSt);
        u8IsTransmit = FALSE;

	}
            
}

void PE_StateChange_TransmitCB(UINT8 u8PortNum, UINT8 u8TXDoneState, UINT8 u8TxDoneSubState, UINT8 u8TxFailedState, UINT8 u8TxFailedSubState)
{	
    /*Policy engine state is assgined based on Tx Interrupt status*/
    switch(gasPRL[u8PortNum].u8TxState)
    {
        case PRL_TX_DONE_ST:
        {
            gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState) u8TXDoneState;
            gasPolicy_Engine[u8PortNum].ePESubState = (ePolicySubState) u8TxDoneSubState;
            break;  
        }       
        case PRL_TX_ABORTED_ST:
        {
            break;  
        }
                    
        case PRL_TX_FAILED_ST:
        {
            gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState) u8TxFailedState;
            gasPolicy_Engine[u8PortNum].ePESubState = (ePolicySubState) u8TxFailedSubState;
            break;  
        }
        
        case PRL_TX_EOP_ST:
        {
            gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState) u8TXDoneState;
            gasPolicy_Engine[u8PortNum].ePESubState = (ePolicySubState) u8TxDoneSubState;
            break;  
        }
    }   
}

/* Function to recover HardReset */
void PE_HardResetRecover(UINT8 u8PortNum)
{
    /*Inform Protocol Layer about Hard Reset Complete*/
    PRL_HRorCRCompltIndicationFromPE(u8PortNum);  
}

void PE_HRReceived(UINT8 u8PortNum)
{
    gasDPM[u8PortNum].u8DPM_Status |= DPM_HARDRESET_RCVD_MASK;
}


void PE_Set_States(UINT8 u8PortNum ,UINT8 u8PEState,UINT8 u8PESubState)
{
    /*Setting the policy engine State with a given State*/
    gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState) u8PEState;
  
    /*Setting the policy engine substate with a given substate*/
    gasPolicy_Engine[u8PortNum].ePESubState = (ePolicySubState) u8PESubState;
}
                
void PE_Set_State(UINT8 u8PortNum, UINT8  u8PEState)
{
    /*Setting the policy engine State with a given State*/
    gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState) u8PEState;
}

void PE_Set_SubState(UINT8 u8PortNum, UINT8  u8PESubstate)
{
    /*Setting the policy engine substate with a given substate*/
	gasPolicy_Engine[u8PortNum].ePESubState = (ePolicySubState) u8PESubstate;
}

void PE_StateChange_TimerCB(UINT8 u8PortNum, UINT8 u8PE_State)
{
    gasPolicy_Engine[u8PortNum].u3TimeoutMsgHeader = PRL_IsAnyMsgPendinginPRL (u8PortNum);
    
    /* Check for Msg Header is NULL */
    if(NULL != gasPolicy_Engine[u8PortNum].u3TimeoutMsgHeader)
    {
        /* Copy Receive Msg Handler Header to Timeout Header */
        gasPolicy_Engine[u8PortNum].u3TimeoutMsgHeader = gasPolicy_Engine[u8PortNum].u32MsgHeader;
    }
    
	gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState) u8PE_State;
}

void PE_SubStateChange_TimerCB (UINT8 u8PortNum, UINT8 u8PESubState)
{
     gasPolicy_Engine[u8PortNum].u3TimeoutMsgHeader = PRL_IsAnyMsgPendinginPRL (u8PortNum);
    
    /* Check for Msg Header is NULL */
    if(NULL != gasPolicy_Engine[u8PortNum].u3TimeoutMsgHeader)
    {
        /* Copy Receive Msg Handler Header to Timeout Header */
        gasPolicy_Engine[u8PortNum].u3TimeoutMsgHeader = gasPolicy_Engine[u8PortNum].u32MsgHeader;
    }
    gasPolicy_Engine[u8PortNum].ePESubState = (ePolicySubState) u8PESubState;
}

void PE_NoResponseTimerCB(UINT8 u8PortNum, UINT8 u8PE_State)
{
    gasPolicy_Engine[u8PortNum].u8PEPortSts |= PE_NO_RESPONSE_TIMEDOUT;
}

void PE_SetVDMStateActiveFlag(UINT8 u8PortNum)
{
    switch(gasPolicy_Engine[u8PortNum].ePEState)
    {
        case ePE_VDM_GET_IDENTITY:
        case ePE_RESP_VDM_GET_IDENTITY_NAK:
        case ePE_RESP_VDM_GET_SVIDS_NAK:  
        case ePE_RESP_VDM_GET_MODES_NAK:
        case ePE_RESP_VDM_ENTER_MODE_NAK:
        case ePE_RESP_VDM_EXIT_MODE_NACK:
        {
            gasDPM[u8PortNum].u8DPM_Status |= DPM_VDM_STATE_ACTIVE_MASK;
            break;
        }
        default:
        {
           gasDPM[u8PortNum].u8DPM_Status &= ~DPM_VDM_STATE_ACTIVE_MASK;
           break;
        }     
    }
}