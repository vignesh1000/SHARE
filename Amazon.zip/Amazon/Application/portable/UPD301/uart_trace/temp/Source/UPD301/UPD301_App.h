/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _UPD301_APP_H_
#define _UPD301_APP_H_

#include <ZeusStackConfig.h>
#include <policy_manager.h>


/* Capability selection through strap */
#define CONFIG1         0x0A
#define CONFIG2         0x0B
#define CONFIG3         0x02
#define CONFIG4         0x1B
#define CONFIG5         0x00
#define CONFIG6         0x1F

#define CONFIG1_PDO_COUNT   1
#define CONFIG2_PDO_COUNT   1
#define CONFIG3_PDO_COUNT   2
#define CONFIG4_PDO_COUNT   3
#define CONFIG5_PDO_COUNT   4
#define CONFIG6_PDO_COUNT   4

#define SRC_CAP_GENERATION( USB_SUSPEND, UNCONS_POWER, USB_COM, MAX_CURRENT, MAX_VOLTAGE)  \
        ((USB_SUSPEND << 28) | (UNCONS_POWER << 27) | (USB_COM << 26) | ((MAX_VOLTAGE/50) << 10) | ((MAX_CURRENT)/10))

#define SRC_CAP_5V_1P5A     SRC_CAP_GENERATION(1, 1, 0, 1500, 5000)
#define SRC_CAP_5V_3A       SRC_CAP_GENERATION(1, 1, 0, 3000, 5000)                                             
#define SRC_CAP_5V_5A       SRC_CAP_GENERATION(1, 1, 0, 5000, 5000)
#define SRC_CAP_9V_3A       SRC_CAP_GENERATION(0, 0, 0, 3000, 9000)
#define SRC_CAP_9V_5A       SRC_CAP_GENERATION(0, 0, 0, 5000, 9000)
#define SRC_CAP_15V_3A      SRC_CAP_GENERATION(0, 0, 0, 3000, 15000)                                                                  
#define SRC_CAP_15V_5A      SRC_CAP_GENERATION(0, 0, 0, 5000, 15000)                                                                  
#define SRC_CAP_20V_3A      SRC_CAP_GENERATION(0, 0, 0, 3000, 20000)
#define SRC_CAP_20V_5A      SRC_CAP_GENERATION(0, 0, 0, 5000, 20000)

#define SNK_CAP_GENERATION( HIGER_CAP,UNCONSTRAINED, USB_COM, MAX_CURRENT, MAX_VOLTAGE) \
        ((HIGER_CAP << 28) | (UNCONSTRAINED << 27)| ((USB_COM) << 26) | (((MAX_VOLTAGE)/50) << 10) | ((MAX_CURRENT)/10))


#define SNK_CAP_5V_1P5A     SNK_CAP_GENERATION(0,1, 0, 1500, 5000)
#define SNK_CAP_5V_3A_LOW   SNK_CAP_GENERATION(0,1, 0, 3000, 5000)
#define SNK_CAP_5V_3A       SNK_CAP_GENERATION(1,1, 0, 3000, 5000)                                             
#define SNK_CAP_5V_5A       SNK_CAP_GENERATION(1,1, 0, 5000, 5000)
#define SNK_CAP_9V_3A       SNK_CAP_GENERATION(0,0,0, 3000, 9000)
#define SNK_CAP_9V_5A       SNK_CAP_GENERATION(0,0,0, 5000, 9000)
#define SNK_CAP_15V_3A      SNK_CAP_GENERATION(0,0,0, 3000, 15000)                                                                  
#define SNK_CAP_15V_5A      SNK_CAP_GENERATION(0,0,0, 5000, 15000)                                                                  
#define SNK_CAP_20V_3A      SNK_CAP_GENERATION(0,0,0, 3000, 20000)
#define SNK_CAP_20V_5A      SNK_CAP_GENERATION(0,0,0, 5000, 20000)
   
#define EXTERNAL_UPD350_PIO_STS     0x20
#define EXTERNAL_UPD350_PIO2_MASK   0x04
          
#define RP_VAL_RD           0
#define RP_VAL_1P5A         2
#define RP_VAL_3A           3
          

/* Decode Strap for Capabilitie */          
void  DecodePDPStrapCap(UINT8 u8PortNum, UINT8 u8PortRole, PORT_CONFIG_DATA *PortConfigData);
void STRAPS_PowerRole_Set(PORT_CONFIG_DATA *PortConfigData);

void PDStack_Events(UINT8 u8PortNum, UINT8 u8PDEvent);
void InitOrientationPins();

void* UPD301_MemCpy(void *dest, const void *src, int n);
int UPD301_MemCmp(const void *pau8Data1, const void *pau8Data2, int len);
void GPIOStrap_SetTristate(UINT8 u8pin);



#endif