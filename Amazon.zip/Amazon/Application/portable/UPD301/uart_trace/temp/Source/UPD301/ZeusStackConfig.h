
/*******************************************************************************
  Zeus stack configuration

  Company:
    Microchip Technology Inc.

  File Name:
    config.h

  Summary:
    Zeus stack configuration header file

  Description:
    This header file contains the configuration parameters of zeus stack to configures the Power delivery modules
*******************************************************************************/
//DOM-IGNORE-BEGIN
/*******************************************************************************

Copyright � 2018 released Microchip Technology Inc.  All rights
reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
********************************************************************************

*******************************************************************************/
//DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: File includes
// *****************************************************************************
// *****************************************************************************


#include <stdbool.h>
#include <SERCOM_Spi.h>
#include <Hermes_Interface.h>
#include <PDFWUpdate.h>
#include <UPD301_App.h>
#include <GPIO.h>
#include <hal_atomic.h>
#include <portpower_control.h>
#include <Timers.h>
#include <Interrupts.h>
#include <SERCOM_UART.h>


#ifdef MCHP_TRACE
	#include <uart_trace\trace.h>
#endif

/* Number of ports that are going to be handled by the PD stack */
#define CONFIG_PD_PORT_COUNT			2


// *****************************************************************************
// *****************************************************************************
// Section: INCLUDE/EXCLUDE AT COMPILE TIME
// *****************************************************************************
// *****************************************************************************
/*Following flags are applicable for all CONFIG_PD_PORT_COUNT*/
/*If any of the port from CONFIG_PD_PORT_COUNT requires following features then enable it to 
handle in the code otherwise disable it to exclude the part of the code for the corresponding feature*/

#define INCLUDE_PD_3_0          1

/* Source only */
#define INCLUDE_PD_SOURCE_ONLY  1

/* Sink Only */
#define INCLUDE_PD_SINK_ONLY    1

/*VCONN Swap Support*/
#define INCLUDE_VCONN_SWAP_SUPPORT  1

// *****************************************************************************
// *****************************************************************************
// Section: HOOK CONFIGURATION
// *****************************************************************************
// *****************************************************************************

/***********************************************************************************************************
  Function:
              CONFIG_HOOK_POLICY_ENGINE_PRE_PROCESS(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_)
  Summary:
    This function is called before entering into the policy engine state
    machine
  Description:
    This function is called at the entry of PE_RunStateMachine() API before
    executing the policy engine state machine.New PD message received by
    the protocol layer is passed as argument in this function before
    processing it in the policy engine state machine.USER_APPLICATION can
    define this function if a change in default policy engine state machine
    behaviour is needed. Define relevant function that has one UINT8
    argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
    _u8DataBuf_ -   Pointer to a byte buffer containing PD message.
    _u8SOPType_ -   Sop Type of the message
    _u32Header_ -   32 bit header passed of which lower word is PD message
                    header and higher word is extended message header if
                    passed message is extended message.
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_POLICY_ENGINE_PRE_PROCESS(_u8Port_Num_, _u8DataBuf_\\
    ,_u8SOPType_,_u32Header_)\\
    HookPolicyEnginePreProcess(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_)
    
    void HookPolicyEnginePreProcess(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header);
    
    void HookPolicyEnginePreProcess(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header)
    {
    
        //any application related change or enhancement for the PE_RunStateMachine() API
    
    }
    </code>
  Remarks:
    User definition of this Hook function is optional                                                       
  ***********************************************************************************************************/
#define CONFIG_HOOK_POLICY_ENGINE_PRE_PROCESS(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_) 			

/************************************************************************************************************
  Function:
          CONFIG_HOOK_POLICY_ENGINE_POST_PROCESS(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_)
    
  Summary:
    This function is called before exiting from the policy engine state
    machine
  Description:
    This function is called at the exit of PE_RunStateMachine() API after
    executing the policy engine state machine. USER_APPLICATION can define
    this function if a change in default policy engine state machine
    behaviour is needed. Define relevant function that has one UINT8
    argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
    _u8DataBuf_ -   Pointer to a byte buffer containig PD message to be send
    _u8SOPType_ -   Sop Type of the message to be send
    _u32Header_ -   32 bit header of the PD message to be send.Lower word is
                    PD message header and higher word is extended message
                    header if passed message is extended message.
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_POLICY_ENGINE_POST_PROCESS(_u8Port_Num_, _u8DataBuf_, \\
    _u8SOPType_,_u32Header_) \\
    HookPolicyEnginePostProcess(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_)
    
    void HookPolicyEnginePostProcess(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header);
    
    void HookPolicyEnginePostProcess(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header)
    {
    
    //any application related change or enhancement for the PE_RunStateMachine() API
    
    }
    </code>
  Remarks:
    User definition of this Hook function is optional                                                        
  ************************************************************************************************************/
#define CONFIG_HOOK_POLICY_ENGINE_POST_PROCESS(_u8Port_Num_, _u8DataBuf_, _u8SOPType_,_u32Header_) 			

/**************************************************************************
  Function:
            CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS(_u8port_num_)
  Summary:
    This function is called before entering into the DPM state machine
  Description:
    This function is called at the entry of DPM_StateMachine() API before
    executing the Type C state machine and policy engine state machine.
    USER_APPLICATION can define this function if a change is required in
    default device policy manager functionality. Define relevant function
    that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS(_u8port_num_) \\
                    HookDevicePolicyManagerPreProcess(_u8port_num_)
    
    void HookDevicePolicyManagerPreProcess(UINT8 u8PortNum);
    
    void HookDevicePolicyManagerPreProcess(UINT8 u8PortNum)
    {
    
        //any application related change or enhancement for the
        //DPM_StateMachine() API
    
    }
    </code>
  Remarks:
    User definition of this Hook function is optional                      
  **************************************************************************/
#ifdef VALIDATION

#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS(_u8port_num_) 	PRLVAL_DPMStateMachine(_u8port_num_)

#else

#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS(_u8port_num_)

#endif
/*************************************************************************************
  Function:
            CONFIG_HOOK_DEVICE_POLICY_MANAGER_POST_PROCESS(_u8port_num_)
  Summary:
    This function is called before exiting from the DPM state machine
  Description:
    This function is called at the exit of DPM_StateMachine() API after
    executing the Type C state machine and policy engine state machine.
    USER_APPLICATION can define this function if a change is required in
    default device policy manager functionality. Define relevant function
    that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_POST_PROCESS(_u8port_num_) \\
                          HookDevicePolicyManagerPostProcess(_u8port_num_)
    
    void HookDevicePolicyManagerPostProcess(UINT8 u8PortNum);
    
    void HookDevicePolicyManagerPostProcess(UINT8 u8PortNum)
    {
    
        //any application related change or enhancement for the DPM_StateMachine() API
    
    }
    </code>

  Remarks:
    User definition of this Hook function is optional                                 
  *************************************************************************************/
#define CONFIG_HOOK_DEVICE_POLICY_MANAGER_POST_PROCESS(_u8port_num_) 	

/******************************************************************************************
  Function:
          CONFIG_HOOK_TYPE_C_MANANGEMENT_PRE_PROCESS(_u8port_num_)
    
  Summary:
    This function is called before entering into the Type C state machine
  Description:
    This function is called at the entry of TypeC_RunStateMachine() API
    before executing the TypeC state machine. USER_APPLICATION can define
    this function if a change in default Type C state machine behaviour is
    needed. Define relevant function that has one UINT8 argument without
    \return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_TYPE_C_MANANGEMENT_PRE_PROCESS(_u8port_num_)   \\
     HookTypeCManagementPreProcess(_u8port_num_)
    
    void HookTypeCManagementPreProcess(UINT8 u8PortNum);
    
    void HookTypeCManagementPreProcess(UINT8 u8PortNum)
    {
    
        //any application related change or enhancement for the TypeC_RunStateMachine() API
    
    }
    </code>
  Remarks:
    None                                                                                   
  ******************************************************************************************/
#define CONFIG_HOOK_TYPE_C_MANANGEMENT_PRE_PROCESS(_u8port_num_)		

/******************************************************************************************
  Function:
          CONFIG_HOOK_TYPE_C_MANANGEMENT_POST_PROCESS(_u8port_num_)
    
  Summary:
    This function is called before exiting from the Type C state machine
  Description:
    This function is called at the exit of TypeC_RunStateMachine() API
    after executing the TypeC state machine. USER_APPLICATION can define
    this function if a change in default TypeC state machine behaviour is
    needed. Define relevant function that has one UINT8 argument without
    \return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_TYPE_C_MANANGEMENT_POST_PROCESS(_u8port_num_)   \\
    HookTypeCManagementPostProcess(_u8port_num_)
    
    void HookTypeCManagementPostProcess(UINT8 u8PortNum);
    
    void HookTypeCManagementPostProcess(UINT8 u8PortNum)
    {
    
        //any application related change or enhancement for the TypeC_RunStateMachine() API
    
    }
    </code>
  Remarks:
    None                                                                                   
  ******************************************************************************************/
#define CONFIG_HOOK_TYPE_C_MANANGEMENT_POST_PROCESS(_u8port_num_)

/********************************************************************************************************************************************
  Function:
              CONFIG_HOOK_PRL_TX_MSG_PRE_PROCESS(_u8port_num_, _u8sop_type, _u32header, _pu8databuff, _pfntxcallback, _u32PkdPEstOn_TxStatus)
    
  Summary:
    This function is called before processing the transmit message data
    from policy engine in protocol layer
  Description:
    This function is called at the entry of PRL_Tranmsit() API before
    processing the Message from Policy Engine. It has all the arguments
    passed to the API PRL_Transmit() by policy engine It is a placeholder
    for USER_APPLICATION to enhance the API.Define relevant function that
    has UINT8,UINT8,UINT32,UINT8 * ,PRLTxCallback and UINT32 arguments
    without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -                         Port number of the device. Value
                                           passed will be less than
                                           CONFIG_PD_PORT_COUNT
    _u8sop_type -                          Sop Type of the message
    _u32header -                           32 bit header passed of which
                                           lower word is PD message header &amp;
                                           higher word is extended message
                                           header if passed message is
                                           extended message.
    _pu8databuff -                         pointer to a byte buffer
                                           containig PD message
    _pfntxcallback -                       Pointer to callback function of
                                           type PRLTxCallback
    _u32PkdPEstOn_TxStatus -               argument to Tx callback function<p />
    Prototype of PRLTxCallback function -  void (*PRLTxCallback)(UINT8
                                           u8PortNum, UINT8 u8TxDonePEst,
                                           UINT8 u8TxDonePESubst, UINT8
                                           u8TxFailedPEst, UINT8
                                           u8TxFailedPESubst);
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_PRL_TX_MSG_PRE_PROCESS(_u8port_num_, _u8sop_type, _u32header,\\
       _pu8databuff,_pfntxcallback, _u32PkdPEstOn_TxStatus) \\
        HookPRLTxMsgPreProcess(_u8port_num_, _u8sop_type, _u32header, _pu8databuff,\\
        _pfntxcallback,_u32PkdPEstOn_TxStatus)
    
        void HookPRLTxMsgPreProcess(UINT8 u8PortNum, UINT8 u8SOPType, UINT32 u32Header, UINT8 *pu8DataBuffer,
                       PRLTxCallback pfnTxCallback, UINT32  u32PkdPEstOnTxStatus);
    
        void HookPRLTxMsgPreProcess(UINT8 u8PortNum, UINT8 u8SOPType, UINT32 u32Header, UINT8 *pu8DataBuffer,
                       PRLTxCallback pfnTxCallback, UINT32  u32PkdPEstOnTxStatus)
        {
            //any application related change or enhancement for the PRL_Tranmsit() API
        }
    
    </code>
  Remarks:
    None                                                                                                                                     
  ********************************************************************************************************************************************/
#define CONFIG_HOOK_PRL_TX_MSG_PRE_PROCESS(_u8port_num_, _u8sop_type, _u32header, _pu8databuff, _pfntxcallback, _u32PkdPEstOn_TxStatus)

/*****************************************************************************************************************************************
  Function:
          CONFIG_HOOK_PRL_TX_MSG_POST_PROCESS(_u8port_num_, _u8sop_type, _u32header, _pu8databuff, _pfntxcallback, _u32PkdPEstOn_TxStatus)
    
  Summary:
    This function is called after processing the transmit message data from
    policy engine to UPD350 FIFO format
  Description:
    This function is called in PRL_Tranmsit() API after processing the
    message from Policy Engine into UPD350 FIFO format.Exactly,After
    filling the UPD350's TX_FIFO. It has all the arguments passed to the
    API PRL_Transmit() by policy engine It is a placeholder for
    USER_APPLICATION to enhance the API.Define relevant function that has
    UINT8,UINT8,UINT32,UINT8 * ,PRLTxCallback and UINT32 arguments without
    \return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -                         Port number of the device. Value
                                           passed will be less than
                                           CONFIG_PD_PORT_COUNT
    _u8sop_type -                          Sop Type of the message
    _u32header -                           32 bit header passed of which
                                           lower word is PD message header &amp;
                                           higher word is extended message
                                           header if passed message is
                                           extended message.
    _pu8databuff -                         pointer to a byte buffer
                                           containig PD message
    _pfntxcallback -                       Pointer to callback function of
                                           type PRLTxCallback
    _u32PkdPEstOn_TxStatus -               argument to Tx callback function<p />
    Prototype of PRLTxCallback function -  void (*PRLTxCallback)(UINT8
                                           u8PortNum, UINT8 u8TxDonePEst,
                                           UINT8 u8TxDonePESubst, UINT8
                                           u8TxFailedPEst, UINT8
                                           u8TxFailedPESubst);
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_PRL_TX_MSG_POST_PROCESS(_u8port_num_, _u8sop_type, _u32header,\\
        _pu8databuff,pfntxcallback, _u32PkdPEstOn_TxStatus)\\
        HookPRLTxMsgPostProcess(_u8port_num_, _u8sop_type, _u32header,\\
        _pu8databuff, _pfntxcallback, _u32PkdPEstOn_TxStatus)
    
        void HookPRLTxMsgPostProcess(UINT8 u8PortNum, UINT8 u8SOPType, UINT32 u32Header, UINT8 *pu8DataBuffer,
                       PRLTxCallback pfnTxCallback, UINT32  u32PkdPEstOnTxStatus);
    
        void HookPRLTxMsgPostProcess(UINT8 u8PortNum, UINT8 u8SOPType, UINT32 u32Header, UINT8 *pu8DataBuffer,
                       PRLTxCallback pfnTxCallback, UINT32  u32PkdPEstOnTxStatus)
        {
            //any application related change or enhancement for the PRL_Tranmsit() API
        }
    
    </code>
  Remarks:
    None                                                                                                                                  
  *****************************************************************************************************************************************/
#define CONFIG_HOOK_PRL_TX_MSG_POST_PROCESS(_u8port_num_, _u8sop_type, _u32header, _pu8databuff, _pfntxcallback, _u32PkdPEstOn_TxStatus)

/**************************************************************************************
  Function:
          \#define CONFIG_HOOK_PRL_RX_MSG_PRE_PROCESS(_u8port_num_)
    
  Summary:
    This function is called before receiving the message from UPD350's
    RX_FIFO
  Description:
    The function is called at the entry of PRL_ReceiveMsg() API.It is a
    placeholder for USER_APPLICATION to enhance the API. Define relevant
    \function that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_PRL_RX_MSG_PRE_PROCESS(_u8port_num_)     \\
        HookPRLRxMsgPreProcess(_u8port_num_)
    
       void HookPRLRxMsgPreProcess(UINT8 u8Portnum);
    
       void HookPRLRxMsgPreProcess(UINT8 u8Portnum)
        {
            //any application related change or enhancement for the  PRL_ReceiveMsg API
        }
    
    </code>
  Remarks:
    None                                                                               
  **************************************************************************************/
#define CONFIG_HOOK_PRL_RX_MSG_PRE_PROCESS(_u8port_num_)

/**********************************************************************************
  Function:
          \#define CONFIG_HOOK_PRL_RX_MSG_POST_PROCESS(_u8port_num_)
    
  Summary:
    This function is called after receiving and processing the message from
    UPD350's RX_FIFO
  Description:
    The function is called at the exit of PRL_ReceiveMsg() API. It is a
    placeholder for USER_APPLICATION to enhance the API. Define relevant
    \function that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_PRL_RX_MSG_POST_PROCESS(_u8port_num_)   \\
    HookPRLRxMsgPostProcess(_u8port_num_)
    
    void HookPRLRxMsgPostProcess(UINT8 u8Portnum);
    
    void HookPRLRxMsgPostProcess(UINT8 u8Portnum)
    {
    
        //any application related change or enhancement for the  PRL_ReceiveMsg API
    
    }
    
    </code>
  Remarks:
    None                                                                           
  **********************************************************************************/
#define CONFIG_HOOK_PRL_RX_MSG_POST_PROCESS(_u8port_num_)

/************************************************************************************************
  Function:
          \#define CONFIG_HOOK_PRL_CHUNK_SM(_u8port_num_)
    
  Summary:
    This function is called before running the chunk state machine
  Description:
    The function is called at the entry of PRL_RunChunkStateMachine() API.
    It is a placeholder for USER_APPLICATION to enhance the API. Define
    relevant function that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
        \#define CONFIG_HOOK_PRL_CHUNK_SM(_u8port_num_)  \\
        HookPRLChunkSM(_u8port_num_)
    
        void HookPRLChunkSM(UINT8 u8Portnum);
    
        void HookPRLChunkSM(UINT8 u8Portnum)
        {
            // any application related change or enhancement for the PRL_RunChunkStateMachine API
        }
    
    </code>
  Remarks:
    None                                                                                         
  ************************************************************************************************/
#define CONFIG_HOOK_PRL_CHUNK_SM(_u8port_num_)

/************************************************************************************
  Function:
          \#define CONFIG_HOOK_UPD_ALERT_ISR_ALL_PORT(_u8port_num_)
    
  Summary:
    This function is called before processing the UPD alert interrupt
  Description:
    The function is called at the entry of UPDIntr_AlertHandler() API. It
    is a placeholder for USER_APPLICATION to enhance the API. Define
    relevant function that has one UINT8 argument without return type.
  Conditions:
    None.
  Input:
    _u8port_num_ -  Port number of the device. Value passed will be less
                    than CONFIG_PD_PORT_COUNT
  Return:
    None.
  Example:
    <code>
    \#define CONFIG_HOOK_UPD_ALERT_ISR_ALL_PORT(_u8port_num_)    \\
    HookUPDAlertISRAllPort(_u8port_num_)
    
    void HookUPDAlertISRAllPort(UINT8 u8Portnum);
    
    void HookUPDAlertISRAllPort(UINT8 u8Portnum)
    {
        // any application related change or enhancement for UPDIntr_AlertHandler API
    }
    
    </code>
  Remarks:
    None                                                                             
  ************************************************************************************/
#define CONFIG_HOOK_UPD_ALERT_ISR_ALL_PORT(_u8port_num_)				

/*Call back function for external Device policy manager to notify PD events */
#define CONFIG_HOOK_NOTIFY_PD_EVENTS_CB(PortNum, PDEvent)    PDStack_Events(PortNum, PDEvent)

#define TYPEC_ATTACH_EVENT                  0
#define TYPEC_DETACH_EVENT                  1
#define TYPEC_CC1_ORIENTATION               2
#define TYPEC_CC2_ORIENTATION               3


/*Hook function for straps to set power role */
#define  CONFIG_HOOK_STRAPS_PORT_ROLE(PortConfigData)            STRAPS_PowerRole_Set(PortConfigData)       

// *****************************************************************************
// *****************************************************************************
// Section: DEBUG MESSAGES CONFIGURATION
// *****************************************************************************
// *****************************************************************************

#ifdef CONFIG_HOOK_DEBUG_MSG
	#define CONFIG_HOOK_DEBUG_INIT()				                            SERCOMUART_Init()
	#define CONFIG_HOOK_DEBUG_STRING(_str_)		                                SERCOMUART_WriteString(_str_)
	#define CONFIG_HOOK_DEBUG_CHAR(_char_)			                           	SERCOMUART_WriteChar(_char_)
	#define CONFIG_HOOK_DEBUG_UINT8(_u8Val_)		                            SERCOMUART_WriteUINT8(_u8Val_)
	#define CONFIG_HOOK_DEBUG_UINT16(_u16Val_)		                            SERCOMUART_WriteUINT16(_u16Val_)
	#define CONFIG_HOOK_DEBUG_UINT32(_u32Val_)		                            SERCOMUART_WriteUINT32(_u32Val_)
    #define CONFIG_HOOK_DEBUG_INT32(_i32Val_)		                            SERCOMUART_WriteINT32(_i32Val_)
#else
	#define CONFIG_HOOK_DEBUG_INIT()				
	#define CONFIG_HOOK_DEBUG_STRING(_str_)		
	#define CONFIG_HOOK_DEBUG_CHAR(_char_)			
	#define CONFIG_HOOK_DEBUG_UINT8(_u8Val_)		
	#define CONFIG_HOOK_DEBUG_UINT16(_u16Val_)			
	#define CONFIG_HOOK_DEBUG_UINT32(_u32Val_)
    #define CONFIG_HOOK_DEBUG_INT32(_i32Val_)	
#endif


// *****************************************************************************
// *****************************************************************************
// Section: Timeout configuration
// *****************************************************************************
// *****************************************************************************

/* Timers used in TypeC State machine*/
#define CONFIG_TYPEC_TCCDEBOUNCE_TIMEOUT			MILLISECONDS_TO_TICKS(150)
#define CONFIG_TYPEC_TPDEBOUNCE_TIMEOUT			    MILLISECONDS_TO_TICKS(10)
#define CONFIG_TYPEC_VBUSDEBOUNCE_TIMEOUT			MILLISECONDS_TO_TICKS(10)
#define CONFIG_TYPEC_ERROR_RECOVERY_TIMEOUT         MILLISECONDS_TO_TICKS(25)
#define CONFIG_TYPEC_VCONN_DISCHARGE_TIMEOUT        MILLISECONDS_TO_TICKS(35)  

/* Timers used in PD State machine*/
#define CONFIG_PE_SOURCECAPABILITY_TIMEOUT          MILLISECONDS_TO_TICKS(200)              
#define CONFIG_PE_NORESPONSE_TIMEOUT                SECONDS_TO_TICKS(5.5) 
#define CONFIG_PE_SENDERRESPONSE_TIMEOUT           MILLISECONDS_TO_TICKS(26)
#define CONFIG_PE_SINKWAITCAP_TIMEOUT             MILLISECONDS_TO_TICKS(465)
#define CONFIG_PE_PSTRANSITION_TIMEOUT              MILLISECONDS_TO_TICKS(500)
#define CONFIG_PE_SINKREQUEST_TIMEOUT               MILLISECONDS_TO_TICKS(100)
#define CONFIG_PE_HARDRESET_TIMEOUT                 MILLISECONDS_TO_TICKS(35)
#define CONFIG_PE_SEND_SRC_CAP_TIMEOUT              MILLISECONDS_TO_TICKS(150)
#define CONFIG_PE_VCONNON_TIMEOUT                   MILLISECONDS_TO_TICKS(100)
#define CONFIG_PE_VDM_RESPONSE_TIMEOUT              MILLISECONDS_TO_TICKS(28)
#define CONFIG_PE_PS_HARD_RESET_TIMEOUT             MILLISECONDS_TO_TICKS(28)
#define CONFIG_PE_SRC_RECOVER_TIMEOUT               MILLISECONDS_TO_TICKS(800)

/*Timers used in Protocol Layer*/
#define CONFIG_PRL_CHUNK_SENDER_REQUEST_TIMEOUT		MILLISECONDS_TO_TICKS(26)
#define CONFIG_PRL_CHUNK_SENDER_RESPONSE_TIMEOUT    MILLISECONDS_TO_TICKS(26)
#define CONFIG_PRL_SINK_TX_TIMEOUT				    MILLISECONDS_TO_TICKS(16)


// *****************************************************************************
// *****************************************************************************
// Section: PDTimer configuration
// *****************************************************************************
// *****************************************************************************
/*Initialization function of PD Hardware Timer*/			      
#define CONFIG_HOOK_HW_PDTIMER_INIT()	                Timer_Init()

/*Frequency of interrupt from PD MCU Timer */
/* Eg:# define CONFIG_PDTIMER_INTERRUPT_RATE 1000  , 1000 interrupts per seconnd, with interrupt interval of 1ms */
#define CONFIG_PDTIMER_INTERRUPT_RATE	1000  

/*Data Type of the Timeout variable in PD Software Timer*/
/* Eg: #define CONFIG_16_BIT_PDTIMEOUT 1 , will make timeout variable unsigned 16bit */
#define CONFIG_16_BIT_PDTIMEOUT

// *****************************************************************************
// *****************************************************************************
// Section: Port power control configuration
// *****************************************************************************
// *****************************************************************************
/*Initialization function of Hardware Module used for Port Power Control*/
#define PWRCTRL_VBUS_0V		0
#define PWRCTRL_VBUS_5V		1
#define PWRCTRL_VBUS_9V		2
#define PWRCTRL_VBUS_15V	3
#define PWRCTRL_VBUS_20V	4

/*Defines to be used for variable in u8EnaDisVBUSDIS PWRCTRL_SetVBUSDischarge API */
#define PWRCTRL_ENABLE_VBUSDIS      1
#define PWRCTRL_DISABLE_VBUSDIS     0
    
/*Defines to be used for variable in u8EnaDisVBUSDIS PWRCTRL_SetVBUSDischarge API */
#define PWRCTRL_ENABLE_SINK      1
#define PWRCTRL_DISABLE_SINK     0

#define CONFIG_HOOK_HW_PORTPOWER_INIT()                        PWRCTRL_initialization()

/* VBUS drive function for set voltage in VBUS */
#define CONFIG_HOOK_VBUS_DRIVE_VOLTAGE(PortNum, VBUS_Volatge)	PWRCTRL_SetPortPower (PortNum, VBUS_Volatge)

/* VBUS discharge function for enabling and disabling VBUS discharge functionality */
#define CONFIG_HOOK_VBUS_DISCHARGE(PortNum, EnableDisable)	    PWRCTRL_ConfigVBUSDischarge (PortNum, EnableDisable)
  
/*Function for enabling and disabling sink hardware circuitry */
#define CONFIG_HOOK_SINK_HW(PortNum, EnableDisable)	            PWRCTRL_ConfigSink (PortNum, EnableDisable)

// *****************************************************************************
// *****************************************************************************
// Section: Port Specific configurations for CONFIG_PD_PORT_COUNT ports
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// *****************************************************************************
// Section: Port0 basic configurations
// *****************************************************************************
// *****************************************************************************        

#define  CONFIG_PORT_0_POWER_ROLE           1          				/* 0- PD_ROLE_SINK , 1- PD_ROLE_SOURCE */

#define  CONFIG_PORT_0_DATA_ROLE            0          				    /* 0- PD_ROLE_DFP , 1- PD_ROLE_UFP */

#define  CONFIG_PORT_0_RP_CURRENT_VALUE     2         		            /* 0- RP_DISABLED(To be set for Sink), 1- DEFAULT_CURRENT ,2- CURRENT_15 ,3- CURRENT_30 */

// *****************************************************************************
// *****************************************************************************
// Section: Port0 configuration
// *****************************************************************************
// *****************************************************************************
#define CONFIG_PORT_0_SOURCE_NUM_OF_PDOS           3

/********************* PDO-1 ********************************/
#define CONFIG_PORT_0_SOURCE_PDO_1_USB_COM         1
#define CONFIG_PORT_0_SOURCE_PDO_1_CURRENT         3000        /* Specify in mA */
#define CONFIG_PORT_0_SOURCE_PDO_1_VOLTAGE         5000        /* Specify in mV */

/********************* PDO-2 ********************************/
#define CONFIG_PORT_0_SOURCE_PDO_2_USB_COM         0
#define CONFIG_PORT_0_SOURCE_PDO_2_CURRENT         3000        /* Specify in mA */
#define CONFIG_PORT_0_SOURCE_PDO_2_VOLTAGE         9000        /* Specify in mV */

/********************* PDO-3 ********************************/
#define CONFIG_PORT_0_SOURCE_PDO_3_USB_COM         0
#define CONFIG_PORT_0_SOURCE_PDO_3_CURRENT         3000        /* Specify in mA */
#define CONFIG_PORT_0_SOURCE_PDO_3_VOLTAGE         15000       /* Specify in mV */

/********************* PDO-4 ********************************/
#define CONFIG_PORT_0_SOURCE_PDO_4_USB_COM         0
#define CONFIG_PORT_0_SOURCE_PDO_4_CURRENT         3000        /* Specify in mA */
#define CONFIG_PORT_0_SOURCE_PDO_4_VOLTAGE         20000       /* Specify in mV */

/********************* PDO-5 ********************************/
#define CONFIG_PORT_0_SOURCE_PDO_5_USB_COM         0
#define CONFIG_PORT_0_SOURCE_PDO_5_CURRENT         0           /* Specify in mA */
#define CONFIG_PORT_0_SOURCE_PDO_5_VOLTAGE         0           /* Specify in mV */

/********************* PDO-6 ********************************/
#define CONFIG_PORT_0_SOURCE_PDO_6_USB_COM         0
#define CONFIG_PORT_0_SOURCE_PDO_6_CURRENT         0           /* Specify in mA */
#define CONFIG_PORT_0_SOURCE_PDO_6_VOLTAGE         0           /* Specify in mV */

/********************* PDO-7 ********************************/
#define CONFIG_PORT_0_SOURCE_PDO_7_USB_COM         0
#define CONFIG_PORT_0_SOURCE_PDO_7_CURRENT         0           /* Specify in mA */
#define CONFIG_PORT_0_SOURCE_PDO_7_VOLTAGE         0           /* Specify in mV */



#define CONFIG_PORT_0_SINK_NUM_OF_PDOS           4
#define CONFIG_PORT_0_SINK_HIGHER_CAPABILITY     1

/********************* PDO-1 ********************************/

#define CONFIG_PORT_0_SINK_PDO_1_USB_COM                   1
#define CONFIG_PORT_0_SINK_PDO_1_VOLTAGE                   5000        /* Specify in mV */
#define CONFIG_PORT_0_SINK_PDO_1_CURRENT                   1000        /* Specify in mA */

/********************* PDO-2 ********************************/
#define CONFIG_PORT_0_SINK_PDO_2_USB_COM                   1
#define CONFIG_PORT_0_SINK_PDO_2_VOLTAGE                   9000        /* Specify in mV */
#define CONFIG_PORT_0_SINK_PDO_2_CURRENT                   1000        /* Specify in mA */

/********************* PDO-3 ********************************/
#define CONFIG_PORT_0_SINK_PDO_3_USB_COM                   1
#define CONFIG_PORT_0_SINK_PDO_3_VOLTAGE                   15000        /* Specify in mV */
#define CONFIG_PORT_0_SINK_PDO_3_CURRENT                   1000        /* Specify in mA */

/********************* PDO-4 ********************************/
#define CONFIG_PORT_0_SINK_PDO_4_USB_COM                   1
#define CONFIG_PORT_0_SINK_PDO_4_VOLTAGE                   20000        /* Specify in mV */
#define CONFIG_PORT_0_SINK_PDO_4_CURRENT                   1000        /* Specify in mA */

/********************* PDO-5 ********************************/
#define CONFIG_PORT_0_SINK_PDO_5_USB_COM                   0
#define CONFIG_PORT_0_SINK_PDO_5_VOLTAGE                   0        /* Specify in mV */
#define CONFIG_PORT_0_SINK_PDO_5_CURRENT                   0        /* Specify in mA */

/********************* PDO-6 ********************************/
#define CONFIG_PORT_0_SINK_PDO_6_USB_COM                   0
#define CONFIG_PORT_0_SINK_PDO_6_VOLTAGE                   0        /* Specify in mV */
#define CONFIG_PORT_0_SINK_PDO_6_CURRENT                   0        /* Specify in mA */

/********************* PDO-7 ********************************/
#define CONFIG_PORT_0_SINK_PDO_7_USB_COM                   0
#define CONFIG_PORT_0_SINK_PDO_7_VOLTAGE                   0        /* Specify in mV */
#define CONFIG_PORT_0_SINK_PDO_7_CURRENT                   0        /* Specify in mA */


// *****************************************************************************
// *****************************************************************************
// Section: Port1 basic configurations
// *****************************************************************************
// *****************************************************************************
#define  CONFIG_PORT_1_POWER_ROLE           0           		

#define  CONFIG_PORT_1_DATA_ROLE            1         			

#define  CONFIG_PORT_1_RP_CURRENT_VALUE     0  


// *****************************************************************************
// *****************************************************************************
// Section: Port1 configurations
// *****************************************************************************
// *****************************************************************************

/********************** Source PDOs **********************************/

#define CONFIG_PORT_1_SOURCE_NUM_OF_PDOS           4

/********************* PDO-1 ********************************/
#define CONFIG_PORT_1_SOURCE_PDO_1_USB_COM         1
#define CONFIG_PORT_1_SOURCE_PDO_1_CURRENT         3000        /* Specify in mA */
#define CONFIG_PORT_1_SOURCE_PDO_1_VOLTAGE         5000        /* Specify in mV */

/********************* PDO-2 ********************************/
#define CONFIG_PORT_1_SOURCE_PDO_2_USB_COM         0
#define CONFIG_PORT_1_SOURCE_PDO_2_CURRENT         3000        /* Specify in mA */
#define CONFIG_PORT_1_SOURCE_PDO_2_VOLTAGE         9000        /* Specify in mV */

/********************* PDO-3 ********************************/
#define CONFIG_PORT_1_SOURCE_PDO_3_USB_COM         0
#define CONFIG_PORT_1_SOURCE_PDO_3_CURRENT         3000        /* Specify in mA */
#define CONFIG_PORT_1_SOURCE_PDO_3_VOLTAGE         15000       /* Specify in mV */

/********************* PDO-4 ********************************/
#define CONFIG_PORT_1_SOURCE_PDO_4_USB_COM         0
#define CONFIG_PORT_1_SOURCE_PDO_4_CURRENT         3000        /* Specify in mA */
#define CONFIG_PORT_1_SOURCE_PDO_4_VOLTAGE         20000       /* Specify in mV */

/********************* PDO-5 ********************************/
#define CONFIG_PORT_1_SOURCE_PDO_5_USB_COM         0
#define CONFIG_PORT_1_SOURCE_PDO_5_CURRENT         0           /* Specify in mA */
#define CONFIG_PORT_1_SOURCE_PDO_5_VOLTAGE         0           /* Specify in mV */

/********************* PDO-6 ********************************/
#define CONFIG_PORT_1_SOURCE_PDO_6_USB_COM         0
#define CONFIG_PORT_1_SOURCE_PDO_6_CURRENT         0           /* Specify in mA */
#define CONFIG_PORT_1_SOURCE_PDO_6_VOLTAGE         0           /* Specify in mV */

/********************* PDO-7 ********************************/
#define CONFIG_PORT_1_SOURCE_PDO_7_USB_COM         0
#define CONFIG_PORT_1_SOURCE_PDO_7_CURRENT         0           /* Specify in mA */
#define CONFIG_PORT_1_SOURCE_PDO_7_VOLTAGE         0           /* Specify in mV */



#define CONFIG_PORT_1_SINK_NUM_OF_PDOS           4
#define CONFIG_PORT_1_SINK_HIGHER_CAPABILITY     1

/********************* PDO-1 ********************************/
#define CONFIG_PORT_1_SINK_PDO_1_USB_COM                   1
#define CONFIG_PORT_1_SINK_PDO_1_VOLTAGE                   5000        /* Specify in mV */
#define CONFIG_PORT_1_SINK_PDO_1_CURRENT                   1000        /* Specify in mA */

/********************* PDO-2 ********************************/
#define CONFIG_PORT_1_SINK_PDO_2_USB_COM                   1
#define CONFIG_PORT_1_SINK_PDO_2_VOLTAGE                   9000        /* Specify in mV */
#define CONFIG_PORT_1_SINK_PDO_2_CURRENT                   1000        /* Specify in mA */

/********************* PDO-3 ********************************/
#define CONFIG_PORT_1_SINK_PDO_3_USB_COM                   1
#define CONFIG_PORT_1_SINK_PDO_3_VOLTAGE                   15000        /* Specify in mV */
#define CONFIG_PORT_1_SINK_PDO_3_CURRENT                   1000        /* Specify in mA */

/********************* PDO-4 ********************************/
#define CONFIG_PORT_1_SINK_PDO_4_USB_COM                   1
#define CONFIG_PORT_1_SINK_PDO_4_VOLTAGE                   20000        /* Specify in mV */
#define CONFIG_PORT_1_SINK_PDO_4_CURRENT                   1000        /* Specify in mA */

/********************* PDO-5 ********************************/
#define CONFIG_PORT_1_SINK_PDO_5_USB_COM                   0
#define CONFIG_PORT_1_SINK_PDO_5_VOLTAGE                   0        /* Specify in mV */
#define CONFIG_PORT_1_SINK_PDO_5_CURRENT                   0        /* Specify in mA */

/********************* PDO-6 ********************************/
#define CONFIG_PORT_1_SINK_PDO_6_USB_COM                   0
#define CONFIG_PORT_1_SINK_PDO_6_VOLTAGE                   0        /* Specify in mV */
#define CONFIG_PORT_1_SINK_PDO_6_CURRENT                   0        /* Specify in mA */

/********************* PDO-7 ********************************/
#define CONFIG_PORT_1_SINK_PDO_7_USB_COM                   0
#define CONFIG_PORT_1_SINK_PDO_7_VOLTAGE                   0        /* Specify in mV */
#define CONFIG_PORT_1_SINK_PDO_7_CURRENT                   0        /* Specify in mA */


/****************** Configure TypeC Port Data *********************************/
#define CONFIG_TYPEC_PORT_DATA           TYPEC_CONFIGURATION(0), \
                                         TYPEC_CONFIGURATION(1)
                                           
/****************** Configure Port Source PDOs *********************************/
#define CONFIG_PORT_SOURCE_PDOS          PE_SRC_PORT_FIXED_PDO(0), \
                                         PE_SRC_PORT_FIXED_PDO(1)
                                           
/****************** Configure Port Sink PDOs *********************************/
#define CONFIG_PORT_SINK_PDOS          PE_SNK_PORT_FIXED_PDO(0), \
                                       PE_SNK_PORT_FIXED_PDO(1)
                                           

// *****************************************************************************
// *****************************************************************************
// Section: MCU INTERRUPT CONFIGURATION
// *****************************************************************************
// *****************************************************************************
/**************************************************************************************************
	Function:
        CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT()
        CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT()

	Summary:
		Disable global interrupt.

	Description:
		These macros are called when entering into critical section and exiting from the critical section of the stack.
        Critical sections are entered by calling CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT(), and subsequently exited by calling CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT().
        These macros must provide a implementation to disable/enable the interrupts gloabally.

        These routines must be very short, otherwise interrupt response time to the interrupt will take longer time. 
              
	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

    Example:
    <code>
        #define CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT()                  CRITICAL_SECTION_ENTER()     

        #define CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT()                   CRITICAL_SECTION_LEAVE()
  
    </code>


	Remarks:
		None
**************************************************************************************************/
#define CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT()                  CRITICAL_SECTION_ENTER()            
#define CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT()                   CRITICAL_SECTION_LEAVE()
                                         
/*Status of ports whether disabled or enabled*/
#define PORT_STATUS_DISABLED        0x01
#define PORT_STATUS_ENABLED         0x00

/**************************************************************************************************
	Function:
        CONFIG_HOOK_UPD_INTERRUPT_INIT(_pu8PortDisable_)

	Summary:
		Interrupt initialization for corresponding UPD350 alert lines.

	Description:
		CONFIG_HOOK_UPD_INTERRUPT_INIT() is a function that is called during initialization of stack.

        Define relevant function that has no arguments with out return type.
        
	Precondition:
		None.

	Parameters:
		_pu8PortDisable_ - Pointer to buffer holds the status of port whether enabled or disabled

	Return:
		None.

    Example:
    <code>
        #define CONFIG_HOOK_UPD_INTERRUPT_INIT(_pu8PortDisable_)      InterruptInit(_pu8PortDisable_)

        void InterruptInit(UINT8 *pu8PortDisable);
        
        void InterruptInit(UINT8 *pu8PortDisable)
        {
            //Microcontroller interrupt init for corresponding UPD350 alert lines
        }
  
    </code>


	Remarks:
		None
**************************************************************************************************/
#define CONFIG_HOOK_UPD_INTERRUPT_INIT(_pu8PortDisable_)	INT_ExtIrqInit(_pu8PortDisable_)

// *****************************************************************************
// *****************************************************************************
// Section: Reset UPD350 through MCU GPIO initialization
// *****************************************************************************
// *****************************************************************************

/*Reset UPD350 through MCU GPIO*/ 
#define CONFIG_HOOK_RESET_UPD350_THRU_GPIO()              Reset_UPD350_Thru_MCU_GPIO()

#define CONFIG_HOOK_UPD350_RESETGPIO_INIT()               IRQ_ResetUPD350ThruGPIOInit()

// *****************************************************************************
// *****************************************************************************
// Section: Structure packing
// *****************************************************************************
// *****************************************************************************
// *****************************************************************************
/* Structure packing

  Summary:
    Structure packing to align the bytes in data memory based on the compiler.

  Description:
		Generally packed structures will be used to save space & align the bytes in data memory based on the compiler.
	If this pre-processor is defined then all used PD stack �C� structures will be replaced with keyword for compilation.
	If this pre-processor is not defined then it will be default compilation rules based on the compiler.

  Remarks:
    Need to be packed always based on type of microcontroller.
	
  Example:
	#define CONFIG_STRUCT_PACKED_START   __attribute__((__packed__)) 
	
*/
#define CONFIG_STRUCT_PACKED_START  _Pragma("pack(1)")  
#define CONFIG_STRUCT_PACKED_END    _Pragma("pack()")
// *****************************************************************************
// *****************************************************************************
// Section: SPI Interface Configuration
// *****************************************************************************
// *****************************************************************************
/**************************************************************************************************
	Function:
        CONFIG_HOOK_HW_SPI_INIT ()

	Summary:
		Initialize SPI module related initialization with respect to the hardware

	Description:
		CONFIG_HOOK_HW_SPI_INIT() is a function that is called during initialization of stack.

        Define relevant function that has no arguments with out return type.
    
  
	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

    Example:
    <code>
        #define CONFIG_HOOK_HW_SPI_INIT()      hw_spi_init()

        void hw_spi_init( void );
        
        void hw_spi_init( void )
        {
            //Microcontroller SPI module init
        }
  
    </code>

	Remarks:
		None
**************************************************************************************************/
#define CONFIG_HOOK_HW_SPI_INIT()                                                   SPI_Init()
/**************************************************************************************************
	Function:
        CONFIG_HOOK_HW_SPI_CS_LOW(_port_num_)

	Summary:
		Drive SPI CS level as low with respect to the port number given in the argument of this function

	Description:
        CONFIG_HOOK_HW_SPI_CS_LOW(_port_num_) is a function that is called before starting to read/write registers 
        with respect to the port.

        Define relevant function that has one UINT8 argument with out return type.
        
	Precondition:
		None.

	Parameters:
		_port_num_ - Port number of the device. The value will be passed from stack which is less than CONFIG_PD_PORT_COUNT

	Return:
		None.

    Example:
    <code>
        
        #define CONFIG_HOOK_HW_SPI_CS_LOW(_port_num_)      hw_spi_cs_low (UINT8 u8Portnum)

        void hw_spi_cs_low(UINT8 u8Port);

        void hw_spi_cs_low (UINT8 u8Portnum)
        {
            if (u8Portnum == 0)
            {
                //Set pin level low for respective GPIO that is connected to the UPD350 CS pin
            }
            if (u8Portnum == 1)
            {
                //Set pin level low for respective GPIO that is connected to the UPD350 CS pin
            }
        }
    
    </code>

	Remarks:
		None
**************************************************************************************************/
#define CONFIG_HOOK_HW_SPI_CS_LOW(_port_num_)                                       SPI_ChipSelectLow(_port_num_)
/**************************************************************************************************
	Function:
        CONFIG_HOOK_HW_SPI_CS_HIGH(_port_num_)

	Summary:
		Drive SPI CS level as high with respect to the port number given in the argument of this function

	Description:
        CONFIG_HOOK_HW_SPI_CS_HIGH(_port_num_) is a function that is called after finishing read/write registers 
        with respect to the port.

        Define relevant function that has one UINT8 argument with out return type.
        
	Precondition:
		None.

	Parameters:
		_port_num_ - Port number of the device. The value will be passed from stack which is less than CONFIG_PD_PORT_COUNT

	Return:
		None.

    Example:
    <code>
        #define CONFIG_HOOK_HW_SPI_CS_HIGH(_port_num_)      hw_spi_cs_high (UINT8 u8Portnum)

        void hw_spi_cs_high(UINT8 u8Port);

        void hw_spi_cs_high (UINT8 u8Portnum)
        {
            if (u8Portnum == 0)
            {
                //Set pin level high for respective GPIO that is connected to the UPD350 CS pin
            }
            if (u8Portnum == 1)
            {
                //Set pin level high for respective GPIO that is connected to the UPD350 CS pin
            }
        }
    
    
    </code>
	Remarks:
		None
**************************************************************************************************/
#define CONFIG_HOOK_HW_SPI_CS_HIGH(_port_num_)                                      SPI_ChipSelectHigh(_port_num_)
/**************************************************************************************************
	Function:
        CONFIG_HOOK_HW_SPI_WRITE_TRANSFER(_write_buf_,_write_len_)

	Summary:
		SPI Write transfer

	Description:
        This is a function that is called to write UPD350 registers with respect to the port.
        
	Precondition:
		None.

	Parameters:
		_write_buf_ - Stack will pass the pointer to the buffer where data to be written on the SPI bus
                      Data type of the pointer buffer must be UINT8
        _write_len_ - Stack will pass the Number of bytes to be written on the SPI bus.
                      Data type of this parameter must be UINT16

	Return:
		None.

    Example:
    <code>
        #define CONFIG_HOOK_HW_SPI_WRITE_TRANSFER(_write_buf_,_write_len_)                   SPI_Write (_write_buf_, _write_len_) 

        void SPI_Write(UINT8 *pu8WriteBuffer, UINT16 u16Writelength);

        void SPI_Write(UINT8 *pu8WriteBuffer, UINT16 u16Writelength)
        {
            for(UINT16 u16Txcount = 0; u16Txcount < u16Writelength ;u16Txcount++)
            {
                //Wait till data register to empty
                while((REGB(SERCOMSPI_INTFLAG)&SERCOMSPI_INTFLAG_DRE)==0);
                
                //Write buffer data bytes to DATA register
                REGB(SERCOMSPI_DATA) = pu8WriteBuffer[u16Txcount]; 
                
                //Wait till Receive interuupt occurs
                while((REGB(SERCOMSPI_INTFLAG)&SERCOMSPI_INTFLAG_TXC)==0);
                
                //Write DATA register to temp buffer to empty shift register
                u8tempbuff = REGB(SERCOMSPI_DATA);
                
                // Clear Transmit intruppt
                REGB(SERCOMSPI_INTFLAG) &= ~SERCOMSPI_INTFLAG_TXC;
            }
        }
    </code>

	Remarks:
		None
**************************************************************************************************/
#define CONFIG_HOOK_HW_SPI_WRITE_TRANSFER(_write_buf_,_write_len_)                   SPI_Write (_write_buf_, _write_len_) 
/**************************************************************************************************
	Function:
        CONFIG_HOOK_HW_SPI_READ_TRANSFER(_read_buf_, _read_len_) 

	Summary:
		SPI Read transfer

	Description:
        This is a function that is called to read UPD350 registers with respect to the port.
        
	Precondition:
		None.

	Parameters:
		_read_buf_ - Stack will pass the pointer to the buffer where data to be read on the SPI bus
                      Data type of the pointer buffer must be UINT8
        _read_len_ - Stack will pass the number of bytes to be read on the SPI bus.
                      Data type of this parameter must be UINT16

	Return:
		None.

    Example:
    <code>
        #define CONFIG_HOOK_HW_SPI_READ_TRANSFER(_read_buf_, _read_len_)     SPI_Read (_read_buf_, _read_len_)

        void SPI_Read (UINT8 *pu8ReadBuffer, UINT16 u16Readlength)

        void SPI_Read (UINT8 *pu8ReadBuffer, UINT16 u16Readlength)
        {        
            for(UINT16 u16Rxcount = 0; u16Rxcount < u16Readlength; u16Rxcount++)
            {
                //Wait till data register to empty
                while((REGB(SERCOMSPI_INTFLAG)&SERCOMSPI_INTFLAG_DRE)==0);
                
                //Write dummy bytes to DATA register
                REGB(SERCOMSPI_DATA) = DUMMYBYTE; 
                
                // Wait till Receive interuupt occurs
                while((REGB(SERCOMSPI_INTFLAG)&SERCOMSPI_INTFLAG_RXC)==0);
                
                // Copy DATA register to application buffer
                pu8ReadBuffer[u16Rxcount] = REGB(SERCOMSPI_DATA);
                
                // Clear Receive intruppt
                REGB(SERCOMSPI_INTFLAG) &= ~SERCOMSPI_INTFLAG_RXC;
             }
        }
    </code>

	Remarks:
		None
**************************************************************************************************/
#define CONFIG_HOOK_HW_SPI_READ_TRANSFER(_read_buf_, _read_len_)                     SPI_Read (_read_buf_, _read_len_)
                                           
#define CONFIG_HOOK_MEMCMP(_OBJ1_, _OBJ2_, _LEN_)                                   UPD301_MemCmp(_OBJ1_, _OBJ2_, _LEN_) 

#define CONFIG_HOOK_MEMCPY(_DEST_, _SRC_, _LEN_)                                     UPD301_MemCpy(_DEST_, _SRC_, _LEN_)

