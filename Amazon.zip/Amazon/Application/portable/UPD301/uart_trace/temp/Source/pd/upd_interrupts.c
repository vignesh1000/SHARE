
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/


#include <stdinc.h>

void UPDIntr_AlertHandler (UINT8 u8PortNum)
{
    do
    {
        if (gau8PortDisable[u8PortNum] & PORT_STATUS_DISABLED)
        {
            break;
        }
        
        CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
        
        UINT16 u16InterruptStatus = 0;
        UINT8  u8Data = 0;
        
        UPD_RegisterReadISR (u8PortNum,UPDINTR_INT_STS,(UINT8 *)&u16InterruptStatus,BYTE_LEN_2);
        
        /*Checking for Device ready Interrupt*/
        if(u16InterruptStatus & UPDINTR_RDY_INT)
        {            
            UPD_RegisterReadISR (u8PortNum, UPD_HW_CTL, &u8Data, BYTE_LEN_1);
            
            u8Data |= UPD_HW_CTL_REG_DEV_RDY_MSK; 
            
            UPD_RegisterWriteISR (u8PortNum, UPD_HW_CTL, &u8Data, BYTE_LEN_1);
        }

        /*CC,PWR,VBUS interrupts are handled by the function "TypeC_InterruptHandler"*/
        if((u16InterruptStatus & UPDINTR_CC_INT) || (u16InterruptStatus & UPDINTR_PWR_INT) || (u16InterruptStatus & UPDINTR_VBUS_INT))
        {
            TypeC_HandleISR (u8PortNum, u16InterruptStatus);
        }
        
        /*Checking for PD MAC Interrupt*/
        if (u16InterruptStatus & UPDINTR_MAC_INT)
        {
            PRL_HandleISR (u8PortNum);
        }
        
        CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();	
    }
    while (FALSE);
}