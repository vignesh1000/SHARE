/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#include <stdinc.h>

void PE_SnkRunStateMachine(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header)
{

    UINT8 u8TypeCState = 0, u8TypeCSubState = 0;
    UINT8 u8TransmitSOP;
    UINT32 u32DataObj[PDO_MAX_OBJECTS] = {0};
	UINT16 u16Transmit_Header;
	UINT32 *u32pTransmit_DataObj;
	PRLTxCallback Transmit_cb;
	UINT32 u32Transmit_TmrID_TxSt;
	UINT8 u8IsTransmit= FALSE;
    
    /*Get Type-C state and Type-C Sub State from DPM*/
    DPM_GetTypeCStates(u8PortNum, &u8TypeCState, &u8TypeCSubState);
    
    /*If the Device is detached, set the Policy Engine State to PE_SNK_STARTUP */
    if((TYPEC_UNATTACHED_SNK == u8TypeCState) && ((ePE_SNK_STARTUP != gasPolicy_Engine[u8PortNum].ePEState) \
                                   && (ePE_SNK_DISCOVERY != gasPolicy_Engine[u8PortNum].ePEState)))
    {
        gasPolicy_Engine[u8PortNum].ePEState = ePE_SNK_STARTUP;
    }
  
    /*Sink Policy Engine State Machine*/
    switch(gasPolicy_Engine[u8PortNum].ePEState)
    {
        case ePE_SNK_STARTUP:
        {         
            _trace1(21, main_tr, 0, 0x01, u8PortNum,"PE_SNK_STARTUP: Enterted the state\r\n");

            /*Hard Reset Recover is used if the Hard reset completion is not
            intimated to the protocol layer in the ePE_SNK_TRANSITION_TO_DEFAULT
            due to the detach event*/
            PE_HardResetRecover(u8PortNum);
                    
            /*Reset the UPD Protocol Layer for all SOPs*/
            PRL_ProtocolResetAllSOPs(u8PortNum);

            /*Explicit Contract becomes invaild once this state is reached 
            from Hard Reset or Initial Power up*/
            gasPolicy_Engine[u8PortNum].u8PEPortSts &= (~PE_EXPLICIT_CONTRACT);	
            
            /*Resetting the Operating PD Spec Rev to Default*/                   
            gasDPM[u8PortNum].u8DPM_Status &= ~DPM_CURR_PD_SPEC_REV_MASK;
            gasDPM[u8PortNum].u8DPM_Status |= ((DPM_GET_DEFAULT_PD_SPEC_REV(u8PortNum)) << DPM_CURR_PD_SPEC_REV_POS);  

            PE_Set_State(u8PortNum, ePE_SNK_DISCOVERY);
            
            break;
        }            

        case ePE_SNK_DISCOVERY:
        {
            /*This State will be useful in getting the VBUS status, if the state machine comes 
            from ePE_SNK_TRANSITION_TO_DEFAULT state*/
    
            /*Query the Device policy manager for VBUS Presence*/
            if ((DPM_GetVBUSVoltage(u8PortNum) == PWRCTRL_VBUS_5V) && (u8TypeCState == TYPEC_ATTACHED_SNK))
            {
                PE_Set_States(u8PortNum, ePE_SNK_WAIT_FOR_CAPABILITIES, ePE_SNK_WAIT_FOR_CAPABILITIES_ENTRY_SS);
            }
            break;                
        }
           
        case ePE_SNK_WAIT_FOR_CAPABILITIES:
        {
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SNK_WAIT_FOR_CAPABILITIES_ENTRY_SS:
                {
                    
                    _trace1(22, main_tr, 0, 0x01, u8PortNum,"PE_SNK_WAIT_FOR_CAPABILITIES: Enterted the state\r\n");

                    if (gasPolicy_Engine[u8PortNum].u8HardResetCounter <= PE_N_HARD_RESET_COUNT)
                    {
                        /*Start the CONFIG_PE_SINKWAITCAP_TIMEOUT waiting for the source capabilities message*/
                        gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start(CONFIG_PE_SINKWAITCAP_TIMEOUT, &PE_SNK_HardReset_TimeoutCB, u8PortNum, ePE_SNK_HARD_RESET);
                    }
                    else if (gasPolicy_Engine[u8PortNum].u8HardResetCounter > PE_N_HARD_RESET_COUNT)
                    {

                        /*Stay in PE_SNK_Wait_for_Capabilities State if HardReset Counter Overflowed*/
                        /*Do Nothing and Wait for Source capability message*/
                    }

                    PE_Set_SubState(u8PortNum, ePE_SNK_WAIT_FOR_CAPABILITIES_WAIT_SS);                    
                    break;
                }
                    
                case ePE_SNK_WAIT_FOR_CAPABILITIES_WAIT_SS:
                {
                    break; 
                }
                    
            }
            break;
        }
            
        case ePE_SNK_EVALUATE_CAPABILITY:
        {            
            _trace1(23, main_tr, 0, 0x01, u8PortNum,"PE_SNK_EVALUATE_CAPABILITY: Enterted the state\r\n");
                    
            /*Reset the HardResetCounter*/
            gasPolicy_Engine[u8PortNum].u8HardResetCounter = 0;	
            
            /*Ask the Device policy manager to evaluate the received source capability message*/
            DPM_Evaluate_Received_Src_caps(u8PortNum,(UINT16) u32Header ,(UINT32*)u8DataBuf );

            /*Invalid Source Capability Message results in Sink request object count to be 0*/
           if (gasDPM[u8PortNum].u32SinkReqRDO == 0)
            {
                /*TODO:Santhru Do we need to send a soft reset here*/
                if ((gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_PDCONTRACT_MASK ) == PE_EXPLICIT_CONTRACT)
                {
                    PE_Set_State(u8PortNum, ePE_SNK_READY);
                }
                else
                {
                    PE_Set_State(u8PortNum, ePE_SNK_WAIT_FOR_CAPABILITIES);
                }			
            }
            else
            {             
                PE_Set_States(u8PortNum, ePE_SNK_SELECT_CAPABILITY, ePE_SNK_SELECT_CAPABILITY_SEND_REQ_SS);            
            }
            break;
        }           

        case ePE_SNK_SELECT_CAPABILITY:
        {
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SNK_SELECT_CAPABILITY_SEND_REQ_SS:
                {
                    
                    _trace1(24, main_tr, 0, 0x01, u8PortNum,"PE_SNK_SELECT_CAPABILITY: Enterted the state\r\n");

                    /*Set the PD message transmitter API variables to send Sink Data request Message*/
                    u8TransmitSOP = PRL_SOP_TYPE;
                    
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader (u8PortNum, ePE_DATA_REQUEST,\
                                            1, 0);
                    
                    u32pTransmit_DataObj = &gasDPM[u8PortNum].u32SinkReqRDO;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_SELECT_CAPABILITY,\
                                             ePE_SNK_SELECT_CAPABILITY_REQ_SENT_SS,ePE_SNK_SEND_SOFT_RESET,\
                                             ePE_SNK_SEND_SOFT_RESET_ENTRY_SS );
                    u8IsTransmit = TRUE;
                    PE_Set_SubState(u8PortNum, ePE_SNK_SELECT_CAPABILITY_SEND_REQ_IDLE_SS);
                    break;                                   
                }
                
                case ePE_SNK_SELECT_CAPABILITY_SEND_REQ_IDLE_SS:
                {                  
                    break;
                }
                    
                case ePE_SNK_SELECT_CAPABILITY_REQ_SENT_SS:
                {
                    /*Start the CONFIG_PE_SENDERRESPONSE_TIMEOUT for the Sink Data request message sent*/
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start(CONFIG_PE_SENDERRESPONSE_TIMEOUT,\
                                                              &PE_SNK_HardReset_TimeoutCB, u8PortNum, ePE_SNK_HARD_RESET);
                    
                    PE_Set_SubState(u8PortNum, ePE_SNK_SELECT_CAPABILITY_WAIT_FOR_ACCEPT_SS);
                    break;
                }
                    

                case ePE_SNK_SELECT_CAPABILITY_WAIT_FOR_ACCEPT_SS:
                {
                    break;
                }
            }
            break;
        }

        case ePE_SNK_TRANSITION_SINK:
        {
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                /*This State is set by the receive handler if the accept message has been received*/
                case ePE_SNK_TRANSITION_SINK_ENTRY_SS:
                {                    
                    _trace1(25, main_tr, 0, 0x01, u8PortNum,"PE_SNK_TRANSITION_SINK: Enterted the state\r\n");

                    /*Initialize and run CONFIG_PE_PSTRANSITION_TIMEOUT*/
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start(CONFIG_PE_PSTRANSITION_TIMEOUT,\
                                                              &PE_SNK_HardReset_TimeoutCB, u8PortNum, ePE_SNK_HARD_RESET);
                    
                    PE_Set_SubState(u8PortNum, ePE_SNK_TRANSITION_SINK_WAIT_FOR_PSRDY_SS);
                }
                    break;

                case ePE_SNK_TRANSITION_SINK_WAIT_FOR_PSRDY_SS:
                {
                    break;
                }
                    
                default:
                  break;
            }
            break;
        }
            
        case ePE_SNK_READY:
        {
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                 /*This State is set by the receive handler if the PS_RDY message has been received*/
                case ePE_SNK_READY_ENTRY_SS:
                {                    
                    _trace1(26, main_tr, 0, 0x01, u8PortNum,"PE_SNK_READY: Enterted the state\r\n");
                    
                    /*Setting the explicit contract as True*/
                    gasPolicy_Engine[u8PortNum].u8PEPortSts |= (PE_EXPLICIT_CONTRACT);
                    PE_Set_SubState(u8PortNum, ePE_SNK_READY_IDLE_SS);
                    break;
                }
                
                case ePE_SNK_READY_IDLE_SS:
                {
                    break;
                } 
                    
                default:
                    break;
            }
            break;
        }
            
        case ePE_SNK_HARD_RESET:
        {
           switch (gasPolicy_Engine[u8PortNum].ePESubState)
           {           
               case ePE_SNK_HARD_RESET_SEND_SS:
               { 
                    
                    _trace1(27, main_tr, 0, 0x01, u8PortNum,"PE_SNK_HARD_RESET_SEND_SS: Enterted the state\r\n");

                    /*Reset the UPD Protocol Layer*/
                    PRL_ProtocolResetAllSOPs(u8PortNum);

                     /*TODO: Where to impement this API call*/
                    /*Kill All the Active timers for the port*/
                    //PDTimer_KillPortTimers(u8PortNum);
                    
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_TRANSITION_TO_DEFAULT,ePE_SNK_TRANSITION_TO_DEFAULT_ENTRY_SS,\
                                             ePE_SNK_STARTUP,ePE_SRC_STARTUP_ENTRY_SS);
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_HARD_RESET_WAIT_FOR_COMPLETION_SS;

                    PRL_SendCableorHardReset(u8PortNum, PRL_SEND_HARD_RESET, PE_StateChange_TransmitCB, u32Transmit_TmrID_TxSt);

                    /*Increment HardReset Counter*/
                    gasPolicy_Engine[u8PortNum].u8HardResetCounter++;             
                    
                    break;
               }
               case ePE_SNK_HARD_RESET_WAIT_FOR_COMPLETION_SS:
               {
                    break;
               }
                default:
                    break;
            
            }
            break;               
        }

        case ePE_SNK_TRANSITION_TO_DEFAULT:
        {            
           switch (gasPolicy_Engine[u8PortNum].ePESubState)
           {                  
               case ePE_SNK_TRANSITION_TO_DEFAULT_ENTRY_SS:
               {
            
                    _trace1(28, main_tr, 0, 0x01, u8PortNum,"PE_SNK_TRANSITION_TO_DEFAULT: Enterted the state\r\n");

                    /*Turn OFF VCONN if it sources currently*/
                    if (DPM_IsPort_VCONN_Source(u8PortNum))
                    {
                        DPM_VConnOnOff(u8PortNum,0);
                    }
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_TRANSITION_TO_DEFAULT_WAIT_SS;
                                     
                    break;
               }
               
               case ePE_SNK_TRANSITION_TO_DEFAULT_WAIT_SS:
               {                    
                    /*Transition only after the VBUS from Source has gone down to 0V*/
                    if(DPM_GetVBUSVoltage(u8PortNum) == PWRCTRL_VBUS_0V)
                    {                    
                        /*Inform Protocol Layer about Hard Reset Complete */
                        PRL_HRorCRCompltIndicationFromPE(u8PortNum);
                 
                        /*Transistion only when the DPM indicates that the Sink has reached the default level*/
                        PE_Set_State(u8PortNum, ePE_SNK_STARTUP);
                    
                    }                                                     
                    break;                                 
               }
           }
           break;        
        }
            

        case ePE_SNK_GIVE_SINK_CAP:
        {              
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SNK_GIVE_SINK_CAP_ENTRY_SS:
                {
                    _trace1(29, main_tr, 0, 0x01, u8PortNum,"PE_SNK_GIVE_SINK_CAP: Enterted the state\r\n");

                    UINT16 u16Header;
                    UINT8 u8SinkPDOCnt;

                    /*Request Device policy manager for Sink Capability Messsage*/
                    /*If the Port does not have sink capability, send Reject / Not Supported message*/
                    DPM_Get_Sink_Capabilities(u8PortNum, &u8SinkPDOCnt, u32DataObj);
                    
                    if (u8SinkPDOCnt == 0)
                    {                        
                        if (DPM_GET_CURRENT_PD_SPEC_REV(u8PortNum) == PD_SPEC_REVISION_2_0)
                        {
                            /*Send Reject message as per 2.0 Spec*/
                            u16Header = PRL_FormSOPTypeMsgHeader(u8PortNum, ePE_CTRL_REJECT, 0, 0);
                        }
                        else                
                        {
                            /*Send Not Supported message as Per 3.0 Spec*/
                            u16Header = PRL_FormSOPTypeMsgHeader(u8PortNum, ePE_NOT_SUPPORTED,0, 0);
                        }
                    }
                    else
                    {
                        u16Header = PRL_FormSOPTypeMsgHeader(u8PortNum, ePE_DATA_SINK_CAP, u8SinkPDOCnt, 0);
                    }

                    /*Set the PD message transmitter  API to Send Sink Capability Messsage*/
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = u16Header;
                    u32pTransmit_DataObj = u32DataObj;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY,ePE_SNK_READY_IDLE_SS,\
                                             ePE_SNK_SEND_SOFT_RESET, ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    u8IsTransmit = TRUE;
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_GIVE_SINK_CAP_IDLE_SS;
                    
                    break;

                }
                case ePE_SNK_GIVE_SINK_CAP_IDLE_SS:
                {                 
                    break;  
                }
            }
            break;
        }    

        case ePE_SNK_GET_SOURCE_CAP:
        {

            _trace1(30, main_tr, 0, 0x01, u8PortNum,"PE_SNK_GET_SOURCE_CAP: Enterted the state\r\n");

            /*TODO: Notify Protocol layer that Sink is starting an AMS here*/
            /*Set the PD message transmitter  API to Send Get Source Capability message*/
            u8TransmitSOP = PRL_SOP_TYPE;
            u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, ePE_CTRL_GET_SOURCE_CAP,0, 0);
            u32pTransmit_DataObj = NULL;
            Transmit_cb = PE_StateChange_TransmitCB;
            u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_READY,ePE_SNK_READY_ENTRY_SS,\
                                     ePE_SNK_SEND_SOFT_RESET, ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
            u8IsTransmit = TRUE;
            break;
        }

        case ePE_SNK_SOFT_RESET:
        {
             switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SNK_SOFT_RESET_SEND_ACCEPT_SS:
                {
                                   
                    _trace1(31, main_tr, 0, 0x01, u8PortNum,"PE_SNK_SOFT_RESET: Enterted the state\r\n");
                    
                    /*Reset the UPD Protocol Layer for the received soft reset message*/
                    PRL_ProtocolspecificSOPReset(u8PortNum, PRL_SOP_TYPE);

                    /*Set the PD message transmitter API to Send Accept Messsage*/
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, ePE_CTRL_ACCEPT, 0, 0);
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32(ePE_SNK_WAIT_FOR_CAPABILITIES,ePE_SNK_WAIT_FOR_CAPABILITIES_ENTRY_SS,\
                                             ePE_SNK_SEND_SOFT_RESET, ePE_SNK_SEND_SOFT_RESET_ENTRY_SS);
                    u8IsTransmit = TRUE;
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SNK_SOFT_RESET_WAIT_SS;
                    break;
                }
                case ePE_SNK_SOFT_RESET_WAIT_SS:
                {
                                   
                    break;
                }
            }
            break;        
        }

        case ePE_SNK_SEND_SOFT_RESET:
        {
            switch (gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SNK_SEND_SOFT_RESET_ENTRY_SS:
                {

                    _trace1(32, main_tr, 0, 0x01, u8PortNum,"PE_SNK_SEND_SOFT_RESET: Enterted the state\r\n");

                    /*Reset the UPD Protocol Layer*/
                    PRL_ProtocolspecificSOPReset(u8PortNum, PRL_SOP_TYPE);

                    /*Set the PD message transmitter  API to Send SoftReset message*/
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, ePE_CTRL_SOFT_RESET,0, 0);
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SNK_SEND_SOFT_RESET,ePE_SNK_SEND_SOFT_RESET_SENT_SS,\
                                             ePE_SNK_HARD_RESET, ePE_SNK_HARD_RESET);
                    u8IsTransmit = TRUE;
                    PE_Set_SubState(u8PortNum, ePE_SNK_SEND_SOFT_RESET_SEND_IDLE_SS);
                    break;
                }
                               
                case ePE_SNK_SEND_SOFT_RESET_SEND_IDLE_SS:
                {                  
                    break;
                }
                    
                case ePE_SNK_SEND_SOFT_RESET_SENT_SS:
                {
                  
                    /*Start the Sender response timer for the soft reset message being sent*/
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start(CONFIG_PE_SENDERRESPONSE_TIMEOUT, &PE_SNK_HardReset_TimeoutCB, u8PortNum, ePE_SNK_HARD_RESET);
                    PE_Set_SubState(u8PortNum, ePE_SNK_SEND_SOFT_RESET_WAIT_FOR_ACCEPT_SS);
                    break;

                }
                   
                case ePE_SNK_SEND_SOFT_RESET_WAIT_FOR_ACCEPT_SS:
                {
                     break;
                }
                   
            }
            break;
        }
               
        default:
            break;

     }  

    /*Send PD message if the variable "u8IsTransmit" is set as true inside the state machine*/
	if (u8IsTransmit == TRUE)
	{
		PRL_TransmitMsg(u8PortNum, u8TransmitSOP, u16Transmit_Header, (UINT8 *)u32pTransmit_DataObj, Transmit_cb, u32Transmit_TmrID_TxSt);
        u8IsTransmit = FALSE;
	}

}

void PE_SNK_HardReset_TimeoutCB (UINT8 u8PortNum, UINT8 u8PE_State)
{
	/*Setting the policy engine State with a Hard reset State*/
    gasPolicy_Engine[u8PortNum].ePEState = (ePolicyState) u8PE_State;
  
    /*Setting the policy engine substate with a Hard reset substate*/
    gasPolicy_Engine[u8PortNum].ePESubState = (ePolicySubState) ePE_SNK_HARD_RESET_SEND_SS;
    
}

