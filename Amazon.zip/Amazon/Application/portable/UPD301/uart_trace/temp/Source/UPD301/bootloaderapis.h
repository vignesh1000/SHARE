/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _BOOTLOADERAPI_H_
#define _BOOTLOADERAPI_H_

#define __Bootloader_main	0x00000e21
#define __CfgGlobals_Initialize	0x00000e5d
#define __GPIO_SetDirection	0x000003e1
#define __GPIO_SetPinFunction	0x0000033d
#define __GPIO_SetPinLevel	0x00000427
#define __GPIO_SetPullMode	0x00000393
#define __Hermes_HandleDiscoveryResp	0x000006a5
#define __Hermes_HandleProtocolTxReq	0x0000083d
#define __Hermes_IfConnectionRequest	0x0000067f
#define __Hermes_InterfaceInit	0x00000673
#define __Hermes_MemCpy	0x00000659
#define __Hermes_ProcessDebugRequestPacket	0x0000079b
#define __Hermes_ProcessMasterPacket	0x00000687
#define __Hermes_ProcessRequestPacket	0x000006db
#define __Hermes_ProcessResponsePacket	0x00000735
#define __I2C_CheckI2CRequest	0x000001d9
#define __I2C_PortInit	0x00000151
#define __I2C_SlaveAddressResolve	0x00000245
#define __I2C_SlaveConfigure	0x00000177
#define __I2C_SlaveInit	0x000001b3
#define __I2C_SlaveRead	0x00000041
#define __I2C_SlaveTriggerIRQ	0x0000032b
#define __I2C_SlaveWrite	0x000000ab
#define __MCU_DFLLInit	0x00000c45
#define __MCU_Init	0x00000d13
#define __NVM_EraseRow	0x00000a0d
#define __NVM_Init	0x000008c1
#define __NVM_ProgramMemory	0x00000a75
#define __NVM_ReadBuffer	0x000009a5
#define __NVM_ReadMemory	0x00000ad1
#define __NVM_WriteBuffer	0x000008e5
#define __PDFW_ProcessGetFWIDRequest	0x00000b21
#define __PDFW_ProcessPDFUInitateRequest	0x00000b6b
#define __PDFW_ProcessRequestPacket	0x00000b85
#define __SPI_ChipSelectHigh	0x00000471
#define __SPI_ChipSelectLow	0x00000455
#define __SPI_Init	0x000005a5
#define __SPI_PortInit	0x000004f7
#define __SPI_Read	0x000004c5
#define __SPI_SyncInit	0x00000577
#define __SPI_Write	0x0000048d
#define __UPD_RegisterRead	0x00000621
#define __UPD_RegisterWrite	0x000005ed
#define ____iar_copy_init3	0x00000eb9
#define ____iar_data_init3	0x00000ee9
#define ____iar_zero_init3	0x00000e79
#define ____low_level_init	0x00000f4f
#define ___pm_init	0x00000d7d
#define __exit	0x00000f53
#define __main	0x00000d95


#endif

