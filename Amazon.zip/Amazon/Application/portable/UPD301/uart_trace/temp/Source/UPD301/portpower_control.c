
/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/


#include <stdinc.h>
#include <portpower_control.h>


void PWRCTRL_initialization()
{
    
    UPD_GPIOEnableDisable(0,PWRCTRL_ENABLE_VBUS_DIS_IU,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(0,PWRCTRL_ENABLE_VBUS_DIS_IU,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(0,PWRCTRL_ENABLE_VBUS_DIS_IU,UPD_GPIO_SETBUF_PUSHPULL);
    
    UPD_GPIOEnableDisable(0,PWRCTRL_ENABLE_VBUS_IU,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(0,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(0,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_SETBUF_PUSHPULL);
    UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_CLEAR);
    
    DAC_Initialization();
      
    UPD_GPIOEnableDisable(1,PWRCTRL_ENABLE_DC_DC_EU,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SETBUF_PUSHPULL);
    
    UPD_GPIOEnableDisable(1,PWRCTRL_ENABLE_VBUS_EU,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(1,PWRCTRL_ENABLE_VBUS_EU,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(1,PWRCTRL_ENABLE_VBUS_EU,UPD_GPIO_SETBUF_PUSHPULL);
    
    if((gasPortConfigurationData[1].u32CfgData & TYPEC_PORT_TYPE_MASK) == PD_ROLE_SOURCE)
    {
        UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_VBUS_EU,UPD_GPIO_SET);  
    }
    else
    {
        UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_VBUS_EU,UPD_GPIO_CLEAR);  
    }
    
    UPD_GPIOEnableDisable(1,PWRCTRL_ENABLE_VBUS_DIS_EU,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(1,PWRCTRL_ENABLE_VBUS_DIS_EU,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(1,PWRCTRL_ENABLE_VBUS_DIS_EU,UPD_GPIO_SETBUF_PUSHPULL);
    
    UPD_GPIOEnableDisable(1,PWRCTRL_ENABLE_9V_EU,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_SETBUF_PUSHPULL);
    
    UPD_GPIOEnableDisable(1,PWRCTRL_ENABLE_15V_EU,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_SETBUF_PUSHPULL);
    
    UPD_GPIOEnableDisable(1,PWRCTRL_ENABLE_20V_EU,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_SETBUF_PUSHPULL);    

}


void PWRCTRL_SetPortPower (UINT8 u8PortNum, UINT8 u8VBUSVoltage)
{

   if(0 == u8PortNum)
   {
        UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_SET);
        DAC_DriveVoltage(u8VBUSVoltage);
   }
   else if (1 == u8PortNum)
   {
        switch (u8VBUSVoltage)
        {
            case PWRCTRL_VBUS_0V:
            { 
                
                /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_15V_EU,PWRCTRL_ENABLE_20V_EU,
                PWRCTRL_ENABLE_DC_DC_EU*/
                
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_CLEAR);
                break;                       
            }
            
            case PWRCTRL_VBUS_5V:
            {
                
                 /*Setting PWRCTRL_ENABLE_DC_DC_EU */              
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SET);
                
                /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_15V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_CLEAR);
                
                break;                       
            }
            
            case PWRCTRL_VBUS_9V:
            {
                
                /*Setting PWRCTRL_ENABLE_DC_DC_EU,PWRCTRL_ENABLE_9V_EU */
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SET);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_SET);
                
                 /*Resetting PWRCTRL_ENABLE_15V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_CLEAR);
                
                break;                       
            }
            
            case PWRCTRL_VBUS_15V:
            {	
              
                /*Setting PWRCTRL_ENABLE_DC_DC_EU,PWRCTRL_ENABLE_15V_EU*/
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_SET);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SET);
                
                 /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_CLEAR);
                
                break;            
            }
            
            case PWRCTRL_VBUS_20V:
            {			                
                /*Setting PWRCTRL_ENABLE_DC_DC_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_SET);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SET);
                
                /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_15V_EU*/
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_CLEAR);
                break;            
            }
            
            default:
            break;
        }      
   }    
}

void PWRCTRL_ConfigVBUSDischarge (UINT8 u8PortNum, UINT8 u8EnaDisVBUSDIS)
{
    if (u8EnaDisVBUSDIS == PWRCTRL_ENABLE_VBUSDIS )
    {
        if(u8PortNum == PWRCTRL_INTERNAL_UPD_PORT)
        {
            UPD_GPIOSetClearOutput(PWRCTRL_INTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_DIS_IU,UPD_GPIO_SET);
            
        }
        else
        {
            UPD_GPIOSetClearOutput(PWRCTRL_EXTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_DIS_EU,UPD_GPIO_SET);
        }
      
    }
    else
    {
        if(u8PortNum == PWRCTRL_INTERNAL_UPD_PORT)
        {
            UPD_GPIOSetClearOutput(PWRCTRL_INTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_DIS_IU,UPD_GPIO_CLEAR);
        }
        else
        {
            UPD_GPIOSetClearOutput(PWRCTRL_EXTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_DIS_EU,UPD_GPIO_CLEAR);
        }
        
    }
      
}

void PWRCTRL_ConfigSink (UINT8 u8PortNum, UINT8 u8EnaDisSink)
{
    /*Sets the VBUS_SRC_EN pin of PMPD to enable the Sink MOSFETS */
    if (u8EnaDisSink == PWRCTRL_ENABLE_SINK)
    {
        if(u8PortNum == PWRCTRL_INTERNAL_UPD_PORT)
        {
            UPD_GPIOSetClearOutput(PWRCTRL_INTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_SET);
            
        }
        else
        {
            UPD_GPIOSetClearOutput(PWRCTRL_EXTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_EU,UPD_GPIO_SET);
        }
      
    }
    /*Clears the VBUS_SRC_EN pin of PMPD to disable the Sink MOSFETS */
    else
    {
        if(u8PortNum == PWRCTRL_INTERNAL_UPD_PORT)
        {
            UPD_GPIOSetClearOutput(PWRCTRL_INTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_CLEAR);
        }
        else
        {
            UPD_GPIOSetClearOutput(PWRCTRL_EXTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_EU,UPD_GPIO_CLEAR);
        }
        
    }
      
}