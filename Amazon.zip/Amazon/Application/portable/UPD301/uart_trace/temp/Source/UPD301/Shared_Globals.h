/*
 * Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
 *
 * Microchip licenses to you the right to use, modify, copy and distribute
 * Software only when embedded on a Microchip microcontroller or digital signal
 * controller that is integrated into your product or third party product
 * (pursuant to the sublicense terms in the accompanying license agreement).
 *
 * You should refer to the license agreement accompanying this Software for
 * additional information regarding your rights and obligations.
 *
 * SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
 * CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
 * OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
 * INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
 * SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
 * (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 */
#ifndef _CFG_GLBS_H
#define	_CFG_GLBS_H

extern volatile UINT8 gu8CurrentMemory;

extern const volatile UINT32 FixedApplication;   // Application vector address symbol from the linker configuration file
extern const volatile UINT32 UpdatedApplication;   // Application vector address symbol from the linker configuration file
extern const volatile UINT32 FixedApplicationSignature;   // Application vector address symbol from the linker configuration file
extern const volatile UINT32 UpdatedApplicationSignature;   // Application vector address symbol from the linker configuration file

extern volatile UINT32 pFixedApplicationPtr;
extern volatile UINT32 pUpdatedApplicationPtr;
extern volatile UINT32 pFixedApplicationSignature;
extern volatile UINT32 pUpdatedApplicationSignature;

extern UINT8 gu8SlaveAddr;

extern UINT8 gu8HermesReqBuffer[BUFFER_SIZE];
extern UINT8 gu8HermesResBuffer[BUFFER_SIZE];
extern UINT8 gu8AlertRespBuffer[4];
extern UINT8 gu8HResponseCode;
extern UINT16 gu16Rxcount;
extern volatile UINT8 gu8RequestType;
extern volatile UINT8 gu8ConnectionID;

void CfgGlobals_Initialize(void);

#endif
