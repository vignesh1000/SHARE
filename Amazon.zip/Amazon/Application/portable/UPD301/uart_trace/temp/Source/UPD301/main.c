
#include <hal_atomic.h>
#include <stdinc.h>
#include <Interrupts.h>
#include <Hermes_Interface.h>
#include "bootloaderapis.h"
#include "Shared_Globals.h"

/* Pointer to function MCU init in bootloader*/
typedef void (*MCU_Init_cb)(void);
MCU_Init_cb MCU_Init_CB = (MCU_Init_cb )__MCU_Init;

/* Signature bytes to be placed at end of the region"
   The keyword __root symbol is added because this source is not referring the symbol anywhere
   Refer SIGNATURE_BLOCK section in corresponding linker script */
__root const unsigned char SIGNATURE[4] @ "SIGNATURE_BLOCK" = {'2','D','F','U'};


void Userdef_MCU_Enter_Critical()
{
    volatile hal_atomic_t __atomic;                                                                              
    atomic_enter_critical(&__atomic);
}


void Userdef_MCU_Exit_Critical()
{
    volatile hal_atomic_t __atomic;
    atomic_leave_critical(&__atomic); 
}


void main()
{	
    /*Mcu intialisation function changed as pointer to function for Boot loader MCU_init function to optimize the memory*/

   MCU_Init_CB();
   Hermes_InterfaceInit();
    
   PD_Init();
   
   InitOrientationPins();
  
    
    while(TRUE)
	{
        /* Hermes request from I2C slave*/  
        if(Hermes_IfConnectionRequest())
        {  
            Hermes_ProcessMasterPacket();
        }
        PD_Run();
	}
    
}
