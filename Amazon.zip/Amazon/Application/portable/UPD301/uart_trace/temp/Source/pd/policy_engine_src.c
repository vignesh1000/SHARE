/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#include <stdinc.h>

/********************************************************************/
/****************Source Policy Engine State Machine******************/
/********************************************************************/
void PE_SrcRunStateMachine(UINT8 u8PortNum , UINT8 *u8DataBuf , UINT8 u8SOPType ,UINT32 u32Header)
{
    
    UINT32 u32VDMHeader = 0;        				/* Receive VDM Header */
    UINT8 u8SrcPDOCnt = 0;          				/* Source Cap Count */
    UINT32 u32DataObj[7] = {0};     				/* Source Cap Objects */
    UINT8 u8TypeCState = 0, u8TypeCSubState = 0;    /* Type-C state and sub-state */
    UINT8 u8TransmitSOP;                            /* Transmit Msg Type - SOP SOP' SOP" */
	UINT16 u16Transmit_Header = 0;                  /* Transmit Msg Header */
	UINT32 *u32pTransmit_DataObj;                   /* Transmit Data Object */
	PRLTxCallback Transmit_cb;                      /* Transmit Call back */
	UINT32 u32Transmit_TmrID_TxSt = 0;              /* Transmit Call back variables */
	UINT8 u8IsTransmit= 0;                          /* Transmit Flag */
    UINT8 u8RaPresence = 0;                         /* Ra Presence Check */
    
    /* Get the Type-C state from DPM */
    DPM_GetTypeCStates(u8PortNum, &u8TypeCState, &u8TypeCSubState);
    DPM_GetPoweredCablePresence(u8PortNum, &u8RaPresence);
    
    /* If port partner detached set the Policy Engine State to PE_SRC_STARTUP */
    if((TYPEC_UNATTACHED_SRC == u8TypeCState) && (ePE_SRC_STARTUP != gasPolicy_Engine[u8PortNum].ePEState))
    {
        PDTimer_KillPortTimers(u8PortNum);
        gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_STARTUP;
        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_STARTUP_ENTRY_SS;
        
        gasDPM[u8PortNum].u8DPM_Status &= ~DPM_CURR_PD_SPEC_REV_MASK;
        gasDPM[u8PortNum].u8DPM_Status |= (CONFIG_PD_DEFAULT_SPEC_REV << DPM_CURR_PD_SPEC_REV_POS); 
        
        /* Spec Rev is updated by PRL*/
        PRL_UpdateSpecAndDeviceRoles (u8PortNum);
    }
     
    /* Source Policy Engine State Machine */
    switch(gasPolicy_Engine[u8PortNum].ePEState)
    {
        /********************PE_SRC_STARTUP*********************/
        case ePE_SRC_STARTUP:
        {
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_STARTUP_ENTRY_SS:
                {
                    _trace1(33, main_tr, 0, 0x01, u8PortNum,"PE_SRC_STARTUP-ENTRY_SS\r\n");
					
					/* Reset the Caps Counter value */
                    gasPolicy_Engine[u8PortNum].u8CapsCounter = FALSE;
					
                    gasPolicy_Engine[u8PortNum].u8PEPortSts &= (~PE_PDCONNECTED_STS_MASK);
                    
					/* Set PD Contract as Implicit Contract */
                    gasPolicy_Engine[u8PortNum].u8PEPortSts &= (~PE_EXPLICIT_CONTRACT);
                    
                    /* Hard Reset Recover */
                    PE_HardResetRecover( u8PortNum);
					
					/* Reset the Protocol Layer */
                    PRL_ProtocolResetAllSOPs(u8PortNum);
					
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_STARTUP_IDLE_SS;
                    break;
                }
                
                case ePE_SRC_STARTUP_IDLE_SS:
                {
                    if(( TYPEC_ATTACHED_SRC == u8TypeCState) && (TYPEC_ATTACHED_SRC_RUN_SM_SS == u8TypeCSubState))
                    {
                        if(FALSE == u8RaPresence)
                        { 
							/* E-Cable not present, Port partner alone attached */
                            _trace1(34, main_tr, 0, 0x01, u8PortNum,"PE_SRC_STARTUP-IDLE_SS: Device Attached\r\n");
                            gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_SEND_CAPABILITIES;
                            gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_CAP_ENTRY_SS;                      
                        }
                        else
                        {
							/* Port partner attached with E-Cable */
                            _trace1(35, main_tr, 0, 0x01, u8PortNum,"PE_SRC_STARTUP-IDLE_SS: E-Cable and Device Attached\r\n");
                            gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_VDM_IDENTITY_REQUEST;
                            gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_VDM_IDENTITY_REQUEST_ENTRY_SS;                              
                        }
                    }                    
                    break;
                }
                
                default:
                {
                    break;
                }
            }
        break;
        }
        
        case ePE_SRC_SEND_CAPABILITIES:
        {

            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_SEND_CAP_ENTRY_SS:
                {

                    /* HardReset MaxCount and NoResponse timer timedout check*/
                    if((gasPolicy_Engine[u8PortNum].u8HardResetCounter > PE_N_HARD_RESET_COUNT) &&
                       (gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_NO_RESPONSE_TIMEDOUT))
                    {
                        if(gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_PDCONNECTED_STS_MASK)
                        {
                            DPM_SetTypeCState(u8PortNum, TYPEC_ERROR_RECOVERY, TYPEC_ERROR_RECOVERY_ENTRY_SS);
                        }
                        
                        else
                        {
                            gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_DISABLED; 
                        }
                    }
                 
                    else
                    {
						/* Send Source Cabapilities message to Port partner */
                        _trace1(36, main_tr, 0, 0x01, u8PortNum,"PE_SRC_SEND_CAP-ENTRY_SS: Send Source Capabilities\r\n");
                        DPM_Get_Source_Capabilities(u8PortNum, &u8SrcPDOCnt, u32DataObj);
                        
                        u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, (UINT8)ePE_DATA_SOURCE_CAP,  \
                                                                            u8SrcPDOCnt, 0);
                        
                        u8TransmitSOP = PRL_SOP_TYPE;
                        u32pTransmit_DataObj = u32DataObj;
                        Transmit_cb = PE_StateChange_TransmitCB;
                        /* Commented for compilation */
                        if(gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_PDCONNECTED_STS_MASK)
                        {
                            /*The Protocol Layer indicates that the Message has not been sent , so
                             Send Soft reset since pd connected presently*/
                            u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_SEND_CAPABILITIES, \
                                                        ePE_SRC_SEND_CAP_GOODCRC_RECEIVED_SS, \
                                                          ePE_SRC_SEND_SOFT_RESET, ePE_SRC_SEND_SOFT_RESET_SOP_SS);                                                  
                          
                        }
                        else
                        {
                          
                            /*The Policy Engine Shall transition to the PE_SRC_Discovery state when:
                              The Protocol Layer indicates that the Message has not been sent and we are presently not Connected
                             */
                            u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_SEND_CAPABILITIES, \
                                                        ePE_SRC_SEND_CAP_GOODCRC_RECEIVED_SS, \
                                                        ePE_SRC_DISCOVERY, ePE_SRC_DISCOVERY_ENTRY_SS);
                        }

                        u8IsTransmit = TRUE;
                        gasPolicy_Engine[u8PortNum].u8CapsCounter ++;
                                            
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_CAP_IDLE_SS;
                    }
                    break;  
                }
                
                case ePE_SRC_SEND_CAP_IDLE_SS:
                {
                    break;  
                }
                
                case ePE_SRC_SEND_CAP_GOODCRC_RECEIVED_SS:
                {
                    /*Todo: Stop NoResponse Timer */
                    //PDTimer_Kill(gasPolicy_Engine[u8PortNum].u8PENoResponseTimerID);
                    _trace1(37, main_tr, 0, 0x01, u8PortNum,"PE_SRC_SEND_CAP-GOODCRC_RECEIVED_SS\r\n");
                    
                    /* Reset CapsCounter and HardReset Counter to 0 */
                    gasPolicy_Engine[u8PortNum].u8CapsCounter = 0;
                    gasPolicy_Engine[u8PortNum].u8HardResetCounter = 0;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_CAP_IDLE_SS;
					
					/* Set PD Status as Connected */
                    gasPolicy_Engine[u8PortNum].u8PEPortSts |= PE_PDCONNECTED_STS_MASK;
                    
					/* Start Sender Reseponse timer */
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start (
                                                           CONFIG_PE_SENDERRESPONSE_TIMEOUT,
                                                            PE_SubStateChange_TimerCB,u8PortNum,  
                                                            (UINT8)ePE_SRC_SEND_CAP_SENDER_RESPONSE_TIMEOUT_SS);
                    
                    break;
                }
                
                case ePE_SRC_SEND_CAP_SENDER_RESPONSE_TIMEOUT_SS:
                {
					/* Sender Response timer timed out */
                    _trace1(38, main_tr, 0, 0x01, u8PortNum,"PE_SRC_SEND_CAP-SENDER_RESPONSE_TIMEOUT_SS\r\n");
                    gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_HARD_RESET;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_HARD_RESET_ENTRY_SS;
                    break;  
                }
               
                default:
                {
                    break;
                }                

            } 
            break;
        }
        
        case ePE_SRC_NEGOTIATE_CAPABILITY:
        {

            if(PE_VALID_REQUEST == DPM_ValidateRequest(u8PortNum, (UINT16)u32Header, u8DataBuf))
            {
                _trace1(39, main_tr, 0, 0x01, u8PortNum,"PE_SRC_NEGOTIATE_CAPABILITY: Request is Valid\r\n");
                gasPolicy_Engine[u8PortNum].u8PEPortSts |= PE_VALID_PDCONTRACT;
                gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_TRANSITION_SUPPLY;
                gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_TRANSITION_SUPPLY_ENTRY_SS;
            }
            
            else
            {
                _trace1(40, main_tr, 0, 0x01, u8PortNum,"PE_SRC_NEGOTIATE_CAPABILITY: Request is Invalid\r\n");
                gasPolicy_Engine[u8PortNum].u8PEPortSts &= (~PE_VALID_PDCONTRACT); 
                gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_CAPABILITY_RESPONSE;
                gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_CAPABILITY_RESPONSE_ENTRY_SS;
            }
            
            break;
        }
        
        case ePE_SRC_TRANSITION_SUPPLY:
        {

            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_TRANSITION_SUPPLY_ENTRY_SS:
                {
                    _trace1(41, main_tr, 0, 0x01, u8PortNum,"PE_SRC_TRANSITION_SUPPLY-ENTRY_SS\r\n");
                    
					/* Send the Accept message */
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader (u8PortNum, (UINT8)ePE_CTRL_ACCEPT,
                                            0, 0);

                    u8TransmitSOP = PRL_SOP_TYPE;
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = PE_StateChange_TransmitCB;

                    if((DPM_GET_CURRENT_PD_SPEC_REV(u8PortNum) == PD_SPEC_REVISION_3_0))
                    {       
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_TRANSITION_SUPPLY, \
                                                    ePE_SRC_TRANSITION_SUPPLY_EXIT_SS, \
                                                    ePE_SRC_HARD_RESET, ePE_SRC_HARD_RESET_ENTRY_SS);
                    }
                    
                    else
                    {
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_TRANSITION_SUPPLY, \
                                                    ePE_SRC_TRANSITION_SUPPLY_EXIT_SS, \
                                                    ePE_SRC_SEND_SOFT_RESET, ePE_SRC_SEND_SOFT_RESET_SOP_SS);  
                    }

                    u8IsTransmit = TRUE;
                                        
                    /* Drive Power to as requested by port partner*/
                    DPM_SetPortPower(u8PortNum);
                             
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_TRANSITION_SUPPLY_IDLE_SS;
                    break;  
                }
                
                case ePE_SRC_TRANSITION_SUPPLY_EXIT_SS:
                {
                    if(gasDPM[u8PortNum].u8ContractedVoltage == DPM_GetVBUSVoltage(u8PortNum))
                    {
                        _trace1(42, main_tr, 0, 0x01, u8PortNum,"PE_SRC_TRANSITION_SUPPLY-EXIT_SS\r\n");
                        u16Transmit_Header = PRL_FormSOPTypeMsgHeader (u8PortNum, (UINT8)ePE_CTRL_PS_RDY, \
                                            0, 0);

                        u8TransmitSOP = PRL_SOP_TYPE;
                        u32pTransmit_DataObj = NULL;
                        Transmit_cb = PE_StateChange_TransmitCB;
                        
                        if((DPM_GET_CURRENT_PD_SPEC_REV(u8PortNum) == PD_SPEC_REVISION_3_0))
                        {
                            u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_READY, ePE_SRC_READY_ENTRY_SS, \
                                                    ePE_SRC_HARD_RESET, ePE_SRC_HARD_RESET_ENTRY_SS);
                        }
                        
                        else
                        {
                            u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_READY, ePE_SRC_READY_ENTRY_SS, \
                                                    ePE_SRC_SEND_SOFT_RESET, ePE_SRC_SEND_SOFT_RESET_SOP_SS);  
                        }
                        
                        u8IsTransmit = TRUE;
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_TRANSITION_SUPPLY_IDLE_SS;
                    }
                    break;  
                }
                
                case ePE_SRC_TRANSITION_SUPPLY_IDLE_SS:
                {
                    
                    break;  
                }
                
                default:
                {
                    break;    
                }
            }
          
            break;
        }
        
        case ePE_SRC_CAPABILITY_RESPONSE:
        {
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_CAPABILITY_RESPONSE_ENTRY_SS:
                {
					/* Check for Explicit contract and Valid Contract */
                    if((gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_EXPLICIT_CONTRACT) && \
                      (gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_VALID_PDCONTRACT))
                    {
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_READY, \
                                                    ePE_SRC_READY_ENTRY_SS, ePE_SRC_SEND_SOFT_RESET, \
                                                    ePE_SRC_SEND_SOFT_RESET_SOP_SS);
                    }
                    
                    else if((gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_EXPLICIT_CONTRACT) && \
                      (!(gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_VALID_PDCONTRACT)))
                    {
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_HARD_RESET, \
                                                    ePE_SRC_HARD_RESET_ENTRY_SS, ePE_SRC_SEND_SOFT_RESET, \
                                                    ePE_SRC_SEND_SOFT_RESET_SOP_SS);                      
                    }
                    
                    else
                    {
						/* Change the state to PE_SRC_WAIT_NEW_CAPABILITIES to wait for capabilities change */
                        u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_WAIT_NEW_CAPABILITIES, \
                                                    NULL, ePE_SRC_SEND_SOFT_RESET, \
                                                    ePE_SRC_SEND_SOFT_RESET_SOP_SS);
                    }
                    
					/* Send Reject message for Requested Invalid Capability */
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader (u8PortNum, (UINT8)ePE_CTRL_REJECT, \
                                        0, 0);

                    u8TransmitSOP = PRL_SOP_TYPE;
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    
                    u8IsTransmit = TRUE;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_CAPABILITY_RESPONSE_IDLE_SS;
                    
                    break;  
                }
                
                case ePE_SRC_CAPABILITY_RESPONSE_IDLE_SS:
                {
                    break;  
                }
                
                default:
                {
                    break;
                }
            }
            break;
        }
        
        case ePE_SRC_READY:
        {
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_READY_ENTRY_SS:
                {
                    _trace1(43, main_tr, 0, 0x01, u8PortNum,"PE_SRC_READY-ENTRY_SS\r\n");
					
					/* Set the PD contract as Explicit Contract */
                    gasPolicy_Engine[u8PortNum].u8PEPortSts |= PE_EXPLICIT_CONTRACT;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_READY_END_AMS_SS;
                    break;
                }
                
                case ePE_SRC_READY_END_AMS_SS:
                { 
                    break;
                }
            }
            break;
        }
        
        case ePE_SRC_WAIT_NEW_CAPABILITIES:
        {       
            break;  
        }
        
        case ePE_SRC_DISCOVERY:
        {
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_DISCOVERY_ENTRY_SS:
                {
                    _trace1(44, main_tr, 0, 0x01, u8PortNum,"PE_SRC_DISCOVERY-ENTRY_SS\r\n");
					
					/* Start Source Capability  Timer */
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start (
                                                              (CONFIG_PE_SEND_SRC_CAP_TIMEOUT),
                                                              PE_SubStateChange_TimerCB,u8PortNum,  
                                                              (UINT8) ePE_SRC_DISCOVERY_EXIT_SS);
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_DISCOVERY_IDLE_SS;
                    break;  
                }
                
                case ePE_SRC_DISCOVERY_IDLE_SS:
                { 
                    /* Wait for Timeout */
                    break;  
                }
                
                case ePE_SRC_DISCOVERY_EXIT_SS:
                {
                    _trace1(45, main_tr, 0, 0x01, u8PortNum,"PE_SRC_DISCOVERY-EXIT_SS\r\n");
					
					/* Check for Max Caps Count and Hard Reset Count */
                    if((gasPolicy_Engine[u8PortNum].u8CapsCounter > PE_N_CAPSCOUNT) ||
                       ((gasPolicy_Engine[u8PortNum].u8HardResetCounter > PE_N_HARD_RESET_COUNT) &&
                       (!(gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_PDCONNECTED_STS_MASK)) &&
                       (gasPolicy_Engine[u8PortNum].u8PEPortSts & PE_NO_RESPONSE_TIMEDOUT)))
                    {
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_DISABLED;        
                    }
                    
                    else
                    {
                        gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_SEND_CAPABILITIES;
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_CAP_ENTRY_SS;
                    }
                    break;  
                }
                
                default:
                {
                    break;
                }
            }
            break;  
        }
        
        case ePE_SRC_HARD_RESET:
        {
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_HARD_RESET_ENTRY_SS:
                {
                    _trace1(46, main_tr, 0, 0x01, u8PortNum,"PE_SRC_HARD_RESET-ENTRY_SS\r\n");
                    
					/* Todo: Kill All the Active timers for the port */
                    //PDTimer_KillPortTimers(u8PortNum);

                    /* Send Hard Reset to Port Partner*/
                    PRL_SendCableorHardReset(u8PortNum, PRL_SEND_HARD_RESET, NULL, 0);	

                    /* Increment HardReset Counter */
                    gasPolicy_Engine[u8PortNum].u8HardResetCounter++;
                    
                    /* Start the PSHardResetTimer */
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start (
                                                              (CONFIG_PE_PS_HARD_RESET_TIMEOUT),
                                                              PE_SubStateChange_TimerCB, u8PortNum,  
                                                              (UINT8) ePE_SRC_HARD_RESET_EXIT_SS);
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_HARD_RESET_IDLE_SS;
                    
                    break;  
                }
                
                case ePE_SRC_HARD_RESET_IDLE_SS:
                {
                    /* Wait for PSHardResetTimer to times out */
                    break;  
                }
                
                case ePE_SRC_HARD_RESET_EXIT_SS:
                {
                    _trace1(47, main_tr, 0, 0x01, u8PortNum,"PE_SRC_HARD_RESET-EXIT_SS\r\n");
                    gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_TRANSITION_TO_DEFAULT;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_TRANSITION_TO_DEFAULT_ENTRY_SS;
                    break;
                }
                
                default:
                {
                    break;
                }             
            }
            
            break;  
        }
        
         case ePE_SRC_HARD_RESET_RECEIVED:
        {
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_HARD_RESET_RECEIVED_ENTRY_SS:
                {
                    _trace1(48, main_tr, 0, 0x01, u8PortNum,"PE_SRC_HARD_RESET_RECEIVED-ENTRY_SS\r\n");
                    /* Kill All the Active timers for the port */
                    //PDTimer_KillPortTimers(u8PortNum);
                    
                    /* Start PSHardResetTimer */
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start (
                                                              (CONFIG_PE_PS_HARD_RESET_TIMEOUT),
                                                              PE_SubStateChange_TimerCB, u8PortNum,  
                                                              (UINT8) ePE_SRC_HARD_RESET_RECEIVED_EXIT_SS);
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_HARD_RESET_RECEIVED_IDLE_SS;
                    
                    break;  
                }
                
                case ePE_SRC_HARD_RESET_RECEIVED_IDLE_SS:
                {
                    /* Wait for PSHardResetTimer */
                    break;
                }
                
                case ePE_SRC_HARD_RESET_RECEIVED_EXIT_SS:
                {
                    _trace1(49, main_tr, 0, 0x01, u8PortNum,"PE_SRC_HARD_RESET_RECEIVED-EXIT_SS\r\n");
                    gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_TRANSITION_TO_DEFAULT;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_TRANSITION_TO_DEFAULT_ENTRY_SS;  
                    break;
                }
                
                default:
                {
                    break;
                }
            }
            break;    
        }
        
        case ePE_SRC_TRANSITION_TO_DEFAULT:
        {
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_TRANSITION_TO_DEFAULT_ENTRY_SS:
                {
                    _trace1(50, main_tr, 0, 0x01, u8PortNum,"PE_SRC_TRANSITION_TO_DEFAULT-ENTRY_SS\r\n");
                    
					/* Turn Off VConn if E-Cable detected*/
                    if(TRUE == u8RaPresence)
                    {
                        DPM_VConnOnOff(u8PortNum, PE_VCONN_OFF);
                    }
					
					/* Turn Off VBus */
                    DPM_VBusOnOff(u8PortNum, PE_VBUS_OFF);

                    /* Start tSRCRecovery timer */
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start (
                                                            (CONFIG_PE_SRC_RECOVER_TIMEOUT),
                                                            PE_SubStateChange_TimerCB,u8PortNum,  
                                                            (UINT8) ePE_SRC_TRANSITION_TO_DEFAULT_POWER_ON_SS);
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_TRANSITION_TO_DEFAULT_IDLE_SS;
                
                    break;  
                }
                
                case ePE_SRC_TRANSITION_TO_DEFAULT_IDLE_SS:
                {
                    /* Wait for SrcRecoverTimer to times out */
                    break;  
                }
                
                case ePE_SRC_TRANSITION_TO_DEFAULT_POWER_ON_SS:
                {
                    _trace1(51, main_tr, 0, 0x01, u8PortNum,"PE_SRC_TRANSITION_TO_DEFAULT-POWER_ON_SS\r\n");
                    
					/* Turn On VConn if E-Cable detected*/
                    if(TRUE == u8RaPresence)
                    {
                        DPM_VConnOnOff(u8PortNum, PE_VCONN_ON);
                    }
					
					/* Turn On VBus */
                    DPM_VBusOnOff(u8PortNum, PE_VBUS_ON);
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_TRANSITION_TO_DEFAULT_EXIT_SS;
                    
                    break;  
                }
                
                case ePE_SRC_TRANSITION_TO_DEFAULT_EXIT_SS:
                {
                    if(PWRCTRL_VBUS_5V == DPM_GetVBUSVoltage(u8PortNum))
                    {
                        _trace1(52, main_tr, 0, 0x01, u8PortNum,"PE_SRC_TRANSITION_TO_DEFAULT-EXIT_SS\r\n");
                        
                        /* Inform Protocol Layer about Hard Reset Complete */
                        PRL_HRorCRCompltIndicationFromPE(u8PortNum);

                        gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_STARTUP;
                        gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_STARTUP_ENTRY_SS;

                        /* Start NoResponse timer */
                        gasPolicy_Engine[u8PortNum].u8PENoResponseTimerID = PDTimer_Start (
                                                            (CONFIG_PE_NORESPONSE_TIMEOUT),
                                                            PE_NoResponseTimerCB, u8PortNum,  
                                                            0);
                    }
                    break;
                }
            }
            break;  
        }
        
        case ePE_SRC_SEND_SOFT_RESET:
        {
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_SEND_SOFT_RESET_SOP_SS:
                {
                    _trace1(53, main_tr, 0, 0x01, u8PortNum,"ePE_SRC_SEND_SOFT_RESET-SOP_SS\r\n");
                    
					/* Reset the Protocol Layer for SOP type message */
                    PRL_ProtocolspecificSOPReset(u8PortNum, (UINT8) PRL_SOP_TYPE);
                    
					/* Send SoftReset message */
                    u8TransmitSOP = PRL_SOP_TYPE;
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader(u8PortNum, ePE_CTRL_SOFT_RESET, 0, 0);
                    //u16Transmit_Header = 0x16D;
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_SEND_SOFT_RESET, \
                                                    ePE_SRC_SEND_SOFT_RESET_GOODCRC_RECEIVED_SS, \
                                                    ePE_SRC_HARD_RESET, ePE_SRC_HARD_RESET_ENTRY_SS);
                    u8IsTransmit = TRUE;
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_SOFT_RESET_IDLE_SS;
                    
                    break;  
                }
                
                case ePE_SRC_SEND_SOFT_RESET_SOP_P_SS:
                {
                    _trace1(54, main_tr, 0, 0x01, u8PortNum,"PE_SRC_SEND_SOFT_RESET-ENTRY_SS\r\n");
					
					/* Reset the Protocol Layer for SOP_P type message */
                    PRL_ProtocolspecificSOPReset(u8PortNum, PRL_SOP_P_TYPE);

                    /* Send Soft Reset Message */
                    u8TransmitSOP = PRL_SOP_P_TYPE;
                    u16Transmit_Header = PRL_FormNonSOPTypeMsgHeader(u8PortNum, ePE_CTRL_SOFT_RESET, 0, 0);
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_SEND_SOFT_RESET, \
                                                    ePE_SRC_SEND_SOFT_RESET_GOODCRC_RECEIVED_SS, \
                                                    ePE_SRC_HARD_RESET, ePE_SRC_HARD_RESET_ENTRY_SS);
                    u8IsTransmit = TRUE;
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_SOFT_RESET_IDLE_SS;
                    
                    break;  
                }
                
                case ePE_SRC_SEND_SOFT_RESET_IDLE_SS:
                {
                    break;  
                }
                
                case ePE_SRC_SEND_SOFT_RESET_GOODCRC_RECEIVED_SS:
                {
                    _trace1(55, main_tr, 0, 0x01, u8PortNum,"PE_SRC_SEND_SOFT_RESET-GOODCRC_RECEIVED_SS\r\n");
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start (
                                                            CONFIG_PE_SENDERRESPONSE_TIMEOUT,
                                                            PE_SubStateChange_TimerCB,u8PortNum,  
                                                            (UINT8)ePE_SRC_SEND_SOFT_RESET_SENDER_RESPONSE_TIMEDOUT);
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_SOFT_RESET_IDLE_SS;
                    break;  
                }
                
                case ePE_SRC_SEND_SOFT_RESET_SENDER_RESPONSE_TIMEDOUT:
                {
					/* Sender Response timer timed out */
                    _trace1(56, main_tr, 0, 0x01, u8PortNum,"PE_SRC_SEND_SOFT_RESET-SENDER_RESPONSE_TIMEDOUT\r\n");
                    gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_HARD_RESET;
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_HARD_RESET_ENTRY_SS; 
                }
                
                default:
                {
                    break;
                }
              
            }
            break;  
        }
        
        case ePE_SRC_SOFT_RESET:
        {
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_SOFT_RESET_ENTRY_SS:
                {
                    _trace1(57, main_tr, 0, 0x01, u8PortNum,"ePE_SRC_SOFT_RESET-ENTRY_SS\r\n");
                    
					/* Reset Protocol Layer */
                    PRL_ProtocolResetAllSOPs(u8PortNum);
                    
                    /* Send Accept message */
                    u16Transmit_Header = PRL_FormSOPTypeMsgHeader (u8PortNum, (UINT8)ePE_CTRL_ACCEPT,
                                            0, 0);

                    u8TransmitSOP = PRL_SOP_TYPE;
                    u32pTransmit_DataObj = NULL;
                    Transmit_cb = PE_StateChange_TransmitCB;

                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_SEND_CAPABILITIES, \
                                                ePE_SRC_SEND_CAP_ENTRY_SS, \
                                                ePE_SRC_HARD_RESET, ePE_SRC_HARD_RESET_ENTRY_SS);

                    u8IsTransmit = TRUE;
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SOFT_RESET_IDLE_SS;
                    
                    break;  
                }
                
                case ePE_SRC_SOFT_RESET_IDLE_SS:
                {
                    break;
                }
              
            }
            break;  
        }
         
        case ePE_SRC_DISABLED:
        {
            /* Port Disabled */
            break;  
        }
        
        case ePE_SRC_VDM_IDENTITY_REQUEST:
        {
            
            switch(gasPolicy_Engine[u8PortNum].ePESubState)
            {
                case ePE_SRC_VDM_IDENTITY_REQUEST_ENTRY_SS:
                {
                    _trace1(58, main_tr, 0, 0x01, u8PortNum,"PE_SRC_VDM_IDENTITY_REQUEST-ENTRY_SS\r\n");
                    
                    /* Choosing VDM version as per Current spec revision */
                    if(PD_SPEC_REVISION_2_0 == DPM_GET_CURRENT_PD_SPEC_REV(u8PortNum))
                    {
                        u32VDMHeader = PE_SRC_VDM_HEADER_LOW_VER;
                    }
                    
                    else
                    {
                        u32VDMHeader = PE_SRC_VDM_HEADER_HIGH_VER;
                    }
                    
					/* Send VDM Discover Identity message to E-Cable */
                    u16Transmit_Header = PRL_FormNonSOPTypeMsgHeader(u8PortNum, (UINT8)ePE_DATA_VENDOR_DEFINED,  \
                                                                        1, 0);
                    u8TransmitSOP = PRL_SOP_P_TYPE;
                    u32pTransmit_DataObj = &u32VDMHeader;
                    Transmit_cb = PE_StateChange_TransmitCB;
                    /* Commented for compilation */

                    u32Transmit_TmrID_TxSt = PRL_BUILD_PKD_TXST_U32( ePE_SRC_VDM_IDENTITY_REQUEST, \
                                                ePE_SRC_VDM_IDENTITY_REQUEST_GOODCRC_SS, ePE_SRC_VDM_IDENTITY_NAKED, NULL);
              
                    gasPolicy_Engine[u8PortNum].u8DiscoverIdentityCounter++;
                    u8IsTransmit = TRUE;
                    
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_VDM_IDENTITY_REQUEST_IDLE_SS;
                    
                    break;    
                }
            
                case ePE_SRC_VDM_IDENTITY_REQUEST_IDLE_SS:
                {
                    break;
                }
                
                case ePE_SRC_VDM_IDENTITY_REQUEST_GOODCRC_SS:
                {
                    _trace1(59, main_tr, 0, 0x01, u8PortNum,"PE_SRC_VDM_IDENTITY_REQUEST-GOODCRC_SS\r\n");
                    gasPolicy_Engine[u8PortNum].u8PETimerID = PDTimer_Start (
                                                            (CONFIG_PE_VDM_RESPONSE_TIMEOUT),
                                                            PE_StateChange_TimerCB,u8PortNum,  
                                                            (UINT8)ePE_SRC_VDM_IDENTITY_NAKED);
                    gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_VDM_IDENTITY_REQUEST_IDLE_SS;
                    break;  
                }
                
                default:
                {
                    break;
                }
            }
            break;  
        }
        
        case ePE_SRC_VDM_IDENTITY_ACKED:
        {
            _trace1(60, main_tr, 0, 0x01, u8PortNum,"PE_SRC_VDM_IDENTITY_ACKED\r\n");
            
			/* VDM ACK received from cable */
            if( PE_VDM_ACK == DPM_PharseCableVDM(u8PortNum, u8SOPType, (UINT16) u32Header, (UINT32*) u8DataBuf))
            {
                gasDPM[u8PortNum].u8DPM_Status &= ~(DPM_CURR_PD_SPEC_REV_MASK);
                gasDPM[u8PortNum].u8DPM_Status |= (CONFIG_PD_DEFAULT_SPEC_REV << DPM_CURR_PD_SPEC_REV_POS);
                gasPolicy_Engine[u8PortNum].u8DiscoverIdentityCounter = 0;
                gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_SEND_CAPABILITIES;
                gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_CAP_ENTRY_SS;
            }
            
            else
            {
                gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_VDM_IDENTITY_NAKED;
            }
            
            break;  
        }
        
        case ePE_SRC_VDM_IDENTITY_NAKED:
        {
            _trace1(61, main_tr, 0, 0x01, u8PortNum,"PE_SRC_VDM_IDENTITY_NAKED\r\n");
            /* Todo: Capble Nak information pharsed */
            
            /* VDM NAK received */
            if(gasPolicy_Engine[u8PortNum].u8DiscoverIdentityCounter > PE_N_DISCOVER_IDENTITY_COUNT)
            {   
                gasDPM[u8PortNum].u8DPM_Status &= ~(DPM_CURR_PD_SPEC_REV_MASK);
                gasDPM[u8PortNum].u8DPM_Status |= (CONFIG_PD_DEFAULT_SPEC_REV << DPM_CURR_PD_SPEC_REV_POS);
                gasPolicy_Engine[u8PortNum].u8PEPortSts |= PE_CABLE_RESPOND_NAK;
                gasPolicy_Engine[u8PortNum].u8DiscoverIdentityCounter = 0;
                gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_SEND_CAPABILITIES;
                gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_SEND_CAP_ENTRY_SS;               
            }
            
            else
            {
                gasDPM[u8PortNum].u8DPM_Status &= ~(DPM_CURR_PD_SPEC_REV_MASK);
                gasDPM[u8PortNum].u8DPM_Status |= (PD_SPEC_REVISION_2_0 << DPM_CURR_PD_SPEC_REV_POS);
                gasPolicy_Engine[u8PortNum].ePEState = ePE_SRC_VDM_IDENTITY_REQUEST;
                gasPolicy_Engine[u8PortNum].ePESubState = ePE_SRC_VDM_IDENTITY_REQUEST_ENTRY_SS;
            }
                        
            break;  
        }
        case ePE_SRC_SEND_NOT_SUPPORTED_RECEIVED:
        {
            break;
        }
      
        
        default:
        {         
            break;
        }
    }
    
    if (u8IsTransmit == TRUE)
	{
		PRL_TransmitMsg (u8PortNum, (UINT8) u8TransmitSOP, (UINT32)u16Transmit_Header, \
                    (UINT8 *)u32pTransmit_DataObj, Transmit_cb, u32Transmit_TmrID_TxSt); 
        u8IsTransmit = FALSE;
    }
}
