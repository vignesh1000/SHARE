/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _SERCOM_I2CSLAVE_H_
#define _SERCOM_I2CSLAVE_H_
#include <GPIO.h>
#include <stdinc.h>
#include <Hermes_Interface.h>

#define PIN_PA16                                16  /**< \brief Pin Number for PA16 */
#define PIN_PA17                                17  /**< \brief Pin Number for PA17 */
#define PIN_PA06                                6  /**< \brief Pin Number for PA17 */

#define APBCMASK_OFFSET                         0x20 
#define PMREG                                   (0x40000400) /* brief (PM) APB Base Address */
#define APBCREG                                 (PMREG + APBCMASK_OFFSET) 

#define SERCOM1_BASE_ADDR                       (0x42000C00) /* SERCOMM1 */
#define CLKCTRL_GEN_GCLK1                       (0x1)   /**< \brief (GCLK_CLKCTRL) Generic clock generator 1 */
#define GCLKCTLREG                              (0x40000C02) /*brief (GCLK) APB Base Address */

#define I2C_SLAVE_CTRLA                       (0x42000C00) /* I2CS Control A */
#define I2C_SLAVE_CTRLB                       (0x42000C04) /* I2CS Control B */
#define I2C_SLAVE_INTENCLR                    (0x42000C0C) /* I2CS Interrupt Enable Clear */
#define I2C_SLAVE_INTENSET                    (0x42000C0D) /* I2CS Interrupt Enable Set */
#define I2C_SLAVE_INTFLAG                     (0x42000C0E) /* I2CS Interrupt Flag Status and Clear */
#define I2C_SLAVE_STATUS                      (0x42000C10) /* I2CS Status */
#define I2C_SLAVE_ADDR                        (0x42000C14) /* I2CS Address */
#define I2C_SLAVE_DATA                        (0x42000C18) /* I2CS Data */

#define I2C_SLAVE_CTRLA_SWRST_POS              0            /* Software Reset */
#define I2C_SLAVE_CTRLA_SWRST                  ((0x1) << I2C_SLAVE_CTRLA_SWRST_POS)
#define I2C_SLAVE_CTRLA_ENABLE_POS             1            /* Enable */
#define I2C_SLAVE_CTRLA_ENABLE                 ((0x1) << I2C_SLAVE_CTRLA_ENABLE_POS)
#define I2C_SLAVE_CTRLA_MODE_POS               2            /* Operating Mode */
#define I2C_SLAVE_CTRLA_MODE_MSK               ((0x7) << I2C_SLAVE_CTRLA_MODE_POS)
#define I2C_SLAVE_CTRLA_MODE(value)            (I2C_SLAVE_CTRLA_MODE_MSK & ((value) << I2C_SLAVE_CTRLA_MODE_POS))
#define I2C_SLAVE_CTRLA_MODE_USART_EXT_CLK_VAL (0x0)   /* USART mode with external clock */
#define I2C_SLAVE_CTRLA_MODE_USART_INT_CLK_VAL (0x1)   /* USART mode with internal clock */
#define I2C_SLAVE_CTRLA_MODE_SPI_SLAVE_VAL     (0x2)   /* SPI mode with external clock */
#define I2C_SLAVE_CTRLA_MODE_SPI_MASTER_VAL    (0x3)   /* SPI mode with internal clock */
#define I2C_SLAVE_CTRLA_MODE_I2C_SLAVE_VAL     (0x4)   /* I2C mode with external clock */
#define I2C_SLAVE_CTRLA_MODE_I2C_MASTER_VAL    (0x5)   /* I2C mode with internal clock */

#define I2C_SLAVE_CTRLA_MODE_I2C_SLAVE         (I2C_SLAVE_CTRLA_MODE_I2C_SLAVE_Val << I2C_SLAVE_CTRLA_MODE_POS)
#define I2C_SLAVE_CTRLA_MODE_I2C_MASTER        (I2C_SLAVE_CTRLA_MODE_I2C_MASTER_Val << I2C_SLAVE_CTRLA_MODE_POS)
#define I2C_SLAVE_CTRLA_RUNSTDBY_POS           7            /* Run in Standby */
#define I2C_SLAVE_CTRLA_RUNSTDBY               ((0x1) << I2C_SLAVE_CTRLA_RUNSTDBY_POS)
#define I2C_SLAVE_CTRLA_PINOUT_POS             16           /* Pin Usage */
#define I2C_SLAVE_CTRLA_PINOUT                 ((0x1) << I2C_SLAVE_CTRLA_PINOUT_POS)
#define I2C_SLAVE_CTRLA_SDAHOLD_POS            20           /* SDA Hold Time */
#define I2C_SLAVE_CTRLA_SDAHOLD_TIME            ((0x2) << I2C_SLAVE_CTRLA_SDAHOLD_POS)
#define I2C_SLAVE_CTRLA_SDAHOLD(value)         (I2C_SLAVE_CTRLA_SDAHOLD_MSK & ((value) << I2C_SLAVE_CTRLA_SDAHOLD_POS))2

#define I2C_SLAVE_CTRLB_SMEN_POS              8            /* Smart Mode Enable */
#define I2C_SLAVE_CTRLB_SMEN                  ((0x1) << I2C_SLAVE_CTRLB_SMEN_POS)
#define I2C_SLAVE_CTRLB_AMODE_POS 14           /* Address Mode */

#define I2C_SLAVE_CTRLB_AMODE(value)          ((value) << I2C_SLAVE_CTRLB_AMODE_POS)
#define I2C_SLAVE_CTRLB_CMD_POS               16           /* Command */
#define I2C_SLAVE_CTRLB_CMD                    ((0x02) << I2C_SLAVE_CTRLB_CMD_POS)
#define I2C_SLAVE_CTRLB_ACKACT_POS            18           /* Acknowledge Action */
#define I2C_SLAVE_CTRLB_ACKACT                ((0x1) << I2C_SLAVE_CTRLB_ACKACT_POS)

#define I2C_SLAVE_CTRLA_LOWTOUT_POS            30           /* SCL Low Time-out */
#define I2C_SLAVE_CTRLA_LOWTOUT                ((0x1) << I2C_SLAVE_CTRLA_LOWTOUT_POS)

#define I2C_SLAVE_INTFLAG_PREC_POS             0            /*Stop Received */
#define I2C_SLAVE_INTFLAG_PREC                 ((0x1) << I2C_SLAVE_INTFLAG_PREC_POS)
#define I2C_SLAVE_INTFLAG_AMATCH_POS           1            /*Address Match */
#define I2C_SLAVE_INTFLAG_AMATCH               ((0x1) << I2C_SLAVE_INTFLAG_AMATCH_POS)
#define I2C_SLAVE_INTFLAG_DRDY_POS             2            /*Data Ready */
#define I2C_SLAVE_INTFLAG_DRDY                 ((0x1) << I2C_SLAVE_INTFLAG_DRDY_POS)

#define I2C_SLAVE_ADDR_GENCEN_POS                    0            /**< \brief (I2C_SLAVE_ADDR) General Call Address Enable */
#define I2C_SLAVE_ADDR_GENCEN                        ((0x1) << I2C_SLAVE_ADDR_GENCEN_POS)
#define I2C_SLAVE_ADDR_ADDR_POS                      1            /**< \brief (I2C_SLAVE_ADDR) Address */
#define I2C_SLAVE_ADDR_ADDR                          ((0x08) << I2C_SLAVE_ADDR_ADDR_POS)
#define I2C_SLAVE_ADDR_ADDRMASK_POS                  17           /**< \brief (I2C_SLAVE_ADDR) Address Mask */
#define I2C_SLAVE_ADDR_ADDRMASK                     (I2C_SLAVE7BIT_ADDRESSING_MASK << I2C_SLAVE_ADDR_ADDRMASK_POS)
#define I2C_SLAVE7BIT_ADDRESSING_MASK                0x01
#define I2C_SLAVE_STATUSBUSERR_POS                   0            /**< \brief (I2CSSTATUS) Bus Error */
#define I2C_SLAVE_STATUSBUSERR                       ((0x1) << I2C_SLAVE_STATUSBUSERR_POS)
#define I2C_SLAVE_STATUSCOLL_POS                     1            /**< \brief (I2CSSTATUS) Transmit Collision */
#define I2C_SLAVE_STATUSCOLL                         ((0x1) << I2C_SLAVE_STATUSCOLL_POS)
#define I2C_SLAVE_STATUSRXNACK_POS                   2            /**< \brief (I2CSSTATUS) Received Not Acknowledge */
#define I2C_SLAVE_STATUSRXNACK                       ((0x1) << I2C_SLAVE_STATUSRXNACK_POS)
#define I2C_SLAVE_STATUSDIR_POS                      3            /**< \brief (I2CSSTATUS) Read / Write Direction */
#define I2C_SLAVE_STATUSDIR                          ((0x1) << I2C_SLAVE_STATUSDIR_POS)
#define I2C_SLAVE_STATUSSR_POS                       4            /**< \brief (I2CSSTATUS) Repeated Start */
#define I2C_SLAVE_STATUSSR                           ((0x1) << I2C_SLAVE_STATUSSR_POS)
#define I2C_SLAVE_STATUSLOWTOUT_POS                  6            /**< \brief (I2CSSTATUS) SCL Low Time-out */
#define I2C_SLAVE_STATUSLOWTOUT                      ((0x1) << I2C_SLAVE_STATUSLOWTOUT_POS)
#define I2C_SLAVE_STATUSCLKHOLD_POS                  7            /**< \brief (I2CSSTATUS) Clock Hold */
#define I2C_SLAVE_STATUSCLKHOLD                      ((0x1) << I2C_SLAVE_STATUSCLKHOLD_POS)
#define I2C_SLAVE_STATUSSYNCBUSY_POS                 15           /**< \brief (I2CSSTATUS) Synchronization Busy */
#define I2C_SLAVE_STATUSSYNCBUSY                     ((0x1) << I2C_SLAVE_STATUSSYNCBUSY_POS)
#define I2C_SLAVE_BUS_INACTIVITY_TIMEOUT              65535
#define I2C_SLAVE_MODE                          (0x4) << I2C_SLAVE_POS
#define I2C_SLAVE_POS                           2

#define TRUE                                    1
#define FALSE                                   0
#define SERCOM1_GCLK_ID_CORE                    14 
#define SERCOM1_GCLK_ID_SLOW                    12 
#define PHERIPHERAL_SEL_MASK                    0x0000ff00
#define PHERIPHERAL_SEL_SERCOM                  10

#define HERMES_BUFFER_SIZE                     512
#define HERMES_REQUEST_PACKET                  0
#define HERMES_RESPONSE_PACKET                 1



/**************************************************************************************************/
void I2C_SlaveIRQdrive (UINT8 u8driveVal);

#endif