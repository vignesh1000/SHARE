/*
 * Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
 *
 * Microchip licenses to you the right to use, modify, copy and distribute
 * Software only when embedded on a Microchip microcontroller or digital signal
 * controller that is integrated into your product or third party product
 * (pursuant to the sublicense terms in the accompanying license agreement).
 *
 * You should refer to the license agreement accompanying this Software for
 * additional information regarding your rights and obligations.
 *
 * SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
 * CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
 * OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
 * INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
 * SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
 * (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 */

#include <stdinc.h>

void DPM_Init(UINT8 u8PortNum)
{
    UINT8 u8DPM_Status = gasDPM[u8PortNum].u8DPM_Status;
    UINT8 u8DPM_ConfigData = gasDPM[u8PortNum].u8DPM_ConfigData;
    
    u8DPM_Status |= (CONFIG_PD_DEFAULT_SPEC_REV << DPM_CURR_PD_SPEC_REV_POS);
    u8DPM_ConfigData |= (CONFIG_PD_DEFAULT_SPEC_REV  << DPM_DEFAULT_PD_SPEC_REV_POS);
        
    if((gasPortConfigurationData[u8PortNum].u32CfgData & TYPEC_PORT_TYPE_MASK)== (PD_ROLE_SOURCE))
    {   
        /* Set Port Power Role as Source in DPM Configure variable*/
        u8DPM_ConfigData |= (PD_ROLE_SOURCE << DPM_DEFAULT_POWER_ROLE_POS); 
        
        /* Set Port Data Role as DFP in DPM Cofigure variable*/
        u8DPM_ConfigData |= (PD_ROLE_DFP << DPM_DEFAULT_DATA_ROLE_POS);
        
        /* Set Port Power Role as Source in DPM Status variable */
        u8DPM_Status |= (PD_ROLE_SOURCE << DPM_DEFAULT_POWER_ROLE_POS);
        
        /* Set Port Data Role as DFP in DPM Status variable */
        u8DPM_Status |= (PD_ROLE_DFP << DPM_DEFAULT_DATA_ROLE_POS);
    }       
    else
    {
        /* Set the Default Port Power Role as Sink in DPM Status variable */
        u8DPM_ConfigData |= (PD_ROLE_SINK << DPM_DEFAULT_POWER_ROLE_POS);
        
        /* Set the Default Port Data Role as UFP in DPM Status variable */
        u8DPM_ConfigData |= (PD_ROLE_UFP << DPM_DEFAULT_DATA_ROLE_POS);
        
        /* Set the Current Port Power Role as Sink in DPM Status variable */
        u8DPM_Status |= (PD_ROLE_SINK << DPM_DEFAULT_POWER_ROLE_POS);
        
        /* Set the Current  Port Data Role as UFP in DPM Status variable */
        u8DPM_Status |= (PD_ROLE_UFP << DPM_DEFAULT_DATA_ROLE_POS);
    }
    
    gasDPM[u8PortNum].u8DPM_Status =  u8DPM_Status;
    gasDPM[u8PortNum].u8DPM_ConfigData  = u8DPM_ConfigData;
    
}

void DPM_StateMachine (UINT8 u8PortNum)
{
    CONFIG_HOOK_DEVICE_POLICY_MANAGER_PRE_PROCESS(u8PortNum);
    
    TypeC_RunStateMachine (u8PortNum);
    PE_RunStateMachine(u8PortNum);
    
    CONFIG_HOOK_DEVICE_POLICY_MANAGER_POST_PROCESS(u8PortNum);
}


/****************************** DPM APIs Accessing Type C Port Control Module*********************/

void DPM_GetTypeCStates(UINT8 u8PortNum, UINT8 *u8TypeCState, UINT8 *u8TypeCSubState)
{
    *u8TypeCState = gasTypeCcontrol[u8PortNum].u8TypeCState;
    *u8TypeCSubState = gasTypeCcontrol[u8PortNum].u8TypeCSubState;
}

void DPM_GetPoweredCablePresence(UINT8 u8PortNum, UINT8 *u8RaPresence)
{
    *u8RaPresence = (gasTypeCcontrol[u8PortNum].u16PortSts & (BIT(0)));
}

void DPM_SetTypeCState(UINT8 u8PortNum, UINT8 u8TypeCState, UINT8 u8TypeCSubState)
{
    gasTypeCcontrol[u8PortNum].u8TypeCState = u8TypeCState;
    gasTypeCcontrol[u8PortNum].u8TypeCSubState = u8TypeCSubState;
}

void DPM_SetPortPower(UINT8 u8PortNum)
{
    TypeC_VBUSDrive (u8PortNum, gasDPM[u8PortNum].u8ContractedVoltage);
}

void DPM_VConnOnOff(UINT8 u8PortNum, UINT8 u8VConnEnable)
{
    if(u8VConnEnable)
    {
        /*Enable VCONN by switching on the VCONN FETS*/
        TypeC_EnabDisVCONN (u8PortNum, TYPEC_VCONN_ENABLE);
               
    }
    
    else
    {
        /*Disable VCONN by switching off the VCONN FETS*/
        TypeC_EnabDisVCONN (u8PortNum, TYPEC_VCONN_DISABLE);
      
    }
}

UINT8 DPM_GetVBUSVoltage(UINT8 u8PortNum)
{  
    UINT8 u8VBUSvoltage;
    
    u8VBUSvoltage =  ((gasTypeCcontrol[u8PortNum].u16PortSts & TYPEC_VBUS_PRESENCE_MASK) >> TYPEC_VBUS_PRESENCE_POS);    
    return u8VBUSvoltage;
}

void DPM_VBusOnOff(UINT8 u8PortNum, UINT8 u8VbusOnorOff)
{
    CONFIG_HOOK_VBUS_DRIVE_VOLTAGE (u8PortNum, u8VbusOnorOff);
}

/****************************** DPM Source related APIs*****************************************/
UINT8 DPM_ValidateRequest(UINT8 u8PortNum, UINT16 u16Header, UINT8 *u8DataBuf)
{
    UINT8 u8RetVal = FALSE;
    UINT8 u8ObjPos = FALSE;
    UINT16 u16CurrVal = FALSE;
    UINT16 u16ReqPDOCurr = FALSE;
    UINT8 u8RaPresence = FALSE;
    
    u8RaPresence = (gasTypeCcontrol[u8PortNum].u16PortSts & (BIT(0))) & (~((gasPolicy_Engine[u8PortNum].u8PEPortSts & \
                                            PE_CABLE_RESPOND_NAK) >> 5));
     
    u8ObjPos = ((u8DataBuf[3]) & PE_REQUEST_OBJ_MASK) >> PE_REQUEST_OBJ_POS;
    u16CurrVal = ((UINT16)((u8DataBuf[1]) << 8) | u8DataBuf[0]);
    u16CurrVal = (u16CurrVal & PE_REQUEST_MAX_CUR_MASK);

    u16ReqPDOCurr = ((gasPortConfigurationData[u8PortNum].u32SrcCap[u8ObjPos-1]) & PE_REQUEST_MAX_CUR_MASK); 
    
    /* Check for request PDO and Max Current */
    u8RetVal = (u16CurrVal > u16ReqPDOCurr) ? PE_INVALID_REQUEST : (((u8ObjPos <= FALSE) || (u8ObjPos > gasPortConfigurationData[u8PortNum].u8SrcCnt))) ? \
                PE_INVALID_REQUEST : (u8RaPresence == 0) ? PE_VALID_REQUEST : (u16CurrVal > gasDPM[u8PortNum].u16MaxCurrSupported) ? \
                PE_INVALID_REQUEST : PE_VALID_REQUEST;     
    
    if(u8RetVal == PE_VALID_REQUEST)
    {
        gasDPM[u8PortNum].u8ContractedVoltage = u8ObjPos;        
        _trace1(62, main_tr, 0, 0x01, u8PortNum,"DPM-PE: Requested is Valid \r\n");
    }
      
    return u8RetVal;
}
UINT32 DPM_SetCurrent (UINT32 u32SrcCap)
{
    if((u32SrcCap & PE_MAX_CURR_MASK) > DPM_CABLE_CURR_3A_UNIT)
    {
        u32SrcCap &= ~PE_MAX_CURR_MASK;
        u32SrcCap |= DPM_CABLE_CURR_3A_UNIT;
    }
    
    return u32SrcCap; 
}

void DPM_CopyDataObj (UINT32* pu32DataObj, UINT32 *pu32SrcCaps, UINT8 u8pSrcPDOCnt)
{
    for (UINT8 u8PDOindex = 0; u8PDOindex < u8pSrcPDOCnt; u8PDOindex++)
    {   
        pu32DataObj[u8PDOindex] = DPM_SetCurrent (pu32SrcCaps[u8PDOindex]);
    } 
}

void DPM_Get_Source_Capabilities(UINT8 u8PortNum, UINT8* u8pSrcPDOCnt, UINT32* pu32DataObj)
{   
    *u8pSrcPDOCnt = gasPortConfigurationData[u8PortNum].u8SrcCnt;
   
    UINT32 *pu32SrcCap = (UINT32 *)&gasPortConfigurationData[u8PortNum].u32SrcCap[0];
       
    if((gasTypeCcontrol[u8PortNum].u16PortSts & (BIT(0))))
    {
        if(gasDPM[u8PortNum].u16MaxCurrSupported == DPM_CABLE_CURR_5A_UNIT)
        {
            CONFIG_HOOK_MEMCPY( &pu32DataObj[0], &pu32SrcCap[0], \
              ((*u8pSrcPDOCnt) * 4));
        }
        
        else
        {
            DPM_CopyDataObj (&pu32DataObj[0], &pu32SrcCap[0], *u8pSrcPDOCnt);
        }
          
    }
    
    else
    {
        DPM_CopyDataObj (pu32DataObj, &pu32SrcCap[0],*u8pSrcPDOCnt);  
    }
}


void DPM_Get_Sink_Capabilities(UINT8 u8PortNum,UINT8 *u8pSinkPDOCnt, UINT32 * pu32DataObj)
{   
    *u8pSinkPDOCnt = gasPortConfigurationData[u8PortNum].u8SinkCnt;
    
    CONFIG_HOOK_MEMCPY ( pu32DataObj, gasPortConfigurationData[u8PortNum].u32SinkCap, \
                            (gasPortConfigurationData[u8PortNum].u8SrcCnt * 4));
}

UINT8 DPM_PharseCableVDM(UINT8 u8PortNum, UINT8 u8SOPType, UINT16 u16Header, UINT32* u8DataBuf)
{
    UINT8 u8DataObj = FALSE;
    UINT32 u32IDHeaderVDO;
    UINT32 u32ProductTypeVDO;
    UINT8 u8RetVal = FALSE;
    UINT8 u8ECableSts;
    UINT8 u8CurVal;
    u8DataObj = PRL_GET_OBJECT_COUNT(u16Header);
    
    
    if(u8DataObj == 1)
    {
        u8RetVal = PE_VDM_NAK;
    }
    
    else
    {
        u32IDHeaderVDO = u8DataBuf[1];
        
        u8ECableSts = gasDPM[u8PortNum].u8ECableSts;
                
        /* Active or Passive Cable */
        u8ECableSts |= DPM_GET_CABLE_TYPE(u32IDHeaderVDO);
        
        u32ProductTypeVDO = u8DataBuf[4];               
        
        if((u8ECableSts & DPM_ECABLE_TYPE_STS_MASK) == DPM_ACTIVE_ECABLE)
        {
            /* SOP" Presents or not*/
            u8ECableSts |= DPM_GET_CABLE_SOP_PP(u32ProductTypeVDO) << DPM_ECABLE_SOP_PP_STS_POS;
        }
        
        /* Supported Current */
        u8ECableSts |= DPM_GET_CABLE_CUR_VAL(u32ProductTypeVDO) << DPM_ECABLE_CUR_VAL_STS_POS;
        
        u8CurVal = DPM_GET_CABLE_CUR_VAL(u32ProductTypeVDO);
        
        /* Setting E-Cable Max Current Value */
        if(u8CurVal == DPM_CABLE_CURR_3A)
        {
            gasDPM[u8PortNum].u16MaxCurrSupported = DPM_CABLE_CURR_3A_UNIT;
        }
        
        else if(u8CurVal == DPM_CABLE_CURR_5A)
        {
            gasDPM[u8PortNum].u16MaxCurrSupported = DPM_CABLE_CURR_5A_UNIT;
        }
        
        else
        {
            /* Todo: What to do if E-Cable Current Value received as reserved values */  
        }
        
        
        /* Maximum Voltage Support */
        u8ECableSts |= DPM_GET_CABLE_MAX_VOLTAGE(u32ProductTypeVDO) << DPM_ECABLE_MAX_VOLTAGE_STS_POS;
        
        gasDPM[u8PortNum].u8ECableSts = u8ECableSts;
        
        u8RetVal = PE_VDM_ACK;
    }
    
    return u8RetVal;
}

/****************************** DPM Sink related APIs*****************************************/
void  DPM_Evaluate_Received_Src_caps(UINT8 u8PortNum ,UINT16 u16RecvdSrcCapsHeader, UINT32 *pu32RecvdSrcCapsPayload)
{
 
    INT8 i8SinkPDOIndex;
	UINT8 u8SrcPDOIndex;
	UINT8 u8IsMatch = FALSE;
    UINT8 u8CapMismatch = FALSE;
    UINT32 SinkSelectedPDO;
    ePDOType SrcPDOType, SnkPDOType;
	UINT8 u8SinkPDOCnt = gasPortConfigurationData[u8PortNum].u8SinkCnt;
	UINT8 u8Recevd_SrcPDOCnt =  PRL_GET_OBJECT_COUNT(u16RecvdSrcCapsHeader);
    UINT32 u32RcvdSrcCapsPayload;
    UINT32 u32SinkCap;
    PORT_CONFIG_DATA *pConfigData;
    
    pConfigData = &gasPortConfigurationData[u8PortNum];

	/*Loop through each of the Sink capability and find the match with the 
    received source capability message*/  

	for (i8SinkPDOIndex = u8SinkPDOCnt-1; i8SinkPDOIndex >= 0; i8SinkPDOIndex--)
	{
        u32SinkCap = pConfigData->u32SinkCap[i8SinkPDOIndex];
        
		for (u8SrcPDOIndex = 0; u8SrcPDOIndex < u8Recevd_SrcPDOCnt; u8SrcPDOIndex++)
		{
          
            u32RcvdSrcCapsPayload = pu32RecvdSrcCapsPayload[u8SrcPDOIndex];
            
            SrcPDOType  = (ePDOType)DPM_GET_PDO_TYPE(u32RcvdSrcCapsPayload);
            
            SnkPDOType = (ePDOType)DPM_GET_PDO_TYPE(u32SinkCap);
            
            
			u8IsMatch = DPM_Find_Src_Sink_Caps_match(u32RcvdSrcCapsPayload, SrcPDOType,\
		   u32SinkCap,SnkPDOType);

			if (u8IsMatch)
			{   
                /*If the Match has ocurred and there is mismatch in voltage between the selected source PDO and Max Sink Voltage requirement */
                if(DPM_GET_PDO_VOLTAGE(u32RcvdSrcCapsPayload) != DPM_GET_PDO_VOLTAGE(pConfigData->u32SinkCap[u8SinkPDOCnt-1]) )
                {
                
                    u8CapMismatch = TRUE;
                }               
				break;
			}
		}
		if (u8IsMatch)
		{
                        
            /*Update the "u32SinkReqRDO" variable based on the received source capability*/
			gasDPM[u8PortNum].u32SinkReqRDO = DPM_FORM_DATA_REQUEST(u8SrcPDOIndex + 1,u8CapMismatch,\
              DPM_GET_PDO_USB_COMM_CAP(u32SinkCap),DPM_GET_PDO_CURRENT(u32SinkCap),DPM_GET_PDO_CURRENT(u32SinkCap));

			return;
		}
	}
    
    /*This Condition occurs when the capability mismatch occurs due to current mismatch in Vsafe5V PDO*/
    if(u8IsMatch!= TRUE)
    {
         SinkSelectedPDO = pConfigData->u32SinkCap[0];  
         u8CapMismatch = TRUE;

        /*Update the "u32SinkReqRDO" variable based on the received source capability*/
	    gasDPM[u8PortNum].u32SinkReqRDO = DPM_FORM_DATA_REQUEST(1,u8CapMismatch,\
          DPM_GET_PDO_USB_COMM_CAP(SinkSelectedPDO),DPM_GET_PDO_CURRENT(pu32RecvdSrcCapsPayload[0]),\
            DPM_GET_PDO_CURRENT(pu32RecvdSrcCapsPayload[0]));
    }
    
	return;
}

UINT8 DPM_Find_Src_Sink_Caps_match(UINT32 u32SrcPDO, ePDOType SrcPDOType, UINT32 u32SinkPDO, ePDOType SinkPDOType)
{


	if ((SrcPDOType == eFIXED_SUPPLY_PDO) && (SinkPDOType == eFIXED_SUPPLY_PDO))
	{

         /* Match condition for fixed supply source PDO and fixed supply sink PDO  are 
          1. Source Fixed Voltage == Sink Fixed Voltage 
          2.Source Current >= Sink Current*/
      
		if ((DPM_GET_PDO_VOLTAGE(u32SrcPDO) == DPM_GET_PDO_VOLTAGE(u32SinkPDO)) &&
			(DPM_GET_PDO_CURRENT(u32SrcPDO) >= DPM_GET_PDO_CURRENT(u32SinkPDO)))
		{

			return TRUE;

		}

	}
    /*Sink with Fixed Supply PDO cannot neogotiate with Source thta has Battery Supply PDO*/
	else if ((SrcPDOType == eBATTERY_SUPPLY_PDO) && (SinkPDOType == eFIXED_SUPPLY_PDO))
	{

		return FALSE;

	}	
     /*Sink with Fixed Supply PDO cannot neogotiate with Source that has Variable Supply PDO*/
	else if ((SrcPDOType == eVARIABLE_SUPPLY_PDO) && (SinkPDOType == eFIXED_SUPPLY_PDO))
	{
		return FALSE;

	}
	
    return FALSE;

}

/********************************VCONN Related APIs**********************************************/

UINT8 DPM_Evaluate_VCONN_Swap(UINT8 u8PortNum)
{
    /*As of now, Accept the VCONN Swap without any restriction*/
    return 1;
    
}

UINT8 DPM_IsPort_VCONN_Source(UINT8 u8PortNum)
{ 
  
    UINT8 u8IsVCONNSrc;

    if( gasTypeCcontrol[u8PortNum].u16PortSts & TYPEC_VCONN_SOURCE)
    {
        u8IsVCONNSrc =TRUE;
    }
    else
    {
        u8IsVCONNSrc =FALSE;
    }

    return u8IsVCONNSrc;
}