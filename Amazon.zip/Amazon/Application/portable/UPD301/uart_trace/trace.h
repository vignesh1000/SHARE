/*
	trace.h

	Source Description
	Header file for Tracing functionality, Used with SMSC Trace FIFO

	(C) [2009-2011] Standard Microsystems Corporation ("SMSC").  All rights reserved.
	A software license from SMSC is required before using this code.

	This program code listing is proprietary to SMSC and may not be copied,
	distributed, or used without a license to do so. Such license may have
	Limited or Restricted Rights. Please refer to the license for further clarification.

	Notice: The program contained in this listing is a proprietary trade secret of SMSC, Hauppauge,
	New York, and is copyrighted under the United States Copyright Act of 1976 as an unpublished
	work, pursuant to Section 104 and Section 408 of Title XVII of the United States code.
	Unauthorized copying, adaption, distribution, use, or display is prohibited by this law.
	Use, duplication, or disclosure by the Government is subject to restrictions as set forth
	in subparagraph(c)(1)(ii) of the Rights in Technical Data and Computer Software clause at
	DFARS 52.227-7013.
	Contractor/Manufacturer is Standard Microsystems Corporation, 80 Arkay Drive, Hauppauge,
	New York, 1178-8847.
*/
#ifdef MCHP_TRACE
#ifndef __Trace_Dot_H__
#define __Trace_Dot_H__

#include "stdinc.h"


//#define TRBYTE(val); {INTR_EN(); REGB(0xBF80BFFE)=((BYTE)(val)); INTR_DIS();}
#define TRBYTE(val); {CONFIG_HOOK_DEBUG_UINT8(val);}
#define TRSEPERETOR(); {CONFIG_HOOK_DEBUG_CHAR(0xFD);}

#define TRDWORD32(val); {CONFIG_HOOK_DEBUG_UINT32(val);}
#define TRWORD(val);  {CONFIG_HOOK_DEBUG_UINT16(val);}
#define TRINT(val);  {CONFIG_HOOK_DEBUG_INT32(val);}
#define TREVENT(nbr); { CONFIG_HOOK_DEBUG_INT32(nbr); TRSEPERETOR();}
#define TRBYTEBUF(buf,len) {HookDebugBufferUint8(buf,len);}
#define TRWORDBUF(buf,len) {HookDebugBufferUint16(buf,len);}
#define TRDWORDBUF(buf,len) {HookDebugBufferUint32(buf,len);}
#define TRINT32BUF(buf,len) {HookDebugBufferInt32(buf,len);}

#define TRACE0(nbr, cat, lvl, str);                     {TREVENT(nbr);}
#define TRACE1(nbr, cat, lvl, str, p1);                 {TREVENT(nbr); TRDWORD32(p1);}
#define TRACE2(nbr, cat, lvl, str, p1, p2);             {TREVENT(nbr); TRDWORD32(p1); TRDWORD32(p2);}
#define TRACE3(nbr, cat, lvl, str, p1, p2, p3);         {TREVENT(nbr); TRDWORD32(p1); TRDWORD32(p2); TRDWORD32(p3);}
#define TRACE4(nbr, cat, lvl, str, p1, p2, p3, p4);     {TREVENT(nbr); TRDWORD32(p1); TRDWORD32(p2); TRDWORD32(p3); TRDWORD32(p4);}
#define TRACE5(nbr, cat, lvl, str, p1, p2, p3, p4, p5); {TREVENT(nbr); TRDWORD32(p1); TRDWORD32(p2); TRDWORD32(p3); TRDWORD32(p4); TRDWORD32(p5);TRSEPERETOR();}
#define trace();

// lower case trace(n) statements used by older version of trgen. S/B redundant.
#define trace0(nbr, cat, lvl, str);
#define trace1(nbr, cat, lvl, str, p1);
#define trace2(nbr, cat, lvl, str, p1, p2);
#define trace3(nbr, cat, lvl, str, p1, p2, p3);
#define trace4(nbr, cat, lvl, str, p1, p2, p3, p4);
#define trace5(nbr, cat, lvl, str, p1, p2, p3, p4, p5);
// _trace(n) statements for use with enhanced versions of trgen
#define _trace0(nbr, cat, lvl, str);                     {TREVENT(nbr);}
#define _trace1(nbr, cat, lvl, var, prt, str);                {TREVENT(nbr); TRINT(prt); TRSEPERETOR(); }
#define _trace2(nbr, cat, lvl, var, prt, str, buf, len, str2);      {TREVENT(nbr); TRINT(prt); TRBYTEBUF(buf,len); TRSEPERETOR();}
#define _trace3(nbr, cat, lvl, var, prt, str, buf, len, str2);      {TREVENT(nbr); TRINT(prt); TRWORDBUF(buf,len); TRSEPERETOR();}
#define _trace4(nbr, cat, lvl, var, prt, str, buf, len, str2);      {TREVENT(nbr); TRINT(prt); TRDWORDBUF(buf,len); TRSEPERETOR();}
#define _trace5(nbr, cat, lvl, var, prt, str, buf, len, str2);      {TREVENT(nbr); TRINT(prt); TRINT32BUF(buf,len); TRSEPERETOR();}
#define _trace6(nbr, cat, lvl, var, val);                           {TREVENT(nbr); TRDWORD32(val); TRSEPERETOR();}



// troff(n) statements for use with enhanced versions of trgen
#define _troff0(__nbr, __cat, __lvl, __str);
#define _troff1(__nbr, __cat, __lvl, __str, __p1);
#define _troff2(__nbr, __cat, __lvl, __str, __p1, __p2);
#define _troff3(__nbr, __cat, __lvl, __str, __p1, __p2, __p3);
#define _troff4(__nbr, __cat, __lvl, __str, __p1, __p2, __p3, __p4);
#define _troff5(__nbr, __cat, __lvl, __str, __p1, __p2, __p3, __p4, __p5);


#define _trace(__cat, __lvl, ...)


enum {
  mcu,
  spi,
  uart,
  udc,
  hub,
  gpio,
  test,
  main_tr,
  test_spi_master,
  test_spi_slave,

};

#endif //__Trace_Dot_H__
//---eof------------------------------------------------------------------------

#endif