
#include <hal_atomic.h>
#include <stdinc.h>
#include <Interrupts.h>
#include <Hermes_Interface.h>
#include "bootloaderapis.h"
#include "Shared_Globals.h"
#include <adc.h>

#ifdef _IDEAL_
#include <Power_Negotiation.h>
#include <LVDSdriver.h>
#endif

/* Pointer to function MCU init in bootloader*/
typedef void (*MCU_Init_cb)(void);
MCU_Init_cb MCU_Init_CB = (MCU_Init_cb )__MCU_Init;

extern UINT8 PD_Init(void);
extern void PD_Run();

/* Signature bytes to be placed at end of the region"
   The keyword __root symbol is added because this source is not referring the symbol anywhere
   Refer SIGNATURE_BLOCK section in corresponding linker script */
__root const unsigned char SIGNATURE[4] @ "SIGNATURE_BLOCK" = {'2','D','F','U'};


void Userdef_MCU_Enter_Critical()
{
    volatile hal_atomic_t __atomic;
    atomic_enter_critical(&__atomic);
}


void Userdef_MCU_Exit_Critical()
{
    volatile hal_atomic_t __atomic;
    atomic_leave_critical(&__atomic);
}


void main()
{
    
    /*Mcu intialisation function changed as pointer to function for Boot loader MCU_init function to optimize the memory*/
    MCU_Init_CB();

    (void)PD_Init();
    Hermes_InterfaceInit();
        
#ifdef _IDEAL_
    LvdsInitGlobalVariables();
    
    Ideal_UARTInit();
    
    Ideal_PNInit();
    
    Ideal_ADCInit ();
#endif
    while(TRUE)
    {
        /* Hermes request from I2C slave*/
        if(Hermes_IfConnectionRequest())
        {
            (void)Hermes_ProcessMasterPacket();
             /*Processing Hermes is done , lets put MCU into sleep if all
                UPDs are idle*/ 
    
            #if INCLUDE_POWER_MANAGEMENT_CTRL
            
            /*Setting this flag will make MCU idle in PD_Run()*/ 
            if (((gau8ISRPortState[0] == UPD_STATE_IDLE) || (PORT_STATUS_DISABLED == gau8PortDisable[0])) \
                && ((PORT_STATUS_DISABLED == gau8PortDisable[1]) || (gau8ISRPortState[1] == UPD_STATE_IDLE)))
            {
                gu8SetMCUidle = UPD_MCU_IDLE;
            }
            
            #endif
        }
        
#ifdef _IDEAL_
        CheckLVDSMsg();
        
        Ideal_PNRun();
        
        /*
          Workaround for UPD301-281/UPD301-194, due to fluctuating values in the RESET_N pin of 
          UPD350, the UPD350 enters into reset whereas the SAMD20 is still alive. To overcome the 
          scenario, FW polls the Global Interrupt enable register of UPD350 to verify if all the 
          Valid interrupts are enabled by default. If not, the polling mechanism will re-enable the 
          interrupts
        */
        UINT16 u16ReadData = 0;
        
        /*Check if any of the interrupt is Disabled*/
        UPD_RegisterRead(0, UPDINTR_INT_EN, (UINT8 *)&u16ReadData, 2);
        
        if(
           (FALSE == (u16ReadData & UPDINTR_CC_INT))    ||\
           (FALSE == (u16ReadData & UPDINTR_VBUS_INT))  ||\
           (FALSE == (u16ReadData & UPDINTR_PWR_INT))   ||\
           (FALSE == (u16ReadData & UPDINTR_PIO_INT))   ||\
           (FALSE == (u16ReadData & UPDINTR_MAC_INT))
          )
        {
            /*Re-enable all the UPD350 interrupts*/
            u16ReadData = (UPDINTR_CC_INT | UPDINTR_VBUS_INT | UPDINTR_PWR_INT | UPDINTR_PIO_INT | UPDINTR_MAC_INT);
            
            UPD_RegisterWrite (0, UPDINTR_INT_EN, (UINT8 *)&u16ReadData, BYTE_LEN_2);
        }
#endif
        PD_Run();
        
    }

}
