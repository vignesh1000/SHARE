/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _BOOTLOADERAPI_H_
#define _BOOTLOADERAPI_H_
#ifdef _IDEAL_

#define __Bootloader_main	0x00000e29
#define __CfgGlobals_Initialize	0x00000ee1
#define __GPIOStrap_GetInputLevel	0x00000a85
#define __GPIOStrap_SetTristate	0x00000a69
#define __GPIO_SetDirection	0x00000a09
#define __GPIO_SetPinFunction	0x00000965
#define __GPIO_SetPinLevel	0x00000a53
#define __GPIO_SetPullMode	0x000009bb
#define __Hermes_HandleDiscoveryResp	0x0000008d
#define __Hermes_HandleProtocolTxReq	0x000002a5
#define __Hermes_IfConnectionRequest	0x00000067
#define __Hermes_InterfaceInit	0x0000005b
#define __Hermes_MemCpy	0x00000041
#define __Hermes_ProcessDebugRequestPacket	0x000001e7
#define __Hermes_ProcessMasterPacket	0x0000006f
#define __Hermes_ProcessRequestPacket	0x000000cd
#define __Hermes_ProcessResponsePacket	0x00000125
#define __I2C_CheckI2CRequest	0x000004db
#define __I2C_PortInit	0x0000044b
#define __I2C_SlaveAddressResolve	0x00000535
#define __I2C_SlaveConfigure	0x00000471
#define __I2C_SlaveInit	0x000004b5
#define __I2C_SlaveRead	0x00000335
#define __I2C_SlaveWrite	0x000003a5
#define __MCU_DFLLInit	0x00000efd
#define __MCU_Init	0x00000fcb
#define __NVM_EraseRow	0x0000071d
#define __NVM_Init	0x000005d1
#define __NVM_ProgramMemory	0x00000785
#define __NVM_ReadBuffer	0x000006b5
#define __NVM_ReadMemory	0x000007e5
#define __NVM_WriteBuffer	0x000005f5
#define __PDFW_ProcessGetFWIDRequest	0x00000839
#define __PDFW_ProcessPDFUInitateRequest	0x00000887
#define __PDFW_ProcessRequestPacket	0x000008a1
#define __SPI_ChipSelectHigh	0x00000c11
#define __SPI_ChipSelectLow	0x00000bf5
#define __SPI_Init	0x00000d2b
#define __SPI_PortInit	0x00000c97
#define __SPI_Read	0x00000c65
#define __SPI_SyncInit	0x00000cfd
#define __SPI_Write	0x00000c2d
#define __UPD_DriveNRead	0x00000b85
#define __UPD_InputRead	0x00000b21
#define __UPD_RegisterRead	0x00000ae9
#define __UPD_RegisterWrite	0x00000ab5
#define ____iar_copy_init3	0x0000108d
#define ____iar_data_init3	0x000010bd
#define ____iar_zero_init3	0x0000104d
#define ____low_level_init	0x00001123
#define ___pm_init	0x00001035
#define __exit	0x00001127
#define __main	0x00000d75

#else

#define __Bootloader_main	0x00000e41
#define __CfgGlobals_Initialize	0x00000ef9
#define __GPIOStrap_GetInputLevel	0x00000a85
#define __GPIOStrap_SetTristate	0x00000a69
#define __GPIO_SetDirection	0x00000a09
#define __GPIO_SetPinFunction	0x00000965
#define __GPIO_SetPinLevel	0x00000a53
#define __GPIO_SetPullMode	0x000009bb
#define __Hermes_HandleDiscoveryResp	0x0000008d
#define __Hermes_HandleProtocolTxReq	0x000002a5
#define __Hermes_IfConnectionRequest	0x00000067
#define __Hermes_InterfaceInit	0x0000005b
#define __Hermes_MemCpy	0x00000041
#define __Hermes_ProcessDebugRequestPacket	0x000001e7
#define __Hermes_ProcessMasterPacket	0x0000006f
#define __Hermes_ProcessRequestPacket	0x000000cd
#define __Hermes_ProcessResponsePacket	0x00000125
#define __I2C_CheckI2CRequest	0x000004db
#define __I2C_PortInit	0x0000044b
#define __I2C_SlaveAddressResolve	0x00000535
#define __I2C_SlaveConfigure	0x00000471
#define __I2C_SlaveInit	0x000004b5
#define __I2C_SlaveRead	0x00000335
#define __I2C_SlaveWrite	0x000003a5
#define __MCU_DFLLInit	0x00000f15
#define __MCU_Init	0x00000fe3
#define __NVM_EraseRow	0x0000071d
#define __NVM_Init	0x000005d1
#define __NVM_ProgramMemory	0x00000785
#define __NVM_ReadBuffer	0x000006b5
#define __NVM_ReadMemory	0x000007e5
#define __NVM_WriteBuffer	0x000005f5
#define __PDFW_ProcessGetFWIDRequest	0x00000839
#define __PDFW_ProcessPDFUInitateRequest	0x00000887
#define __PDFW_ProcessRequestPacket	0x000008a1
#define __SPI_ChipSelectHigh	0x00000c11
#define __SPI_ChipSelectLow	0x00000bf5
#define __SPI_Init	0x00000d45
#define __SPI_PortInit	0x00000c97
#define __SPI_Read	0x00000c65
#define __SPI_SyncInit	0x00000d17
#define __SPI_Write	0x00000c2d
#define __UPD_DriveNRead	0x00000b85
#define __UPD_InputRead	0x00000b21
#define __UPD_RegisterRead	0x00000ae9
#define __UPD_RegisterWrite	0x00000ab5
#define ____iar_copy_init3	0x000010a5
#define ____iar_data_init3	0x000010d5
#define ____iar_zero_init3	0x00001065
#define ____low_level_init	0x0000113b
#define ___pm_init	0x0000104d
#define __exit	0x0000113f
#define __main	0x00000d8d

#endif

#endif

