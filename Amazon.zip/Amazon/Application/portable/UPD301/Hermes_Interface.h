/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _HERMES_INTERFACE_H_
#define _HERMES_INTERFACE_H_

#include <SERCOM_I2CSlave.h>
#include <ZeusStackConfig.h>

#define HERMES_RESPONSE_MASK                                   0x80

/*Hermes Request IDs*/
#define HERMES_DISCOVERY_REQUEST                               0x01
#define HERMES_CONNECTION_REQUEST                              0x02
#define HERMES_CONFIGURATION_REQUEST                           0x03
#define HERMES_PROTOCOL_TX_REQUEST                             0x04
#define HERMES_PROTOCOL_RX_REQUEST                             0x05
#define HERMES_DISCONNECT_REQUEST                              0x06
#define HERMES_INVALID_REQUEST                                 0xFFu
/*Hermes Response IDs*/
#define HERMES_DISCOVERY_RESPONSE                              (HERMES_RESPONSE_MASK | HERMES_DISCOVERY_REQUEST)
#define HERMES_CONNECTION_RESPONSE                             (HERMES_RESPONSE_MASK | HERMES_CONNECTION_REQUEST)
#define HERMES_CONFIGURATION_RESPONSE                          (HERMES_RESPONSE_MASK | HERMES_CONFIGURATION_REQUEST)
#define HERMES_PROTOCOL_TX_RESPONSE                            (HERMES_RESPONSE_MASK | HERMES_PROTOCOL_TX_REQUEST)
#define HERMES_PROTOCOL_RX_RESPONSE                            (HERMES_RESPONSE_MASK | HERMES_PROTOCOL_RX_REQUEST)
#define HERMES_DISCONNECT_RESPONSE                             (HERMES_RESPONSE_MASK | HERMES_DISCONNECT_REQUEST)

/*Hermes Response Codes*/
#define HERMES_HRESP_OK             0x00
#define HERMES_HRESP_BAD_PEC        0x01
#define HERMES_HRESP_INVALID        0x02
#define HERMES_HRESP_NO_ACTION      0x03
#define HERMES_HRESP_BUSY           0x04

#define SIGNATURE_ERASE_REQUEST                         0x09
#define  SIGNATURE_WRITE_REQUEST                        0x0A
#define UPD_SYSTEM_RESET_REQUEST                        0x0B
#define UPD_VALIDATION_REQUEST                          0x80
#define UPD_VALIDATION_RESPONSE                         0x80
#define UPD_VALIDATION_MASK                             0x8F
#define BUFFER_SIZE                                     275

#define HERMES_CONN_ID_UCSI                             0x50
#define HERMES_CONN_ID_USB_TYPE_C                       0x51
#define HERMES_CONN_ID_USB_TYPE_C_AUTH                  0x52
#define HERMES_CONN_ID_PD_FW_UPDATE                     0x06
#define HERMES_CONN_ID_DEBUG                            0x07
#define HERMES_CONN_ID_VDM_TUNNEL                       0x55
#define HERMES_CONN_ID_VENDOR_SPECIFIC                  0x56
#define HERMES_CONN_ID_INVALID                          0xFFu

/*Protocol ID*/
#define HERMES_PROT_UTC_AUTH                            0x01
#define HERMES_PROT_PDFWU                               0x02
#define HERMES_PROT_UCSI                                0x03
#define HERMES_PROT_UTC_BRIDGE                          0x04
#define HERMES_PROT_VDM_TNL                             0x05
#define HERMES_PROT_UTC_LL                              0x06
#define HERMES_PROT_UTC_PD_PL                           0x07
#define HERMES_PROT_MCHP_HUB                            0x08

#define HERMES_PROT_HERMES_CONFIG                       0xFD
#define HERMES_PROT_PROT_DEBUG                          0xFE
#define SIGNATURE_ERASE_REQUEST                         0x09
#define SIGNATURE_WRITE_REQUEST                         0x0A
#define UPD_SYSTEM_RESET_REQUEST                        0x0B

#define HERMES_NUM_OF_BYTES_CIB_LENGTH                  0x02
#define HERMES_NUM_OF_CONN_SUPPORTED                    0x02

#define UPD_SystemReset            NVIC_SystemReset

/*Size of buffer for received data in blocks of 256 bytes i.e. 0x01 means 256 bytes, 0x02 means
512 bytes etc*/
#define HERMES_CONN_INFO_BUF_SIZE_256                   0x01
#define HERMES_CONN_INFO_BUF_SIZE_512                   0x02

#define HERMES_MAJOR_REV                                0x33
#define HERMES_MINOR_REV                                0x00
#define HERMES_PD_SYS_FW_REV                            SYSTEM_FW_REV
#define HERMES_PD_SYS_HW_REV                            0x0001
#define HERMES_NUM_OF_HERMES_CONNECTIONS                0x02

#define HERMES_DATA_PAYLOAD_START_INDEX                 0x02
#define HERMES_HIGH_BYTE_INDEX                          0x00
#define HERMES_LOW_BYTE_INDEX                           0x01
#define HERMES_LENGTH_BYTE_COUNT                        0x02

#define HERMES_RESPONSE_CODE_LENGTH                     0x01

#define HERMES_COMMAND_SET_FEATURE                      0x02
#define HERMES_COMMAND_MEM_WRITE                        0x03
#define HERMES_COMMAND_MEM_READ                         0x04

#define HERMES_SET_FEATURE_RESET_CMD                    0x02
typedef UINT8 (*NVM_ProgramMemory_cb)(UINT32 , UINT8*, UINT16);
typedef UINT8 (*NVM_ReadMemory_cb)(UINT32 , UINT8*, UINT16);
/** Indexing the Hermes Buffer */
#define HERMES_BUFFER_CNID_IDX                          0x00u
#define HERMES_BUFFER_RQTYP_IDX                         0x01u
#define HERMES_BUFFER_SIZEMSB_IDX                       0x02u
#define HERMES_BUFFER_SIZELSB_IDX                       0x03u
#define HERMES_BUFFER_DATA_IDX                          0x04u

#define HERMES_MIN_REQUEST_LENGTH       0x02

#pragma pack(1)
typedef struct _MEMORY_RW_HEADER
{
    UINT8 u8CMD;
    UINT32 u32MemoryAddr;
    UINT16 u16DataLength;
}MEMORY_RW_HEADER;


void Hermes_InterfaceInit(void);
UINT8 Hermes_IfConnectionRequest(void);
UINT8 Hermes_ProcessMasterPacket(void);
UINT8 Hermes_ProcessRequestPacket(void);
UINT8 Hermes_ProcessResponsePacket(void);
void Hermes_HandleProtocolTxReq(void);
UINT16 Hermes_HandleProtocolTxRxRes(void);
UINT8 Hermes_HandleDiscoveryReq(void);
UINT16 Hermes_HandleProtocolRxReq(void);
void* Hermes_MemCpy(void *dest, const void *src, int n);
UINT8 Hermes_MemCmp(const void *pau8Data1, const void *pau8Data2, int len);
void UPD301_Reset(void);
void UPD301_EraseUpdatableAppSignature(void);
void UPD301_DetachPorts();
void UPD301_DetachDelayCB(
    UINT8   u8PortNum,          /* */
    UINT8   u8PdFwUpdtState);
#endif