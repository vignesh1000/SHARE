/*
	adc.c

	File Description
	This file contains API definitions for ADC module

	Copyright(C) 2018, Microchip Technology Inc. All Rights Reserved.

	This program code listing is proprietary to Microchip and may not be copied,  
	distributed, or used without a license to do so. Such license may have  
	Limited or Restricted Rights. Please refer to the license for further clarification.

	THIS SOFTWARE IS PROVIDED IN AN ?AS IS? CONDITION. NO WARRANTIES,
	WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
	TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
	PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
	IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
	CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*/

#include <stdinc.h>
#include <adc.h>
#include <dac.h>
#include "GPIO.h"
#include "REG_SAMD20.h"

volatile UINT16 gu16PreviousADCValue = 0;
volatile double gdADCValueCalb = 0;
volatile BOOL gbVariationVCC = false;
volatile BOOL gbADCTimerExpires = true;

#ifdef _IDEAL_
UINT16 gau16ADCval[2];
UINT8 gu8iter = 0;
#endif

eADC_INIT_RETURN ADC_Initialization (void)
{
    /**1) Peripheral clock mask of the ADC Module is unmasked.*/
    UINT32 u32Peripheral = (ADC_BASE_ADDRESS & 0x0000ff00uL) >> 10u;    
    REGDW(PM_APBCMASK_REG) |= (1u << u32Peripheral);
    
    /**2) Select Generater0 and set CLK enable bit*/
    REGW(GCLK_CLKCTRL_REG) = (CLKCTRL_ID(ADC_GCLK_INDEX) | CLKCTRL_GEN(CLKCTRL_GEN_GCLK0_Val) | (CLKCTRL_CLKEN));
    
    /**3) Wait for ADC module Interface clock and GCLK to synchronize.**/
    ADC_WAIT_FOR_SYNC();
    
    /**4) check the ENABLE field in the ADC CNTRLA register to verify if the module has already been enabled*/
    if (ADC_CNTRLA_ISENABLE()) 
    {
        /**Already ADC Module is in Enabled state*/
        return eADC_INIT_ERROR;
    }
    
    /**5) Assert the SWRST field in the CNTRLA register*/
    ADC_MODULE_RESET();
     
    /**6) Wait for ADC module Interface clock and GCLK to synchronize**/
    ADC_WAIT_FOR_SYNC();
    
    /**7) Config CTRLA Reg to Enable ADC**/
    REGB(ADC_BASE_ADDRESS + ADC_CTRLA_ADDROFFSET) = ((CONF_ADC_RUNSTDBY << ADC_CTRLA_RUNSTDBY_Pos) | (CONF_ADC_ENABLE << ADC_CTRLA_ENABLE_Pos));
    
    /**8) Config REFCTRL Reg to Enable INT1V as reference voltage**/
    REGB(ADC_BASE_ADDRESS + ADC_REFCTRL_ADDROFFSET) = ((CONF_ADC_REFCOMP << ADC_REFCTRL_REFCOMP_Pos) | ADC_REFCTRL_REFSEL(CONF_ADC_REFSEL));
    
    /**9) Config AVGCTRL Reg to Choose 16 Smaples for Averaging**/
    REGB(ADC_BASE_ADDRESS + ADC_AVGCTRL_ADDROFFSET) = (ADC_AVGCTRL_ADJRES(CONF_ADC_ADJRES) | ADC_AVGCTRL_SAMPLENUM(CONF_ADC_SAMPLENUM));
    
    /**10) Config SAMPLEN Reg **/
    //REGB(ADC_BASE_ADDRESS + ADC_SAMPCTRL_ADDROFFSET) = CONF_ADC_SAMPLEN;
    REGB(ADC_BASE_ADDRESS + ADC_SAMPCTRL_ADDROFFSET) = 0x3E;
 
    /**11) Config CTRLB Reg to Enable Prescalar PCLK/4, Conversion Resolution as 16 bit and Enabling Free Run Mode **/
    ADC_WAIT_FOR_SYNC();
    REGW(ADC_BASE_ADDRESS + ADC_CTRLB_ADDROFFSET) = (ADC_CTRLB_PRESCALER(CONF_ADC_PRESCALER_64) | (CONF_ADC_RESSEL << ADC_CTRLB_RESSEL_Pos) | (CONF_ADC_CORREN << ADC_CTRLB_CORREN_Pos) | (CONF_ADC_FREERUN << ADC_CTRLB_FREERUN_Pos) | (CONF_ADC_LEFTADJ << ADC_CTRLB_LEFTADJ_Pos) | (CONF_ADC_DIFFMODE << ADC_CTRLB_DIFFMODE_Pos));                                                 
    
    /**12) Config INPUTCTRL Reg to Choose Negative MUX I/P as IOGND and Positive MUX I/P as 1/4 Scaled I/O Supply **/
    ADC_WAIT_FOR_SYNC();
    REGDW(ADC_BASE_ADDRESS + ADC_INPUTCTRL_ADDROFFSET) = ((CONF_ADC_MUXNEG << ADC_INPUTCTRL_MUXNEG_Pos) | (CONF_ADC_MUXPOS << ADC_INPUTCTRL_MUXPOS_Pos));    
    
    /**13) Config SWTRIG Reg to Software Trigger the ADC Conversion **/
    ADC_WAIT_FOR_SYNC();
    REGB(ADC_BASE_ADDRESS + ADC_SWTRIG_ADDROFFSET) |= (1 << ADC_SWTRIG_START_Pos);
      
    /**14) Dummy Read to stabilise ADC read value**/
    /* Initial VDD33 voltage is read*/
    ADC_Read_Dummy();
    
    return eADC_INIT_SUCCESS;
}

void ADC_Read_Dummy()
{
    UINT16 u16ADCRegValue =0;
    double dADCResolCalc = 0.000244140625;
    UINT8  u8Iteration;
    
    /**5 Dummy Read to stabilise ADC read value**/
    for (u8Iteration = 0; u8Iteration < 5; u8Iteration++)
    {
        /**Wait for current conversion to finish**/  
        ADC_WAIT_FOR_CONVERSION();
        
        /**Read result register value**/
        u16ADCRegValue  = REGW(ADC_BASE_ADDRESS + ADC_RESULT_OFFSET);              
        gdADCValueCalb = ((dADCResolCalc * u16ADCRegValue) * 4);
    }
    
    DAC_CalibrateStepResolution((float)gdADCValueCalb, 0x3FF);
    gu16PreviousADCValue = (UINT16)(gdADCValueCalb * 1000);      
}

void ADC_Run()
{
    //if((gasPortConfigurationData[PORT0].u32CfgData & PD_ROLE_SOURCE) == PD_ROLE_SOURCE)
    {
        if((DPM_GetVBUSVoltage(PORT0) > PWRCTRL_VBUS_0V) || (DPM_GET_SINK_CURRRENT(PORT0) > 0))
        {
            if (gbADCTimerExpires)
            {
                gbADCTimerExpires = false;
                (void)PDTimer_Start(MILLISECONDS_TO_TICKS(ADC_POLLING_INTERVAL_MS), ADC_SynchronousRead_TimerCB, NULL, NULL);                     
            }
        }
    }
}

void ADC_Deinitialization(void)
{
    /**Reset the Enable ADC field**/
    ADC_WAIT_FOR_SYNC();    
    REGB(ADC_BASE_ADDRESS +ADC_CTRLA_ADDROFFSET) &= (~ADC_CTRLA_ENABLE);
    
    /**Soft Reset of ADC Module**/
    ADC_MODULE_RESET();
}


void ADC_Disable(void)
{
    /**Reset the Enable ADC field**/  
    ADC_WAIT_FOR_SYNC();
    REGB(ADC_BASE_ADDRESS +ADC_CTRLA_ADDROFFSET) &= (~ADC_CTRLA_ENABLE);
}

void ADC_SynchronousRead_TimerCB(UINT8 u8PortNum, UINT8 u8DummyVariable)
{ 
    UINT16 u16Result, u16Temp, u16ADCRegValue =0;
    double dADCResolCalc = 0.000244140625;
    
    /**Wait for current conversion to finish**/  
    ADC_WAIT_FOR_CONVERSION();

    /**Read result register value**/
    u16ADCRegValue  = REGW(ADC_BASE_ADDRESS + ADC_RESULT_OFFSET);              
    gdADCValueCalb = ((dADCResolCalc * u16ADCRegValue) * 4);
        
    /**Comparing with previous ADC value to initiate DAC Reconfigure**/
    u16Temp = (UINT16)(gdADCValueCalb * 1000);
    
    u16Result = (gu16PreviousADCValue > u16Temp) ? (gu16PreviousADCValue - u16Temp) : (u16Temp - gu16PreviousADCValue);
    
    if (u16Temp < ADC_MINIMUM_IP_READ)
    {
        gbVariationVCC = false;
        if (u16Result >= ADC_VOLTAGE_VARIATION)
        {
            gu16PreviousADCValue = u16Temp;
        }
    }
    else 
    {
        
        if (u16Result >= ADC_VOLTAGE_VARIATION)
        {
            gbVariationVCC = true;
            
            if(DPM_GET_CURRENT_POWER_ROLE(0) == PD_ROLE_SOURCE)
            {
                DAC_Reconfigure(gdADCValueCalb);
            }
            else
            {
                /* Add DAC Calibration for Sink */
                UINT16 u16SinkCurrent;
                u16SinkCurrent = DPM_GET_SINK_CURRRENT(0);
                DAC_CalibrateStepResolution(gdADCValueCalb, 0x3ff);
                DAC_SinkCurrentControl(u16SinkCurrent);
            }
            
            /**Storing Previous ADC Value for which DAC was corrected**/
            gu16PreviousADCValue = (UINT16)(gdADCValueCalb * 1000);
        }
    }

    /**Restart PD Timer for next poolling**/
    gbADCTimerExpires = true;
    return;
}

#ifdef _IDEAL_

/*****************************Begin function Definitions*******************************************/
/**************************************************************************************************/
/*
 * \Function Name          - Ideal_ADCInit 
 * \Function Description   - This function initializes the Clocks and registers for ADC
 * \return                 - (eADC_INIT_RETURN) The error status.
 */
/**************************************************************************************************/
eADC_INIT_RETURN Ideal_ADCInit (void)
{
    /*Peripheral clock mask of the ADC Module is unmasked*/   
    REGDW(PM_APBCMASK_REG)              |= IDEAL_PM_APBCMASK_ADC;
    
    /*Select Generater0 as a Clock for ADC and set CLK enable bit*/
    REGW(GCLK_CLKCTRL_REG)              = ((CLKCTRL_ID(ADC_GCLK_INDEX))| \
                                           (CLKCTRL_GEN(CLKCTRL_GEN_GCLK0_Val)) | \
                                           (CLKCTRL_CLKEN));
    
    /*Set the GPIO Pin function to enable ADC AIN0 MUX*/
    GPIO_SetPinFunction(PIN_PA02, PINMUX_PA02B_ADC_AIN0); 
    
    /*Set the GPIO Pin function to enable ADC AIN1 MUX*/
    GPIO_SetPinFunction(PIN_PA03, PINMUX_PA03B_ADC_AIN1);
    
    /*Wait for ADC module Interface clock and GCLK to synchronize*/
    ADC_WAIT_FOR_SYNC();
    
    /*
     * Check the ENABLE field in the ADC CNTRLA register to verify if the module has already been 
      enabled
    */
    if (ADC_CNTRLA_ISENABLE()) 
    {
        /*Already ADC Module is in Enabled state*/
        return eADC_INIT_ERROR;
    }    
    
    /*Assert the SWRST field in the CNTRLA register*/
    ADC_MODULE_RESET();
     
    /*Wait for ADC module Interface clock and GCLK to synchronize*/
    ADC_WAIT_FOR_SYNC();
    
    /*************** CTRLA register configuration ******************************* 
    *  RUNSTDBY        - 0x1   Run in Standby 
    *  ENABLE          - 0x0   Disable ADC
    *  SWRST           - 0x0   No Software Reset enabled
    ***************************************************************************/
    REGB(IDEAL_ADC_CTRLA_REG)           = ((CONF_ADC_ENABLE << ADC_CTRLA_ENABLE_Pos)|\
                                           (CONF_ADC_RUNSTDBY << ADC_CTRLA_RUNSTDBY_Pos));
    
    /*Wait for ADC module Interface clock and GCLK to synchronize*/
    ADC_WAIT_FOR_SYNC();
    
    /*************** REFCTRL register configuration ******************************* 
    *  REFCOMP         - 0x1   Reference Buffer Offset Compensation Enable 
    *  REFSEL[3:0]     - 0x1   1/1.48 VDDANA
    ***************************************************************************/
    REGB(IDEAL_ADC_REFCTRL_REG)         = ((CONF_ADC_REFCOMP << ADC_REFCTRL_REFCOMP_Pos) |\
                                           (ADC_REFCTRL_REFSEL(IDEAL_CONF_ADC_REFSEL)));
    
    /*************** AVGCTRL register configuration ******************************* 
    *  ADJRES[2:0]     - 0x4   Division coefficient 
    *  SAMPLENUM[3:0]  - 0x4   16 samples
    ***************************************************************************/
    REGB(IDEAL_ADC_AVGCTRL_REG)         = ((ADC_AVGCTRL_ADJRES(CONF_ADC_ADJRES)) | \
                                           (ADC_AVGCTRL_SAMPLENUM(CONF_ADC_SAMPLENUM)));
    
    /*************** SAMPCTRL register configuration ******************************* 
    *  SAMPLEN[5:0]    - 0x3E   Sample Time Length 
    ***************************************************************************/
    REGB(IDEAL_ADC_SAMPCTRL_REG)        = IDEAL_CONF_SAMPLEN;
    
    /*************** CTRLB register configuration ******************************* 
    *  PRESCALER[2:0]  - 0x4   Peripheral clock divided by 64
    *  RESSEL[1:0]     - 0x1   16BIT Result
    *  CORREN          - 0x1   Digital Correction Logic Enabled
    *  FREERUN         - 0x1   Free Running Mode Enabled
    *  LEFTADJ         - 0x1   Left-Adjusted Result Enabled
    *  DIFFMODE        - 0x1   Differential Mode Enabled
    ***************************************************************************/        
    REGW(IDEAL_ADC_CTRLB_REG)           = ((ADC_CTRLB_PRESCALER(CONF_ADC_PRESCALER_64) ) |\
                                           (CONF_ADC_RESSEL   << ADC_CTRLB_RESSEL_Pos  ) |\
                                           (CONF_ADC_CORREN   << ADC_CTRLB_CORREN_Pos  ) |\
                                           (CONF_ADC_FREERUN  << ADC_CTRLB_FREERUN_Pos ) |\
                                           (CONF_ADC_LEFTADJ  << ADC_CTRLB_LEFTADJ_Pos ) |\
                                           (CONF_ADC_DIFFMODE << ADC_CTRLB_DIFFMODE_Pos));                                                 
    
    
    /*Wait for ADC module Interface clock and GCLK to synchronize*/
    ADC_WAIT_FOR_SYNC();
    
    /*************** INPUTCTRL register configuration ******************************* 
    *  MUXNEG[4:0]     - 0x19  I/O ground 
    *  MUXPOS[4:0]     - 0x0   ADC AIN0 pin (Basic Initialization)
    ***************************************************************************/
    REGDW(IDEAL_ADC_INPUTCTRL_REG)      = ((CONF_ADC_MUXNEG << ADC_INPUTCTRL_MUXNEG_Pos) |\
                                           (IDEAL_CONF_ADC_MUXPOS_V << ADC_INPUTCTRL_MUXPOS_Pos));    
    
    /*Wait for ADC module Interface clock and GCLK to synchronize*/
    ADC_WAIT_FOR_SYNC();
    
    REGB(IDEAL_ADC_INTENSET_REG) = IDEAL_ADC_INTFLAG_RESRDY;
    
    /*Disable IRQ of ADC to clear the pending interrupts*/
    NVIC_DisableIRQ(ADC_IRQn);
    
    /*Clear the Pending ADC Interrupts*/
    NVIC_ClearPendingIRQ(ADC_IRQn);
    
    /*Enable ADC IRQ*/
    NVIC_EnableIRQ(ADC_IRQn);
    
    /*************** SWTRIG register configuration ******************************* 
    *  START           - 0x1   ADC Start Conversion 
    ***************************************************************************/
    REGB(IDEAL_ADC_SWTRIG_REG)          |= (ADC_SWTRIG_START);
    
    /*Wait for ADC module Interface clock and GCLK to synchronize*/
    ADC_WAIT_FOR_SYNC();
    
    /*Return the Init state as success state*/
    return eADC_INIT_SUCCESS;    
}

/**************************************************************************************************/
/*
 * \Function Name       - ADC_Handler 
 * \Function Description- This function handles the interrupts enabled on ADC Core
 * \return              - void.
 */
/**************************************************************************************************/
void ADC_Handler (void)
{
    /*Check if the result ready interrupt has occured*/
    if ((FALSE != (REGB(IDEAL_ADC_INTFLAG_REG)  & IDEAL_ADC_INTFLAG_RESRDY ))&&\
        (FALSE != (REGB(IDEAL_ADC_INTENSET_REG) & IDEAL_ADC_INTFLAG_RESRDY))) 
    {
        /*Copy the ADC value to the array*/
        gau16ADCval[(gu8iter & 0x01)] = REGW(IDEAL_ADC_RESULT_REG);
        
        /*Increment the array index*/
        gu8iter++;
        
        /*Change the Positive Mux of ADC to the alternate channel*/
        REGB(IDEAL_ADC_INPUTCTRL_REG) = (gu8iter & 0x01);
    }
}
/**************************End Function definitions************************************************/
#endif