#ifndef _INTERRUPTS_H_
#define _INTERRUPTS_H_

#include <GPIO.h>

#define INT_EIC_NMIFILTEN                   0
#define INT_EICNMICTRL_NMIFILTEN_POS       3            /**< \brief (EIC_NMICTRL) Non-Maskable Interrupt Filter Enable */
#define INT_EIC_NMIFILT                     (INT_EIC_NMIFILTEN << INT_EICNMICTRL_NMIFILTEN_POS)
#define INT_NMICTRL_NMISENSE_NONE_Val       (0x0)   /**< \brief (EIC_NMICTRL) No detection */
#define INT_NMICTRL_NMISENSE_POS           0            /**< \brief (EIC_NMICTRL) Non-Maskable Interrupt Sense */
#define INT_NMICTRL_NMISENSE                (INT_NMICTRL_NMISENSE_NONE_Val << INT_NMICTRL_NMISENSE_POS)

#define INT_EICGCLK_ID                      3        // Index of Generic Clock
#define INT_EICSTATUS_OFFSET                0x01         /*(STATUS offset) Status */
#define INT_EICSTATUS_RESETVALUE            (0x00)    /*(STATUS reset_value) Status */

#define INT_EICSTATUS_SYNCBUSY_POS         7            /*(STATUS) Synchronization Busy */
#define INT_EICSTATUS_SYNCBUSY              (0x1) << INT_EICSTATUS_SYNCBUSY_POS)
#define INT_EICSTATUS_MASK                  (0x80)    /*(STATUS) MASK Register */

#define INT_ENCLR_OFFSET                 0x08         /*(INTENCLR offset) Interrupt Enable Clear */
#define INT_ENCLR_RESETVALUE             (0x00000000) /*(INTENCLR reset_value) Interrupt Enable Clear */

#define INT_ENCLR_EXTINT0_POS           0            /*(INTENCLR) External Interrupt 0 Enable */
#define INT_ENCLR_EXTINT0                ((1) << INT_ENCLR_EXTINT0_POS)
#define INT_ENCLR_EXTINT1_POS           1            /*(INTENCLR) External Interrupt 1 Enable */
#define INT_ENCLR_EXTINT1                ((1) << INT_ENCLR_EXTINT1_POS)
#define INT_ENCLR_EXTINT2_POS           2            /*(INTENCLR) External Interrupt 2 Enable */
#define INT_ENCLR_EXTINT2                ((1) << INT_ENCLR_EXTINT2_POS)
#define INT_ENCLR_EXTINT3_POS           3            /*(INTENCLR) External Interrupt 3 Enable */
#define INT_ENCLR_EXTINT3                ((1) << INT_ENCLR_EXTINT3_POS)
#define INT_ENCLR_EXTINT4_POS           4            /*(INTENCLR) External Interrupt 4 Enable */
#define INT_ENCLR_EXTINT4                ((1) << INT_ENCLR_EXTINT4_POS)
#define INT_ENCLR_EXTINT5_POS           5            /*(INTENCLR) External Interrupt 5 Enable */
#define INT_ENCLR_EXTINT5                ((1) << INT_ENCLR_EXTINT5_POS)
#define INT_ENCLR_EXTINT6_POS           6            /*(INTENCLR) External Interrupt 6 Enable */
#define INT_ENCLR_EXTINT6                ((1) << INT_ENCLR_EXTINT6_POS)
#define INT_ENCLR_EXTINT7_POS           7            /*(INTENCLR) External Interrupt 7 Enable */
#define INT_ENCLR_EXTINT7                ((1) << INT_ENCLR_EXTINT7_POS)
#define INT_ENCLR_EXTINT8_POS           8            /*(INTENCLR) External Interrupt 8 Enable */
#define INT_ENCLR_EXTINT8                ((1) << INT_ENCLR_EXTINT8_POS)
#define INT_ENCLR_EXTINT9_POS           9            /*(INTENCLR) External Interrupt 9 Enable */
#define INT_ENCLR_EXTINT9                ((1) << INT_ENCLR_EXTINT9_POS)
#define INT_ENCLR_EXTINT10_POS          10           /*(INTENCLR) External Interrupt 10 Enable */
#define INT_ENCLR_EXTINT10               ((1) << INT_ENCLR_EXTINT10_POS)
#define INT_ENCLR_EXTINT11_POS          11           /*(INTENCLR) External Interrupt 11 Enable */
#define INT_ENCLR_EXTINT11               ((1) << INT_ENCLR_EXTINT11_POS)
#define INT_ENCLR_EXTINT12_POS          12           /*(INTENCLR) External Interrupt 12 Enable */
#define INT_ENCLR_EXTINT12               ((1) << INT_ENCLR_EXTINT12_POS)
#define INT_ENCLR_EXTINT13_POS          13           /*(INTENCLR) External Interrupt 13 Enable */
#define INT_ENCLR_EXTINT13               ((1) << INT_ENCLR_EXTINT13_POS)
#define INT_ENCLR_EXTINT14_POS          14           /*(INTENCLR) External Interrupt 14 Enable */
#define INT_ENCLR_EXTINT14               ((1) << INT_ENCLR_EXTINT14_POS)
#define INT_ENCLR_EXTINT15_POS          15           /*(INTENCLR) External Interrupt 15 Enable */
#define INT_ENCLR_EXTINT15               ((1) << INT_ENCLR_EXTINT15_POS)
#define INT_ENCLR_EXTINT_POS            0            /*(INTENCLR) External Interrupt x Enable */
#define INT_ENCLR_EXTINT_MSK             ((0xFFFF) << INT_ENCLR_EXTINT_POS)
#define INT_ENCLR_EXTINT(value)          (INT_ENCLR_EXTINT_MSK & ((value) << INT_ENCLR_EXTINT_POS))
#define INT_ENCLR_MASK                   (0x0000FFFF) /*(INTENCLR) MASK Register */

/* -------- INTENSET : (EIC Offset: 0x0C) (R/W 32) Interrupt Enable Set -------- */
#define INT_ENSET_OFFSET                 0x0C         /*(INTENSET offset) Interrupt Enable Set */
#define INT_ENSET_RESETVALUE             (0x00000000) /*(INTENSET reset_value) Interrupt Enable Set */
#define INT_ENSET_EXTINT0_POS           0            /*(INTENSET) External Interrupt 0 Enable */
#define INT_ENSET_EXTINT0                ((1) << INT_ENSET_EXTINT0_POS)
#define INT_ENSET_EXTINT1_POS           1            /*(INTENSET) External Interrupt 1 Enable */
#define INT_ENSET_EXTINT1                ((1) << INT_ENSET_EXTINT1_POS)
#define INT_ENSET_EXTINT2_POS           2            /*(INTENSET) External Interrupt 2 Enable */
#define INT_ENSET_EXTINT2                ((1) << INT_ENSET_EXTINT2_POS)
#define INT_ENSET_EXTINT3_POS           3            /*(INTENSET) External Interrupt 3 Enable */
#define INT_ENSET_EXTINT3                ((1) << INT_ENSET_EXTINT3_POS)
#define INT_ENSET_EXTINT4_POS           4            /*(INTENSET) External Interrupt 4 Enable */
#define INT_ENSET_EXTINT4                ((1) << INT_ENSET_EXTINT4_POS)
#define INT_ENSET_EXTINT5_POS           5            /*(INTENSET) External Interrupt 5 Enable */
#define INT_ENSET_EXTINT5                ((1) << INT_ENSET_EXTINT5_POS)
#define INT_ENSET_EXTINT6_POS           6            /*(INTENSET) External Interrupt 6 Enable */
#define INT_ENSET_EXTINT6                ((1) << INT_ENSET_EXTINT6_POS)
#define INT_ENSET_EXTINT7_POS           7            /*(INTENSET) External Interrupt 7 Enable */
#define INT_ENSET_EXTINT7                ((1) << INT_ENSET_EXTINT7_POS)
#define INT_ENSET_EXTINT8_POS           8            /*(INTENSET) External Interrupt 8 Enable */
#define INT_ENSET_EXTINT8                ((1) << INT_ENSET_EXTINT8_POS)
#define INT_ENSET_EXTINT9_POS           9            /*(INTENSET) External Interrupt 9 Enable */
#define INT_ENSET_EXTINT9                ((1) << INT_ENSET_EXTINT9_POS)
#define INT_ENSET_EXTINT10_POS          10           /*(INTENSET) External Interrupt 10 Enable */
#define INT_ENSET_EXTINT10               ((1) << INT_ENSET_EXTINT10_POS)
#define INT_ENSET_EXTINT11_POS          11           /*(INTENSET) External Interrupt 11 Enable */
#define INT_ENSET_EXTINT11       ((1) << INT_ENSET_EXTINT11_POS)
#define INT_ENSET_EXTINT12_POS  12           /*(INTENSET) External Interrupt 12 Enable */
#define INT_ENSET_EXTINT12       ((1) << INT_ENSET_EXTINT12_POS)
#define INT_ENSET_EXTINT13_POS  13           /*(INTENSET) External Interrupt 13 Enable */
#define INT_ENSET_EXTINT13       ((1) << INT_ENSET_EXTINT13_POS)
#define INT_ENSET_EXTINT14_POS  14           /*(INTENSET) External Interrupt 14 Enable */
#define INT_ENSET_EXTINT14       ((1) << INT_ENSET_EXTINT14_POS)
#define INT_ENSET_EXTINT15_POS  15           /*(INTENSET) External Interrupt 15 Enable */
#define INT_ENSET_EXTINT15       ((1) << INT_ENSET_EXTINT15_POS)
#define INT_ENSET_EXTINT_POS    0            /*(INTENSET) External Interrupt x Enable */
#define INT_ENSET_EXTINT_MSK     ((0xFFFF) << INT_ENSET_EXTINT_POS)
#define INT_ENSET_EXTINT(value)  (INT_ENSET_EXTINT_MSK & ((value) << INT_ENSET_EXTINT_POS))
#define INT_ENSET_MASK           (0x0000FFFF) /*(INTENSET) MASK Register */

/* -------- INTFLAG : (EIC Offset: 0x10) (R/W 32) Interrupt Flag Status and Clear -------- */
#define INT_FLAG_OFFSET          0x10         /*(INTFLAG offset) Interrupt Flag Status and Clear */
#define INT_FLAG_RESETVALUE      (0x00000000) /*(INTFLAG reset_value) Interrupt Flag Status and Clear */
#define INT_FLAG_EXTINT0_POS    0            /*External Interrupt 0 */
#define INT_FLAG_EXTINT0         ((1) << INT_FLAG_EXTINT0_POS)
#define INT_FLAG_EXTINT1_POS    1            /*External Interrupt 1 */
#define INT_FLAG_EXTINT1         ((1) << INT_FLAG_EXTINT1_POS)
#define INT_FLAG_EXTINT2_POS    2            /*External Interrupt 2 */
#define INT_FLAG_EXTINT2         ((1) << INT_FLAG_EXTINT2_POS)
#define INT_FLAG_EXTINT3_POS    3            /*External Interrupt 3 */
#define INT_FLAG_EXTINT3         ((1) << INT_FLAG_EXTINT3_POS)
#define INT_FLAG_EXTINT4_POS    4            /*External Interrupt 4 */
#define INT_FLAG_EXTINT4         ((1) << INT_FLAG_EXTINT4_POS)
#define INT_FLAG_EXTINT5_POS    5            /*External Interrupt 5 */
#define INT_FLAG_EXTINT5         ((1) << INT_FLAG_EXTINT5_POS)
#define INT_FLAG_EXTINT6_POS    6            /*External Interrupt 6 */
#define INT_FLAG_EXTINT6         ((1) << INT_FLAG_EXTINT6_POS)
#define INT_FLAG_EXTINT7_POS    7            /*External Interrupt 7 */
#define INT_FLAG_EXTINT7         ((1) << INT_FLAG_EXTINT7_POS)
#define INT_FLAG_EXTINT8_POS    8            /*External Interrupt 8 */
#define INT_FLAG_EXTINT8         ((1) << INT_FLAG_EXTINT8_POS)
#define INT_FLAG_EXTINT9_POS    9            /*External Interrupt 9 */
#define INT_FLAG_EXTINT9         ((1) << INT_FLAG_EXTINT9_POS)
#define INT_FLAG_EXTINT10_POS   10           /*External Interrupt 10 */
#define INT_FLAG_EXTINT10        ((1) << INT_FLAG_EXTINT10_POS)
#define INT_FLAG_EXTINT11_POS   11           /*External Interrupt 11 */
#define INT_FLAG_EXTINT11        ((1) << INT_FLAG_EXTINT11_POS)
#define INT_FLAG_EXTINT12_POS   12           /*External Interrupt 12 */
#define INT_FLAG_EXTINT12        ((1) << INT_FLAG_EXTINT12_POS)
#define INT_FLAG_EXTINT13_POS   13           /*External Interrupt 13 */
#define INT_FLAG_EXTINT13        ((1) << INT_FLAG_EXTINT13_POS)
#define INT_FLAG_EXTINT14_POS   14           /*External Interrupt 14 */
#define INT_FLAG_EXTINT14        ((1) << INT_FLAG_EXTINT14_POS)
#define INT_FLAG_EXTINT15_POS   15           /*External Interrupt 15 */
#define INT_FLAG_EXTINT15        ((1) << INT_FLAG_EXTINT15_POS)
#define INT_FLAG_EXTINT_POS     0            /*External Interrupt x */
#define INT_FLAG_EXTINT_MSK      ((0xFFFF) << INT_FLAG_EXTINT_POS)
#define INT_FLAG_EXTINT(value)   (INT_FLAG_EXTINT_MSK & ((value) << INT_FLAG_EXTINT_POS))
#define INT_FLAG_MASK            (0x0000FFFF) /*MASK Register */

#define INT_CONFIG_OFFSET           0x18         /**< \brief (CONFIG offset) Configuration n */
#define INT_CONFIG_RESETVALUE       (0x00000000) /**< \brief (CONFIG reset_value) Configuration n */
#define INT_CONFIG_SENSE0_POS      0            /**< \brief (CONFIG) Input Sense 0 Configuration */
#define INT_CONFIG_SENSE1_POS      4            /**< \brief (CONFIG) Input Sense 1 Configuration */
#define INT_CONFIG_SENSE2_POS      8            /**< \brief (CONFIG) Input Sense 2 Configuration */
#define INT_CONFIG_SENSE3_POS      12           /**< \brief (CONFIG) Input Sense 3 Configuration */
#define INT_CONFIG_SENSE4_POS      16           /**< \brief (CONFIG) Input Sense 4 Configuration */
#define INT_CONFIG_SENSE5_POS      20           /**< \brief (CONFIG) Input Sense 5 Configuration */
#define INT_CONFIG_SENSE6_POS      24           /**< \brief (CONFIG) Input Sense 6 Configuration */
#define INT_CONFIG_SENSE7_POS      28           /**< \brief (CONFIG) Input Sense 7 Configuration */

#define INT_CONFIG_SENSE0           (INT_CONFIG_SENSE_LOW_Val << INT_CONFIG_SENSE0_POS)
#define INT_CONFIG_SENSE5           (INT_CONFIG_SENSE_LOW_Val << INT_CONFIG_SENSE5_POS)
#define INT_CONFIG1_SENSE6          (INT_CONFIG_SENSE_LOW_Val << INT_CONFIG_SENSE6_POS)
#define INT_CONFIG1_SENSE7          (INT_CONFIG_SENSE_LOW_Val << INT_CONFIG_SENSE7_POS)
#define INT_CONFIG0_SENSE2			(INT_CONFIG_SENSE_BOTH_Val << INT_CONFIG_SENSE2_POS)

#define INT_CONFIG_SENSE_NONE_Val      (0x0)   /**< \brief (CONFIG) No detection */
#define INT_CONFIG_SENSE_RISE_Val      (0x1)   /**< \brief (CONFIG) Rising-edge detection */
#define INT_CONFIG_SENSE_FALL_Val      (0x2)   /**< \brief (CONFIG) Falling-edge detection */
#define INT_CONFIG_SENSE_BOTH_Val      (0x3)   /**< \brief (CONFIG) Both-edges detection */
#define INT_CONFIG_SENSE_HIGH_Val      (0x4)   /**< \brief (CONFIG) High-level detection */
#define INT_CONFIG_SENSE_LOW_Val       (0x5)   /**< \brief (CONFIG) Low-level detection */

#define INT_CONFIG_FILTEN0_POS     3            /**< \brief (CONFIG) Filter 0 Enable */
#define INT_CONFIG_FILTEN0          ((0x1UL) << INT_CONFIG_FILTEN0_POS)
#define INT_CONFIG_FILTEN1_POS     7            /**< \brief (CONFIG) Filter 1 Enable */
#define INT_CONFIG_FILTEN1          ((0x1UL) << INT_CONFIG_FILTEN1_POS)
#define INT_CONFIG_FILTEN2_POS     11           /**< \brief (CONFIG) Filter 2 Enable */
#define INT_CONFIG_FILTEN2          ((0x1UL) << INT_CONFIG_FILTEN2_POS)
#define INT_CONFIG_FILTEN3_POS     15           /**< \brief (CONFIG) Filter 3 Enable */
#define INT_CONFIG_FILTEN3          ((0x1UL) << INT_CONFIG_FILTEN3_POS)
#define INT_CONFIG_FILTEN4_POS     19           /**< \brief (CONFIG) Filter 4 Enable */
#define INT_CONFIG_FILTEN4          ((0x1UL) << INT_CONFIG_FILTEN4_POS)
#define INT_CONFIG_FILTEN5_POS     23           /**< \brief (CONFIG) Filter 5 Enable */
#define INT_CONFIG_FILTEN5          ((0x1UL) << INT_CONFIG_FILTEN5_POS)
#define INT_CONFIG_FILTEN6_POS     27           /**< \brief (CONFIG) Filter 6 Enable */
#define INT_CONFIG_FILTEN6          ((0x1UL) << INT_CONFIG_FILTEN6_POS)
#define INT_CONFIG_FILTEN7_POS     31           /**< \brief (CONFIG) Filter 7 Enable */
#define INT_CONFIG_FILTEN7          ((0x1UL) << INT_CONFIG_FILTEN7_POS)
#define INT_CONFIG_MASK             (0xFFFFFFFF) /**< \brief (CONFIG) MASK Register */

#define INT_EIC_CTRL               (0x40001800) /**< \brief (EIC) Control */
#define INT_EIC_STATUS             (0x40001801) /**< \brief (EIC) Status */
#define INT_EIC_NMICTRL            (0x40001802) /**< \brief (EIC) Non-Maskable Interrupt Control */
#define INT_EIC_NMIFLAG            (0x40001803) /**< \brief (EIC) Non-Maskable Interrupt Flag Status and Clear */
#define INT_EIC_EVCTRL             (0x40001804) /**< \brief (EIC) Event Control */
#define INT_EIC_INTENCLR           (0x40001808) /**< \brief (EIC) Interrupt Enable Clear */
#define INT_EIC_INTENSET           (0x4000180C) /**< \brief (EIC) Interrupt Enable Set */
#define INT_EIC_INTFLAG            (0x40001810) /**< \brief (EIC) Interrupt Flag Status and Clear */
#define INT_EIC_WAKEUP             (0x40001814) /**< \brief (EIC) Wake-Up Enable */
#define INT_EIC_CONFIG0            (0x40001818) /**< \brief (EIC) Configuration 0 */
#define INT_EIC_CONFIG1            (0x4000181C) /**< \brief (EIC) Configuration 1 */

#define SCS_BASE_ADDR            (0xE000E000UL)                            /*!< System Control Space Base Address */
#define SysTick_BASE_ADDR        (SCS_BASE_ADDR +  0x0010UL)                    /*!< SysTick Base Address */
#define NVIC_BASE_ADDR           (SCS_BASE_ADDR +  0x0100UL) 
#define INT_SET_ENABLE_REG_OFFSET  0x000
#define INT_SET_ENABLE_REG       NVIC_BASE_ADDR + INT_SET_ENABLE_REG_OFFSET
#define INT_CLR_ENABLE_REG_OFFSET  0x080
#define INT_CLR_ENABLE_REG       NVIC_BASE_ADDR + INT_CLR_ENABLE_REG_OFFSET
#define INT_SET_PENDING_REG_OFFSET  0x100 
#define INT_SET_PENDING_REG       NVIC_BASE_ADDR + INT_SET_PENDING_REG_OFFSET
#define INT_CLR_PENDING_REG_OFFSET  0x180  
#define INT_CLR_PENDING_REG       NVIC_BASE_ADDR + INT_CLR_PENDING_REG_OFFSET

#define PINPA16A_EIC_EXTINT0          (16) /**< \brief EIC signal: EXTINT0 on PA16 mux A */
#define MUXPA16A_EIC_EXTINT0          (0)
#define PINMUXPA16A_EIC_EXTINT0   ((PINPA16A_EIC_EXTINT0 << 16) | PINPA16A_EIC_EXTINT0)

#define PINPA15A_EIC_EXTINT15        (15) /**< \brief EIC signal: EXTINT15 on PA15 mux A */
#define MUXPA15A_EIC_EXTINT15        (0)
#define PINMUXPA15A_EIC_EXTINT15  ((PINPA15A_EIC_EXTINT15 << 16) | MUXPA15A_EIC_EXTINT15)

#define INT_NVIC_SERCOM1            BIT(8)

#define INT_EIC_EXTINTEO02                          (1 << 02)
#define INT_EIC_WAKEUPEN02 		                (1 << 02)

#define INT_EIC_WAKEUPEN13 		                (1 <<13)
#define INT_EIC_WAKEUPEN14 		                (1 <<14)
#define INT_EIC_WAKEUPEN15                          (1 <<15) 
#define INT_EIC_EXTINTEO13                          (1 << 13)
#define INT_EIC_EXTINTEO14                          (1 << 14)
#define INT_EIC_EXTINTEO15 	                        (1 <<15)
#define INT_CTRL_ENABLE_POS                         1            /**< \brief (EIC_CTRL) Enable */
#define INT_CTRL_ENABLE                              ((0x1) << INT_CTRL_ENABLE_POS)

#define INT_EXT_INT02                                (1 << 02)

#define INT_EXT_INT13                                (1 << 13)
#define INT_EXT_INT14                                (1 << 14)
#define INT_EXT_INT15                                (1 << 15)
#define INT_EXT_WUP14                                (1 << 14)
#define INT_EXT_WUP15                                (1 << 15)
#define INT_EIC_IRQN                                    4
#define INT_EIC_SWRST                                (1 << 0)
/**************************************************************************************************

	Function:
	void INT_Init (void)

	Summary:
		This Function used to Inialize the interrupt control register

	Description:
		This Function Initialize the interrupt controller

	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void INT_Init(void);

/**************************************************************************************************

	Function:
	void INT_ExtIrqInit (UINT8 *pu8PortDisable)

	Summary:
		This Function used to Inialize the External interrupts

	Description:
		This Function Initialize the external interrupt controller

	Precondition:
		None.

	Parameters:
		pu8PortDisable - Pointing to buffer holding information port status whether enabled or disabled

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void INT_ExtIrqInit(UINT8 *pu8PortDisable);

/**************************************************************************************************

	Function:
	void INT_EICHandler (void)

	Summary:
		This Function process the External interrupts

	Description:
		This Function serves external interrupts

	Precondition:
		None.

	Parameters:
		None

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
void INT_EICHandler(void);

#endif
