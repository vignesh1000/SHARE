/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include <SERCOM_Spi.h>
#include "bootloaderapis.h"


const SPI_WRITE         SPI_Write = (SPI_WRITE)__SPI_Write;
const SPI_SYNCINIT      SPI_SyncInit = (SPI_SYNCINIT)__SPI_SyncInit;
const SPI_READ          SPI_Read = (SPI_READ)__SPI_Read;
const SPI_PORTINIT      SPI_PortInit=(SPI_PORTINIT)__SPI_PortInit;
const SPI_INIT          SPI_Init = (SPI_INIT)__SPI_Init;
const SPI_CHIPSELECTLOW SPI_ChipSelectLow = (SPI_CHIPSELECTLOW)__SPI_ChipSelectLow;
const SPI_CHIPSELECTHIGH SPI_ChipSelectHigh = (SPI_CHIPSELECTHIGH)__SPI_ChipSelectHigh;





