/*
 * Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
 *
 * Microchip licenses to you the right to use, modify, copy and distribute
 * Software only when embedded on a Microchip microcontroller or digital signal
 * controller that is integrated into your product or third party product
 * (pursuant to the sublicense terms in the accompanying license agreement).
 *
 * You should refer to the license agreement accompanying this Software for
 * additional information regarding your rights and obligations.
 *
 * SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
 * CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
 * OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
 * INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
 * SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
 * (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 */

#ifdef _IDEAL_
#ifndef LVDSDRIVER_H
#define	LVDSDRIVER_H

#include <stdinc.h>
#include <hal_uart_async.h>

/*Begin Macro Defines*/
/**************************************************************************************************/
/* FW Version Minor Number*/
#define SW_VER_MINOR                    (UINT8)((SYSTEM_FW_REV & 0x00F0)>>4)
/* FW Version Major Number*/
#define SW_VER_MAJOR                    (UINT8)((SYSTEM_FW_REV & 0x0F00)>>8)
/* FW Version Build Number*/
#define SW_VER_BUILD                    0x00
/* FW Version Patch Number*/
#define SW_VER_PATCH                    (UINT8)(SYSTEM_FW_REV & 0x000F)                      

/*Macros for CRC calculation*/
#define CRC8_POLYNOMIAL			0x9B	
#define CRC8_INITIAL_REMAINDER	        0xFF
#define CRC8_FINAL_XOR_VALUE	        0x00

#define CRC10_POLYNOMIAL		0x03D9
#define CRC10_INITIAL_REMAINDER	        0x03FF
#define CRC10_FINAL_XOR_VALUE	        0x0000

#define BITWIDTH8	                (8)
#define TOPBIT8		                (1 << (BITWIDTH8 - 1))

#define BITWIDTH10	                (10)
#define TOPBIT10	                (1 << (BITWIDTH10 - 1))

/*Maximum permissible time between any bus message in msec*/
#define BUS_MESSAGE_TIMEOUT		2000
/*Maximum permissible time between messages addressed to this CM in msec*/
#define ADDRESSED_MESSAGE_TIMEOUT	5000
/*
 *The number of times an alarm must be consecutively detected before setting an alarm condition.
  This does not apply to the bus message timeout alarm, which is handled separately. 
*/
#define ALARM_DETECT_COUNT		3


#define LVDS_TX_BUFFER_SIZE             64
#define LVDS_RX_BUFFER_SIZE             64

/* Set to 1 if the device is capable of drawing power from the inner power rails. 0 otherwise */
#define DEVICE_CAP_SUPPLY_1_CAPABLE	1
/* Set to 1 if the device is capable of drawing power from the outer power rails. 0 otherwise */
#define DEVICE_CAP_SUPPLY_2_CAPABLE	0		

/* The Product VDO value per the USB Power Delivery Spec for the attached Portable Device */
#define DEVICE_CAP_PRODUCT_VDO		0x00
/* The SVID value per the USB Power Delivery Spec for the attached Portable Device */
#define DEVICE_CAP_PRODUCT_SVID		0x00
/*Increment the Global alarm counter based on the individual alarms*/
#define INCREMENT_ALARM_COUNTER(X, Y)	(Y += X ? 1 : 0)
/*Minimum ADC Value on pin RC3 to consider input voltage to be acceptable */
#define MIN_DC_INPUT			1
/*Maximum time in msec to allow CM to operate with a low supply voltage */
#define MAX_FAULT_MODE_TIME		100		

/*Macros for LVDS functionality*/
#define LVDS_BUSADDRESS_MASTER          0x00
#define LVDS_BUSADDRESS_DEFAULT_SLV     0xFF
#define LVDS_TIMESLOT_SEL_INVALID       -1
#define LVDS_DEVID_ADDR                 0x0000FFF0
#define LVDS_RX_MIN_NUM_BYTES           4
#define LVDS_JUNK_PKT_SIZE_LIM          20
#define UART_RX_DIS_IDLE_TMR            5
#define UART_WRITE_IDLE_TMR             2
#define LVDS_65W_CUR_LIM                3250
#define LVDS_DEF_CUR_LIM                3000
#define LVDS_LED_ON_500                 500
#define LVDS_LED_ON_2000                2000
#define LVDS_LED_OFF_2000               2000
/**************************************************************************************************/
/*End Macro Defines*/

/*Begin Variable Declaration*/
/**************************************************************************************************/
/**
 * Enum Name            - ControlMessage 
 * Enum Description     - Holds the control message types
 *
 * Enum variables:  
 * Name                                     Function
 *
 * ControlMessage_Ping                      Ping Message
 * ControlMessage_Acknowledge               Acknowledgment Message
 * ControlMessage_Wait                      Wait Message
 * ControlMessage_BadCRC                    CRC error control message
 * ControlMessage_SoftReset                 Soft reset message
 * ControlMessage_StopBER                   Stop BER control message
 * ControlMessage_SendBERFrame              Send BER message
 * ControlMessage_Error                     Error message
 * ControlMessage_GetCRCErrors              GET CRC error message
 * ControlMessage_GetTemp                   Get Temp Control message 
 * ControlMessage_GetFirmwareVer            Get FW Version message 
 * ControlMessage_GetAlarmStatus            Alarm status message
 * ControlMessage_GetAuthentication         Authendication message
 */
/**************************************************************************************************/
typedef enum 
{
    ControlMessage_Reserved,
    ControlMessage_Ping,
    ControlMessage_Acknowledge,
    ControlMessage_Wait,
    ControlMessage_BadCRC,
    ControlMessage_SoftReset,
    ControlMessage_StopBER,
    ControlMessage_SendBERFrame,
    ControlMessage_Error,
    ControlMessage_SendMonCommand,
    ControlMessage_GetCRCErrors,
    ControlMessage_GetTemp,
    ControlMessage_GetFirmwareVer,
    ControlMessage_GetAlarmStatus,
    ControlMessage_GetAuthentication,
    ControlMessage_,
    
} ControlMessage;

/**************************************************************************************************/
/**
 * Enum Name        - Data Message 
 * Enum Description - Holds the data message types
 *
 * Enum variables:  
 * Name                                      Function
 *
 *	DataMessage_GetNewDevices            Get New Device request from Master   
 *	DataMessage_SendID                   Send ID data message         
 *	DataMessage_SetBusAddress            Set Bus Address message from Master
 *	DataMessage_SendChallenge            Send Challenge Message from Master
 *	DataMessage_SendAuthentication       Send Authendication message to Master
 *	DataMessage_StartCurrentMeasure      Start current  measurement request from Master
 *	DataMessage_GetCurrent               Get current request from Master
 *	DataMessage_SendCurrent              Send Current measurement to master   
 *	DataMessage_GetDeviceCap             Get Device capabilities from master
 *	DataMessage_SendDeviceCap            Send Device capabilities to master 
 *	DataMessage_SetMaxPower              Set max power request from Master
 *	DataMessage_BERFrame                 BER FRame
 *	DataMessage_BERErrors                Send BER Errors 
 *	DataMessage_MonCommand               Mon command  
 *	DataMessage_MonResponse              Mon Response
 *	DataMessage_SendCRCErrors            Send CRC error data message
 *	DataMessage_SendTemp                 Send Temp measurement data message
 *	DataMessage_StartRxBER               Start RxBER
 *	DataMessage_StartTxBER               Start Tx BER
 *	DataMessage_SendFirmwareVer          Send FW version to master 
 *	DataMessage_SendAlarmStatus          Send Alarm status to master
 *	DataMessage_GetTestMeasure           Hanle Test measure request from Master
 *	DataMessage_SendTestMeasure          Send Test Meaurement to master
 */
/**************************************************************************************************/
typedef enum 
{
    DataMessage_GetNewDevices = 32,
    DataMessage_SendID,
    DataMessage_SetBusAddress,
    DataMessage_SendChallenge,
    DataMessage_SendAuthentication,
    DataMessage_StartCurrentMeasure,
    DataMessage_GetCurrent,
    DataMessage_SendCurrent,
    DataMessage_GetDeviceCap,
    DataMessage_SendDeviceCap,
    DataMessage_SetMaxPower,
    DataMessage_BERFrame,
    DataMessage_BERErrors,
    DataMessage_MonCommand,
    DataMessage_MonResponse,
    DataMessage_SendCRCErrors,
    DataMessage_SendTemp,
    DataMessage_StartRxBER,
    DataMessage_StartTxBER,
    DataMessage_SendFirmwareVer,
    DataMessage_SendAlarmStatus,
    DataMessage_GetTestMeasure,
    DataMessage_SendTestMeasure,
    DataMessage_,
} DataMessage;

/**************************************************************************************************/
/**
 * Enum Name        - TestMeasureSelect 
 * Enum Description - Holds the Test Measure message types
 *
 * Enum variables:  
 * Name                                         Function
 *
 *	TestMeasure_Reserved                    Reserved Enum   
 *	TestMeasure_SendTempAdc                 Sends Temperature ADC value         
 *	TestMeasure_SendBusOutVoltageAdc        Sends Bus Output Voltage ADC value
 *	TestMeasure_SendRegulatorOutVoltageAdc  Sends Regulator Output voltage ADC value
 *	TestMeasure_SendInputVoltageAdc         Sends Input voltage ADC value
 *	TestMeasure_SendCurrentSenseAdc         Sends Current Sense ADC value
 *	TestMeasure_SendPowerGoodState          Sends power good state value
 *	TestMeasure_SendMemoryValue             Sends Memory Value   
 *	TestMeasure_SetMemoryValue              Sets memory value
 *	TestMeasure_SendChargingState           Sends the charging state 
 *	TestMeasure_SendRegulatorEnableState    Sends the regulator enable state
 *	TestMeasure_SendDeviceIdByte            Sends the Device ID byte
 *	TestMeasure_SendAlarmCounter            Sends the alarm counter
 */
/**************************************************************************************************/
typedef enum
{
    TestMeasure_Reserved,
    TestMeasure_SendTempAdc,
    TestMeasure_SendBusOutVoltageAdc,
    TestMeasure_SendRegulatorOutVoltageAdc,
    TestMeasure_SendInputVoltageAdc,
    TestMeasure_SendCurrentSenseAdc,
    TestMeasure_SendPowerGoodState,
    TestMeasure_SendMemoryValue,
    TestMeasure_SetMemoryValue,
    TestMeasure_SendChargingState,
    TestMeasure_SendRegulatorEnableState,
    TestMeasure_SendDeviceIdByte,
    TestMeasure_SendAlarmCounter
      
} TestMeasureSelect;

/**************************************************************************************************/
/**
 * Enum Name        - LedState 
 * Enum Description - Holds the LED state types
 *
 * Enum variables:  
 * Name                                         Function
 *
 *	LedOn                           LED is on indefinitey 
 *	LedOff                          LED is off indefinitey          
 *	LedBlink0p5                     LED is 500mS on and 2S Off
 *	LedBlink2p0                     LED is 2S on and 2S Off
 */
/**************************************************************************************************/
typedef enum
{
    LedOn,
    LedOff,
    LedBlink0p5,
    LedBlink2p0
      
} LedState;

/**************************************************************************************************/
/**
 * Enum Name        - PowerSetting 
 * Enum Description - Holds the Power Settings for UPD in deciwatt
 *
 * Enum variables:  
 * Name                                         Function
 *
 *	PowerSetting_Err                        0 Watt 
 *	PowerSetting_0                          15 Watts          
 *	PowerSetting_1                          27 Watts
 *	PowerSetting_2                          45 Watts
 *	PowerSetting_3                          65 Watts
 */
/**************************************************************************************************/
typedef enum
{
    PowerSetting_Err    = 0,
    PowerSetting_0      = 150,
    PowerSetting_1      = 270,
    PowerSetting_2      = 450,
    PowerSetting_3      = 650
      
} PowerSetting;

/**************************************************************************************************/
/**
 * Enum Name        - SupplySelect 
 * Enum Description - Holds the power supply selection type
 *
 * Enum variables:  
 * Name                                         Function
 *
 *	Inner                           Draw power from inner rails
 *	Outer                           Draw power from outer rails
 */
/**************************************************************************************************/
typedef enum
{
    Inner,
    Outer
      
} SupplySelect;

/**************************************************************************************************/
/**
 * Structure Name        - CurrentMeasureParams 
 * Structure Description - Holds the Curent Measure parameters
 *
 * Structure variables:  
 * Name                  Type         Function
 * messageId             UINT8        Holds the Msg ID of the corresponding Current measure data
 * numberOfMeasurements  UINT8        Holds the number of measurements to be taken
 * samplesLengthMsec     UINT32       Holds the interval duration in which the sample must be taken
 */
/**************************************************************************************************/
typedef struct
{
    UINT8  messageId;
    UINT8  numberOfMeasurements;
    UINT32 samplesLengthMsec;
	
} CurrentMeasureParams;

/**************************************************************************************************/
/**
 * Structure Name        - CurrentMeasureState 
 * Structure Description - Holds the Curent Measure values
 *
 * Structure variables:  
 * Name                  Type         Function
 * measurementIndex      UINT8        Holds the number of intervals to sample data
 * currentMeasure        UINT32       Holds the value of current measured
 * numberOfBadReadings   UINT8        Holds the number of bad current readings encountered
 */
/**************************************************************************************************/
typedef struct
{
    UINT8  measurementIndex;
    UINT32 currentMeasure;	
    UINT8  numberOfBadReadings;
    
} CurrentMeasureState;

/**************************************************************************************************/
/**
 * Structure Name        - MessageHeader 
 * Structure Description - Holds the LVDS Message header
 *
 * Structure variables:  
 * Name                 Type                    Function
 * msgType              UINT8                 Holds the LVDS message type 
 * msgId                UINT8                 Holds the LVDS message ID
 * numDataBytes         UINT8                 Holds the number of LVDS message data bytes
 */
/**************************************************************************************************/
typedef struct
{
    UINT8 msgType;
    UINT8 msgId;
    UINT8 numDataBytes;
    
} MessageHeader;

/**************************************************************************************************/
/**
 * Structure Name        - Packet 
 * Structure Description - Holds the LVDS packet fields
 *
 * Structure variables:  
 * Name                 Type                    Function
 * busAddress          UINT8                 Holds the LVDS device Bus Address 
 * messageHeader       MessageHeader         Holds the LVDS message header
 * data[]              UINT8                 Holds the LVDS message data bytes in array
 */
/**************************************************************************************************/
typedef struct 
{
    UINT8               busAddress;
    MessageHeader       messageHeader;
    UINT8               data[20];
    
} Packet;

/**************************************************************************************************/
/**
 * Union Name        - AlarmStatus 
 * Union Description - Holds the Alarm status of LVDS protocol
 *
 * Union variables:  
 * Name                         Type                    Function
 * bits                         Struct bits         BitFields containing bits of different monitors
 *
    * alarmState                - UINT8:1
    * tempAlarm                 - UINT8:1
    * inputVoltageAlarm         - UINT8:1
    * inputCurrentAlarm         - UINT8:1
    * outputVoltageAlarm        - UINT8:1
    * powerGoodAlarm            - UINT8:1
    * busMessageTimeoutAlarm    - UINT8:1
    * rxOverrunWarning          - UINT8:1
    * reserved  UINT8 
 *
 * value                        UINT16               
 * bytes[2]                     UINT8
 */
/**************************************************************************************************/
typedef union
{
    struct
    {
        UINT8 alarmState:1;
        UINT8 tempAlarm:1;
        UINT8 inputVoltageAlarm:1;
        UINT8 inputCurrentAlarm:1;
        UINT8 outputVoltageAlarm:1;
        UINT8 powerGoodAlarm:1;
        UINT8 busMessageTimeoutAlarm:1;
        UINT8 rxOverrunWarning:1;
        UINT8 reserved;
        
    } bits;
    
    UINT16 value;
    UINT8  bytes[2];
    
} AlarmStatus;

/**************************************************************************************************/
/**
 * Structure Name        - Packet 
 * Structure Description - Holds the LVDS packet fields
 *
 * Structure variables:  
 * Name                         Type                    Function
 * alarmState                   UINT16                 Holds the LVDS overall alarm state 
 * tempAlarm                    UINT16                 indicates LVDS Temperature alarm 
 * inputVolatageAlarm           UINT16                 indicates LVDS device input volatage error 
 * inputCurrentAlarm            UINT16                 indicates LVDS device input current error
 * outputVoltageAlarm           UINT16                 indicates LVDS device output volatage error
 * powerGoodAlarm               UINT16                 indicates LVDS power good alarm 
 * busMessageTimeoutAlarm       UINT16                 indicates LVDS bus timed out
 * rxOverrunWarning             UINT16                 indicates LVDS communication overrun
 */
/**************************************************************************************************/
typedef struct
{
    UINT16 alarmState;
    UINT16 tempAlarm;
    UINT16 inputVoltageAlarm; 
    UINT16 inputCurrentAlarm;
    UINT16 outputVoltageAlarm;
    UINT16 powerGoodAlarm;
    UINT16 busMessageTimeoutAlarm;
    UINT16 rxOverrunWarning;
    
} AlarmCounter;

/**************************************************************************************************/
/**
 * Structure Name        - DeviceCapabilities0 
 * Structure Description - Holds the Device capability 0 Fields
 *
 * Structure variables:  
 * Name                         Type            Function
 *
 * deviceType                   UINT8           Holds the type of TypeC device 
 * powerSetting1                UINT16          Holds the value corresponding to PwrSetting 1 
 * powerSetting2                UINT16          Holds the value corresponding to PwrSetting 2 
 * powerSetting3                UINT16          Holds the value corresponding to PwrSetting 3
 * powerSetting4                UINT16          Holds the value corresponding to PwrSetting 4
 * efficiency                   UINT8           Holds the efficiency of the UPD system 
 * isSupply1Capable             UINT8           Indicates whether it can draw power from inner rails
 * isSupply2Capable             UINT8           Indicates whether it can draw power from Outer rails
 * supportsPowerDelivery        UINT8           Indicates whether UPD is PD capable
 * reserved                     UINT8           Reserved
 */
/**************************************************************************************************/
typedef struct
{
    UINT8  deviceType;
    UINT16 powerSetting1;
    UINT16 powerSetting2;
    UINT16 powerSetting3;
    UINT16 powerSetting4;
    UINT8  efficiency;
    UINT8  isSupply1Capable;
    UINT8  isSupply2Capable;
    UINT8  supportsPowerDelivery;
    UINT8  reserved;
    
} DeviceCapabilities0;

/**************************************************************************************************/
/**
 * Structure Name        - DeviceCapabilities1 
 * Structure Description - Holds the Device capability 1 Fields
 *
 * Structure variables:  
 * Name                         Type            Function
 *
 * SVID                         UINT8           Holds the SVID of UPD301 
 * ProductVDO                   UINT16          Holds the VDO info of UPD301 
 */
/**************************************************************************************************/
typedef struct
{
    UINT8 SVID;
    UINT8 ProductVDO;
    
} DeviceCapabilities1;

/**************************************************************************************************/
/**
 * Structure Name        - Time 
 * Structure Description - Holds the time in milli seconds
 *
 * Structure variables:  
 * Name                 Type                    Function
 * msec                UINT16                 Holds the count/time in milli seconds 
 */
/**************************************************************************************************/
typedef struct
{
    UINT16 msec;
    
} Time;

/**************************************************************************************************/
/**
 * Structure Name        - SystemState 
 * Structure Description - Holds the LVDS system variables
 *
 * Structure variables:  
 * Type                 Name                    Function
 * UINT16	         busAddress		Currently assigned bus address 
 * bool		         outputEnabled		Indicates if DC-DC converter is enabled 
 * PowerSetting          powerSetting		The current power setting of the module 
 * AlarmStatus	         alarmStatus		Contains the current alarm status of the CM
 * AlarmCounter	         alarmCounter	        Contains the count for each alarm
 * UINT16	         inputCurrent		Measured input current in mA 
 * UINT16	         dcInputLevel		ADC value corresponding to the current input level 
 * SupplySelect	         supplySelect	        The currently selected rail used to draw power 
 * UINT8		 getNewDevicesMsgId	The message ID for the most recent GetNewDevices  
 * UINT8		 timeSlotsPerMsg	Available time slots exist per GetNewDevices message
 * INT8		         selectedTimeSlot	timeslot selected to respond to the GetNewDevices  
 * UINT8		 isSendIdSent		Indicates that we sent our ID to the CCM 
 * UINT8		 isSetBusAddrRcvd	Indicates that we received the SetBusAddress message 
 * UINT8		 isWaitingLowVoltage    alarm check detected a low voltage condition
 * UINT8		 lowVoltageWaitCount    mS Since the low voltage condition has been active 
 * UINT32	         busMessageElapsedMsec	mS Since the last message on the bus was received	
 * UINT32	         addressedElapsedMsec	mS Since the last message addressed to us was rcvd	
 * CurrentMeasureParams  currentMeasureParams   variables which stores the Current w.r.t Msg ID
 * CurrentMeasureState	 currentMeasureState[8] Current measurement state per possible message ID 
 * UINT8                 u8MilliSecCtr          Counter to initialize the Random number block
 *
 */
/**************************************************************************************************/
typedef struct
{
    UINT16	         busAddress;		/*Currently assigned bus address. Value of 255 indicates no bus address is assigned. */
    bool		 outputEnabled;		/*Indicates if the output of the +5V DC-DC converter is enabled */
    PowerSetting         powerSetting;		/*The current power setting of the module */
    AlarmStatus	         alarmStatus;		/*Contains the current alarm status of the CM, indicating if it's in alarm, and which alarm was triggered */
    AlarmCounter	 alarmCounter;	        /*Contains the count for each alarm, indicating how many times an alarm was triggered */
    UINT16	         inputCurrent;		/*Measured input current in mA */
    UINT16	         dcInputLevel;		/*ADC value corresponding to the current DC input level */
    SupplySelect	 supplySelect;	        /*The currently selected rail used to draw power */
    UINT8		 getNewDevicesMsgId;	/*The message ID for the most recent GetNewDevices message. Used to calculate the current timeslot. */
    UINT8		 timeSlotsPerMsg;	/*How many available time slots exist per GetNewDevices message. Used to calculate the current timeslot. */
    INT8		 selectedTimeSlot;	/*The timeslot selected to respond to the GetNewDevices message */
    UINT8		 isSendIdSent;		/*Indicates that we sent our ID to the CCM. */
    UINT8		 isSetBusAddrRcvd;	/*Indicates that we received the SetBusAddress message. */
    UINT8		 isWaitingLowVoltage;   /*Indicates that the alarm check detected a low voltage condition and is waiting for it to clear */
    UINT8		 lowVoltageWaitCount;   /*The approximate number of msec that the low voltage condition has been active */
    UINT32	         busMessageElapsedMsec;	/*The approximate number of msec since the last message on the bus was received	*/
    UINT32	         addressedElapsedMsec;	/*The approximate number of msec since the last message addressed to us was received	*/
    CurrentMeasureParams currentMeasureParams;
    CurrentMeasureState	 currentMeasureState[8];/*Current measurement state per possible message ID */
    UINT8                u8MilliSecCtr;         /* Counter to initialize the Random number block*/

} SystemState;
/**************************************************************************************************/
/*End Variable Declaration*/

/*Begin Function Declaration*/
/**************************************************************************************************/
/*
 * \Function Name           - Compute_CRC8 
 * \Function Description    - Function which calculates CRC8 
 * \param[in] message[]     - const array variable of type UINT8
 * \param[in] nBytes        - variable of type UINT32
 * \return                  - UINT8
 */
/**************************************************************************************************/
UINT8 Compute_CRC8(UINT8 const message[], UINT32 nBytes);

/**************************************************************************************************/
/*
 * \Function Name           - Compute_CRC10 
 * \Function Description    - Function which calculates CRC10 
 * \param[in] message[]     - const array variable of type UINT8
 * \param[in] nBytes        - variable of type UINT32
 * \return                  - UINT16
 */
/**************************************************************************************************/
UINT16 Compute_CRC10(UINT8 const message[], UINT32 nBytes);

/**************************************************************************************************/
/*
 * \Function Name          - CheckLVDSMsg 
 * \Function Description   - State machine which handles the LVDS requests, Alarms and LED states
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void CheckLVDSMsg(void);

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_SetMaxPower 
 * \Function Description    - Function which assigns the power for negotiating with a PD device
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_SetMaxPower(void);

/**************************************************************************************************/
/*
 * \Function Name          - HandleControlMessage_GetFirmwareVer 
 * \Function Description   - Function which returns the firmware version of UPD for GetFirmwareVer
 *                           Request
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void HandleControlMessage_GetFirmwareVer(void);

/**************************************************************************************************/
/*
 * \Function Name          - HandleDataMessage_GetNewDevices 
 * \Function Description   - Function which returns the device ID for the GetNewDevices request
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void HandleDataMessage_GetNewDevices(void);

/**************************************************************************************************/
/*
 * \Function Name          - HandleDataMessage_SetBusAddress 
 * \Function Description   - Function which assigns the bus address and acknowledges the 
 *                           SetBusAddress request
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void HandleDataMessage_SetBusAddress(void);

/**************************************************************************************************/
/*
 * \Function Name           - SendControlMessage 
 * \Function Description    - Function which sends the 0 byte response packet to master
 * \param[in] msgType       - variable of type UINT8
 * \return                  - void
 */
/**************************************************************************************************/
void SendControlMessage(UINT8 msgType);

/**************************************************************************************************/
/*
 * \Function Name           - LVDS_FramePacket 
 * \Function Description    - Function which frames the response packet to CCM master
 * \param[in] messageHeader - variable of type MessageHeader
 * \param[in] data          - Pointer to type UINT8
 * \param[in] dataSize      - variable of type UINT16
 * \return                  - void
 */
/**************************************************************************************************/
void LVDS_FramePacket(MessageHeader messageHeader, uint8_t *data, uint16_t dataSize);

/**************************************************************************************************/
/*
 * \Function Name           - HandleControlMessage_Ping 
 * \Function Description    - Function which sends an acknowledge response to ping message
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleControlMessage_Ping(void);

/**************************************************************************************************/
/*
 * \Function Name          - HandleControlMessage_SoftReset 
 * \Function Description   - Function which resets the entire UPD
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void HandleControlMessage_SoftReset(void);

/**************************************************************************************************/
/*
 * \Function Name           - InitRand 
 * \Function Description    - Function which initializes the seed for random number generation
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void InitRand(void);

/**************************************************************************************************/
/*
 * \Function Name           - HandleControlMessage_GetAlarmStatus 
 * \Function Description    - Function which sends the alarms status to CCM master
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleControlMessage_GetAlarmStatus(void);

/**************************************************************************************************/
/*
 * \Function Name          - LvdsInitGlobalVariables 
 * \Function Description   - function which initializes the LVDS system variables 
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void LvdsInitGlobalVariables(void);

/**************************************************************************************************/
/*
 * \Function Name           - rand 
 * \Function Description    - Function which generates a random number
 * \param[in]               - void
 * \return                  - UINT8
 */
/**************************************************************************************************/
UINT8 rand (void);

/**************************************************************************************************/
/*
 * \Function Name           - EnterAlarmState 
 * \Function Description    - Function which disables PD functionality on exceeding the threshold
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void EnterAlarmState(void);

/**************************************************************************************************/
/*
 * \Function Name           - CheckForAlarms 
 * \Function Description    - State Machine which checks if any input Voltage, Current or Bus Idle 
 *                            time exceeds the threshold
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void CheckForAlarms(void);

/**************************************************************************************************/
/*
 * \Function Name           - CheckIndividualAlarms 
 * \Function Description    - State Machine which checks if Current or Bus Idle 
 *                            time exceeds the threshold
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void CheckIndividualAlarms(void);

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_StartCurrentMeasure 
 * \Function Description    - Function which initiates the current measure on arrival of  
 *                            StartCurrentMeasure Request
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_StartCurrentMeasure(void);

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_GetCurrent 
 * \Function Description    - Function which responds the current measured to the CCM master
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_GetCurrent(void);

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_GetDeviceCap 
 * \Function Description    - Function which sends the device capabilities to the Master
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_GetDeviceCap(void);

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_GetTestMeasure 
 * \Function Description    - Function which provides the information regarding the alarms to the 
 *                            CCM master
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_GetTestMeasure(void);

/**************************************************************************************************/
/*
 * \Function Name           - Ideal_UARTInit 
 * \Function Description    - Function which initializes UART RX/TX registers and SW variables
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void Ideal_UARTInit(void);

/**************************************************************************************************/
/*
 * \Function Name          - UpdateLedState 
 * \Function Description   - State Machine which modifies the LED state based on the allocated Power
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void UpdateLedState(void);

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_UARTCollisionIdleCB 
 * \Function Description   - Callback Function which enables RX data reception on UART after 
 *                           data collision
 * \param[in] dummy1       - variable of type UINT8
 * \param[in] dummy2       - variable of type UINT8
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_UARTCollisionIdleCB (UINT8 dummy1, UINT8 dummy2);

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_UARTWriteCB 
 * \Function Description   - Callback Function to send the data to CCM
 * \param[in] dummy1       - variable of type UINT8
 * \param[in] dummy2       - variable of type UINT8
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_UARTWriteCB (UINT8 dummy1, UINT8 dummy2);

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_CurrMeasCB 
 * \Function Description   - Callback Function which stores the Current measured at definite 
 *                           intervals to the corresponding Message ID 
 * \param[in] dummy1       - variable of type UINT8
 * \param[in] dummy2       - variable of type UINT8
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_CurrMeasCB (UINT8 dummy1, UINT8 dummy2);

/**************************************************************************************************/
/*
 * \Function Name          - ReadLVDSMsg 
 * \Function Description   - State machine which handles the LVDS data and control Messages
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void ReadLVDSMsg(void);

/**************************************************************************************************/
/*
 * \Function Name          - ReadLvdsDeviceID 
 * \Function Description   - function which reads the device ID from the specified address 
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void ReadLvdsDeviceID(void);

/**************************************************************************************************/
/*End Function Declaration*/
#endif	/* LVDS driver*/

#endif