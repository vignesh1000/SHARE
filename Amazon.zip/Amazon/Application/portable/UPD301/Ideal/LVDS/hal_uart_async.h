/**
 * \file
 *
 * \brief USART related functionality declaration.
 *
 * Copyright (c) 2014-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
#ifdef _IDEAL_
   
#ifndef _HAL_USART_H_INCLUDED
#define _HAL_USART_H_INCLUDED

#include <SERCOM_UART.h>

/*Begin Macro Defines*/
/**************************************************************************************************/
/*External Clock frequency for UART baud rate generator*/
#define EXT_OSC_FREQUENCY               14745600    

/*RXPO[20:21] is 0x03 SERCOM PAD[3] is configured for UART */
#define SERCOM_UART_CTRLA_RXPO_SERCOM_PAD2          BIT(21)

/* TXPO 1 - SERCOM PAD[2], 0 - SECOM PAD[1] */       
#define SERCOM_UART_CTRLA_TXPO_SERCOM_PAD0          (0<<16)

/*The Data will be sampled on the Rising edge and Transmited on the falling edge of XCK*/
#define SERCOM_UART_CTRLA_CPOL          BIT(29)

/*Ideal Defined Max Baud Rate*/
#define SERCOM_IDEAL_UART_BAUDRATE    	230400

/* Baud rate calculation*/
#define IDEAL_SERCOM_UART_BAUD_REG_VALUE(u32BaudRate)      \
(uint16_t)(65536 - ((65536 * 16.0f * u32BaudRate) / EXT_OSC_FREQUENCY))

/*SERCOM Interrupt Flag Register Definitions*/
#define SERCOM_UART_INTFLAG_TXC         BIT(1)

/*SERCOM Interrupt Enable Set Register Definitions*/
#define SERCOM_UART_INTENSET_DRE        BIT(0)
#define SERCOM_UART_INTENSET_TXC        BIT(1)
#define SERCOM_UART_INTENSET_RXC        BIT(2)

/*SERCOM Status Register Definitions*/
#define SERCOM_UART_STATUS_PERR         BIT(0)
#define SERCOM_UART_STATUS_FERR         BIT(1)
#define SERCOM_UART_STATUS_BUFOVF       BIT(2)

#define SERCOM_UART_STAT_ERR_MSK        (SERCOM_UART_STATUS_PERR | \
                                         SERCOM_UART_STATUS_FERR | \
                                         SERCOM_UART_STATUS_BUFOVF)

/**************************************************************************************************/
/*End Macro Defines*/

/*Begin Variable Declaration*/
/**************************************************************************************************/
/**
 * Enum Name        - E_USART_TX_STATUS 
 * Enum Description - Variables holding the status of the Transmission
 */
/**************************************************************************************************/
typedef enum usart_tx_status
{ 
    USART_TX_STATUS_IDLE, 
    USART_TX_STATUS_BUSY
      
}E_USART_TX_STATUS;

/**************************************************************************************************/
/**
 * Structure Name        - USART_RX_BUFFER 
 * Structure Description - Holds the functional variables of RX buffer
 *
 * Structure variables:  
 * Name                 Type             Function
 * pu8Buf               (UINT8 *)        pointer to RX buffer
 * u8BufSize            UINT8            Holds the Buffer size (Mask)
 * u8BufReadIdx         UINT8            Holds the Read Index buffer pointer
 * u8BufWriteIdx        UINT8            Holds the Write Index buffer pointer
 * u8NumByToRd          UINT8            Holds the Number of Bytes yet to be read by the App
 * u8RxBufOverFlow      UINT8            Holds the SW Buffer Overflow status
 * u8RxError            UINT8            Holds the RX Hardware error status
 * u8Reserved[3]        UINT8            Reserved (For Alignment)       
 */
/**************************************************************************************************/
typedef struct usart_rx_buffer 
{
    UINT8  *pu8Buf;         
    UINT8  u8BufSize;        
    UINT8  u8BufReadIdx;  
    UINT8  u8BufWriteIdx; 
    UINT8  u8NumByToRd;   
    UINT8  u8RxBufOverFlow;
    UINT8  u8RxError;
    UINT8  u8Reserved[2];
    
}USART_RX_BUFFER;

/**************************************************************************************************/
/**
 * Structure Name        - USART_TX_BUFFER 
 * Structure Description - Holds the functional variables of TX buffer
 *
 * Structure variables:  
 * Name                 Type                    Function
 * u8TxPor              UINT8                   Holds the Point of reference to the 
 * pu8TxBuf             (UINT8 *)               Pointer to the transmit Buffer
 * u8TxBufLen           UINT8                   Holds the length of the transmit buffer
 * eTxStat              E_USART_TX_STATUS       Holds the transmit status
 */
/**************************************************************************************************/
typedef struct usart_tx_buffer 
{
    UINT8                   u8TxPor;                    
    UINT8                   *pu8TxBuf;                    
    UINT8                   u8TxBufLen;                 
    E_USART_TX_STATUS       eTxStat;     
    
}USART_TX_BUFFER;

/**************************************************************************************************/
/**
 * Structure Name        - USART_DESC 
 * Structure Description - Holds the functional variables of TX, RX and callback feature
 *
 * Structure variables:  
 * Name                 Type                            Function
 * sUSARTDescCb          USART_DESC_CALLBACK        Holds the function Pointers for callback 
 * sUSARTRx              USART_RX_BUFFER            Variables used to traverse RX Buffer
 * sUSARTTx              USART_TX_BUFFER            Variables used to traverse TX Buffer *               
 */
/**************************************************************************************************/
typedef struct usart_descriptor 
{
    USART_RX_BUFFER       sUSARTRx;
    USART_TX_BUFFER       sUSARTTx;
        
}USART_DESC;
/**************************************************************************************************/
/*End Variable Declaration*/

/*Extern the Global Structure variable to access the status and other relevant information*/
extern USART_DESC gsUSARTDesc;

/*Begin Function Declarations*/
/**************************************************************************************************/
/* 
 * \Function Name          - Ideal_USARTInit 
 * \Function Description   - This function initializes the Clocks, Pins and SERCOM 
 *                           for UART communication
 * \param[in] pu8RxBuffer  - The pointer pointing to the Databuffer which receives 
 *                           the databytes from data register 
 * \param[in] u8RxBuflen   - Size of RX buffer
 * \return                 - (INT32) The error status.
 */
/**************************************************************************************************/
INT32 Ideal_USARTInit(UINT8 *pu8RxBuffer, UINT8 u8RxBuflen);

/**************************************************************************************************/
/*
 * \Function Name       - Ideal_USARTRead 
 * \Function Description- This function reads the given data to UART Rx buffer
 * \param[in] pu8Buf    - The pointer pointing to the Databuffer to which data 
 *                        must be received
 * \param[in] u16Length - The number of bytes to read
 * \return              - (INT32) The number of bytes read.
 */
/**************************************************************************************************/
INT32 Ideal_USARTRead(UINT8 *pu8Buf, UINT8 u8Length);

/**************************************************************************************************/
/*
 * \Function Name       - Ideal_USARTWrite 
 * \Function Description- This function writes the given data to UART interface
 * \param[in] pu8Buf    - The pointer pointing to the Databuffer whose data must be
 *                        transmitted
 * \param[in] u8Length  - The number of bytes to write
 * \return              - (INT32) The number of bytes written.
 */
/**************************************************************************************************/
INT32 Ideal_USARTWrite(UINT8 *pu8Buf, UINT8 u8Length);

/*End Function Declarations*/

#endif /* _HAL_USART_ASYNC_H_INCLUDED */
#endif
