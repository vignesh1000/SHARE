/**
 * \file
 *
 * \brief I/O USART related functionality implementation.
 *
 * Copyright (c) 2014-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
#ifdef _IDEAL_
   
#include <hal_uart_async.h>

/*Instance of Global UART structure variable*/
USART_DESC gsUSARTDesc;

/*Begin function Definitions*/
/**************************************************************************************************/
/*
 * \Function Name          - Ideal_USARTInit 
 * \Function Description   - This function initializes the Clocks, Pins and SERCOM and Buffers for 
 *                           UART communication
 * \param[in] pu8RxBuffer  - The pointer pointing to the Databuffer which receives the databytes 
 *                           from data register 
 * \param[in] u8RxBuflen   - Size of RX buffer
 * \return                 - (INT32) The error status.
 */
/**************************************************************************************************/
INT32 Ideal_USARTInit(UINT8 *pu8RxBuffer, UINT8 u8RxBuflen)
{
    
    /*******************UART RX Buffer Initialization Begin********************/
    
    /*Obtaining the RX buffer Handle from the desriptor*/
    USART_RX_BUFFER *psBufRx = &gsUSARTDesc.sUSARTRx;
    
    /* Check if the buf size is aligned to power of 2 - For Ring Buffer Impl*/
    if ((u8RxBuflen & (u8RxBuflen - 1)) != 0) 
    {
        return ERR_INVALID_ARG;
    }

    /*Check if the Allocated Buffer is not a NULL buffer*/
    if(NULL == pu8RxBuffer)
    {
        return ERR_NO_RESOURCE;
    }
    
    /* Assign the Buffer size; This variable also acts as a Buffer length Mask*/
    psBufRx->u8BufSize       = u8RxBuflen - 1;
    /* Assign the Buffer Read Index*/
    psBufRx->u8BufReadIdx    = 0;
    /* Assign the Buffer Write Index - Ring Buffer Mechanism*/
    psBufRx->u8BufWriteIdx   = psBufRx->u8BufReadIdx;
    /*Assign the Number of bytes to be read variable to 0*/
    psBufRx->u8NumByToRd     = 0;
    /*Initialize the overflow status to 0*/
    psBufRx->u8RxBufOverFlow = 0;
    /*Initialize the Error status to 0*/
    psBufRx->u8RxError       = 0;
    /* Assign the Buffer Address*/
    psBufRx->pu8Buf          = pu8RxBuffer;
    
    /*******************UART RX Buffer Initialization Ends*********************/
    
    /*******************UART TX Buffer Initialization Begin********************/
    
    /*Obtaining the TX buffer Handle from the desriptor*/
    USART_TX_BUFFER *psBufTx = &gsUSARTDesc.sUSARTTx;

    /*Initialize the Transmission status to IDLE*/
    psBufTx->eTxStat         = USART_TX_STATUS_IDLE;    
    /*Initialize the TX Buffer Point of reference to 0*/
    psBufTx->u8TxPor         = 0;
    /*Initialize the Buffer length as 0*/
    psBufTx->u8TxBufLen      = 0;
    /*Initialize the Buffer Pointer to a NULL pointer*/
    psBufTx->pu8TxBuf        = NULL;
    
    /*******************UART TX Buffer Initialization Ends*********************/
    
    /*******************SERCOM Initialization for UART Begins******************/
    
    /* Select AHBC bus clk for SERCOM0 */    
    REGDW(PM_APBCMASK_REG)  |= PM_APBCMASK_SERC0M0;
    
     /* Select Generater0 and set CLK enable bit*/
    REGW(GCLK_CLKCTRL_REG)   = ((GCLK_CLKCTRL_ID(GCLK_CLKCTRL_ID_SERCOM0_CORE)) | 
                                (GCLK_CLKCTRL_GEN(GCLK_CLKCTRL_GEN_GCLK0_Val))  | 
                                (GCLK_CLKCTRL_CLKEN));

    /* Wait Until SYNCBUSY bit to clear*/
    while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);

    /*Soft Reset*/
    REGW(SERCOM_UART_CTRLA_REG)  = SERCOM_UART_CTRLA_SWRST;

    /* Synchronization Wait Until SYNCBUSY bit to clear */
    while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);

    /*************** CTRLA register configuration ******************************* 
    *  MODE    - 0x1   External clock 
    *  CMODE   - 0x0   Asynchronous mode
    *  RXPO    - 0x02  SERCOM PAD[2]
    *  TXPO    - 0x00  SERCOM PAD[0]
    *  DORD    - 0x01  MSB first 
    ***************************************************************************/
    REGDW(SERCOM_UART_CTRLA_REG) = (SERCOM_UART_CTRLA_DORD | \
                                    SERCOM_UART_CTRLA_TXPO_SERCOM_PAD0 |\
                                    SERCOM_UART_CTRLA_RXPO_SERCOM_PAD2|\
                                    SERCOM_UART_CTRLA_MODE_EXT_CLK);
    
    while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);
    
    /*************** CTRLB register configuration ******************************* 
    *  CHSIZE  - 0x0   Character Size to 8 bit 
    *  SBMODE  - 0x0   One Stop bit
    *  TXEN    - 0x01  Transmitter Enable
    *  RXEN    - 0x01  Receiver Enable
    ***************************************************************************/
    REGDW(SERCOM_UART_CTRLB_REG) = (SERCOM_UART_CTRLB_TXEN | SERCOM_UART_CTRLB_RXEN);

    while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);
    
    /* BAUD Register*/
    REGW(SERCOM_UART_BAUD_REG)   = IDEAL_SERCOM_UART_BAUD_REG_VALUE(SERCOM_IDEAL_UART_BAUDRATE);
    
    /*Set Pin For UART Transmission*/  
    GPIO_SetPinFunction (PIN_PA04, PINMUX_PA04D_SERCOM0_PAD0);
  
    /*Set the Pin Direction of USART XCK to be OUT*/
    GPIO_SetDirection(PIN_PA05, GPIO_SETDIRECTION_IN);
    
    /*Set the Pin for USART XCK*/
    GPIO_SetPinFunction (PIN_PA05, PINMUX_PA05D_SERCOM0_PAD1);
    
    /*Set Pin For UART Reception*/
    GPIO_SetPinFunction (PIN_PA06, PINMUX_PA06D_SERCOM0_PAD2);    

    /*******************SERCOM Initialization for UART Ends********************/
    
    /*********************SERCOM3 Interrupt initialization Begins**************/
    
    /*Enable UART receiver interrupt to receive data*/
    REGB(SERCOM_UART_INTENSET_REG) |= SERCOM_USART_INTENSET_RXC;

    /*Disable IRQ of SERCOM0 to clear the pending interrupts*/
    NVIC_DisableIRQ(SERCOM0_IRQn);
    
    /*Clear the Pending SERCOM0 Interrupts*/
    NVIC_ClearPendingIRQ(SERCOM0_IRQn);
    
    /*Enable SERCOM0 IRQ*/
    NVIC_EnableIRQ(SERCOM0_IRQn);
    
    /* Enable UART*/
    REGDW(SERCOM_UART_CTRLA_REG) |= SERCOM_UART_CTRLA_ENABLE;
    
    while((REGW(SERCOM_UART_STATUS_REG))& SERCOM_UART_STATUS_SYNCBUSY);
    
    /*********************SERCOM3 Interrupt initialization Ends****************/    

    return ERR_NONE;
}
/**************************************************************************************************/
/*
 * \Function Name       - Ideal_USARTWrite 
 * \Function Description- This function writes the given data to UART interface
 * \param[in] pu8Buf    - The pointer pointing to the Databuffer whose data must be
 *                        transmitted
 * \param[in] u8Length  - The number of bytes to write
 * \return              - (INT32) Write status.
 */
/**************************************************************************************************/
INT32 Ideal_USARTWrite(UINT8 *pu8Buf, UINT8 u8Length)
{
    USART_TX_BUFFER *psBufTx = &gsUSARTDesc.sUSARTTx;
    
    /*Check if there are any bytes already in the Queue to be transmitted*/
    if (psBufTx->u8TxPor != psBufTx->u8TxBufLen) 
    {
        return ERR_NO_RESOURCE;
    }
    
    /*Assign the TX buffer address to the Pointer*/
    psBufTx->pu8TxBuf         = pu8Buf;
    /*Assign the Number of bytes to be transmitted*/
    psBufTx->u8TxBufLen       = u8Length;
    /*Initialize the write pointer to first index*/
    psBufTx->u8TxPor          = 0;
    /*Set the TX status as BUSY (0x01)*/
    psBufTx->eTxStat          = USART_TX_STATUS_BUSY;
    
    /*Enable the Data ready Interrupt*/
    REGB(SERCOM_UART_INTENSET_REG)  = SERCOM_UART_INTENSET_DRE;
    
    
    /*Return the number of bytes transmitted*/
    return (INT32)u8Length;
}

/**************************************************************************************************/
/*
 * \Function Name       - Ideal_USARTRead 
 * \Function Description- This function reads the given data to UART Rx buffer
 * \param[in] pu8Buf    - The pointer pointing to the Databuffer to which data 
 *                        must be received
 * \param[in] u8Length  - The number of bytes to read
 * \return              - (INT32) The number of bytes read.
 */
/**************************************************************************************************/
INT32 Ideal_USARTRead(UINT8 *pu8Buf, UINT8 u8Length)
{
    UINT8 u8BytesRead = 0;
    UINT8 u8NumOfElem;
    USART_RX_BUFFER *psBufRx = &gsUSARTDesc.sUSARTRx;
    
    /*Disable the Global interrupt*/
    CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
    
    /*Identify the number of Bytes yet to be read from the RX buffer*/
    u8NumOfElem = psBufRx->u8NumByToRd;
    
    /*Enable the Global interrupt*/
    CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();

    /*Check periodically whether the Required bytes are read; Also check if 
      number of bytes read does not exceed the unread bytes of RX buffer*/
    while ((u8BytesRead < u8NumOfElem) && (u8BytesRead < u8Length)) 
    {        
        /*Copy the data from the RX buffer to the buffer specified by the App*/
        *(pu8Buf + u8BytesRead) = psBufRx->pu8Buf[psBufRx->u8BufReadIdx++];
        
        /*Move the read index to start of the buffer if the index exceeds 
          the buffer size*/
        psBufRx->u8BufReadIdx = (psBufRx->u8BufReadIdx & psBufRx->u8BufSize);
        
        /*Increment the number of bytes read*/
        u8BytesRead++;
    }    
    
    /*Decrement the number of bytes to be read by App*/
    psBufRx->u8NumByToRd = psBufRx->u8NumByToRd - u8BytesRead;

    /*Return the number of bytes read by the app*/
    return (INT32)u8BytesRead;
}

/**************************End UART Module Functions***************************/

/**************************Begin UART SERCOM Handler***************************/


/**************************************************************************************************/
/*
 * \Function Name       - SERCOM3_Handler 
 * \Function Description- This function handles the interrupts enabled on SERCOM3 Core
 * \return              - void.
 */
/**************************************************************************************************/
void SERCOM0_Handler(void)
{
    UINT8 u8UARTData = 0;
    USART_RX_BUFFER *psBufRx = &gsUSARTDesc.sUSARTRx;
    USART_TX_BUFFER *psBufTx = &gsUSARTDesc.sUSARTTx;   
  
    /*
     * -> Check if the DATA REGISTER EMPTY bit is set in the INTFLAG register
     * -> Also Check if the DATA REGISTER EMPTY interrupt is enabled in the 
     *    INTENSET Register
     */
    
    if ((FALSE != (REGB(SERCOM_UART_INTFLAG_REG)  & SERCOM_UART_INTFLAG_DRE ))&&\
        (FALSE != (REGB(SERCOM_UART_INTENSET_REG) & SERCOM_UART_INTENSET_DRE))) 
    {
        /*Disable the DATA REGISTER EMPTY interrupt*/
        REGB(SERCOM_UART_INTENCLR_REG) = SERCOM_UART_INTENSET_DRE;
        
        /*Check if there is any pending data to be transmitted*/
        if (psBufTx->u8TxPor != psBufTx->u8TxBufLen) 
        {
            /*Write the Data from the TX buffer to the DATA register*/
            REGB(SERCOM_UART_DATA_REG) = (UINT8)(psBufTx->pu8TxBuf[psBufTx->u8TxPor++]);
            
            /*Enable the DATA REGISTER EMPTY interrupt*/
            REGB(SERCOM_UART_INTENSET_REG) = SERCOM_UART_INTENSET_DRE;
        } 
        else /*Else Enable the TRANSMIT COMPLETE interrupt*/
        {
            REGB(SERCOM_UART_INTENSET_REG) = SERCOM_UART_INTENSET_TXC;
        }
    } 
    /*
     * -> Check if the TRANSMIT COMPLETE bit is set in the INTFLAG register
     * -> Also Check if the TRANSMIT COMPLETE interrupt is enabled in the 
     *    INTENSET Register
     */
    else if ((FALSE != (REGB(SERCOM_UART_INTFLAG_REG)  & SERCOM_UART_INTFLAG_TXC ))&&\
             (FALSE != (REGB(SERCOM_UART_INTENSET_REG) & SERCOM_UART_INTENSET_TXC)))
    {
        /*Disable the TRANSMIT COMPLETE interrupt*/
        REGB(SERCOM_UART_INTENCLR_REG) = SERCOM_UART_INTENSET_TXC;
        
        /*Update the Transmission Status to IDLE*/
        psBufTx->eTxStat = USART_TX_STATUS_IDLE;
    }
    /*
     * -> Check if the RECEIVE COMPLETE bit is set in the INTFLAG register
     */
    else if (FALSE != (REGB(SERCOM_UART_INTFLAG_REG) & SERCOM_UART_INTFLAG_RXC)) 
    {       
        /*Check if there are any Parity, Frame or buffer overflow errors*/
        if (FALSE != (REGB(SERCOM_UART_STATUS_REG) & ((UINT8)SERCOM_UART_STAT_ERR_MSK)))
        {
            /*Clear the Status Register*/
            REGB(SERCOM_UART_STATUS_REG) = (UINT8)SERCOM_UART_STAT_ERR_MSK;

            /*If Error - increment the HW Error counter*/
            psBufRx->u8RxError++;
        }
        else
        {            
            /*Read the received data from the DATA register*/
            u8UARTData = REGB(SERCOM_UART_DATA_REG);
            
            /*Copy the Read data to the Data buffer*/
            psBufRx->pu8Buf[psBufRx->u8BufWriteIdx++] = u8UARTData;
            
            /*Move the read index to start of the buffer if the index exceeds 
              the buffer size*/
            psBufRx->u8BufWriteIdx = (psBufRx->u8BufWriteIdx & psBufRx->u8BufSize);
            
            /*Increment the number of bytes to be read by App*/
            psBufRx->u8NumByToRd++;
            
            /*Check if the number of Bytes yet to be read by the App exceeds the
              number of bytes written to the buffer*/
            if(psBufRx->u8NumByToRd > (psBufRx->u8BufSize + 1))
            {
                /*If yes - increment the Overflow counter*/
                psBufRx->u8RxBufOverFlow++;
            }
        }
    }
}

/****************************End UART SERCOM Handler***************************/
#endif