/*
 * Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
 *
 * Microchip licenses to you the right to use, modify, copy and distribute
 * Software only when embedded on a Microchip microcontroller or digital signal
 * controller that is integrated into your product or third party product
 * (pursuant to the sublicense terms in the accompanying license agreement).
 *
 * You should refer to the license agreement accompanying this Software for
 * additional information regarding your rights and obligations.
 *
 * SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
 * CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
 * OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
 * INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
 * SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
 * (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 */

#ifdef _IDEAL_
#include <LVDSdriver.h>
#include <Power_Negotiation.h>

/*Begin Global variable definition*/
/**************************************************************************************************/
/* Received Packet Descriptor*/
Packet          receivedPacket;
/*Descriptor containing the LVDS system variables*/
SystemState     gSystemState;           

/*Array which holds the Voltage and Current ADC values*/
extern UINT16   gau16ADCval[2];
/*Timer ID for the UART write callback timer*/
extern UINT8    gu8UARTWriteTimerID;  
/*Timer ID for the Current Measure callback timer*/
extern UINT8    gu8CurrMeasTimerID;
 /*Descriptor containing the Power Negotiation state*/
extern PN_MNGR  gsPNMngr;  

extern float gdADCICalibFac;

/*Variable which holds the random value generated*/
static UINT8    gu8Next = 1;  
/*UART transmitter Buffer*/
static UINT8    gau8LVDSTxBuff[LVDS_TX_BUFFER_SIZE];
/*Number of bytes to transmit*/
volatile UINT8  gu8TxBytesCount;  

/* This variable keeps track of the consecutive number of times an alarm is detected*/
UINT8 gu8alarmDetCnt;
/* Seed Value for Random Number Generator Block*/
UINT8 gu8Seed;  
/* LVDS Receive buffer*/
UINT8 gu8UARTRxBuff[LVDS_RX_BUFFER_SIZE]; 
/*Control variable to identify if the entire header packet is received*/
BOOL gbHeaderByteRc             = TRUE;
/*Pointer to the UART RX descriptor*/
USART_RX_BUFFER *psBufRx        = &gsUSARTDesc.sUSARTRx;
/*UPD301 Device ID buffer*/
UINT8 gau8LvdsDeviceId[9]       ={0}; 

/*LED timer - Holds the time elapsed*/
UINT16 gu16LedTimerMsec         = 0;
/*Holds the status of LED*/
BOOL gbLedOnorOff               = FALSE;
/*Holds the duration upto which the LED must stay off*/
UINT16 gu16LedoffValue          = 0;
/*Holds the duration upto which the LED must stay ON*/
UINT16 gu16LedOnValue           = 0;
/**************************************************************************************************/
/*End Global variable Definition*/

/*Begin Function Definitions*/
/**************************************************************************************************/
/**************************************************************************************************/
/*
 * \Function Name          - LvdsInitGlobalVariables 
 * \Function Description   - function which initializes the LVDS system variables 
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void LvdsInitGlobalVariables(void)
{
    /*Bus address assigned as 0xFF - default Bus address*/
    gSystemState.busAddress                                     = LVDS_BUSADDRESS_DEFAULT_SLV;
    /*No Time slot has been selected*/
    gSystemState.selectedTimeSlot                               = LVDS_TIMESLOT_SEL_INVALID;
    /*ID is not sent to the CCM master*/
    gSystemState.isSendIdSent                                   = FALSE;
    /*SetBusAddress request is not received*/
    gSystemState.isSetBusAddrRcvd                               = FALSE;
    /*Bus Message timeout is initialized to 0*/
    gSystemState.busMessageElapsedMsec                          = 0;
    /*The address Message timeout is initialized to 0*/
    gSystemState.addressedElapsedMsec                           = 0;
    /*Alarm status is reset to 0*/
    gSystemState.alarmStatus.value                              = 0;
    /*The system is initialized to draw power from inner rails*/
    gSystemState.supplySelect                                   = Inner;
    /*Power setting is initialized to Error/No power*/
    gSystemState.powerSetting                                   = PowerSetting_Err;
    /*The system input Voltage is not low*/
    gSystemState.isWaitingLowVoltage                            = FALSE;
    /*The system input Low voltage wait count is reset to Zero*/
    gSystemState.lowVoltageWaitCount                            = 0;
    /*The Bus message timeout alarm is reset to 0*/
    gSystemState.alarmCounter.busMessageTimeoutAlarm            = 0;
    /*The input current alarm is set to 0*/
    gSystemState.alarmCounter.inputCurrentAlarm                 = 0;
    /*The input voltage alarm is set to 0*/
    gSystemState.alarmCounter.inputVoltageAlarm                 = 0;
    
    /*The unhandled alarms are set to 0 -as per spec*/
    gSystemState.alarmCounter.outputVoltageAlarm                = 0;
    gSystemState.alarmCounter.powerGoodAlarm                    = 0;
    gSystemState.alarmCounter.rxOverrunWarning                  = 0;
    gSystemState.alarmCounter.tempAlarm                         = 0;
    
    /*The overall alarm state is reset to 0*/
    gSystemState.alarmCounter.alarmState                        = 0;    
    /*The seed value for Random function is initialized to 0*/
    gSystemState.u8MilliSecCtr                                  = 0;
    /*The Message ID for CurrentMeasure request is set to 0*/
    gSystemState.currentMeasureParams.messageId                 = 0;
    /*The number of Current measurements to be taken is set to 0*/
    gSystemState.currentMeasureParams.numberOfMeasurements      = 0;
    /*The duration till which the samples must be taken is set to 0*/
    gSystemState.currentMeasureParams.samplesLengthMsec         = 0;
}

/**************************************************************************************************/
/*
 * \Function Name          - ReadLvdsDeviceID 
 * \Function Description   - function which reads the device ID from the specified address 
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void ReadLvdsDeviceID(void)
{    
#ifdef _TEST_LVDS_
    volatile UINT8* ptr = (UINT8*)0x0080A00C;
    
    gau8LvdsDeviceId[0] = *ptr;
    ptr++;
    gau8LvdsDeviceId[1] = *ptr;
    ptr++;
    gau8LvdsDeviceId[2] = *ptr;
    ptr++;
    gau8LvdsDeviceId[3] = *ptr;
    ptr++;
    
    ptr = (UINT8*)0x0080A040;
   
    gau8LvdsDeviceId[4] = *ptr;
    ptr++;
    gau8LvdsDeviceId[5] = *ptr;
    ptr++;
    gau8LvdsDeviceId[6] = *ptr;
    ptr++;
    gau8LvdsDeviceId[7] = *ptr;
    ptr++;
    gau8LvdsDeviceId[8] = *ptr;  
#else
    
    UINT8 u8Iter = 0;
    volatile UINT8* pu8DevID = (UINT8*)(LVDS_DEVID_ADDR);
    
    /*Read the 9 bytes of serial number from the address specified in the ptr*/
    for (u8Iter = 0; u8Iter < 9; u8Iter++)
    {
        gau8LvdsDeviceId[u8Iter] = *(pu8DevID + u8Iter);
    }
    
#endif
}

/**************************************************************************************************/
/*
 * \Function Name          - CheckLVDSMsg 
 * \Function Description   - State machine which handles the LVDS requests, Alarms and LED states
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void CheckLVDSMsg(void)
{
    /*Process the received LVDS message from the CCM master*/
    ReadLVDSMsg();
    
    /*Check if Voltage/Current or Bus timeout needs attention*/
    CheckForAlarms();
    
    /*Update the LED state based on the power contract negotiated*/
    UpdateLedState ();
    
    /*Check if there is no bus request to the registered Puck for more than 5S*/
    if (gSystemState.addressedElapsedMsec > ADDRESSED_MESSAGE_TIMEOUT)
    {
        /* force ourselves to register again*/  
      
        /*Reset the Bus message timeout counter*/
        gSystemState.addressedElapsedMsec       = 0;
        /*Reset the bus address to its default address*/
        gSystemState.busAddress                 = LVDS_BUSADDRESS_DEFAULT_SLV;
        /*reset the Time slot selected to -1*/
        gSystemState.selectedTimeSlot           = LVDS_TIMESLOT_SEL_INVALID;
        /*Set the FW to send the Device ID again*/        
        gSystemState.isSendIdSent               = FALSE;
        /*Wait for the master to send the SetBusAddress request*/
        gSystemState.isSetBusAddrRcvd           = FALSE;
    } 
  
}

/**************************************************************************************************/
/*
 * \Function Name          - ReadLVDSMsg 
 * \Function Description   - State machine which handles the LVDS data and control Messages
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void ReadLVDSMsg(void)
{ 
    UINT8 LVDSTempBuff[20] = {0};
    UINT8 headerHB;
    UINT8 headerLB; 
    UINT16 receivedCrc;
    UINT16 calculatedCrc;
    bool isCrcOk = FALSE;
    
    /*Check if the header byte is yet to be received*/
    if(gbHeaderByteRc)
    {
        /* any valid message must have at least 4 bytes*/
        if (psBufRx->u8NumByToRd >= LVDS_RX_MIN_NUM_BYTES) 
        {
            /* 1st Byte is bus address*/
            receivedPacket.busAddress = psBufRx->pu8Buf[\
                                                        (psBufRx->u8BufReadIdx + 0)&\
                                                        (psBufRx->u8BufSize)\
                                                       ];
            /*Copy the 2nd and 3rd bytes of the msg*/
            headerHB                  = psBufRx->pu8Buf[\
                                                        (psBufRx->u8BufReadIdx + 1)&\
                                                        (psBufRx->u8BufSize)\
                                                       ];
            
            headerLB                  = psBufRx->pu8Buf[\
                                                        (psBufRx->u8BufReadIdx + 2)&\
                                                        (psBufRx->u8BufSize)\
                                                       ];
             
            /* Number of data bytes to receive*/
            receivedPacket.messageHeader.numDataBytes = (headerHB >> 1) & 0x7F;            
            /* Parse MsgID and Type*/
            receivedPacket.messageHeader.msgId = \
                                              (((headerHB & 0x01) << 2)|((headerLB & 0xC0) >> 6));
            receivedPacket.messageHeader.msgType = headerLB & 0x3F;
            
            /*Check if a Junk packet is received*/
            if(receivedPacket.messageHeader.numDataBytes > LVDS_JUNK_PKT_SIZE_LIM)
            {
                /*Disable the Global Interrupt*/
                CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
                
                /*Reset the UART receive Buffer variables*/
                psBufRx->u8BufReadIdx   = 0;
                psBufRx->u8BufWriteIdx  = 0;
                psBufRx->u8NumByToRd    = 0;
                
                /*Disable the UART Receiver*/
                REGDW(SERCOM_UART_CTRLB_REG) &= ~(SERCOM_UART_CTRLB_RXEN);
                
                /*Enable the Global Interrupt*/
                CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();
                
                /*Start timer to enable the UART receiver after 5mS*/
                PDTimer_Start(\
                              MILLISECONDS_TO_TICKS(UART_RX_DIS_IDLE_TMR),\
                              Ideal_UARTCollisionIdleCB,\
                              NULL,\
                              NULL\
                              );                
            }
            else
            {
                /*VAlid packet - Header byte is received*/
                gbHeaderByteRc = FALSE;
            }
        }
    }
    /* Wait till the complete packet is received after Header bytes*/
    else if(psBufRx->u8NumByToRd >= (receivedPacket.messageHeader.numDataBytes + 4))
    {
        /*Enable the State machine to read new header packets*/
        gbHeaderByteRc = TRUE;
        
        /*Bus request is received before the IDLE timer expires*/
        gSystemState.busMessageElapsedMsec = 0;
        
        /* Copy the recieved data bytes*/
        if(FALSE != receivedPacket.messageHeader.numDataBytes)
        {
            for (UINT8 i =0; i < receivedPacket.messageHeader.numDataBytes; i++)
            {
                receivedPacket.data[i] = psBufRx->pu8Buf[\
                                                        ((psBufRx->u8BufReadIdx + 3) + i)&\
                                                        (psBufRx->u8BufSize)\
                                                        ];
            }
        }
        
        /* determine if we can even pay attention based on the address*/
        if (LVDS_BUSADDRESS_MASTER != receivedPacket.busAddress)
        {
            /* CHeck if the message is not a SendChallenge Message and allocate a byte for CRC*/            
            if (receivedPacket.messageHeader.msgType != (UINT8)DataMessage_SendChallenge)
            {
                /*Receive the Actual CRC sent by the master*/
                receivedCrc = psBufRx->pu8Buf[\
                                            (psBufRx->u8BufReadIdx + \
                                            (receivedPacket.messageHeader.numDataBytes + 3))&\
                                            (psBufRx->u8BufSize)\
                                             ];
                  
                /*Copy the entire message for CRC calculation*/
                for (UINT8 i = 0; i < (receivedPacket.messageHeader.numDataBytes + 3); i++)
                {
                    LVDSTempBuff[i] = psBufRx->pu8Buf[\
                                                      (psBufRx->u8BufReadIdx + i)&\
                                                      (psBufRx->u8BufSize)\
                                                     ];
                }
                
                /* Calculate the CRC*/
                calculatedCrc = Compute_CRC8(\
                                              LVDSTempBuff, \
                                              (receivedPacket.messageHeader.numDataBytes + 3)\
                                             );
                
                /* Check if calculated CRC and Received CRC matches*/
                isCrcOk = (receivedCrc == calculatedCrc);
            }
            
            /* if we're not registered, we only care about the GetNewDevices and 
               SetBusAddress messages*/
            if (LVDS_BUSADDRESS_DEFAULT_SLV == gSystemState.busAddress)
            {
                /*respond only if CRC matches*/
                if (FALSE != isCrcOk)
                {
                    switch (receivedPacket.messageHeader.msgType)
                    {
                        case DataMessage_GetNewDevices:
                                HandleDataMessage_GetNewDevices();
                                break;
                        case DataMessage_SetBusAddress:
                                HandleDataMessage_SetBusAddress();
                                break;       
                        default:
                                /*SendControlMessage((UINT8)ControlMessage_Error);*/                  
                                break;
                    }
                }
            }
            /*Current measure request is a broadcast message - hence handled separately*/
            else if (receivedPacket.messageHeader.msgType == (UINT8)DataMessage_StartCurrentMeasure)
            {
                HandleDataMessage_StartCurrentMeasure();
            }
            /*If registered Handle all the rest of the LVDS messages*/
            else if (gSystemState.busAddress == receivedPacket.busAddress)
            {
                /*Reset the address elapsed timer since we have received a packet for the 
                  registered device*/
                gSystemState.addressedElapsedMsec = 0;
                
                /*respond only if CRC matches*/
                if (FALSE != isCrcOk)
                {
                    switch (receivedPacket.messageHeader.msgType)
                    {
                        case ControlMessage_GetAlarmStatus:
                                HandleControlMessage_GetAlarmStatus();
                                break;
                        case ControlMessage_Ping:
                                HandleControlMessage_Ping();
                                break;
                        case ControlMessage_SoftReset:
                                HandleControlMessage_SoftReset();
                                break;
                        case ControlMessage_GetFirmwareVer:
                                HandleControlMessage_GetFirmwareVer();
                                break;
                        case DataMessage_GetCurrent:
                                HandleDataMessage_GetCurrent();
                                break;
                        case DataMessage_GetDeviceCap:
                                HandleDataMessage_GetDeviceCap(); 
                                break;
                        case DataMessage_GetTestMeasure:
                                HandleDataMessage_GetTestMeasure();
                                break;
                        case DataMessage_SetMaxPower:
                                HandleDataMessage_SetMaxPower();
                                break;
                        case ControlMessage_GetAuthentication:  
                                /*HandleControlMessage_GetAuthentication();*/
                                break;
                        case ControlMessage_GetTemp:
                                /*HandleControlMessage_GetTemp();*/
                                break;
                        case ControlMessage_StopBER:
                                /*HandleControlMessage_StopBer();*/
                                break;
                        case ControlMessage_SendBERFrame:
                                /*HandleControlMessage_SendBerFrame();*/
                                break;
                        case DataMessage_BERFrame:
                                /*HandleDataMessage_BerFrame();*/
                                break;
                        case DataMessage_SendChallenge:
                                /*HandleDataMessage_SendChallenge();*/
                                break;
                        case DataMessage_StartRxBER:
                                /*HandleDataMessage_StartRxBer();*/
                                break;
                        case DataMessage_StartTxBER:
                                /*HandleDataMessage_StartTxBer();*/
                                break;

                        default:
                                /* Else the send Error msg*/
                                SendControlMessage((UINT8)ControlMessage_Error);
                    }
                }
            }
        }
        
        /* UART RX Buffer Overflow handling - Ring buffer*/
        psBufRx->u8BufReadIdx += \
          ((receivedPacket.messageHeader.numDataBytes + 4)&(psBufRx->u8BufSize));
        
        psBufRx->u8NumByToRd  -= \
          ((receivedPacket.messageHeader.numDataBytes + 4)&(psBufRx->u8BufSize));
    }
}

/**************************************************************************************************/
/*
 * \Function Name          - HandleControlMessage_SoftReset 
 * \Function Description   - Function which resets the entire UPD
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void HandleControlMessage_SoftReset(void)
{
    /*Reset the UPD301*/
    UPD301_Reset();
}

/**************************************************************************************************/
/*
 * \Function Name          - HandleControlMessage_GetFirmwareVer 
 * \Function Description   - Function which returns the firmware version of UPD for GetFirmwareVer
 *                           Request
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void HandleControlMessage_GetFirmwareVer(void)
{
    UINT8 u8Data[2];
    MessageHeader sMessageHeader;
    
    /*Assign the received Msg ID to the response Msg*/
    sMessageHeader.msgId         = receivedPacket.messageHeader.msgId;
    /*Sending the Firmware Version - MsgType SendFirmwareVer*/
    sMessageHeader.msgType       = DataMessage_SendFirmwareVer;
    /*2 Bytes required to transferthe data*/
    sMessageHeader.numDataBytes  = 2;
    
    /* Read the FW version*/
    u8Data[0] = SW_VER_MINOR << 4 | SW_VER_MAJOR;
    u8Data[1] = SW_VER_BUILD << 4 | SW_VER_PATCH;
    
    /* Frame the LVDSPacket to send*/
    LVDS_FramePacket(sMessageHeader, u8Data, sMessageHeader.numDataBytes);
    /* Send the LVDS packet*/
    gu8UARTWriteTimerID = PDTimer_Start(\
                                        MILLISECONDS_TO_TICKS(UART_WRITE_IDLE_TMR),\
                                        Ideal_UARTWriteCB,\
                                        NULL,\
                                        NULL\
                                        );
}

/**************************************************************************************************/
/*
 * \Function Name          - HandleDataMessage_GetNewDevices 
 * \Function Description   - Function which returns the device ID for the GetNewDevices request
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void HandleDataMessage_GetNewDevices(void)
{
    UINT8 dataByte;
    UINT8 numberOfMessages;
    UINT8 numberOfSlots;
    MessageHeader sMessageHeader;
    
    /*Check if the device is not registered - if so, ignore the request*/
    if (LVDS_BUSADDRESS_DEFAULT_SLV == gSystemState.busAddress)
    {
        /* Read the UPD Device ID*/
        ReadLvdsDeviceID();
        
        /*Parse the data message and identify the number of messages and number of slots*/
        dataByte                                = receivedPacket.data[0];
        numberOfMessages                        = (((dataByte & 0xF0) >> 5) + 1);
        numberOfSlots                           = ((dataByte & 0x1F) + 1);
        
        /*identify the total number of slots available*/
        UINT8 totalNumberOfSlots                = numberOfMessages * numberOfSlots;

        /*copy the message ID for the response*/
        gSystemState.getNewDevicesMsgId         = receivedPacket.messageHeader.msgId;          

        /*Did we send our ID and not get a response? If so, then send our ID again, but make sure to
          only do it in one of the messages*/
        if (0 == receivedPacket.messageHeader.msgId)
        {
            if(FALSE != gSystemState.isSendIdSent)
            {
                PDTimer_Kill(gu8UARTWriteTimerID);
            }
            
            /*Initialize the random generator*/
            InitRand();
            
            /*Obtain a random value and Use the random value to select the time slot*/
            gSystemState.selectedTimeSlot       = ((rand()) % totalNumberOfSlots);

            /*Frame the Message header and number of Data bytes*/            
            sMessageHeader.msgId                = (gSystemState.selectedTimeSlot / numberOfSlots);
            sMessageHeader.msgType              = (UINT8)DataMessage_SendID;
            sMessageHeader.numDataBytes         = 9;
            
            /*Frame the device ID*/
            LVDS_FramePacket(sMessageHeader, gau8LvdsDeviceId, sMessageHeader.numDataBytes);
            /*store the time slots to the system variables*/
            gSystemState.timeSlotsPerMsg        = numberOfSlots;
            
            /*initialize the Send ID state machine variables*/
            gSystemState.isSendIdSent           = FALSE;      
            gSystemState.isSetBusAddrRcvd       = FALSE;			
        }
        
        /*Corner case - check if the selceted time slot is 0*/
        if (0 == gSystemState.selectedTimeSlot)
        {
            /*Respond to the CCM master*/
            (void)Ideal_USARTWrite(gau8LVDSTxBuff,gu8TxBytesCount);
            /*Device ID is sent now*/
            gSystemState.isSendIdSent = TRUE;            
        }
        /*time slot is not 0*/
        else
        {
            /*Check if the current time slot resides in the received message ID*/
            if((gSystemState.getNewDevicesMsgId == (gSystemState.selectedTimeSlot/numberOfSlots))&&\
              (FALSE == gSystemState.isSendIdSent))
            {
                /*corner case - selected time slot matches the (message ID*number of slots)*/
                if((gSystemState.getNewDevicesMsgId*numberOfSlots) == gSystemState.selectedTimeSlot)
                {
                    /*Respond to the CCM master*/
                    (void)Ideal_USARTWrite(gau8LVDSTxBuff,gu8TxBytesCount);
                    /*Device ID is sent now*/
                    gSystemState.isSendIdSent = TRUE;
                }
                else
                {
                    /*Device ID is sent now*/
                    gSystemState.isSendIdSent = TRUE;
                    /*Wait till the time slot is reached and write the data*/
                    gu8UARTWriteTimerID = PDTimer_Start(\
                             MILLISECONDS_TO_TICKS(gSystemState.selectedTimeSlot % numberOfSlots),\
                             Ideal_UARTWriteCB,\
                             NULL,\
                             NULL\
                             );
                }
            }
            else 
            {
                    /*Do nothing - control will never reach here*/
            }
        }
    }
}

/**************************************************************************************************/
/*
 * \Function Name          - HandleDataMessage_SetBusAddress 
 * \Function Description   - Function which assigns the bus address and acknowledges the 
 *                           SetBusAddress request
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void HandleDataMessage_SetBusAddress(void)
{
    UINT8 u8IsNotOurDeviceId = FALSE;
    UINT8 u8Iter;
    
    /*Check if the Bus address corresponds to default address*/
    if (LVDS_BUSADDRESS_DEFAULT_SLV == receivedPacket.busAddress)
    {  
        for (u8Iter = 0; u8Iter < 9; u8Iter++)
        {
            /*Check if the device ID sent by CCM corresponds to our Device ID*/
            if((receivedPacket.data[u8Iter] != gau8LvdsDeviceId[u8Iter]))
            {
                u8IsNotOurDeviceId = TRUE;
                break;
            }
        }
        
        /* Received DeviceID from master Matched*/
        if (FALSE == u8IsNotOurDeviceId)
        {
            /*Bus address is assigned*/
            gSystemState.busAddress             = receivedPacket.data[u8Iter];
            /*registration is complete*/
            gSystemState.isSetBusAddrRcvd       = TRUE;
            /*Acknowledge the master*/            
            SendControlMessage((UINT8)ControlMessage_Acknowledge);
        }
    }
}

/**************************************************************************************************/
/*
 * \Function Name           - LVDS_FramePacket 
 * \Function Description    - Function which frames the response packet to CCM master
 * \param[in] messageHeader - variable of type MessageHeader
 * \param[in] data          - Pointer to type UINT8
 * \param[in] dataSize      - variable of type UINT16
 * \return                  - void
 */
/**************************************************************************************************/
void LVDS_FramePacket(MessageHeader messageHeader, UINT8 *data, UINT16 dataSize)
{
    UINT8  headerHB;
    UINT8  headerLB;
    UINT8  crc8;
    UINT16 crc16;
    UINT8  i;
    
    /* clear the buffer and fill the data bytes to 0x00*/
    for (i = 0; i != LVDS_TX_BUFFER_SIZE; i++)
    {
        gau8LVDSTxBuff[i] = 0x00;
    }
    
    /*Fill the Header Bytes 1 and 2 using the data parsed from the request*/
    headerHB = (dataSize << 1) | (messageHeader.msgId >> 2);
    headerLB = (messageHeader.msgId << 6) | (messageHeader.msgType);
    
    /*Initialize the number of bytes to transmit as 0*/
    gu8TxBytesCount = 0;
    
    /*Fill the Message ID with the address of master*/
    gau8LVDSTxBuff[gu8TxBytesCount++] = LVDS_BUSADDRESS_MASTER;
    /*Fill the Header bytes 1 and 2*/
    gau8LVDSTxBuff[gu8TxBytesCount++] = headerHB;
    gau8LVDSTxBuff[gu8TxBytesCount++] = headerLB;
    
    /*Fill the data bytes*/
    for (i = 0; i < dataSize; i++)
    {
        gau8LVDSTxBuff[gu8TxBytesCount++] = data[i];
    }
    /* calculate CRC8 If data msgs and control msgs*/
    if (messageHeader.msgType != (UINT8)DataMessage_SendAuthentication)
    {
        /*Calculate the CRC8*/
        crc8 = Compute_CRC8(gau8LVDSTxBuff, gu8TxBytesCount);
        /*store the CRC8 value in the response buffer*/
        gau8LVDSTxBuff[gu8TxBytesCount++] = crc8;
    }
    /*calculate CRC16 for sendchallenge msg*/
    else
    {
        /*Calculate the CRC16*/
        crc16 = Compute_CRC10(gau8LVDSTxBuff, gu8TxBytesCount);
        /*store the CRC16 value in the response buffer*/
        gau8LVDSTxBuff[gu8TxBytesCount++] = (uint8_t)(crc16 >> 8);
        gau8LVDSTxBuff[gu8TxBytesCount++] = (uint8_t)crc16;
    }
}

/**************************************************************************************************/
/*
 * \Function Name           - SendControlMessage 
 * \Function Description    - Function which sends the 0 byte response packet to master
 * \param[in] msgType       - variable of type UINT8
 * \return                  - void
 */
/**************************************************************************************************/
void SendControlMessage(UINT8 msgType)
{
    UINT8 *data = NULL;
    MessageHeader sMessageHeader;    
    
    /*Fill the Message header with MsgID, Msg Type and Number of data bytes to transmit*/
    sMessageHeader.msgId         = receivedPacket.messageHeader.msgId;
    sMessageHeader.msgType       = msgType;
    sMessageHeader.numDataBytes  = 0;
    
    /* Frame LVDS packet*/
    LVDS_FramePacket(sMessageHeader, data, sMessageHeader.numDataBytes);
    /*Send the Response packet to the master*/
    gu8UARTWriteTimerID = PDTimer_Start(\
                                        MILLISECONDS_TO_TICKS(UART_WRITE_IDLE_TMR),\
                                        Ideal_UARTWriteCB,\
                                        NULL,\
                                        NULL\
                                        );
}

/**************************************************************************************************/
/*
 * \Function Name           - Compute_CRC8 
 * \Function Description    - Function which calculates CRC8 
 * \param[in] message[]     - const array variable of type UINT8
 * \param[in] nBytes        - variable of type UINT32
 * \return                  - UINT8
 */
/**************************************************************************************************/
UINT8 Compute_CRC8(UINT8 const message[], UINT32 nBytes)
{
    UINT8 remainder = CRC8_INITIAL_REMAINDER;
    UINT8 currentByte;
    UINT8 currentBit;

    /*Perform modulo-2 division, one byte at a time*/
    for (currentByte = 0; currentByte < nBytes; ++currentByte)
    {
        /*Bring the next byte into the remainder*/
        remainder ^= (message[currentByte] << (BITWIDTH8 - 8));

        /*Perform modulo-2 division, a bit at a time*/
        for (currentBit = 8; currentBit > 0; --currentBit)
        {
            /*Try to divide the current data bit*/
            if (remainder & TOPBIT8)
            {
                remainder = (remainder << 1) ^ CRC8_POLYNOMIAL;
            }
            else
            {
                remainder = (remainder << 1);
            }
        }
    }

    /*The final remainder is the CRC result*/
    return (remainder ^ CRC8_FINAL_XOR_VALUE);
} 

/**************************************************************************************************/
/*
 * \Function Name           - Compute_CRC10 
 * \Function Description    - Function which calculates CRC10 
 * \param[in] message[]     - const array variable of type UINT8
 * \param[in] nBytes        - variable of type UINT32
 * \return                  - UINT16
 */
/**************************************************************************************************/
UINT16 Compute_CRC10(UINT8 const message[], UINT32 nBytes)
{
    unsigned short remainder = CRC10_INITIAL_REMAINDER;
    unsigned char currentByte;
    unsigned char currentBit;

    /*Perform modulo-2 division, one byte at a time*/
    for (currentByte = 0; currentByte < nBytes; ++currentByte)
    {
        /*Bring the next byte into the remainder*/
        remainder ^= (unsigned short)(message[currentByte] << (BITWIDTH10 - 8));

        /*Perform modulo-2 division, a bit at a time*/
        for (currentBit = 8; currentBit > 0; --currentBit)
        {
            /*Try to divide the current data bit*/
            if (remainder & TOPBIT10)
            {
                remainder = (remainder << 1) ^ CRC10_POLYNOMIAL;
            }
            else
            {
                remainder = (remainder << 1);
            }
        }
    }

    /*The final remainder is the CRC result*/
    remainder ^= CRC10_FINAL_XOR_VALUE;
    remainder &= 0x3FF;
    
    return (remainder);
}

/**************************************************************************************************/
/*
 * \Function Name           - HandleControlMessage_Ping 
 * \Function Description    - Function which sends an acknowledge response to ping message
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleControlMessage_Ping(void)
{
    /*Send the response message as Acknowledge*/
    SendControlMessage((UINT8)ControlMessage_Acknowledge);
}

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_SetMaxPower 
 * \Function Description    - Function which assigns the power for negotiating with a PD device
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_SetMaxPower(void)
{   
    /*UINT8 supplySelect = (receivedPacket.data[0] >> 2) & 0x01;*/
    UINT16 u16SetPower;
    
    /*Parse the power requested to be allocated by the CCM master*/
    u16SetPower = ((receivedPacket.data[0] & 0x03) << 8 | receivedPacket.data[1]);
    
    /*Check if any alarm has been triggered before setting the power*/
    if (gSystemState.alarmStatus.bits.alarmState)
    {
        /*if so, let the master know that an alarm has been triggered*/
        SendControlMessage((UINT8)ControlMessage_Error);
    }
    /*No alarms - proceed to power allocation*/
    else
    {
        /*Enable the output if the allocated power is not 0*/
        gSystemState.outputEnabled = ((FALSE != u16SetPower) ? TRUE : FALSE);
        
        /*Check if the device is already running at the power requested*/
        if (gSystemState.powerSetting == (PowerSetting)u16SetPower)
        {
            /*Do not modify the power , only acknowledge*/
            SendControlMessage((UINT8)ControlMessage_Acknowledge);
        }                    
        else
        {
            /*Request the power negotiator to modify power*/
            gsPNMngr.sPNPwrDesc.bIsPwrAlloc     = TRUE;
            gsPNMngr.sPNPwrDesc.u16ReqPwr       = u16SetPower;
            
            /*Change the power setting*/            
            gSystemState.powerSetting           = (PowerSetting)u16SetPower;
            
            /*Acknowledge the CCM master*/
            SendControlMessage((UINT8)ControlMessage_Acknowledge);
        }
    }
}

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_GetDeviceCap 
 * \Function Description    - Function which sends the device capabilities to the Master
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_GetDeviceCap(void)
{
    UINT8 u8CapType;
    UINT8 u8Data[8];
    MessageHeader sMessageHeader;
    DeviceCapabilities0 sDevCap0;
    DeviceCapabilities1 sDevCap1;

    /*Parse the Request from data message*/
    u8CapType = receivedPacket.data[0];
    
    /*Check if an invalid capability request is sent by the master*/
    if (u8CapType > 1)
    {
        /*Error response to CCM master*/
        SendControlMessage((UINT8)ControlMessage_Error);
    }
    else
    {
        /*valid request - fill the message ID and the Message type*/
        sMessageHeader.msgId     = receivedPacket.messageHeader.msgId;
        sMessageHeader.msgType   = (UINT8)DataMessage_SendDeviceCap;
        
        /*Check if the capability type requested is 0 or 1*/
        if (u8CapType == 0)
        {
            /*Frame the capability information*/
            sMessageHeader.numDataBytes      = 8;
            
            /*30W PD device - Ideal to take care of this field*/
#if 0
            sDevCap0.deviceType              = 3;
#else
            sDevCap0.deviceType              = 4;
#endif
            /*Power profiles supported 15/27/45/60 W*/
            sDevCap0.powerSetting1           = 150;
            sDevCap0.powerSetting2           = 270;
            sDevCap0.powerSetting3           = 450;
            sDevCap0.powerSetting4           = 650;
            /*100% efficiency - Ideal to take care of this field*/
            sDevCap0.efficiency              = 100;
            /*Can draw power only from inner rails*/
            sDevCap0.isSupply1Capable        = DEVICE_CAP_SUPPLY_1_CAPABLE;
            sDevCap0.isSupply2Capable        = DEVICE_CAP_SUPPLY_2_CAPABLE;
            /*UPD301 supports power delivery*/
            sDevCap0.supportsPowerDelivery   = 1;
            
            /*Frame the data message from the capability information*/
            u8Data[0] = sDevCap0.deviceType;
            u8Data[1] = (uint8_t)sDevCap0.powerSetting1;
            u8Data[2] = ((sDevCap0.powerSetting1 >> 8) & 0x03 ) | (sDevCap0.powerSetting2 << 2);
            u8Data[3] = ((sDevCap0.powerSetting2 >> 6) & 0x0F ) | (sDevCap0.powerSetting3 << 4);
            u8Data[4] = ((sDevCap0.powerSetting3 >> 4) & 0x3F ) | (sDevCap0.powerSetting4 << 6);
            u8Data[5] = ((sDevCap0.powerSetting4 >> 2) );
            u8Data[6] = (sDevCap0.efficiency & 0x7F)  |  (sDevCap0.isSupply1Capable << 7);
            u8Data[7] = (sDevCap0.isSupply2Capable)	|  (sDevCap0.supportsPowerDelivery << 1);
        }
        else
        {
            /*Frame the capability information*/
            sMessageHeader.numDataBytes = 2; 
            /*Dummy SVID and VDO info - UPD301 won't support SVIDs or VDOs*/
            sDevCap1.ProductVDO      = DEVICE_CAP_PRODUCT_VDO;
            sDevCap1.SVID            = DEVICE_CAP_PRODUCT_SVID;
            
            /*Frame the data message from the capability information*/
            u8Data[0] = sDevCap1.SVID;
            u8Data[1] = sDevCap1.ProductVDO;
        }
        
        /*Frame the header and data packet into a single response packet*/
        LVDS_FramePacket(sMessageHeader, u8Data, sMessageHeader.numDataBytes);
        
        /*Send the response to the CCM master*/
        gu8UARTWriteTimerID = PDTimer_Start(\
                                            MILLISECONDS_TO_TICKS(UART_WRITE_IDLE_TMR),\
                                            Ideal_UARTWriteCB,\
                                            NULL,\
                                            NULL\
                                            );
    }
}

/**************************************************************************************************/
/*
 * \Function Name           - HandleControlMessage_GetAlarmStatus 
 * \Function Description    - Function which sends the alarms status to CCM master
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleControlMessage_GetAlarmStatus(void)
{
    MessageHeader sMessageHeader;
    UINT8 u8Data[2];
    
    /*Fill the Message header with MsgID, Msg Type and Number of data bytes to transmit*/
    sMessageHeader.msgId         = receivedPacket.messageHeader.msgId;
    sMessageHeader.msgType       = (UINT8)DataMessage_SendAlarmStatus;
    sMessageHeader.numDataBytes  = 2;
    
    /*Fill the data bytes with alarm status information*/
    u8Data[0] = gSystemState.alarmStatus.bytes[0];
    u8Data[1] = gSystemState.alarmStatus.bytes[1];
    
    /*Frame the header and data packet into a single response packet*/
    LVDS_FramePacket(sMessageHeader, u8Data, sMessageHeader.numDataBytes);
    
    /*Send the response to the CCM master*/
    gu8UARTWriteTimerID = PDTimer_Start(\
                                        MILLISECONDS_TO_TICKS(UART_WRITE_IDLE_TMR),\
                                        Ideal_UARTWriteCB,\
                                        NULL,\
                                        NULL\
                                        );
}

/**************************************************************************************************/
/*
 * \Function Name           - InitRand 
 * \Function Description    - Function which initializes the seed for random number generation
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void InitRand(void)
{
    /*use multiple sources for the seed to try to give it some variability over modules*/
    gu8Seed     =  (UINT8)gSystemState.u8MilliSecCtr;
    gu8Seed     ^= (UINT8) gau8LvdsDeviceId[0];
    gu8Seed     ^= (UINT8) gau8LvdsDeviceId[1];
    gu8Seed     ^= (UINT8) gau8LvdsDeviceId[2];
    gu8Seed     ^= (UINT8) gau8LvdsDeviceId[3];
    gu8Seed     ^= (UINT8) gau8LvdsDeviceId[4];
    gu8Seed     ^= (UINT8) gau8LvdsDeviceId[5];
    gu8Seed     ^= (UINT8) gau8LvdsDeviceId[6];
    gu8Seed     ^= (UINT8) gau8LvdsDeviceId[7];
    gu8Seed     ^= (UINT8) gau8LvdsDeviceId[8];
    
    /*Assign the seed to the variable which generates Random number*/
    gu8Next     =  gu8Seed;       
}

/**************************************************************************************************/
/*
 * \Function Name           - rand 
 * \Function Description    - Function which generates a random number
 * \param[in]               - void
 * \return                  - UINT8
 */
/**************************************************************************************************/
UINT8 rand (void)
{
    /*Generate a Random number*/
    gu8Next = (UINT8)(((UINT8)(gu8Next * 110)) + 123);
    
    /*Return the random number rounded to 128*/
    return (gu8Next % 127);
}

/**************************************************************************************************/
/*
 * \Function Name           - Ideal_UARTInit 
 * \Function Description    - Function which initializes UART RX/TX registers and SW variables
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void Ideal_UARTInit(void)
{    
    /*Initialize the Global Variables for UART SERCOM3*/
    (void)Ideal_USARTInit(gu8UARTRxBuff, LVDS_RX_BUFFER_SIZE); 
}

/**************************************************************************************************/
/*
 * \Function Name           - CheckForAlarms 
 * \Function Description    - State Machine which checks if any input Voltage, Current or Bus Idle 
 *                            time exceeds the threshold
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void CheckForAlarms(void)
{
    /*are we monitoring a low voltage condition?*/
    if (gSystemState.isWaitingLowVoltage)
    {
        /*did we stay low too long?*/
        if (gSystemState.lowVoltageWaitCount > MAX_FAULT_MODE_TIME)
        {
            /*Reset UPD301*/
            UPD301_Reset(); 
        }
        
        /*Obtain the DC input voltage from the ADC SW registers*/
        gSystemState.dcInputLevel = \
          (UINT16)(((double)gau16ADCval[ADC_INPUT_V] * IDEAL_ADC_V_MUL_FACTOR)*1000);
        
        /*did we get above our input voltage limit?*/
        if (gSystemState.dcInputLevel >= MIN_DC_INPUT)
        {
            /*The state machine is not waiting in Low Voltage Condition*/
            gSystemState.isWaitingLowVoltage = FALSE;
            
            /*Obtain the DC input voltage from the ADC SW registers - Debounce*/
            gSystemState.dcInputLevel = \
              (UINT16)(((double)gau16ADCval[ADC_INPUT_V] * IDEAL_ADC_V_MUL_FACTOR)*1000);
            
            /*Check if the voltage has gone low again - Identify any glitch in Input Voltage*/
            if (gSystemState.dcInputLevel < MIN_DC_INPUT)
            {
                /*Glitch detected - back to wait state*/
                gSystemState.lowVoltageWaitCount = FALSE;
                gSystemState.isWaitingLowVoltage = TRUE;
            }
            else
            {
                /*Voltage is stable and above MIN_DC_INPUT - proceed with current measure*/
                CheckIndividualAlarms();
            }
        }
    }
    else
    {
        /*Obtain the DC input voltage from the ADC SW registers*/
        gSystemState.dcInputLevel = \
          (UINT16)(((double)gau16ADCval[ADC_INPUT_V] * IDEAL_ADC_V_MUL_FACTOR)*1000);
        
        /*Check if the voltage has gone below the threshold*/
        if (gSystemState.dcInputLevel < MIN_DC_INPUT)
        {
            /*Enter wait state*/
            gSystemState.lowVoltageWaitCount = FALSE;
            gSystemState.isWaitingLowVoltage = TRUE;
        }
        else
        { 
            /*Proceed with Current measure*/
            CheckIndividualAlarms();
        }
    }
}

/**************************************************************************************************/
/*
 * \Function Name           - CheckIndividualAlarms 
 * \Function Description    - State Machine which checks if Current or Bus Idle 
 *                            time exceeds the threshold
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void CheckIndividualAlarms(void)
{
    UINT16 limit;
    UINT16 currentMilliAmps;
    
    /*blank out individual alarm states, keeping aggregate status as is*/
    gSystemState.alarmStatus.value &= 0x01;
    
    /*Obtain the input Current from the ADC SW registers*/
    currentMilliAmps = \
      (UINT16)(((double)gau16ADCval[ADC_INPUT_I] *IDEAL_ADC_STEP_RESOLUTION * gdADCICalibFac)*1000);
    
    /*Identify the limit based on the power profile negotiated*/
    limit =  ((gSystemState.powerSetting == PowerSetting_3) ? LVDS_65W_CUR_LIM : LVDS_DEF_CUR_LIM); 
    
    /*Check if the Current exceeds the MAX threshold - if so, enalbe the input current alarm*/
    gSystemState.alarmStatus.bits.inputCurrentAlarm = currentMilliAmps > limit;
    
    /*Check if the Bus Idle timer exceeds the MAX threshold - if so, enable the Bus message 
      timeout alarm*/
    gSystemState.alarmStatus.bits.busMessageTimeoutAlarm = \
                                      gSystemState.busMessageElapsedMsec > BUS_MESSAGE_TIMEOUT;
    
    /*Increment the Global Alarm counter*/
    INCREMENT_ALARM_COUNTER(\
                            gSystemState.alarmStatus.bits.inputCurrentAlarm,\
                            gSystemState.alarmCounter.inputCurrentAlarm\
                            );
    
    INCREMENT_ALARM_COUNTER(\
                            gSystemState.alarmStatus.bits.busMessageTimeoutAlarm,\
                            gSystemState.alarmCounter.busMessageTimeoutAlarm\
                            );
    
    /*Check if there is any input current alarm - if so, increment the Alarm detected count*/
    if (FALSE != gSystemState.alarmStatus.bits.inputCurrentAlarm)
    {
        gu8alarmDetCnt++;
    }
    else
    {
        /*reset running count*/
        gu8alarmDetCnt = 0;	
    }
    
    /*Check if the alarm counter exceeds the threshold*/
    if (gu8alarmDetCnt >= ALARM_DETECT_COUNT)
    {
        /*reset running count*/
        gu8alarmDetCnt = 0;
        /*Enter into alarm state and Disable PD*/
        EnterAlarmState();        
    }
    /* Note that the busMessageTimeoutAlarm is treated separately */
    else if (gSystemState.alarmStatus.bits.busMessageTimeoutAlarm)
    {
        /*reset Bus idle timer*/
        gSystemState.busMessageElapsedMsec = 0;
        /*Enter into alarm state and Disable PD*/
        EnterAlarmState();        
    }
    else
    {
        /*The control will never reach here*/
    }
}

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_StartCurrentMeasure 
 * \Function Description    - Function which initiates the current measure on arrival of  
 *                            StartCurrentMeasure Request
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_StartCurrentMeasure(void)
{
    UINT8 u8MessageID;
    UINT16 lengthTenthsSec;
    UINT8 numberOfSamples;
    
    /*Parse the Duration of sample intervals and the number of samples from the data bytes*/
    lengthTenthsSec = ((receivedPacket.data[0]) >> 3);
    numberOfSamples = (receivedPacket.data[0] & 0x07);

    /*Check if the data message is not invalid*/
    if ((lengthTenthsSec != 0)&&(numberOfSamples != 0))
    {
        /*Store the message ID to the system and local variables*/
        u8MessageID                                     = receivedPacket.messageHeader.msgId;
        gSystemState.currentMeasureParams.messageId     = receivedPacket.messageHeader.msgId;
        
        /*Store the Sample interval duration and number of samples to the system variables*/
        gSystemState.currentMeasureParams.samplesLengthMsec = \
                                                      ((lengthTenthsSec * 100) / (numberOfSamples));
        gSystemState.currentMeasureParams.numberOfMeasurements = numberOfSamples;
        
        /*initialize the Current measure state system variables*/
        gSystemState.currentMeasureState[u8MessageID].measurementIndex          = 0;
        gSystemState.currentMeasureState[u8MessageID].currentMeasure            = 0;
        gSystemState.currentMeasureState[u8MessageID].numberOfBadReadings       = 0;
        
        /*Start the Current Measure interval timer*/
        gu8CurrMeasTimerID = PDTimer_Start(\
                        MILLISECONDS_TO_TICKS(gSystemState.currentMeasureParams.samplesLengthMsec),\
                        Ideal_CurrMeasCB, \
                        NULL, \
                        NULL\
                        );
    }
}

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_GetCurrent 
 * \Function Description    - Function which responds the current measured to the CCM master
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_GetCurrent(void)
{
    MessageHeader sMessageHeader;  
    UINT8         u8MessageId;
    UINT8         u8Data[2];
    UINT32        u32CurrentInmA;
    
    /*Copy the Message ID for which the Master requests the measured current*/
    u8MessageId                 = receivedPacket.data[0];
    
    /*Fill the Message header with MsgID, Msg Type and Number of data bytes to transmit*/
    sMessageHeader.msgId        = receivedPacket.messageHeader.msgId;
    sMessageHeader.msgType      = (UINT8)DataMessage_SendCurrent;
    sMessageHeader.numDataBytes = 2;
    
    /*Obtain the Current measure from the averaged measured current*/
    u32CurrentInmA = gSystemState.currentMeasureState[u8MessageId].currentMeasure;
    
    /*Frame the data bytes along with the details regarding the bad readings and supply selection*/
    u8Data[0]      = ((gSystemState.currentMeasureState[u8MessageId].numberOfBadReadings << 6) \
                     | ((UINT8)gSystemState.supplySelect << 5) | (0 << 4) | (u32CurrentInmA >> 8));
    
    u8Data[1]      = (u32CurrentInmA & 0xFF);	
    
    /*Frame the header and data packet into a single response packet*/
    LVDS_FramePacket(sMessageHeader, u8Data, sMessageHeader.numDataBytes);
    
    /*Send the response to the CCM master*/
    gu8UARTWriteTimerID = PDTimer_Start(\
                                        MILLISECONDS_TO_TICKS(UART_WRITE_IDLE_TMR),\
                                        Ideal_UARTWriteCB,\
                                        NULL,\
                                        NULL\
                                        );
}

/**************************************************************************************************/
/*
 * \Function Name           - HandleDataMessage_GetTestMeasure 
 * \Function Description    - Function which provides the information regarding the alarms to the 
 *                            CCM master
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void HandleDataMessage_GetTestMeasure(void)
{
    MessageHeader     sMessageHeader;
    TestMeasureSelect eTestMeasureSelect;
    UINT32            u32TestMeasureReqData;
    UINT16            u16RespData = 0;
    UINT8             u8Data[2];
    
    /*Obtain the First Data byte sent by the master*/
    eTestMeasureSelect = (TestMeasureSelect)receivedPacket.data[0];
    
    /*Obtain the Request data regarding the alarm counter from the data bytes*/
    (void)CONFIG_HOOK_MEMCPY((UINT8 *)&u32TestMeasureReqData, &receivedPacket.data[1],4);

    /*Send Error response on receiving an invalid request*/
    if (eTestMeasureSelect == TestMeasure_Reserved)
    {
        SendControlMessage((UINT8)ControlMessage_Error);
    }
    /*Send the Response to the valid request*/
    else
    {
        switch (eTestMeasureSelect)
        {
            /*
            case TestMeasure_SendTempAdc:
                    u16RespData = temperatureAdc;
                    break;
            case TestMeasure_SendBusOutVoltageAdc:
                    u16RespData = ADC_GetConversion(BUS_OUT);
                    break;
            case TestMeasure_SendRegulatorOutVoltageAdc:
                    u16RespData = ADC_GetConversion(REGULATOR_OUT);
                    break;
            case TestMeasure_SendInputVoltageAdc:
                    u16RespData = ADC_GetConversion(INPUT_24V);
              responseData =(UINT16) Ideal_ADCReadValue (ADC_INPUT_V);
                    break;
            case TestMeasure_SendCurrentSenseAdc:
                    u16RespData = ADC_GetConversion(I_SENSE);
              responseData =(UINT16) Ideal_ADCReadValue (ADC_INPUT_I);
                    break;
            case TestMeasure_SendPowerGoodState:
                    u16RespData = POWER_GOOD_GetValue();
                    break;
            case TestMeasure_SendMemoryValue:
            {
                    UINT16 address = testMeasureRequestData & 0x0000FFFF;
                    address += 0x7000;	// offset for EEPROM
                    u16RespData = DATAEE_ReadByte(address);
            }
                    break;
            case TestMeasure_SetMemoryValue:
            {
                if (memoryMap.ignoreWriteCommands)
                {
                        SendControlMessage((UINT8)ControlMessage_Error);
                        return;
                }
                uint16_t address = testMeasureRequestData & 0x0000FFFF;
                address += 0x7000;	// offset for EEPROM
                uint16_t value = testMeasureRequestData >> 16;
                DATAEE_WriteByte(address, value);
                uint16_t readValue = DATAEE_ReadByte(address);
                u16RespData = readValue;
            }
                    break;
            case TestMeasure_SendChargingState:
                    u16RespData = CHARGER_MODE_GetValue();
                    break;
            case TestMeasure_SendRegulatorEnableState:
                    u16RespData = REG_ENABLE_GetValue();
                    break;
            case TestMeasure_SendDeviceIdByte:
                    u16RespData = DeviceId[testMeasureRequestData];
                    break;
            */
            
            case TestMeasure_SendAlarmCounter:
            {
                switch (u32TestMeasureReqData)
                {
                    case 0:
                        u16RespData = gSystemState.alarmCounter.alarmState;
                        break;
                    case 1:
                        u16RespData = gSystemState.alarmCounter.tempAlarm;
                        break;
                    case 2:
                        u16RespData = gSystemState.alarmCounter.inputVoltageAlarm;
                        break;
                    case 3:
                        u16RespData = gSystemState.alarmCounter.inputCurrentAlarm;
                        break;
                    case 4:
                        u16RespData = gSystemState.alarmCounter.outputVoltageAlarm;
                        break;
                    case 5:
                        u16RespData = gSystemState.alarmCounter.powerGoodAlarm;
                        break;
                    case 6:
                        u16RespData = gSystemState.alarmCounter.busMessageTimeoutAlarm;
                        break;
                    case 7:
                        u16RespData = gSystemState.alarmCounter.rxOverrunWarning;
                        break;
                }
                break;
            }
            /*Request which is not currently handled*/
            default:
            {
                u16RespData = 0;
            }
        }
        
        /*Fill the Message header with MsgID, Msg Type and Number of data bytes to transmit*/
        sMessageHeader.msgId        = receivedPacket.messageHeader.msgId;
        sMessageHeader.msgType      = (UINT8)DataMessage_SendTestMeasure;
        sMessageHeader.numDataBytes = 2;

        /*Frame the data bytes with the test measure response*/
        u8Data[0] = u16RespData & 0x00FF;
        u8Data[1] = u16RespData >> 8;
        
        /*Frame the header and data packet into a single response packet*/
        LVDS_FramePacket(sMessageHeader, u8Data, sMessageHeader.numDataBytes);
        
        /*Send the response to the CCM master*/
        gu8UARTWriteTimerID = PDTimer_Start(\
                                            MILLISECONDS_TO_TICKS(UART_WRITE_IDLE_TMR),\
                                            Ideal_UARTWriteCB,\
                                            NULL,\
                                            NULL\
                                            );
    }
}

/**************************************************************************************************/
/*
 * \Function Name           - EnterAlarmState 
 * \Function Description    - Function which disables PD functionality on exceeding the threshold
 * \param[in]               - void
 * \return                  - void
 */
/**************************************************************************************************/
void EnterAlarmState(void)
{
    /*Alarm Flag is now set*/
    gSystemState.alarmStatus.bits.alarmState = true;
    
    /*Global Alarm counter is incremented*/
    INCREMENT_ALARM_COUNTER(\
                            gSystemState.alarmStatus.bits.alarmState, \
                            gSystemState.alarmCounter.alarmState\
                            );
    
    /*Disbale the Pd functionality*/
    if(gSystemState.powerSetting != PowerSetting_Err)
    {
        /*Indicate to LVDS system that the Power has been disabled*/
        gSystemState.outputEnabled      = FALSE;        
        gSystemState.powerSetting       = PowerSetting_Err;
        
        /*Request the PN manager to disbale PD*/
        gsPNMngr.sPNPwrDesc.bIsPwrAlloc = TRUE;
        gsPNMngr.sPNPwrDesc.u16ReqPwr   = PowerSetting_Err;
    }
}

/**************************************************************************************************/
/*
 * \Function Name          - UpdateLedState 
 * \Function Description   - State Machine which modifies the LED state based on the allocated Power
 * \param[in]              - void
 * \return                 - void
 */
/**************************************************************************************************/
void UpdateLedState(void)
{
    /*Condition 1 - if Alarm detected, LED is switched off*/
    if((FALSE != gSystemState.alarmStatus.bits.alarmState))
    {
        /*LED off*/
        GPIO_SetPinLevel(PIN_PA28, TRUE);
        /*Reset the LED timer counter*/
        gu16LedTimerMsec = 0;
    }    
    /*Condition 2 - if Output is enabled, LED is switched On*/
    else if(FALSE != gSystemState.outputEnabled)
    {
        /*LED On*/
        GPIO_SetPinLevel(PIN_PA28, FALSE);
        /*Reset the LED timer counter*/
        gu16LedTimerMsec = 0;
    }
    /*LED toggle states*/
    else 
    {
        /*Condition 3 - if no power is allocated at all - UART comm fails*/
        if(0xFFFF == gsPNMngr.sPNPwrDesc.u16AllocPwr)
        {
            /*LED on for 500mS*/
            gu16LedOnValue      = LVDS_LED_ON_500;
            /*LED off for 2S*/
            gu16LedoffValue     = LVDS_LED_OFF_2000;
        }
        /*Condition 4 - if Power allocated is not sufficient (0 Watt)*/
        else if(FALSE == gSystemState.outputEnabled)
        {
            /*LED On for 2S*/
            gu16LedOnValue      = LVDS_LED_ON_2000;
            /*LED off for 2S*/
            gu16LedoffValue     = LVDS_LED_OFF_2000;
        }
        else
        {
            /*Control shall never reach here*/
            GPIO_SetPinLevel(PIN_PA28, TRUE);
            gu16LedTimerMsec = 0;
        }
        
        /*Check if the LED timer counter exceeds the threshold based on the state of LED*/
        if(gu16LedTimerMsec > (gbLedOnorOff ? gu16LedOnValue:gu16LedoffValue))
        {  
            /*If LED is ON, Switch it off*/
            if(gbLedOnorOff)
            {
                /*LED Off*/
                GPIO_SetPinLevel(PIN_PA28, TRUE);
                gbLedOnorOff = FALSE;
            }
            /*If LED is Off, Switch it On*/
            else
            {
                /*LED On*/
                GPIO_SetPinLevel(PIN_PA28, FALSE);
                gbLedOnorOff = TRUE;
            }
            
            /*Reset the LED timer counter*/
            gu16LedTimerMsec = 0;
        }
    }
}

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_UARTCollisionIdleCB 
 * \Function Description   - Callback Function which enables RX data reception on UART after 
 *                           data collision
 * \param[in] dummy1       - variable of type UINT8
 * \param[in] dummy2       - variable of type UINT8
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_UARTCollisionIdleCB (UINT8 dummy1, UINT8 dummy2)
{
    /*UART RX is enabled on the corresponding SERCOM*/
    REGDW(SERCOM_UART_CTRLB_REG) |= (SERCOM_UART_CTRLB_RXEN);
}

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_UARTWriteCB 
 * \Function Description   - Callback Function to send the data to CCM
 * \param[in] dummy1       - variable of type UINT8
 * \param[in] dummy2       - variable of type UINT8
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_UARTWriteCB (UINT8 dummy1, UINT8 dummy2)
{
    /*Call the UART Write API*/
    (void)Ideal_USARTWrite(gau8LVDSTxBuff,gu8TxBytesCount);
}

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_CurrMeasCB 
 * \Function Description   - Callback Function which stores the Current measured at definite 
 *                           intervals to the corresponding Message ID 
 * \param[in] dummy1       - variable of type UINT8
 * \param[in] dummy2       - variable of type UINT8
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_CurrMeasCB (UINT8 dummy1, UINT8 dummy2)
{
    UINT8 u8MessageID           = gSystemState.currentMeasureParams.messageId;
    UINT8 u8NumMeasurements     = gSystemState.currentMeasureParams.numberOfMeasurements;    
    UINT32 u32SampleLength      = gSystemState.currentMeasureParams.samplesLengthMsec;
    
    /*Check if the Callback has completed the measurements at all the specified intervals for the 
      specified Message ID*/
    if (gSystemState.currentMeasureState[u8MessageID].measurementIndex >= u8NumMeasurements)
    {
        /*Do nothing - Break out of the Current measure recursion*/
    }
    else
    {
        /*Check if the input Voltage is below the threshold*/
        if (gSystemState.dcInputLevel < MIN_DC_INPUT)
        {
            /*Increment the bad readings counter*/
            gSystemState.currentMeasureState[u8MessageID].numberOfBadReadings++;
        }
        else
        {
            /*Accumulate the Current measured from ADC*/
            gSystemState.inputCurrent =\
              (UINT16)(((double)gau16ADCval[ADC_INPUT_I] *IDEAL_ADC_STEP_RESOLUTION * gdADCICalibFac)*1000);
            
            gSystemState.currentMeasureState[u8MessageID].currentMeasure \
              = gSystemState.inputCurrent;
        }
        
        /*increment the measurement index*/
        gSystemState.currentMeasureState[u8MessageID].measurementIndex++;
        
        /*Enable the Measument interval timer*/
        gu8CurrMeasTimerID = PDTimer_Start(\
                                            MILLISECONDS_TO_TICKS(u32SampleLength),\
                                            Ideal_CurrMeasCB,\
                                            NULL, \
                                            NULL\
                                            );
    }
}

/**************************************************************************************************/
/*End Function Definitions*/
#endif
