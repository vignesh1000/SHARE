/**
 * \file
 *
 * \brief Power Negotiation related functionality implementation.
 *
 * Copyright (c) 2014-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */

#ifdef _IDEAL_

#include <Power_Negotiation.h>

/*Instance of Global PN structure variable*/   
PN_MNGR gsPNMngr;

/*Begin function Definitions*/
/**************************************************************************************************/
/*
 * \Function Name          - Ideal_PNSetState 
 * \Function Description   - static function which assigns the state to the PN state Variable 
 * \param[in] eState       - The Enum to which the state must transit
 * \return                 - void
 */
/**************************************************************************************************/
static inline void Ideal_PNSetState (E_PN_STATE eState)
{
    /*Assign the State value to the global state variable*/
    gsPNMngr.ePNState = eState;
}

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_PNGetState 
 * \Function Description   - static function which returns the state of PN module
 * \return                 - (E_PN_STATE) PNstate
 */
/**************************************************************************************************/
static inline E_PN_STATE Ideal_PNGetState (void)
{
    /*Return the state of the PN module*/
    return gsPNMngr.ePNState;
}

/**************************************************************************************************/
/*
 * \Function Name       - Ideal_PNInit 
 * \Function Description- This function initializes the Global Variables used for Power Negotiation
 * \return              - void
 */
/**************************************************************************************************/
void Ideal_PNInit(void)
{    
    PORT_CONFIG_DATA *PortConfigurationData     = &gasPortConfigurationData[0];
    PN_PWR_DESC *psPNPwrDesc                    = &gsPNMngr.sPNPwrDesc;
    PDO_INFO *psPDOInfo                         = &gsPNMngr.sPDOInfo;
    UINT8 u8PDOcnt                              = PortConfigurationData->u8PDOCnt;
    UINT8 u8Loop;
    
    /*Initialize the Power allocation variables to Reset values*/
    
    /*Initialize the Allocated power to Zero*/
    psPNPwrDesc->u16AllocPwr    = 0xFFFF;
    /*Initialize the Maximum power to be allocated as 65W (in tenths of a Watt)*/
    psPNPwrDesc->u16MaxPwr      = 650U;
    /*Initialize the Requested Power to Zero*/
    psPNPwrDesc->u16ReqPwr      = 0xFFFF;
    /*Initialize the Status of Power Allocation to 0*/
    psPNPwrDesc->bIsPwrAlloc    = FALSE;
    
    /*Initialize the Power Negotiation State*/
    Ideal_PNSetState (ePN_DISABLE_PORT_ENTRY);
    
    /*Initialize the PDO Count to Zero*/
    psPDOInfo->u8PDOcnt  = 0;
    
    /*Save the default PDO configuration to derive the Custom PDOs based on the allocated power*/
    for(u8Loop = 0; u8Loop < u8PDOcnt; u8Loop++)
    {
        /*Copy the PDO Contents from the Global Config Data to PN Manager PDO INFO*/
        psPDOInfo->u32PDOs[u8Loop] = PortConfigurationData->u32PDO[u8Loop];
        /*Increment the PDO Count*/
        psPDOInfo->u8PDOcnt++;
    }
}

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_PNSetupPDO 
 * \Function Description   - This function calculates and voltage and current based on the available
 *                           power and modifies the PDOs accordingly
 * \param[in] u16AllocPwr  - The variable which holds the power allocated to the system 
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_PNSetupPDO(UINT16 u16AllocPwr)
{    
    UINT8  u8PDOIndex;    
    UINT16 u16Current;
    UINT16 u16Voltage;
    UINT16 u16MaxCurrent;
    
    PDO_INFO *psPDOInfo = &gsPNMngr.sPDOInfo;
        
    for(u8PDOIndex = 0; u8PDOIndex < psPDOInfo->u8PDOcnt; u8PDOIndex++)
    {        
        /*Get the voltage from the default PDO structure*/
        u16Voltage    = (UINT16)(DPM_GET_VOLTAGE_FROM_PDO_MILLI_V(psPDOInfo->u32PDOs[u8PDOIndex]));
        
        /*Get the maximum Current allocated to the System from the Default PDO structure*/
        u16MaxCurrent = (UINT16)(DPM_GET_CURRENT_FROM_PDO_MILLI_A(psPDOInfo->u32PDOs[u8PDOIndex]));
        
        /*Calculate the Current based on the Power allocated and Voltage obtained*/
        u16Current    = (UINT16)(((UINT32)(u16AllocPwr) *100000U) / ((UINT32)u16Voltage));         
        
        /*Check if the calculated current exceeds the maximum current for the System*/
        if(u16Current > u16MaxCurrent)
        {
            /*Allocate the maximum current if the calculated current exceeds the Max Current*/
            u16Current = u16MaxCurrent;
        }
        
        /*Clear the Current and Voltage Values in the PDO*/
        gasPortConfigurationData[0].u32PDO[u8PDOIndex] &= ~(DPM_VOLTAGE_CURRENT_MASK);
        
        if(FALSE == u8PDOIndex)
        {
          /*Assign the Voltage and current (PDO) values to the Global Configuration data*/
          gasPortConfigurationData[0].u32PDO[u8PDOIndex] |= \
                                        (UINT32)(SRC_CAP_GENERATION(1, 1, 0, u16Current, u16Voltage));
        }
        else
        {
          /*Assign the Voltage and current (PDO) values to the Global Configuration data*/
          gasPortConfigurationData[0].u32PDO[u8PDOIndex] |= \
                                        (UINT32)(SRC_CAP_GENERATION(0, 0, 0, u16Current, u16Voltage));
        }
    }
}

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_PNEnDisPD 
 * \Function Description   - This function Enables / Disables the PD Port 
 * \param[in] bEnable      - The variable specifying whether to enable or disable the PD system 
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_PNEnDisPD(BOOL bEnable)
{    
    /*This function serves as a workaround - A better approach can still be followed*/
    if(TRUE == bEnable)
    {
        /*Set the Type C State machine to Exit Error Recovery Mode*/
        DPM_SetTypeCState(PORT0, TYPEC_ERROR_RECOVERY, TYPEC_ERROR_RECOVERY_TO_SS);
        
        /*Clear the Error recovery Entry Status Flag*/
        gbEnteredErrRec = FALSE;
        
        /*Clear the PD disabled status Flag*/
        gbPDDisabled = FALSE;        
    }
    else
    {
        /*Kill all the Timers enabled for the Port 0*/
        PDTimer_KillPortTimers (PORT0);
        
        /*Set the Type C State machine to Enter Error Recovery Mode*/
        DPM_SetTypeCState(PORT0, TYPEC_ERROR_RECOVERY, TYPEC_ERROR_RECOVERY_ENTRY_SS); 
        
        /*Disable Power delivery and enter into Error state - PD disabling*/
        gbPDDisabled = TRUE; 
        
        /*Setting Initial Source Policy Engine State as Startup State*/
        gasPolicy_Engine[PORT0].ePEState = ePE_SRC_STARTUP;
        
        /*Set the Inital Source Policy Engine Sub state to Startup state*/
        gasPolicy_Engine[PORT0].ePESubState = ePE_SRC_STARTUP_ENTRY_SS;
    }
}

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_PNRun 
 * \Function Description   - This function Handles the state machine transitions within the PN
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_PNRun(void)
{
    switch (Ideal_PNGetState ())
    {
        case ePN_DISABLE_PORT_ENTRY:
        {		
            /*Disables the PD port*/
            Ideal_PNEnDisPD(PD_PORT_DISABLE);
            /*Change the PN state to ePN_DISABLE_PORT_EXIT*/
            Ideal_PNSetState (ePN_DISABLE_PORT_EXIT);
            
            break;
        }
        
        case ePN_DISABLE_PORT_EXIT:
        {	
            /*Check if the Port Got disabled*/
            if(TRUE == gbEnteredErrRec)
            {
                /*If so, change the PN state to ePN_IDLE*/
                Ideal_PNSetState (ePN_IDLE);
            }
            break;
        }
        
        case ePN_IDLE:
        {
            /*Check if the LVDS SetCapabilities has allocated power to the system*/
            if(TRUE == gsPNMngr.sPNPwrDesc.bIsPwrAlloc)
            {
                /*Check if the PD port Got disabled*/
                if(FALSE == gbPDDisabled)
                {
                    /*Move to ePN_DISABLE_PORT_ENTRY and disable the port*/
                    Ideal_PNSetState (ePN_DISABLE_PORT_ENTRY);
                }
                else
                {
                    /*If the Port is disabled, move to ePN_PDO_UPDATE_ENTRY*/
                    Ideal_PNSetState (ePN_PDO_UPDATE_ENTRY);
                }
            }
            /*Test function: TODO remove the Macro from Preprocessor*/
#ifdef _TEST_
            if(gbTest)
            {
                gsPNMngr.sPNPwrDesc.bIsPwrAlloc = TRUE;
                gsPNMngr.sPNPwrDesc.u16ReqPwr = 650;
                gbTest = FALSE;
            }
#endif
            break;
        }
        
        case ePN_PDO_UPDATE_ENTRY:
        {
            /*Check if the Power allocated is not Equal to Zero*/
            if((FALSE == gsPNMngr.sPNPwrDesc.u16ReqPwr)&&(FALSE == gsPNMngr.sPNPwrDesc.u16AllocPwr))
            {
                /*If the Power allocated is Zero, Clear the Power allocation flag*/
                gsPNMngr.sPNPwrDesc.bIsPwrAlloc = FALSE;
                
                /*Move to ePN_IDLE state*/
                Ideal_PNSetState (ePN_IDLE);
            }
            else 
            {
                /*check if the Allocated power is more than the Maxpower of the system*/
                if (gsPNMngr.sPNPwrDesc.u16ReqPwr > gsPNMngr.sPNPwrDesc.u16MaxPwr)
                {
                    /*If yes, Assign the Maxpower to the Allocated power*/
                    gsPNMngr.sPNPwrDesc.u16ReqPwr = gsPNMngr.sPNPwrDesc.u16MaxPwr;
                }
                
                /*Configure the PDOs to the allocated power*/
                Ideal_PNSetupPDO(gsPNMngr.sPNPwrDesc.u16ReqPwr);
                
                /*Change the PN state to ePN_PDO_UPDATE_EXIT*/
                Ideal_PNSetState (ePN_PDO_UPDATE_EXIT);
            }
            break;
        }
        
        case ePN_PDO_UPDATE_EXIT:
        {
            /*Clear the Power allocation status Flag*/
            gsPNMngr.sPNPwrDesc.bIsPwrAlloc = FALSE;
            
            /*Assign the power requested to the allocated Power*/
            gsPNMngr.sPNPwrDesc.u16AllocPwr = gsPNMngr.sPNPwrDesc.u16ReqPwr;
            
            /*Clear the Requested Power*/
            gsPNMngr.sPNPwrDesc.u16ReqPwr = 0;
            
            if(FALSE != gsPNMngr.sPNPwrDesc.u16AllocPwr)
            {
                /*Enable the PD port*/
                Ideal_PNEnDisPD(PD_PORT_ENABLE);
            }
            
            /*Change the PN state to ePN_IDLE*/
            Ideal_PNSetState (ePN_IDLE);
            
            break;
        }
    }
}
#endif  