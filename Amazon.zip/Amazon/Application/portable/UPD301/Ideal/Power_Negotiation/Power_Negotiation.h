/**
 * \file
 *
 * \brief Power Negotiation module related functionality declaration
 *
 * Copyright (c) 2014-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
#ifdef _IDEAL_

#ifndef _POWER_NEGOTIATION_H_INCLUDED
#define _POWER_NEGOTIATION_H_INCLUDED

#include <stdinc.h>

/*Begin Macro Defines*/
/**************************************************************************************************/
/*MAX PDO Count for the internal PDO structure*/
#define K_MAX_PDOS 7

/*Port enable/disable defines*/
#define PD_PORT_ENABLE                                  TRUE
#define PD_PORT_DISABLE                                 FALSE

/*PDO Current Mask Defines*/
#define DPM_PDO_CURRENT_MASK                            0x3FF
#define DPM_PDO_CURRENT_UNIT                            10
#define DPM_GET_CURRENT_FROM_PDO_MILLI_A(u32PDO)        ((u32PDO  & DPM_PDO_CURRENT_MASK) * DPM_PDO_CURRENT_UNIT) 

/*Voltage and Current Mask for the PDO*/
#define DPM_VOLTAGE_CURRENT_MASK                        0x000FFFFFU
/**************************************************************************************************/
/*End Macro Defines*/

/*Begin Variable Declaration*/
/**************************************************************************************************/
/**
 * Enum Name        - E_PN_STATE 
 * Enum Description - Variables which points to the different states of PN
 */
/**************************************************************************************************/
typedef enum _PN_MNGR_STATE
{
    ePN_IDLE = 0,
    ePN_DISABLE_PORT_ENTRY,
    ePN_DISABLE_PORT_EXIT,
    ePN_PDO_UPDATE_ENTRY,
    ePN_PDO_UPDATE_EXIT,
      
}E_PN_STATE;

/**************************************************************************************************/
/**
 * Structure Name        - PDO_INFO 
 * Structure Description - Holds the default PDOs and PDO count
 *
 * Structure variables:  
 * Name                 Type            Function
 * u32PDOs[K_MAX_PDOS]  UINT32          Variable which holds the PDO values
 * u8PDOcnt             UINT8           Variable which holds the number of PDOs in the Array of PDOs
 */
/**************************************************************************************************/
typedef struct _PDO_INFO
{
    UINT32      u32PDOs[K_MAX_PDOS];
    UINT8       u8PDOcnt;
    
} PDO_INFO;

/**************************************************************************************************/
/**
 * Structure Name        - PN_PWR_DESC 
 * Structure Description - Holds the value of Power Requested and allocated to the System
 *
 * Structure variables:  
 * Name                 Type            Function
 * u16AllocPwr          UINT16          Variable which stores the current operating power of system
 * u16ReqPwr            UINT16          Variable which specifies the power requested by CCM
 * u16MaxPwr            UINT16          Variable which Holds the Max Power of the system
 * bIsPwrAlloc          BOOL            Status Flag which specifies whether the Power is allocated
 */
/**************************************************************************************************/
typedef struct _PN_PWR_DESC
{
    UINT16      u16AllocPwr;
    UINT16      u16ReqPwr;
    UINT16      u16MaxPwr;    
    BOOL        bIsPwrAlloc;
    
}PN_PWR_DESC;

/**************************************************************************************************/
/**
 * Structure Name        - PN_MNGR 
 * Structure Description - Holds the functional variables of PDO_INFO, PN_STATE and PN_PWR_DESC
 *
 * Structure variables:  
 * Name                 Type                           Function
 * sPDOInfo             PDO_INFO                       Holds the variable for accessing Default PDOs
 * ePNState             E_PN_STATE                     Holds the State of the PN module
 * sPNPwrDesc           PN_PWR_DESC                    Holds the variables to modify/assign power              
 */
/**************************************************************************************************/
typedef struct _PN_MNGR
{
    PDO_INFO    sPDOInfo;
    E_PN_STATE  ePNState;
    PN_PWR_DESC sPNPwrDesc;
    
}PN_MNGR;
/*End Variable Declaration*/

/*Begin Function Declarations*/
/**************************************************************************************************/
/*
 * \Function Name          - Ideal_PNSetupPDO 
 * \Function Description   - This function calculates and voltage and current based on the available
 *                           power and modifies the PDOs accordingly
 * \param[in] u16AllocPwr  - The variable which holds the power allocated to the system 
 * \return                 - void
 */
/**************************************************************************************************/
void Ideal_PNSetupPDO(UINT16 u16AllocPwr);

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_PNRun 
 * \Function Description   - This function Handles the state machine transitions within the PN
 * \return                 - void
 */
/**************************************************************************************************/    
void Ideal_PNRun(void);

/**************************************************************************************************/
/*
 * \Function Name       - Ideal_PNInit 
 * \Function Description- This function initializes the Global Variables used for Power Negotiation
 * \return              - void
 */
/**************************************************************************************************/
void Ideal_PNInit(void);

/**************************************************************************************************/
/*
 * \Function Name          - Ideal_PNEnDisPD 
 * \Function Description   - This function Enables / Disables the PD Port 
 * \param[in] bEnable      - The variable specifying whether to enable or disable the PD system 
 * \return                 - void
 */
/**************************************************************************************************/  
void Ideal_PNEnDisPD(BOOL bEnable);

/*End Function Declarations*/

#endif
#endif