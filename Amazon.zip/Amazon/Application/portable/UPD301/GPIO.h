/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#ifndef _GPIO_H_
#define _GPIO_H_
#include <stdinc.h>
#include <samd20j16b.h>

#define UPD350_RESET        PIN_PA00
#define UPD350_IRQ0         PIN_PA14
#define UPD350_IRQ1         PIN_PA15

#define GPIO_GROUPA_BASE_ADDR                (0x41004400)
#define GPIO_DIR_REG_ADDR          	        (GPIO_GROUPA_BASE_ADDR + 0x00)
#define GPIO_DIRCLR_REG_ADDR                 (GPIO_GROUPA_BASE_ADDR + 0x04)
#define GPIO_DIRSET_REG_ADDR                 (GPIO_GROUPA_BASE_ADDR + 0x08)
#define GPIO_OUTCLR_REG_ADDR                 (GPIO_GROUPA_BASE_ADDR + 0x14)
#define GPIO_OUTSET_REG_ADDR                 (GPIO_GROUPA_BASE_ADDR + 0x18)
#define GPIO_OUT_REG_ADDR                    (GPIO_GROUPA_BASE_ADDR + 0x10)
#define GPIO_IN_REG_ADDR                     (GPIO_GROUPA_BASE_ADDR + 0x20)
#define GPIO_WRCONFIG_REG_ADDR               (GPIO_GROUPA_BASE_ADDR + GPIO_WRCONFIG_OFFSET)
#define GPIO_PMUX_REG_ADDR(pin)         	    (GPIO_GROUPA_BASE_ADDR + GPIO_PMUX_OFFSET + pin)
#define GPIO_PINCFG_REG_ADDR(index)          (GPIO_GROUPA_BASE_ADDR + GPIO_PINCFG_OFFSET+ index)

#define GPIOPIN(n) 			((n)&0x1Fu)
#define GPIOPORT(n) 			((n) >> 5)
#define GPIOCONFIG(port, pin) 		((((port)&0x7u) << 5) + ((pin)&0x1Fu))

#define GPIO_DRIVEHIGH                       1
#define GPIO_DRIVELOW                        0   
#define GPIO_PULLUP                          1
#define GPIO_PULLDOWN                        0
#define GPIO_PULLOFF                         0xff
#define GPIO_SETDIRECTION_IN                  0
#define GPIO_SETDIRECTION_OUT                 1
#define GPIO_SETDIRECTION_OFF                 0xff
#define GPIO_SET_TRISTATE                     10
#define GPIO_PIN_FUNC_OFF                     0xffffffff
#define GPIO_PMUX_PMUXO_POS                  4            /**< \brief (PORT_PMUX) Peripheral Multiplexing Odd */
#define GPIO_PMUX_PMUXO_MSK                  ((0xF) << GPIO_PMUX_PMUXO_POS)
#define GPIO_PMUX_PMUXO(value)               (GPIO_PMUX_PMUXO_MSK & ((value) << GPIO_PMUX_PMUXO_POS))
#define GPIO_PINCFG_OFFSET                   0x40         /*(PINCFG offset) Pin Configuration n */
#define GPIO_PINCFG_RESETVALUE               0x00)    /*(PINCFG reset_value) Pin Configuration n */
#define GPIO_PINCFG_PMUXEN_POS               0            /*(PINCFG) Peripheral Multiplexer Enable */
#define GPIO_PINCFG_PMUXEN                   ((0x1) << GPIO_PINCFG_PMUXEN_POS)
#define GPIO_PINCFG_INEN_POS                 1            /*(PINCFG) Input Enable */
#define GPIO_PINCFG_INEN                     ((0x1) << GPIO_PINCFG_INEN_POS)
#define GPIO_PINCFG_PULLEN_POS               2            /*(PINCFG) Pull Enable */
#define GPIO_PINCFG_PULLEN                   ((0x1) << GPIO_PINCFG_PULLEN_POS)
#define GPIO_PINCFG_DRVSTR_POS               6            /*(PINCFG) Output Driver Strength Selection */
#define GPIO_PINCFG_DRVSTR                   ((0x1) << GPIO_PINCFG_DRVSTR_POS)
#define GPIO_PINCFG_MASK                     (0x47)    /*(PINCFG) MASK Register */

#define GPIO_WRCONFIG_OFFSET                 0x28         /*(WRCONFIG offset) Write Configuration */
#define GPIO_WRCONFIG_RESETVALUE             (0x00000000) /*(WRCONFIG reset_value) Write Configuration */
#define GPIO_WRCONFIG_PINMASK_POS            0            /*(WRCONFIG) Pin Mask for Multiple Pin Configuration */
#define GPIO_WRCONFIG_PINMASK_MSK            ((0xFFFF) << GPIO_WRCONFIG_PINMASK_POS)
#define GPIO_WRCONFIG_PINMASK(value)         (GPIO_WRCONFIG_PINMASK_MSK & ((value) << GPIO_WRCONFIG_PINMASK_POS))
#define GPIO_WRCONFIG_PMUXEN_POS             16           /*(WRCONFIG) Peripheral Multiplexer Enable */
#define GPIO_WRCONFIG_PMUXEN                 (_U_(0x1) << GPIO_WRCONFIG_PMUXEN_POS)
#define GPIO_WRCONFIG_INEN_POS               17           /*(WRCONFIG) Input Enable */
#define GPIO_WRCONFIG_INEN                   (_U_(0x1) << GPIO_WRCONFIG_INEN_POS)
#define GPIO_WRCONFIG_PULLEN_POS             18           /*(WRCONFIG) Pull Enable */
#define GPIO_WRCONFIG_PULLEN                 ((0x1UL) << GPIO_WRCONFIG_PULLEN_POS)
#define GPIO_WRCONFIG_DRVSTR_POS             22           /*(WRCONFIG) Output Driver Strength Selection */
#define GPIO_WRCONFIG_DRVSTR                 ((0x1UL) << GPIO_WRCONFIG_DRVSTR_POS)
#define GPIO_WRCONFIG_PMUX_POS               24           /*(WRCONFIG) Peripheral Multiplexing */
#define GPIO_WRCONFIG_PMUX_MSK               ((0xF) << GPIO_WRCONFIG_PMUX_POS)
#define GPIO_WRCONFIG_PMUX(value)            (GPIO_WRCONFIG_PMUX_MSK & ((value) << GPIO_WRCONFIG_PMUX_POS))
#define GPIO_WRCONFIG_WRPMUX_POS             28           /*(WRCONFIG) Write PMUX */
#define GPIO_WRCONFIG_WRPMUX                 ((0x1UL) << GPIO_WRCONFIG_WRPMUX_POS)
#define GPIO_WRCONFIG_WRPINCFG_POS           30           /*(WRCONFIG) Write PINCFG */
#define GPIO_WRCONFIG_WRPINCFG               ((0x1UL) << GPIO_WRCONFIG_WRPINCFG_POS)
#define GPIO_WRCONFIG_HWSEL_POS              31           /*(WRCONFIG) Half-Word Select */
#define GPIO_WRCONFIG_HWSEL                  ((0x1UL) << GPIO_WRCONFIG_HWSEL_POS)
#define GPIO_WRCONFIG_MASK                   (0xDF47FFFF) /*(WRCONFIG) MASK Register */

#define GPIO_PMUX_OFFSET                     0x30         /*(PMUX offset) Peripheral Multiplexing n */
#define GPIO_PMUX_RESETVALUE                 (0x00)    /*(PMUX reset_value) Peripheral Multiplexing n */

#define GPIO_PMUX_PMUXE_POS                  0            /*(PMUX) Peripheral Multiplexing Even */
#define GPIO_PMUX_PMUXE_MSK                  ((0xF) << GPIO_PMUX_PMUXE_POS)
#define GPIO_PMUX_PMUXE(value)               (GPIO_PMUX_PMUXE_MSK & ((value) << GPIO_PMUX_PMUXE_POS))

#define GPIO_OUTSET_OFFSET                   0x18         /*(OUTSET offset) Data Output Value Set */
#define GPIO_OUTSET_RESETVALUE               (0x00000000) /*(OUTSET reset_value) Data Output Value Set */

#define GPIO_OUTSET_OUTSET_POS               0            /*(OUTSET) Port Data Output Value Set */
#define GPIO_OUTSET_OUTSET_MSK               ((0xFFFFFFFF) << GPIO_OUTSET_OUTSET_POS)
#define GPIO_OUTSET_OUTSET(value)            (GPIO_OUTSET_OUTSET_MSK & ((value) << GPIO_OUTSET_OUTSET_POS))

#define GPIO_OUTCLR_OFFSET                   0x14         /*(OUTCLR offset) Data Output Value Clear */
#define GPIO_OUTCLR_RESETVALUE               (0x00000000) /*(OUTCLR reset_value) Data Output Value Clear */

#define GPIO_OUTCLR_OUTCLR_POS               0            /*(OUTCLR) Port Data Output Value Clear */
#define GPIO_OUTCLR_OUTCLR_MSK               ((0xFFFFFFFF) << GPIO_OUTCLR_OUTCLR_POS)
#define GPIO_OUTCLR_OUTCLR(value)            (GPIO_OUTCLR_OUTCLR_MSK & ((value) << GPIO_OUTCLR_OUTCLR_POS))

#define GPIO_DIR_OFFSET                      0x00         /*(DIR offset) Data Direction */
#define GPIO_DIR_RESETVALUE                  (0x00000000) /*(DIR reset_value) Data Direction */

#define GPIO_DIR_DIR_POS                     0            /*(DIR) Port Data Direction */
#define GPIO_DIR_DIR_MSK                     ((0xFFFFFFFF) << GPIO_DIR_DIR_POS)
#define GPIO_DIR_DIR(value)                  (GPIO_DIR_DIR_MSK & ((value) << GPIO_DIR_DIR_POS))

#define GPIO_DIRCLR_OFFSET                   0x04         /*(DIRCLR offset) Data Direction Clear */
#define GPIO_DIRCLR_RESETVALUE               (0x00000000) /*(DIRCLR reset_value) Data Direction Clear */

#define GPIO_DIRCLR_DIRCLR_POS               0            /*(DIRCLR) Port Data Direction Clear */
#define GPIO_DIRCLR_DIRCLR_MSK               ((0xFFFFFFFF) << GPIO_DIRCLR_DIRCLR_POS)
#define GPIO_DIRCLR_DIRCLR(value)            (GPIO_DIRCLR_DIRCLR_MSK & ((value) << GPIO_DIRCLR_DIRCLR_POS))

#define GPIO_DIRSET_OFFSET                   0x08         /*(DIRSET offset) Data Direction Set */
#define GPIO_DIRSET_RESETVALUE               (0x00000000) /*(DIRSET reset_value) Data Direction Set */

#define GPIO_DIRSET_DIRSET_POS               0            /*(DIRSET) Port Data Direction Set */
#define GPIO_DIRSET_DIRSET_MSK               ((0xFFFFFFFF) << GPIO_DIRSET_DIRSET_POS)
#define GPIO_DIRSET_DIRSET(value)            (GPIO_DIRSET_DIRSET_MSK & ((value) << GPIO_DIRSET_DIRSET_POS))

#define GPIO_MASK_OFFSET                     16
#define GPIO_MASK_HIGHWORD                   0xffff0000
#define GPIO_MASK_LOWWORD                    0xffff

/* GPIO Module routines*/
/**************************************************************************************************

	Function:
	void GPIO_SetPinFunction (UINT32 gpio, UINT15 function)

	Summary:
		This Function used to set GPIO Pin function

	Devices Supported:
		UPD350 REV C&E

	Description:
		This Function used to set GPIO Pin function

	Precondition:
		None.

	Parameters:
		GPIO pin and Pin function

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
//void GPIO_SetPinFunction(UINT32 gpio, UINT32 function);

/**************************************************************************************************

	Function:
	void GPIO_SetPullMode (UINT32 gpio, UINT8 Pullmode)

	Summary:
		This Function used to set GPIO Pin pull mode

	Devices Supported:
		UPD350 REV C&E

	Description:
		This Function used to set GPIO Pin pull mode

	Precondition:
		None.

	Parameters:
		GPIO pin and Pull mode

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
//void GPIO_SetPullMode(UINT8 pin,UINT8 pullmode);

/**************************************************************************************************

	Function:
	void GPIO_SetDirection (UINT32 gpio, UINT8 direction)

	Summary:
		This Function used to set GPIO Pin direction

	Devices Supported:
		UPD350 REV C&E

	Description:
		This Function used to set GPIO Pin direction

	Precondition:
		None.

	Parameters:
		GPIO pin and direction

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
//void GPIO_SetDirection(UINT8 pin,UINT8 direction);

/**************************************************************************************************

	Function:
	void GPIO_SetPinLevel (UINT32 gpio, UINT8 level)

	Summary:
		This Function used to set GPIO Pin level

	Devices Supported:
		UPD350 REV C&E

	Description:
		This Function used to set GPIO Pin level

	Precondition:
		None.

	Parameters:
		GPIO pin and level

	Return:
		None.

	Remarks:
		None
**************************************************************************************************/
typedef void (*GPIO_SetPinFunction_cb)(UINT32 u8Pin, UINT32 u32Function);
extern GPIO_SetPinFunction_cb GPIO_SetPinFunction;
typedef void (*GPIO_SetPullMode_cb)(UINT8 u8Pin,UINT8 u8Pullmode);
extern GPIO_SetPullMode_cb GPIO_SetPullMode;

typedef void (*GPIO_SetPinLevel_cb)(UINT8 pin ,UINT8 level);
extern GPIO_SetPinLevel_cb GPIO_SetPinLevel;
typedef void (*GPIO_SetDirection_cb)(UINT8 u8pin,UINT8 u8direction);
extern GPIO_SetDirection_cb GPIO_SetDirection;
void IRQ_ResetUPD350ThruGPIOInit(void);
UINT32 GPIO_GetPinLevel(UINT8 u8pin);
#endif