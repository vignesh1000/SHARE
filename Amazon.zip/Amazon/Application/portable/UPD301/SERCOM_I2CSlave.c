/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include <SERCOM_I2CSlave.h>

/***************************************************************************************************/
#ifndef _IDEAL_
void I2C_SlaveIRQdrive (UINT8 u8driveVal)
{
	GPIO_SetPinLevel(PIN_PA06, u8driveVal);
}
#endif
void SERCOM1_Handler(void)
{
    /*Sercom1 interrupt enabled before going to MCU Idle.
    MCU woke up due to I2C addr match interrupt. 
    Dont acknowledge the interrupt, but disable the interrupt here,
    henceforth interrupt will not hit since handling in foreground.
    */ 
	
	/*Clear Set NVIC SERCOM1 Interrupt before going to sleep*/
	REGDW(NVIC_BASE_ADDR) &=~ INT_NVIC_SERCOM1;
  
  	/*Disable Address Match to wake up from MCU Idle*/
    REGB(I2C_SLAVE_INTENCLR) |= I2C_SLAVE_INTFLAG_AMATCH;
    
    #if INCLUDE_POWER_MANAGEMENT_CTRL
	/*Dont make MCU into IDLE*/
    gu8SetMCUidle = UPD_MCU_ACTIVE;
    #endif
     

}