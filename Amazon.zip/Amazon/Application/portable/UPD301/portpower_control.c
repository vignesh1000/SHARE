/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/


#include <stdinc.h>
#include <portpower_control.h>
#include <dac.h>

#ifdef _IDEAL_
float gdADCICalibFac = 0;
#endif

static void UPD_GPIOGeneric(UINT8 u8PortNum,UINT8 u8PIONum);

static void UPD_GPIOGeneric(UINT8 u8PortNum,UINT8 u8PIONum)
{
    UPD_GPIOEnableDisable(u8PortNum,u8PIONum,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(u8PortNum,u8PIONum,UPD_GPIO_SETDIR_OUTPUT);
    UPD_GPIOSetBufferType(u8PortNum,u8PIONum,UPD_GPIO_SETBUF_PUSHPULL);
}

void PWRCTRL_initialization(UINT8* pu8PortEnDis)
{

    if(PORT_STATUS_ENABLED == pu8PortEnDis[PORT0])
    {
        UPD_GPIOGeneric(PORT0,PWRCTRL_ENABLE_VBUS_DIS_IU);

        UPD_GPIOGeneric(PORT0,PWRCTRL_ENABLE_VBUS_IU);
#ifdef _IDEAL_        
        UPD_GPIOSetClearOutput(PORT0,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_SET);
#else        
        UPD_GPIOSetClearOutput(PORT0,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_CLEAR);
#endif
        
#ifdef _IDEAL_
        GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinFunction(PIN_PA28, GPIO_PIN_FUNC_OFF);
        
        GPIO_SetDirection(PIN_PA01, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinFunction(PIN_PA01, GPIO_PIN_FUNC_OFF);
        GPIO_SetDirection(PIN_PA15, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinFunction(PIN_PA15, GPIO_PIN_FUNC_OFF);

		
#else
        if(DCDC_RESERVED != gu8Port0DCDCSelType)
        {
            (void)DAC_Initialization();
            (void)ADC_Initialization();
        }
#endif
    }

    if(PORT_STATUS_ENABLED == pu8PortEnDis[PORT1])
    {
        UPD_GPIOGeneric(PORT1,PWRCTRL_ENABLE_DC_DC_EU);

        UPD_GPIOGeneric(PORT1,PWRCTRL_ENABLE_VBUS_EU);
        UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_VBUS_EU,UPD_GPIO_CLEAR);

        UPD_GPIOGeneric(PORT1,PWRCTRL_ENABLE_VBUS_DIS_EU);
        
        UPD_GPIOGeneric(PORT1,PWRCTRL_ENABLE_9V_EU);
        
        UPD_GPIOGeneric(PORT1,PWRCTRL_ENABLE_15V_EU);
        
        UPD_GPIOGeneric(PORT1,PWRCTRL_ENABLE_20V_EU);
    }

}


void PWRCTRL_SetPortPower (UINT8 u8PortNum, UINT16 u16VBUSVoltage)
{

   if(PORT0 == u8PortNum)
   {
        if ((PWRCTRL_VBUS_0V == u16VBUSVoltage) || \
		  			(!(UPD_RegReadWord (u8PortNum, UPD_PIO_STS) & \
					  				BIT(CONFIG_PORT_0_PRT_CTL_OCS_UPD_PIO))))
        {
			

#ifdef _IDEAL_
            UPD_GPIOSetClearOutput(PORT0,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_SET);
            
            gdADCICalibFac = 0;
            //GPIO_SetPinLevel(PIN_PA28, TRUE);
#else
            /*Drive EN_VBUS low when driving VBUS zero*/
            UPD_GPIOSetClearOutput(PORT0,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_CLEAR);
#endif
        }
        else
        {

#ifdef _IDEAL_
                UPD_GPIOSetClearOutput(PORT0,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_CLEAR);
                //GPIO_SetPinLevel(PIN_PA28, FALSE);
#else
		/*Drive EN_VBUS high when driving VBUS high*/
		UPD_GPIOSetClearOutput(PORT0,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_SET);
#endif

        }

#ifdef _IDEAL_

   switch (u16VBUSVoltage)
   {
  
	   case PWRCTRL_VBUS_5V:
	   {
		   GPIO_SetPinLevel(PIN_PA01, FALSE);
		   GPIO_SetPinLevel(PIN_PA15, FALSE);
                   gdADCICalibFac = 5.280528;
		   break;
	   }
   
	   case PWRCTRL_VBUS_9V:
	   {
   
		   GPIO_SetPinLevel(PIN_PA01, TRUE);
		   GPIO_SetPinLevel(PIN_PA15, FALSE);
                   gdADCICalibFac = 4.670012;
		   break;
	   }
   
	   case PWRCTRL_VBUS_15V:
	   {
		   GPIO_SetPinLevel(PIN_PA01, FALSE);
		   GPIO_SetPinLevel(PIN_PA15, TRUE);
                   gdADCICalibFac = 3.233154;
		   break;
	   }
   
	   case PWRCTRL_VBUS_20V:
	   {
		   GPIO_SetPinLevel(PIN_PA01, TRUE);
		   GPIO_SetPinLevel(PIN_PA15, TRUE);
                   gdADCICalibFac = 2.446134;
		   break;
	   }
   
	   default:
	   break;
   }
#else
   (void)DAC_DriveVoltage(u16VBUSVoltage);
#endif



   }

   else if (1 == u8PortNum)
   {
		if ((PWRCTRL_VBUS_0V == u16VBUSVoltage) || \
		  			(!(UPD_RegReadWord (u8PortNum, UPD_PIO_STS) & \
					  				BIT(CONFIG_PORT_1_PRT_CTL_OCS_UPD_PIO))))
		{
            /*Drive EN_VBUS low when driving VBUS zero*/
            UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_VBUS_EU, UPD_GPIO_CLEAR);
        }
        else
        {
            /*Drive EN_VBUS high when driving VBUS high*/
            UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_VBUS_EU, UPD_GPIO_SET);
        }
		
        switch (u16VBUSVoltage)
        {
            case PWRCTRL_VBUS_0V:
            {

                /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_15V_EU,PWRCTRL_ENABLE_20V_EU,
                PWRCTRL_ENABLE_DC_DC_EU*/

                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_CLEAR);
                break;
            }

            case PWRCTRL_VBUS_5V:
            {

                 /*Setting PWRCTRL_ENABLE_DC_DC_EU */
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SET);

                /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_15V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_CLEAR);

                break;
            }

            case PWRCTRL_VBUS_9V:
            {

                /*Setting PWRCTRL_ENABLE_DC_DC_EU,PWRCTRL_ENABLE_9V_EU */
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SET);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_SET);

                 /*Resetting PWRCTRL_ENABLE_15V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_CLEAR);

                break;
            }

            case PWRCTRL_VBUS_15V:
            {

                /*Setting PWRCTRL_ENABLE_DC_DC_EU,PWRCTRL_ENABLE_15V_EU*/
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_SET);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SET);

                 /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_CLEAR);

                break;
            }

            case PWRCTRL_VBUS_20V:
            {
                /*Setting PWRCTRL_ENABLE_DC_DC_EU,PWRCTRL_ENABLE_20V_EU*/
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_20V_EU,UPD_GPIO_SET);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_DC_DC_EU,UPD_GPIO_SET);

                /*Resetting PWRCTRL_ENABLE_9V_EU,PWRCTRL_ENABLE_15V_EU*/
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_9V_EU,UPD_GPIO_CLEAR);
                UPD_GPIOSetClearOutput(PORT1,PWRCTRL_ENABLE_15V_EU,UPD_GPIO_CLEAR);
                break;
            }

            default:
            break;
        }
   }
}

void PWRCTRL_ConfigVBUSDischarge (UINT8 u8PortNum, UINT8 u8EnaDisVBUSDIS)
{
    if (u8EnaDisVBUSDIS == PWRCTRL_ENABLE_VBUSDIS )
    {
        if(u8PortNum == PWRCTRL_INTERNAL_UPD_PORT)
        {
            UPD_GPIOSetClearOutput(PWRCTRL_INTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_DIS_IU,UPD_GPIO_SET);

        }
        else
        {
            UPD_GPIOSetClearOutput(PWRCTRL_EXTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_DIS_EU,UPD_GPIO_SET);
        }

    }
    else
    {
        if(u8PortNum == PWRCTRL_INTERNAL_UPD_PORT)
        {
            UPD_GPIOSetClearOutput(PWRCTRL_INTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_DIS_IU,UPD_GPIO_CLEAR);
        }
        else
        {
            UPD_GPIOSetClearOutput(PWRCTRL_EXTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_DIS_EU,UPD_GPIO_CLEAR);
        }

    }

}

void PWRCTRL_ConfigSink (UINT8 u8PortNum, UINT8 u8EnaDisSink)
{
    /*Sets the VBUS_SRC_EN pin of PMPD to enable the Sink MOSFETS */
    if (u8EnaDisSink == PWRCTRL_ENABLE_SINK_HW)
    {
        if(u8PortNum == PWRCTRL_INTERNAL_UPD_PORT)
        {
            UPD_GPIOSetClearOutput(PWRCTRL_INTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_SET);

        }
        else
        {
            UPD_GPIOSetClearOutput(PWRCTRL_EXTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_EU,UPD_GPIO_SET);
        }

    }
    /*Clears the VBUS_SRC_EN pin of PMPD to disable the Sink MOSFETS */
    else
    {
        if(u8PortNum == PWRCTRL_INTERNAL_UPD_PORT)
        {
            UPD_GPIOSetClearOutput(PWRCTRL_INTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_IU,UPD_GPIO_CLEAR);
        }
        else
        {
            UPD_GPIOSetClearOutput(PWRCTRL_EXTERNAL_UPD_PORT,PWRCTRL_ENABLE_VBUS_EU,UPD_GPIO_CLEAR);
        }

    }

}
