/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
#include <stdinc.h>
#include <Hermes_Interface.h>
#include <PDFWUpdate.h>
#ifndef ZEUSSTACKCONFIG_H /*To avoid multiple inclusion of the file*/  
#define ZEUSSTACKCONFIG_H
#endif
#include "Shared_Globals.h"
#include "bootloaderapis.h"

static UINT8 gu8LatestRequest;

typedef UINT8 (*CheckI2CReq_cb)(void);
CheckI2CReq_cb CheckI2CReqCB = (CheckI2CReq_cb )__I2C_CheckI2CRequest;
	/* Assign the jump address */
typedef void (*I2CSlaveInit_cb)(void);
I2CSlaveInit_cb I2CSlaveInitCB = (I2CSlaveInit_cb )__I2C_SlaveInit;
	/* Assign the jump address */
typedef UINT8 (*I2CSlaveRead_cb)(UINT8*);
I2CSlaveRead_cb I2CSlaveReadCB = (I2CSlaveRead_cb )__I2C_SlaveRead;
	/* Assign the jump address */
typedef UINT8 (*I2CSlaveWrite_cb)(UINT8*,UINT16);
I2CSlaveWrite_cb I2CSlaveWriteCB = (I2CSlaveWrite_cb )__I2C_SlaveWrite;
	/* Assign the jump address */


NVM_ProgramMemory_cb NVM_ProgramMemoryCB = (NVM_ProgramMemory_cb )__NVM_ProgramMemory;
NVM_ReadMemory_cb NVM_ReadMemoryCB = (NVM_ReadMemory_cb )__NVM_ReadMemory;

/* Call back routine for NVM init in boot loader*/
typedef UINT8 (*NVM_Init_cb)(void);
NVM_Init_cb NVM_InitCB = (NVM_Init_cb )__NVM_Init;

static volatile UINT8 gu8DetachdelayExpired = FALSE;
/******************************************************************************
 * Function:        Hermes_GetLength(UINT8 u8HighByte, UINT8 u8LowByte)
 * Input:           MSB byte of Data length, LSB Byte of Data length
 * Output:          Combined 16bits of length
 * Overview:
 * Note:
 *****************************************************************************/
static UINT16 Hermes_GetLength (UINT8 u8HighByte,   /* MSB Byte of Data Length */
                                UINT8 u8LowByte)    /* LSB Byte of Data Length */
{
    /*Get Length from Hermes Buffer */
    return (((UINT16) ((UINT16) u8HighByte) << 8u) | ((UINT16) u8LowByte));
}

/******************************************************************************
 * Function:        Hermes_InterfaceInit(void)
 * Input:           None
 * Output:          None
 * Overview:        This routine initilizes I2C module
 * Note:
 *****************************************************************************/
void Hermes_InterfaceInit(void)
{
    if(PORT_STATUS_ENABLED!=gau8PortDisable[PORT0])
    {
      /**Internal UPD350 is not working, Assign the default slave address to 0x78u*/
        gu8SlaveAddr = 0x78u;
    }
    else
    {
      /**Initialization value, will be overwritten by according to configured I2C Strap*/
        gu8SlaveAddr = 0x00u;
    }
    
    I2CSlaveInitCB();
    (void)NVM_InitCB();
}

/******************************************************************************
 * Function:        Hermes_IfConnectionRequest(void)
 * Input:           None
 * Output:          UINT8 u8ReqStatus
 * Overview:        This routine Checks I2C master transmission request from master
 * Note:
 *****************************************************************************/
UINT8 Hermes_IfConnectionRequest(void)
{
    UINT8 u8ReqStatus;
    /*Check I2C master transmission request from master*/
    u8ReqStatus = CheckI2CReqCB();
    return u8ReqStatus;
}

/******************************************************************************
 * Function:        Hermes_ProcessMasterRequest(void)
 * Input:           None
 * Output:          UINT8 u8ReqStatus
 * Overview:        This routine process the request from master
 * Note:
 *****************************************************************************/
UINT8 Hermes_ProcessMasterPacket (void)
{
    UINT8 u8HermesStatus = TRUE;

    if ((REGW (I2C_SLAVE_STATUS) & I2C_SLAVE_STATUSDIR))
    {
        /* Read request from Hermes master */
        u8HermesStatus = Hermes_ProcessResponsePacket ();
        //todo: john to fix this workaround
        gu8RequestType = HERMES_INVALID_REQUEST;
    }
    else
    {
        /* Write request from Hermes master */
        u8HermesStatus = Hermes_ProcessRequestPacket ();
    }

    return u8HermesStatus;
}

UINT8 Hermes_HandleDiscoveryReq (void)
{
    UINT8 u8HRespCode = HERMES_HRESP_OK;

    //Initialization Functions
    return u8HRespCode;
}

UINT16 Hermes_HandleDiscoveryResp (void)
{
    UINT16 u16Index = 1;

    /*Hermes Major Revision */
    gu8HermesResBuffer[u16Index++] = HERMES_MAJOR_REV;

    /*Hermes Minor Revision */
    gu8HermesResBuffer[u16Index++] = HERMES_MINOR_REV;

    /*Hermes PD System Firmware Major Revision */
    gu8HermesResBuffer[u16Index++] = (HERMES_PD_SYS_FW_REV >> 8);

    /*Hermes PD System Firmware Minor Revision */
    gu8HermesResBuffer[u16Index++] = (HERMES_PD_SYS_FW_REV & 0xff);

    /*Hermes PD System HW Major Revision */
    gu8HermesResBuffer[u16Index++] = (HERMES_PD_SYS_HW_REV >> 8);

    /*Hermes PD System HW Minor Revision */
    gu8HermesResBuffer[u16Index++] = (HERMES_PD_SYS_HW_REV & 0xff);

    /*Hermes- v0.33 User Flags */
    gu8HermesResBuffer[u16Index++] = 0x00;
    gu8HermesResBuffer[u16Index++] = gu8CurrentMemory;

    gu8HermesResBuffer[u16Index++] = HERMES_NUM_OF_CONN_SUPPORTED;

    /* Connection Information block about PDFW_UPDATE */
    /*Index 0 represents Connection_ID */
    gu8HermesResBuffer[u16Index++] = HERMES_CONN_ID_PD_FW_UPDATE;

    /*Index 1 represents Number of bytes following CIB_Length Field */
    gu8HermesResBuffer[u16Index++] = HERMES_NUM_OF_BYTES_CIB_LENGTH;

    /*Protocol ID */
    gu8HermesResBuffer[u16Index++] = HERMES_PROT_PDFWU;

    /*Buffer Size */
    gu8HermesResBuffer[u16Index++] = HERMES_CONN_INFO_BUF_SIZE_256;

    /*Connection Information block about DEBUG */
    /*Index 0 represents Connection_ID */
    gu8HermesResBuffer[u16Index++] = HERMES_CONN_ID_DEBUG;

    /*Index 1 represents Number of bytes following CIB_Length Field */
    gu8HermesResBuffer[u16Index++] = HERMES_NUM_OF_BYTES_CIB_LENGTH;

    /*Protocol ID */
    gu8HermesResBuffer[u16Index++] = HERMES_PROT_PROT_DEBUG;

    /*Buffer Size */
    gu8HermesResBuffer[u16Index] = HERMES_CONN_INFO_BUF_SIZE_256;

    /*Update Byte Count */
    gu8HermesResBuffer[0] = (UINT8)u16Index;

    return u16Index;
}
/******************************************************************************
 * Function:        Hermes_ProcessRequestPacket(void)
 * Input:           None
 * Output:          UINT8 u8ReqStatus
 * Overview:        This routine process hermes master request packet
 * Note:
 *****************************************************************************/
UINT8 Hermes_ProcessRequestPacket (void)
{
    UINT8 u8Status;

    u8Status =I2CSlaveReadCB(gu8HermesReqBuffer);

    if (FALSE != u8Status)
    {
        if (HERMES_MIN_REQUEST_LENGTH > gu16Rxcount)
        {
            gu8RequestType = HERMES_INVALID_REQUEST;
            gu8ConnectionID = HERMES_CONN_ID_INVALID;
        }
        else
        {
            gu8RequestType = gu8HermesReqBuffer[HERMES_BUFFER_RQTYP_IDX];
            gu8ConnectionID = gu8HermesReqBuffer[HERMES_BUFFER_CNID_IDX];
        }
        
        if (gu8RequestType == 0x00u)
        {
            return 0;
        }
        #ifdef PDFU_VALIDATION
        if (gu8RequestType >= UPD_VALIDATION_REQUEST)
        {
            /* process Validation Request */
            pdfuValidation_ProcessHermesRequest(&gu8HermesReqBuffer[2]);
            return u8Status;
        }
        #endif

        
        #ifdef VALIDATION
        #if VALIDATION == 1
        if (gu8RequestType >= UPD_VALIDATION_REQUEST)
        {
            /* process Validation Request */
            Validation_ProcessHermesRequest(&gu8HermesReqBuffer[2]);
            return u8Status;
        }
        #endif
        #endif
        
        switch (gu8RequestType & UPD_VALIDATION_MASK)
        {
            case HERMES_DISCOVERY_REQUEST:
            {
                /*Process Discovery request */
                gu8LatestRequest = HERMES_DISCOVERY_REQUEST;
                (void) Hermes_HandleDiscoveryReq ();
                break;
            }

            case HERMES_PROTOCOL_TX_REQUEST:
            {
                /*Process Protocol Tx request */
                Hermes_HandleProtocolTxReq ();
                break;
            }
            #ifdef VALIDATION
			#if VALIDATION == 1
            case UPD_SYSTEM_RESET_REQUEST:
            {
                /* process System reset  */
                UPD301_Reset();
                break;
            }
            #endif
			#endif
            case HERMES_CONNECTION_REQUEST:
            {
                gu8LatestRequest = HERMES_CONNECTION_REQUEST;
                #if (FALSE != INCLUDE_PDFU)
                
                if(FALSE != gsPdfuInfo.u8IsPDFUActive)
                {
                    gu8HermesConnectionActive = FALSE;
                }
                else
                {
                    gu8HermesConnectionActive = TRUE;
                }
                #else
                gu8HermesConnectionActive = TRUE;
                #endif
                break;
            }                   
            case HERMES_DISCONNECT_REQUEST:
            {
                gu8LatestRequest = HERMES_DISCONNECT_REQUEST;
                gu8HermesConnectionActive = FALSE;
                break;
            }            
            
            default:
            {
                /**
                  
                  HERMES_DISCONNECT_RESPONSE
                  HERMES_CONFIGURATION_RESPONSE
                */
                break;
            }
          
        }
    }

    return u8Status;

}


/******************************************************************************
 * Function:        Hermes_ProcessResponsePacket(void)
 * Input:           None
 * Output:          UINT8 u8ReqStatus
 * Overview:        This routine process hermes master response packet
 * Note:
 *****************************************************************************/
UINT8 Hermes_ProcessResponsePacket (void)
{
    UINT16 u16Length = 0u;
    UINT8 u8Status = FALSE;

#ifdef VALIDATION
#if VALIDATION == 1
    if (gu8RequestType >= UPD_VALIDATION_REQUEST)
    {
                u16Length = Validation_ProcessHermesResponse(gu8HermesResBuffer);
                u8Status = I2CSlaveWriteCB (gu8HermesResBuffer, u16Length);
                return u8Status;
    }
#endif
#endif

#ifdef PDFU_VALIDATION
if (gu8RequestType >= 0x90)
{
    /* process Validation Request */
                u16Length = pdfuValidation_ProcessHermesResponse(gu8HermesResBuffer);
                u8Status = I2CSlaveWriteCB (gu8HermesResBuffer, u16Length);
    return u8Status;
}
#endif


    switch (gu8RequestType & UPD_VALIDATION_MASK)
    {
        case HERMES_DISCOVERY_RESPONSE:
        {
            if (HERMES_DISCOVERY_REQUEST==gu8LatestRequest)
            {
	            //Process Discovery request
	            u16Length = Hermes_HandleDiscoveryResp ();
	            u8Status = I2CSlaveWriteCB (gu8HermesResBuffer, u16Length);
            }
            else
            {
                gu8HResponseCode = HERMES_HRESP_INVALID;
                /*Send zero length I2C packet, otherwise I2CMaster may hang */
                u8Status = I2CSlaveWriteCB
                    (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);                  
            }
            gu8LatestRequest = HERMES_INVALID_REQUEST;
            break;
        }

        case HERMES_PROTOCOL_TX_RESPONSE:
        case HERMES_PROTOCOL_RX_RESPONSE:
        {

              /*gu8HResponseCode is last error occurred in I2C transaction */
            u8Status = I2CSlaveWriteCB (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);
            break;
        }
        case HERMES_PROTOCOL_RX_REQUEST:
        {

            /*Process Protocol Rx request*/
            u16Length = Hermes_GetLength (gu8HermesResBuffer[HERMES_HIGH_BYTE_INDEX],
                                            gu8HermesResBuffer[HERMES_LOW_BYTE_INDEX]);


            if (u16Length != 0)
            {
                u8Status = I2CSlaveWriteCB (&gu8HermesResBuffer[0], (u16Length + HERMES_LENGTH_BYTE_COUNT));

                /*Check return value whether true or false*/
                if (u8Status)
                {
                    /*Everything is okay, set error code as OK*/
                    gu8HResponseCode = HERMES_HRESP_OK;
                }
                else
                {
                    /*I2C write was failed, set error code as OK*/
                    gu8HResponseCode = HERMES_HRESP_INVALID;
                }
            }
            else
            {
                /*Send zero length I2C packet, otherwise I2CMaster may hang*/
                u8Status = I2CSlaveWriteCB (&gu8HermesResBuffer[0], (u16Length + HERMES_LENGTH_BYTE_COUNT));

                /*Nothing matched the request ID, Hence set the error code as invalid*/
                gu8HResponseCode = HERMES_HRESP_NO_ACTION;
            }

            /*Process completed, Invalidate the length here*/
            gu8HermesResBuffer[HERMES_HIGH_BYTE_INDEX] = 0;
            gu8HermesResBuffer[HERMES_LOW_BYTE_INDEX] = 0;

            break;
        }
        case HERMES_CONNECTION_RESPONSE:
        {
            if(HERMES_CONNECTION_REQUEST==gu8LatestRequest)
            {
	            if((gu8ConnectionID == HERMES_CONN_ID_PD_FW_UPDATE) || (gu8ConnectionID == HERMES_CONN_ID_DEBUG))
	            {
                
	                #if (FALSE != INCLUDE_PDFU)
                
	                if(FALSE == gsPdfuInfo.u8IsPDFUActive)
	                {
	                    gu8HResponseCode = HERMES_HRESP_OK;
	                    gu8HermesConnectionActive = TRUE;
	                }
	                else
	                {
	                  /**
	                      Both PD FW Update & Debug connection chaannels has provisions to write ROM memory;
	                      Hence both the connections shall not be allowed when PDFU through CC interface is already active.
	                    */
	                    gu8HermesConnectionActive = FALSE;
	                    gu8HResponseCode = HERMES_HRESP_BUSY;
	                }
	                #else
	                gu8HResponseCode = HERMES_HRESP_OK;
	                #endif
	            }
	            else
	            {/** If the connection request is given to unavailable channel*/ 
	                gu8HResponseCode = HERMES_HRESP_INVALID;
	            }
	            /*Send zero length I2C packet, otherwise I2CMaster may hang */
	            u8Status = I2CSlaveWriteCB
	                (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);
            }
            else
            {
                gu8HResponseCode = HERMES_HRESP_INVALID;
                /*Send zero length I2C packet, otherwise I2CMaster may hang */
                u8Status = I2CSlaveWriteCB
                    (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);                  
            } 
            gu8LatestRequest = HERMES_INVALID_REQUEST;            
            break;
        }
        
        case HERMES_DISCONNECT_RESPONSE:
        {
            if(HERMES_DISCONNECT_REQUEST==gu8LatestRequest)
            {
	            gu8HermesConnectionActive = FALSE;
	            gu8HResponseCode = HERMES_HRESP_OK;
	            /*Send zero length I2C packet, otherwise I2CMaster may hang */
	            u8Status = I2CSlaveWriteCB
	                (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);
            }
            else
            {
                gu8HResponseCode = HERMES_HRESP_INVALID;
                /*Send zero length I2C packet, otherwise I2CMaster may hang */
                u8Status = I2CSlaveWriteCB
                    (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);                  
            }
            gu8LatestRequest = HERMES_INVALID_REQUEST;
            break;
        }      
        default:
        {
            /**
              HERMES_CONNECTION_RESPONSE
              HERMES_DISCONNECT_RESPONSE
              HERMES_CONFIGURATION_RESPONSE
            */
            /**Fix for JIRA:UPD301-93 */

            gu8HResponseCode = HERMES_HRESP_INVALID;
            /*Send zero length I2C packet, otherwise I2CMaster may hang */
            u8Status = I2CSlaveWriteCB
                (&gu8HResponseCode, HERMES_RESPONSE_CODE_LENGTH);
			gu8LatestRequest = HERMES_INVALID_REQUEST;
            break;
        }
    }
    return u8Status;
}


UINT8 Hermes_ProcessDebugRequestPacket (UINT8 * u8RequestBuffer,
                                  UINT16 u16RequestLength,
                                  UINT8 * u8ResponseBuffer,
                                  UINT16 * u16ResponseLength)
{
    UINT8 u8Status = HERMES_HRESP_OK;
    //MEMORY_RW_HEADER MemReadWrite;
    UINT32 u32MemAddr;
    *u16ResponseLength = 0;
    //(void)CONFIG_HOOK_MEMCPY((UINT8 *)&MemReadWrite, &u8RequestBuffer[2], sizeof(MEMORY_RW_HEADER));

    u32MemAddr = ((MEMORY_RW_HEADER*)(&u8RequestBuffer[2]))->u32MemoryAddr;

    /*u8RequestBuffer[0] & [1] is reserved for length*/
    switch (((MEMORY_RW_HEADER*)(&u8RequestBuffer[2]))->u8CMD)
    {
        case HERMES_COMMAND_SET_FEATURE:
            if(u8RequestBuffer[7] == HERMES_SET_FEATURE_RESET_CMD)
            {
                UPD301_Reset();
            }
        break;
        case HERMES_COMMAND_MEM_WRITE:
        {

            if (u32MemAddr <= 0x0000FFFF)
            {
                (void)NVM_ProgramMemoryCB( u32MemAddr , &u8RequestBuffer[9], ((MEMORY_RW_HEADER*)(&u8RequestBuffer[2]))->u16DataLength);
            }
            else
            {
                //TODO: Valid Address check must be done
                (void)CONFIG_HOOK_MEMCPY((UINT8 *)u32MemAddr, &u8RequestBuffer[9],((MEMORY_RW_HEADER*)(&u8RequestBuffer[2]))->u16DataLength);
            }


            break;
        }

        case HERMES_COMMAND_MEM_READ:
        {

            if (u32MemAddr <= 0x0000FFFF)
            {
                /*Read NVM Flash with same address and length*/
                (void)NVM_ReadMemoryCB(u32MemAddr, &u8ResponseBuffer[sizeof(MEMORY_RW_HEADER) + 2], ((MEMORY_RW_HEADER*)(&u8RequestBuffer[2]))->u16DataLength);
            }
            else
            {
                (void)CONFIG_HOOK_MEMCPY(&u8ResponseBuffer[sizeof(MEMORY_RW_HEADER) + 2], (UINT8 *)u32MemAddr, ((MEMORY_RW_HEADER*)(&u8RequestBuffer[2]))->u16DataLength);
            }
            /*Fill the response buffer*/
            (void)CONFIG_HOOK_MEMCPY(&u8ResponseBuffer[2], (UINT8 *)&u8RequestBuffer[2], sizeof(MEMORY_RW_HEADER));

            *u16ResponseLength =
                sizeof (MEMORY_RW_HEADER) + 2 + ((MEMORY_RW_HEADER*)(&u8RequestBuffer[2]))->u16DataLength;

            break;
        }
        default:
        {
             u8Status = HERMES_HRESP_INVALID;
             break;
        }
    }
    return u8Status;

}
/******************************************************************************
 * Function:        Hermes_HandleProtocolTxReq(void)
 * Input:           None
 * Output:          UINT8 u8ReqStatus
 * Overview:        This routine process hermes Protocol Tx Request
 * Note:
 *****************************************************************************/
void Hermes_HandleProtocolTxReq (void)
{
    UINT16 u16ReqLength;
    UINT16 u16ResponseLength = 0;


    /*Get Length from Hermes Buffer*/
    u16ReqLength =
      Hermes_GetLength (gu8HermesReqBuffer[HERMES_BUFFER_SIZEMSB_IDX],
                        gu8HermesReqBuffer[HERMES_BUFFER_SIZELSB_IDX]);


      /*Check requested connection ID to check protocol ID*/
    if (gu8ConnectionID == HERMES_CONN_ID_PD_FW_UPDATE)
    {
        /*For Request & Response buffer: Ignore length indexes and process from index 2 and so
        length would be length - 2*/
      gu8HResponseCode =
        PDFW_ProcessRequestPacket (&gu8HermesReqBuffer
                                   [HERMES_BUFFER_SIZEMSB_IDX], u16ReqLength,
                                   &gu8HermesResBuffer
                                   [HERMES_DATA_PAYLOAD_START_INDEX],
                                   &u16ResponseLength);

    }
    else if (gu8ConnectionID == HERMES_CONN_ID_DEBUG)
    {
      gu8HResponseCode =
        Hermes_ProcessDebugRequestPacket (&gu8HermesReqBuffer
                                          [HERMES_BUFFER_SIZEMSB_IDX],
                                          u16ReqLength,
                                          &gu8HermesResBuffer
                                          [HERMES_DATA_PAYLOAD_START_INDEX],
                                          &u16ResponseLength);
    }
    /*Add Else if cases for other connections*/
    else
    {
        /*Fill zeroes in response buffer length*/
        u16ResponseLength = 0;

        /*Nothing matched the request ID, Hence set the error code as invalid*/
        gu8HResponseCode = HERMES_HRESP_INVALID;

    }


      /*Assign Length MSB and LSB*/
    gu8HermesResBuffer[HERMES_HIGH_BYTE_INDEX] =
      (UINT8) (u16ResponseLength >> 8);
    gu8HermesResBuffer[HERMES_LOW_BYTE_INDEX] =  u16ResponseLength & 0xff;

}


void UPD301_Reset(void)
{
    __DSB();   /* Ensure all outstanding memory accesses included
                  buffered write are completed before reset */
    /*SCB->AIRCR  = ((0x5FAUL << SCB_AIRCR_VECTKEY_Pos) |
    SCB_AIRCR_SYSRESETREQ_Msk);*/

    *((volatile UINT32*)(0xe000ed0c)) = 0x5fa0004;


    __DSB();                                                          /* Ensure completion of memory access */

    for(;;)                                                           /* wait until reset */
    {
        __NOP();
    }

}

void UPD301_EraseUpdatableAppSignature(void)
{
    
    (void)NVM_ReadMemoryCB((UINT32)0xFF00u, &gu8HermesReqBuffer[0u], 256);
    gu8HermesReqBuffer[255]  = 0xaa;
    gu8HermesReqBuffer[254]  = 0xaa;
    gu8HermesReqBuffer[253]  = 0xaa;
    gu8HermesReqBuffer[252]  = 0xaa;
    (void)NVM_ProgramMemoryCB( (UINT32)0xFF00u ,&gu8HermesReqBuffer[0u], 256);
}



void UPD301_DetachPorts(void)
{
    UINT8 u8CurrentPowerRole;
    UINT16 u16CCControlReg1Val;
    
  	for (UINT8 u8PortNum = 0; u8PortNum < CONFIG_PD_PORT_COUNT; u8PortNum++)
  	{
        u8CurrentPowerRole= DPM_GET_CURRENT_POWER_ROLE(u8PortNum);
        
        if (PD_ROLE_SINK == u8CurrentPowerRole)
        {
            u16CCControlReg1Val = (TYPEC_CC1_PULL_DOWN_OPEN|TYPEC_CC2_PULL_DOWN_OPEN);
            
            /*Writing the CC control register directly because it wont affect the CC comparator Sample 
            operation as it would have been turned down at this time*/
            
            /*Setting the Rd and Rp Value*/ 
            UPD_RegisterWrite (u8PortNum, TYPEC_CC_CTL1, (UINT8 *)&u16CCControlReg1Val, BYTE_LEN_2);
        }
        else
        if (PD_ROLE_SOURCE== u8CurrentPowerRole)
        {
            u16CCControlReg1Val = 0;
            u16CCControlReg1Val |= (TYPEC_CC1_PULL_DOWN_OPEN|TYPEC_CC2_PULL_DOWN_OPEN);
            
            /*Writing the CC control register directly because it wont affect the CC comparator Sample 
            operation as it would have been turned down at this time*/
            
            /*Setting the Rd and Rp Value*/ 
            UPD_RegisterWrite (u8PortNum, TYPEC_CC_CTL1, (UINT8 *)&u16CCControlReg1Val, BYTE_LEN_2);
            gu8DetachdelayExpired = FALSE;
            
            (void)PDTimer_Start(25u, UPD301_DetachDelayCB, NULL, NULL);
            while(FALSE == gu8DetachdelayExpired);
            /** Disable VBUS */
            TypeC_VBUSDrive (u8PortNum, PWRCTRL_VBUS_0V);
            
            if(DPM_IsPort_VCONN_Source(u8PortNum))
            {
                DPM_VConnOnOff(u8PortNum, DPM_VCONN_OFF);
            }
        }
    }
    
    /** 25ms Delay for the Detach to be identified by the Port partner*/
    gu8DetachdelayExpired = FALSE;
    
    (void)PDTimer_Start(25u, UPD301_DetachDelayCB, NULL, NULL);
    
    while(FALSE == gu8DetachdelayExpired);
}
    
          
void UPD301_DetachDelayCB(
    UINT8   u8PortNum,          /* */
    UINT8   u8PdFwUpdtState)    /* */
{
    gu8DetachdelayExpired = TRUE;
}
