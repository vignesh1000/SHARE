/**
 * \file
 *
 * \brief HPL initialization related functionality implementation.
 *
 * Copyright (C) 2014-2017 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

#include <hpl_gpio.h>
#include <hpl_init.h>
#include <hpl_pm_config.h>
#include <hpl_sysctrl_config.h>

/**
 * \brief Initialize the hardware abstraction layer
 */
#define MY_SYSCTRL_OSC8M_MASK ((uint32_t)0xCFFF0002ul)
#define GCLK_GENERATOR_1 1
#define GCLK_GENERATOR_0 0


void CLOCKS_OSC8M_Init(uint8_t divider)
{
  /* change the clock frequency from 1MHz to 8MHz */
  SYSCTRL->OSC8M.reg = (MY_SYSCTRL_OSC8M_MASK & SYSCTRL->OSC8M.reg) |
                       SYSCTRL_OSC8M_ONDEMAND |
                       SYSCTRL_OSC8M_RUNSTDBY |
                       divider;
}
/**************************************************************************
Initialize the DFLL to run at 48MHz. Using the OSC8M clock which must 
have its divider set to 0 (running at 8MHz). GCLK1 is used to create the 32KHz
clock to be the reference for the DFLL. Then configure and enable the DFLL.
Choose GCLK0 source to be DFLL for the CPU and its buses 
**************************************************************************/
void CLOCKS_DFLL_Init(void)
{
 /* To configure the generic clock generator refer section 15.6.2.1. Initialization in Datasheet*/	
	
  /* configuration of the NVM CTRLB register and set the flash wait states */
  NVMCTRL->CTRLB.bit.RWS = 1;

  /* use the OSC8M as the reference clock for the DFLL, the reference input needs
   to be less than or equal to 32KHz for 48MHz DFLL. 8MHz/250 = 32KHz */
  GCLK_GENDIV_Type gendiv =
  {
    .bit.DIV = 250,
    .bit.ID = GCLK_GENERATOR_1,
  };
  GCLK->GENDIV.reg = gendiv.reg;

  //Configure GCLK1 as 32Khz with use of OSC8Mhz
  GCLK_GENCTRL_Type genctrl =
  {
    .bit.RUNSTDBY = false,  /* Run in Standby */
    .bit.DIVSEL = false,    /* Divide Selection */
    .bit.OE = false,        /* Output Enable to observe on a port pin */
    .bit.OOV = false,       /* Output Off Value */
    .bit.IDC = true,        /* Improve Duty Cycle */
    .bit.GENEN = true,
    /* Select which generic clock source,These bits define the clock source to be used as the source for the generic clock generator */
    .bit.SRC = GCLK_SOURCE_OSC8M,
    /* Select which generic clock generator to configure */
    .bit.ID = GCLK_GENERATOR_1,
  };
  
  //Write the register
  GCLK->GENCTRL.reg = genctrl.reg;
  
  /* wait for synchronization to complete */
  while (GCLK->STATUS.bit.SYNCBUSY);

  /*Configure DFLLCTRL reg */
  GCLK_CLKCTRL_Type clkctrl =
  {
    /* The generic clock and the associated generic clock generator and division factor are locked */
    .bit.WRTLOCK = false,
    /* The generic clock is enabled */
    .bit.CLKEN = true,
    /* Select Generic Clock Generator,The Generic Clock Generator used as the source of the generic clock gclk1*/
    .bit.GEN = GCLK_GENERATOR_1,
    /* Select the Generic Clock 0 */
    .bit.ID = SYSCTRL_GCLK_ID_DFLL48,
  };
  
  //Write DFLLCTRL reg
  GCLK->CLKCTRL.reg = clkctrl.reg;

  /* Workaround for errata 9905 */
  SYSCTRL->DFLLCTRL.bit.ONDEMAND = 0;
  
  /* wait for the DFLL clock to be ready */
  while (SYSCTRL->PCLKSR.bit.DFLLRDY == false);

  //Configure DFLL ctrl register with following configuration
  SYSCTRL_DFLLCTRL_Type dfllctrl =
  {
    /*.bit.WAITLOCK = false,   Output clock when DFLL is locked 
    .bit.BPLCKC = false,     Bypass coarse lock is enabled */
    .bit.QLDIS = true,      /* Quick Lock is disabled */
    .bit.CCDIS = false,     /* Chill Cycle is disabled */
    .bit.ONDEMAND = false,  /* The oscillator is enabled when a peripheral is requesting the oscillator to be used as a clock source */
    .bit.RUNSTDBY = false,  /* The oscillator is not stopped in standby sleep mode */
    /*.bit.USBCRM = false,     USB Clock Recovery Mode is enabled. */
    .bit.LLAW = false,      /* Locks will be lost after waking up from sleep modes if the DFLL clock has been stopped */
    .bit.STABLE = false,    /* FINE calibration register value will be fixed after a fine lock */
    .bit.MODE = true,       /* The DFLL operates in closed-loop operation. */
    .bit.ENABLE = false,    /* The DFLL oscillator is enabled. */
  };
  
  //Write the register
  SYSCTRL->DFLLCTRL.reg = dfllctrl.reg;
  
  /* wait for the DFLL clock to be ready */
  while (SYSCTRL->PCLKSR.bit.DFLLRDY == false);

  /* get the coarse and fine values stored in NVM */
  uint32_t coarse = (*(uint32_t *)(0x806024) >> 26);
  uint32_t fine = (*(uint32_t *)(0x806028) & 0x3FF);

  SYSCTRL_DFLLVAL_Type dfllval =
  {
    .bit.COARSE = coarse,
    .bit.FINE = fine,
  };
  SYSCTRL->DFLLVAL.reg = dfllval.reg;

  //Update MUL value register. This is to multiply the DFLL clock with 32Khz input clock
  SYSCTRL_DFLLMUL_Type dfllmul =
  {
    .bit.MUL = 1500, /* 32KHz * 1500 = 48MHz */
    .bit.CSTEP = (coarse >> 1), /* must be 50% or less of coarse value */
    .bit.FSTEP = (fine >> 1), /* must be 50% or less of fine value */
  };
  SYSCTRL->DFLLMUL.reg = dfllmul.reg;

  /* enable DFLL */
  SYSCTRL->DFLLCTRL.bit.ENABLE = true;
  
  /* wait for DFLL closed loop lock */
  while (SYSCTRL->PCLKSR.bit.DFLLLCKF == false);

  //Write division register of gen 0
  gendiv.bit.DIV = 1; /* no division */
  gendiv.bit.ID = GCLK_GENERATOR_0;
  GCLK->GENDIV.reg = gendiv.reg;

 /* Configure GCLK 0 (CPU clock) to run from the DFLL */
  genctrl.bit.RUNSTDBY = false; /* Run in Standby */
  genctrl.bit.DIVSEL = false;   /* Divide Selection */
  genctrl.bit.OE = false;       /* Output Enable */
  genctrl.bit.OOV = false;      /* Output Off Value */
  genctrl.bit.IDC = true;       /* Improve Duty Cycle */
  genctrl.bit.GENEN = true;
  
  /* Generic clock source */
  genctrl.bit.SRC = GCLK_SOURCE_DFLL48M;
  genctrl.bit.ID = GCLK_GENERATOR_0;
  
  //Write GEN Ctrl register
  GCLK->GENCTRL.reg = genctrl.reg;
  
   /* wait for synchronization to complete */
  while (GCLK->STATUS.bit.SYNCBUSY);
}
void _init_chip(void)
{
	hri_nvmctrl_set_CTRLB_RWS_bf(NVMCTRL, CONF_NVM_WAIT_STATE);

	_pm_init();
    
	//Initialize internal 8Mhz oscillator
    CLOCKS_OSC8M_Init(SYSCTRL_OSC8M_PRESC_0_Val);
	
	//Initialize DFLL 48Mhz oscillator
    CLOCKS_DFLL_Init();
}
