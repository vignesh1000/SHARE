/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/

#include <UPD301_App.h>

UINT8 gu8VBUSEffectiveTimer = MAX_CONCURRENT_TIMERS;
UINT8 gu8PwrFaultDACCorrectStISR = UPD301_DAC_CORRECT_RESET_VALUE;
UINT8 gu8Port0DCDCSelType = DCDC_RESERVED;
extern volatile BOOL gbADCTimerExpires;
static UINT32 gu32CriticalSectionCnt = SET_TO_ZERO;

void* UPD301_MemCpy(void *dest, const void *src, int n)
{
   // Typecast src and dest addresses to (char *)
   char *csrc = (char *)src;
   char *cdest = (char *)dest;
 
   // Copy contents of src[] to dest[]
   for (int i=0; i<n; i++)
       cdest[i] = csrc[i];
   
   return dest;
}

int UPD301_MemCmp(const void *pau8Data1, const void *pau8Data2, int len)
{
	int i;
    UINT8 *pu8Obj1 = (UINT8 *)pau8Data2;
    UINT8 *pu8Obj2 = (UINT8 *)pau8Data2;
	
	for (i = 0; i < len; i++)
    {
    	if (pu8Obj1[i] != pu8Obj2[i])
            return (pu8Obj1[i] - pu8Obj2[i]);            	
	}
    
	return 0;
}


void GPIOStrap_SetTristate(UINT8 u8pin)
{
      UINT32 u32mask = (UINT32)((1u) << (GPIOPIN(u8pin)));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN | (u32mask & GPIO_MASK_LOWWORD));
      REGDW(GPIO_WRCONFIG_REG_ADDR) = (GPIO_WRCONFIG_HWSEL | GPIO_WRCONFIG_WRPINCFG | GPIO_WRCONFIG_INEN |\
	  									((u32mask & GPIO_MASK_HIGHWORD) >> GPIO_MASK_OFFSET));
}

UINT8 GPIOStrap_GetInputLevel(UINT8 u8pin)
{
    UINT32 u32mask = (UINT32)((1u) << (GPIOPIN(u8pin)));
     
    return ((UINT8)((REGDW(GPIO_IN_REG_ADDR) & u32mask) > 0) ? 1 : 0);
}

void UPD301_PortDisable (UINT8 *u8PortEnDis,PORT_CONFIG_DATA *PortConfigData)
{

    if (PD_ROLE_SINK == (PortConfigData[PORT0].u32CfgData & TYPEC_PORT_TYPE_MASK))
    {
        u8PortEnDis[PORT1] = PORT_STATUS_DISABLED;
        return;
    }
    
    else if(PD_ROLE_SINK == (PortConfigData[PORT1].u32CfgData & TYPEC_PORT_TYPE_MASK))
    {
        /* Work arround - If port-0 as source and port-1 as sink interrupt issued continuously */
        PortConfigData[PORT1].u32CfgData = 0;
        u8PortEnDis[PORT1] = PORT_STATUS_DISABLED;
    }  
}

void Ports_EnableDisable(UINT8 *u8PortEnDis,PORT_CONFIG_DATA *PortConfigData)
{

#ifdef _IDEAL_
	gu8Port0DCDCSelType = DCDC_LINEAR_DAC_TYPE;
#else
    if (PD_ROLE_SOURCE == (PortConfigData[PORT0].u32CfgData & TYPEC_PORT_TYPE_MASK))
    {
        if(DCDC_COMPATIBLE != DCDCSel_StrapDecode())
        {
            u8PortEnDis[PORT0] = PORT_STATUS_DISABLED;
        }
        else
        {
            /*Compatible DCDC strap */
        }
    }
    else
    {
        /** DAC Operation is not necessary for SINK mode*/
        gu8Port0DCDCSelType = DCDC_LINEAR_DAC_TYPE;
    }
#endif    
    UPD301_PortDisable (u8PortEnDis, PortConfigData);
    
}

/* Starps Read for Port Role Set */
void STRAPS_PowerRole_Set(PORT_CONFIG_DATA *PortConfigData)
{
    UINT32 u32CfgData = 0;
       
    GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_IN);
    GPIO_SetPullMode(PIN_PA28,GPIO_PULLOFF);
    
    if(GPIOStrap_GetInputLevel(PIN_PA28))
    {

        /* Port Role Source */
        u32CfgData |= PD_ROLE_SOURCE;
        u32CfgData |= (RP_VAL_3A << TYPEC_PORT_RPVAL_POS);
        PortConfigData[0].u32CfgData = u32CfgData;
        DecodePDPStrapCap( 0, PD_ROLE_SOURCE, PortConfigData);
    }
    
    else
    {
        /* Port Role Sink */
        u32CfgData |= PD_ROLE_SINK;
        u32CfgData |= (RP_VAL_RD << TYPEC_PORT_RPVAL_POS);
        PortConfigData[0].u32CfgData = u32CfgData;
        DecodePDPStrapCap( 0, PD_ROLE_SINK, PortConfigData);
    }
    
    
    /* Writting to clear pull up / pull down in PIO */
    UINT8 u8Data = 0;   
    UPD_RegWriteByte (1, (UPD_CFG_PIO_BASE + UPD_PIO2), u8Data);
    
    u32CfgData = 0;
       
    UPD_GPIOEnableDisable(1,UPD_PIO2 ,UPD_ENABLE_GPIO);
    UPD_GPIOSetDirection(1,UPD_PIO2 ,UPD_GPIO_SETDIR_INPUT);
    
    UINT16 u16Data = UPD_RegReadWord ( 1, EXTERNAL_UPD350_PIO_STS);
    
    if(u16Data & EXTERNAL_UPD350_PIO2_MASK)
    {

        /* Port Role Source */
        u32CfgData |= PD_ROLE_SOURCE;
        u32CfgData |= (RP_VAL_3A << TYPEC_PORT_RPVAL_POS);
        PortConfigData[1].u32CfgData = u32CfgData;
        DecodePDPStrapCap( 1, PD_ROLE_SOURCE, PortConfigData);
    }
    
    else
    {
        /* Port Role Sink */
        u32CfgData |= PD_ROLE_SINK;
        u32CfgData |= (RP_VAL_RD << TYPEC_PORT_RPVAL_POS);
        PortConfigData[1].u32CfgData = u32CfgData;
        DecodePDPStrapCap( 1, PD_ROLE_SINK, PortConfigData);    
	}
	
		
}

UINT8  GenericStrapDecode(UINT8 u8PinVal)
{
  
    
    UINT8  u8Strapvalue = 0;
    
    /*Step1:Setting Input enable,Setting pull down*/
    GPIO_SetDirection(u8PinVal, GPIO_SETDIRECTION_IN);
  
    GPIO_SetPullMode(u8PinVal,GPIO_PULLDOWN); 
    
    /*Delay*/
     PDTimer_WaitforTicks(MILLISECONDS_TO_TICKS(5));
    
       
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {
    
        u8Strapvalue |= BIT(4);
    }
   
    
    /*Step2: Setting Pull up*/
    GPIO_SetPullMode(u8PinVal,GPIO_PULLUP); 
    
    /*Temporary delay*/
    PDTimer_WaitforTicks( MILLISECONDS_TO_TICKS(5));
    
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {
    
        u8Strapvalue |= BIT(3);
    }
    
    /*Step3:Drive the pin as low.Enable Output.*/
    GPIO_SetDirection(u8PinVal, GPIO_SETDIRECTION_OUT); 
    GPIO_SetPinLevel(u8PinVal, GPIO_DRIVELOW); 
    GPIOStrap_SetTristate(u8PinVal);
    
    /*Temporary delay*/
    PDTimer_WaitforTicks( MILLISECONDS_TO_TICKS(5));
    
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {
    
        u8Strapvalue |= BIT(2);
    }
    
    /*Step4:Drive the pin as high.*/
    
    GPIO_SetDirection(u8PinVal, GPIO_SETDIRECTION_OUT);
    GPIO_SetPinLevel(u8PinVal, GPIO_DRIVEHIGH);
    GPIOStrap_SetTristate(u8PinVal);
    
    /*Temporary delay*/
    PDTimer_WaitforTicks( MILLISECONDS_TO_TICKS(5));
    
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {
    
        u8Strapvalue |= BIT(1);
    }
    
    /*Step5:Disable the output*. TODO:Hoow to enable GPIO_SET_TRISTATE*/
    /*Disable the output by enabling the input*/
    GPIO_SetDirection(u8PinVal, GPIO_SETDIRECTION_IN);
    GPIO_SetPullMode(u8PinVal,GPIO_PULLOFF); 
    GPIOStrap_SetTristate(u8PinVal);
    
    /*Temporary delay*/
    PDTimer_WaitforTicks( MILLISECONDS_TO_TICKS(5));
    
        
    if(GPIOStrap_GetInputLevel(u8PinVal))
    {    
        u8Strapvalue |= BIT(0);
    }

    return u8Strapvalue;
}

void DecodePDPStrapCap(UINT8 u8PortNum, UINT8 u8PortRole, PORT_CONFIG_DATA *PortConfigData)
{
    UINT8 u8Strapvalue = 0;
    UINT8 u8PinVal = 0;
    
    /*PA04: PDP_SEL0_S*/
    /*PA05: PDP_SEL1_S*/
   
    //Tested:200K Pull-up,200K Pull-down,4K7 Pull-down,4K7O Pull-up,10Q pull down,10Q pull up
    
    //CONFIG1->0x0A,CONFIG2->0x0B,CONFIG3->0x00,CONFIG4->0x1F,CONFIG5->0x00,CONFIG6->0x1F
  
    if(u8PortNum == 0)
    {
        u8PinVal = PIN_PA04;
    }
    
    else
    {
        u8PinVal = PIN_PA05;
    }
    
    u8Strapvalue = GenericStrapDecode(u8PinVal);
    
    UINT32 u32PDOs[4] = {0};
    UINT8 u8PDOCnt = 0;
    
    switch(u8Strapvalue)
    {
        case CONFIG1:
        {
            if(PD_ROLE_SOURCE == u8PortRole)
            {
                u8PDOCnt = CONFIG1_PDO_COUNT;
                u32PDOs[0] = SRC_CAP_5V_1P5A;
                PortConfigData[u8PortNum].u32CfgData &= ~TYPEC_PORT_RPVAL_MASK;
                PortConfigData[u8PortNum].u32CfgData |= (RP_VAL_1P5A << TYPEC_PORT_RPVAL_POS);
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_1P5A;
                u8PDOCnt = CONFIG1_PDO_COUNT;             
            }
            break;  
        }
        case CONFIG2:
        {
            if((UINT8)PD_ROLE_SOURCE == u8PortRole)
            {
                u32PDOs[0] =  SRC_CAP_5V_3A;
                u8PDOCnt = CONFIG2_PDO_COUNT;
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_3A_LOW;
                u8PDOCnt = CONFIG2_PDO_COUNT;             
            }
            break;  
        }
        case CONFIG3:
        {
            if(u8PortRole == PD_ROLE_SOURCE)
            {
                u32PDOs[0] =  SRC_CAP_5V_3A;
                u32PDOs[1] =  SRC_CAP_9V_3A;
                u8PDOCnt = CONFIG3_PDO_COUNT;
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_3A;
                u32PDOs[1] =  SNK_CAP_9V_3A;
                u8PDOCnt = CONFIG3_PDO_COUNT;             
            }
            break;  
        }
        case CONFIG4:
        {
            if(u8PortRole == PD_ROLE_SOURCE)
            {
                u32PDOs[0] =  SRC_CAP_5V_3A;
                u32PDOs[1] =  SRC_CAP_9V_3A;
                u32PDOs[2] =  SRC_CAP_15V_3A;
                u8PDOCnt = CONFIG4_PDO_COUNT;
            }            
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_3A;
                u32PDOs[1] =  SNK_CAP_9V_3A;
                u32PDOs[2] =  SNK_CAP_15V_3A;
                u8PDOCnt = CONFIG4_PDO_COUNT;
            }
            break;  
        }
        case CONFIG5:
        {
            if(u8PortRole == PD_ROLE_SOURCE)
            {
                u32PDOs[0] =  SRC_CAP_5V_3A;
                u32PDOs[1] =  SRC_CAP_9V_3A;
                u32PDOs[2] =  SRC_CAP_15V_3A;
                u32PDOs[3] =  SRC_CAP_20V_3A;
                u8PDOCnt = CONFIG5_PDO_COUNT;
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_3A;
                u32PDOs[1] =  SNK_CAP_9V_3A;
                u32PDOs[2] =  SNK_CAP_15V_3A;
                u32PDOs[3] =  SNK_CAP_20V_3A;
                u8PDOCnt = CONFIG5_PDO_COUNT;            
            }
            break;  
        }
        case CONFIG6:
        {
            if(u8PortRole == PD_ROLE_SOURCE)
            {
                u32PDOs[0] =  SRC_CAP_5V_5A;
                u32PDOs[1] =  SRC_CAP_9V_5A;
                u32PDOs[2] =  SRC_CAP_15V_5A;
                u32PDOs[3] =  SRC_CAP_20V_5A;
                u8PDOCnt = CONFIG6_PDO_COUNT;
            }
            else
            {
                u32PDOs[0] =  SNK_CAP_5V_5A;
                u32PDOs[1] =  SNK_CAP_9V_5A;
                u32PDOs[2] =  SNK_CAP_15V_5A;
                u32PDOs[3] =  SNK_CAP_20V_5A;
                u8PDOCnt = CONFIG6_PDO_COUNT;              
            }
            break;  
        }      
    }
    
    UINT8 u8Loop = 0;
    if(u8PortRole == PD_ROLE_SOURCE)
    {
        PortConfigData[u8PortNum].u8PDOCnt = u8PDOCnt;
        
        for(u8Loop = 0; u8Loop < u8PDOCnt; u8Loop++)
        {
            PortConfigData[u8PortNum].u32PDO[u8Loop] = u32PDOs[u8Loop];
        }
    }
    
    else
    {
        PortConfigData[u8PortNum].u8PDOCnt = u8PDOCnt;
        
        for(u8Loop = 0; u8Loop < u8PDOCnt; u8Loop++)
        {
            PortConfigData[u8PortNum].u32PDO[u8Loop] = u32PDOs[u8Loop];
        }        
    }

}

void PDStack_Events(UINT8 u8PortNum, UINT8 u8PDEvent)
{
    if((TYPEC_ATTACHED_SRC_DRIVE_PWR_EVENT == u8PDEvent) || (TYPEC_SNK_CURRENT_LIMIT_EVENT == u8PDEvent))
    {
        if (u8PortNum == PORT0)
        {
            CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
          //  ADC_Read_Dummy();
            CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();
#ifndef _IDEAL_
            gbADCTimerExpires = true;
#endif
        }
    }
    else if(TYPEC_DETACH_EVENT == u8PDEvent)
    {
        /*Set tristate for detach event*/
        if(0 == u8PortNum)
        {
            GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_IN);
            GPIO_SetPullMode(PIN_PA28,GPIO_PULLOFF); 
            GPIOStrap_SetTristate(PIN_PA28);
        }
        else
        {
             UPD_GPIOEnableDisable(1,UPD_PIO2,UPD_DISABLE_GPIO);
        }
    
    }
    else if((TYPEC_CC1_ORIENTATION == u8PDEvent))
    {
        /*UPD301-245 - Fix */
        /*Drive Low for CC1 Orientation*/
        if(0 == u8PortNum)
        {
            GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_OUT);
            GPIO_SetPinLevel(PIN_PA28, GPIO_DRIVELOW);
        }
        else
        {
            UPD_GPIOEnableDisable(1,UPD_PIO2,UPD_ENABLE_GPIO);
            UPD_GPIOSetDirection(1,UPD_PIO2,UPD_GPIO_SETDIR_OUTPUT);
            UPD_GPIOSetBufferType(1,UPD_PIO2,UPD_GPIO_SETBUF_PUSHPULL);
            UPD_GPIOSetClearOutput(1,UPD_PIO2,UPD_GPIO_CLEAR);
        }          
    }
    else if(TYPEC_CC2_ORIENTATION == u8PDEvent)
    {
        /*UPD301-245 - Fix */
        /*Drive High for CC2 Orientation*/
        if(0 == u8PortNum)
        {
            GPIO_SetDirection(PIN_PA28, GPIO_SETDIRECTION_OUT);
            GPIO_SetPinLevel(PIN_PA28, GPIO_DRIVEHIGH);
        }
        else
        {
            UPD_GPIOEnableDisable(1,UPD_PIO2,UPD_ENABLE_GPIO);
            UPD_GPIOSetDirection(1,UPD_PIO2,UPD_GPIO_SETDIR_OUTPUT);
            UPD_GPIOSetBufferType(1,UPD_PIO2,UPD_GPIO_SETBUF_PUSHPULL);
            UPD_GPIOSetClearOutput(1,UPD_PIO2,UPD_GPIO_SET);
        }    
    }
}
/**************************************************************/
#if INCLUDE_POWER_FAULT_HANDLING

UINT8 UPD301_HandlePowerFault(UINT8 u8PortNum, UINT8 *pu8PwrFaultSts)
{
  	UINT8 u8Return = DPM_HANDLE_PWR_FAULT, u8VBUSMatch = 0;
    if ((PORT0 == u8PortNum)  && \
        (PD_ROLE_SOURCE == (gasPortConfigurationData[u8PortNum].u32CfgData & TYPEC_PORT_TYPE_MASK)))
    {
        switch(gu8PwrFaultDACCorrectStISR)
        {
            case UPD301_WAIT_FOR_VBUSEFF_TIMER:
            {
              u8Return = DPM_NEGLECT_PWR_FAULT;
              break;
            }
            
            
            case UPD301_VALID_VBUS:
            {
                /* Read the VBUS match*/
                UPD_RegisterRead (u8PortNum, TYPEC_VBUS_MATCH, &u8VBUSMatch, BYTE_LEN_1);
                if (TYPEC_VBUS_DESIRED_N_UNDER_MATCH_VAL == u8VBUSMatch)
                {
                    /* Power faults are cleared*/
                    CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
                    *pu8PwrFaultSts &= ~(DPM_POWER_FAULT_UV | DPM_POWER_FAULT_OVP);
                    CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();
                    u8Return = DPM_NEGLECT_PWR_FAULT;
                }
                else
                {
                    /*Handle the Power fault*/
                    /*Drive EN_VBUS low since power fault still persists*/
#ifdef _IDEAL_
                  	UPD_GPIOSetClearOutput(PORT0, PWRCTRL_ENABLE_VBUS_IU, UPD_GPIO_SET);
#else
                    UPD_GPIOSetClearOutput(PORT0, PWRCTRL_ENABLE_VBUS_IU, UPD_GPIO_CLEAR);
#endif
                    /* Enable the VBUS discharge functionality */                  
                    CONFIG_HOOK_PORTPWR_EN_DIS_VBUSDISCHARGE (u8PortNum, PWRCTRL_ENABLE_VBUSDIS);
                    /* Handle Power Fault: DPM_HANDLE_PWR_FAULT is returned*/
                }
                /*gu8PwrFaultDACCorrectStISR is set to UPD301_DAC_CORRECT_RESET_VALUE
                break was intentionally missed in this case*/
            }
            /*-fallthrough*/
            case UPD301_HANDLE_POWER_FAULT:
            {
                CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
                gu8PwrFaultDACCorrectStISR = UPD301_DAC_CORRECT_RESET_VALUE;
                CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();
                /* Handle Power Fault: DPM_HANDLE_PWR_FAULT is returned*/
                break;
            }
            
            case UPD301_DAC_CORRECT_RESET_VALUE:
            {
              /*IDle state*/
              break;
            }    
            case UPD301_CHECK_VDD33_VARIATION:  
            {
                if((DPM_POWER_FAULT_UV & *pu8PwrFaultSts) || \
                        (DPM_POWER_FAULT_OVP & *pu8PwrFaultSts))
                {

                    /* added in critical section as ADC_SynchronousRead_TimerCB is called
                        as part of 50ms timer */
                    /* Adjust the ADC */
#ifndef _IDEAL_
                    CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
                    ADC_SynchronousRead_TimerCB(NULL, NULL);
                    CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();
#endif                    

                    /* if there is no variance on VCC voltage. Then handle the power fault*/
                    if (gbVariationVCC)
                    {
                        /* Start the timer CONFIG_UPD301_VBUS_EFFECTIVE_TIMER_MS*/
                         gu8VBUSEffectiveTimer = PDTimer_Start (CONFIG_UPD301_VBUS_EFFECTIVE_TIMER_MS,\
                                                              UPD301_VBUSEffective_TimerCB, u8PortNum, NULL);
                        CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
                        /* VDD has issue*/
                        gbVariationVCC = FALSE;
                        /* PowerFault Variable is set toUPD301_WAIT_FOR_VBUSEFF_TIMER */
                         gu8PwrFaultDACCorrectStISR = UPD301_WAIT_FOR_VBUSEFF_TIMER;
                         CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();
                         
                         u8Return = DPM_NEGLECT_PWR_FAULT;
                    }
                    else
                    {
                      /* Handle the power fault*/
                    }
                }
                break;
            }
                
        }/* end of switch*/
    }
	return u8Return;
}
/*********************************************************************/
void UPD301_VBUSEffective_TimerCB (UINT8 u8PortNum, UINT8 u8DummyVariable)
{
    UINT16 u16PIORegValue;
    /* If there is still wait for the VBUS to be correted */
    if (UPD301_WAIT_FOR_VBUSEFF_TIMER == gu8PwrFaultDACCorrectStISR)
    {
        gu8PwrFaultDACCorrectStISR = UPD301_HANDLE_POWER_FAULT;
        /*Drive EN_VBUS low since power fault still persists*/
        UPD_RegisterReadISR (u8PortNum, (UPD_CFG_PIO_BASE + gasPortConfigurationData[u8PortNum].u8VBUSEnPio),\
                                    (UINT8 *)&u16PIORegValue, BYTE_LEN_1);
        u16PIORegValue &= ~ UPD_GPIO_DATAOUTPUT;
        UPD_RegisterWriteISR (u8PortNum, (UPD_CFG_PIO_BASE + gasPortConfigurationData[u8PortNum].u8VBUSEnPio),\
                                        (UINT8 *)&u16PIORegValue, BYTE_LEN_1);
        /* Enable the VBUS discharge functionality */                  
        CONFIG_HOOK_PORTPWR_EN_DIS_VBUSDISCHARGE (u8PortNum, PWRCTRL_ENABLE_VBUSDIS); 
    }
    if (!gasDPM[u8PortNum].u8PowerFaultISR)
    {
         gu8PwrFaultDACCorrectStISR = UPD301_DAC_CORRECT_RESET_VALUE;
    }
     
	/* Set the timer Id to Max Value*/
 	gu8VBUSEffectiveTimer = MAX_CONCURRENT_TIMERS;

}
/******************************************************************************/
void UPD301_PwrFaultHanlderToDriveVBUSlow_ISR(UINT8 u8PortNum, UINT8 *pu8PwrFaultSts)
{
  UINT16 u16PIORegValue;
    /* For UPD301, Port0 VBUS_EN is not lowered for Port0 undervoltage*/
    if (PORT0 == u8PortNum)
    {
        gu8PwrFaultDACCorrectStISR = UPD301_CHECK_VDD33_VARIATION;
    }
    else
    {
        /* Disable EN_VBUS gasPortConfigurationData[u8PortNum].u8VBUSEnPio*/
        UPD_RegisterReadISR (u8PortNum, (UPD_CFG_PIO_BASE + gasPortConfigurationData[u8PortNum].u8VBUSEnPio),\
                                    (UINT8 *)&u16PIORegValue, BYTE_LEN_1);
        u16PIORegValue &= ~ UPD_GPIO_DATAOUTPUT;
        UPD_RegisterWriteISR (u8PortNum, (UPD_CFG_PIO_BASE + gasPortConfigurationData[u8PortNum].u8VBUSEnPio),\
                                        (UINT8 *)&u16PIORegValue, BYTE_LEN_1);
        
        /* Enable the VBUS discharge functionality */                  
        CONFIG_HOOK_PORTPWR_EN_DIS_VBUSDISCHARGE (u8PortNum, PWRCTRL_ENABLE_VBUSDIS);
    }
}

/**********************************************************************************/

void UPD301_ConfigPrtCtlforOCSdet (UINT8 u8PortNum)
{
	/* Get the PIO number*/
	UINT8 u8PIONum = gasPortConfigurationData[u8PortNum].u8PrtctlOCSPio;
	  
	/* Enable the PIO*/
	UPD_GPIOEnableDisable (u8PortNum, u8PIONum, UPD_ENABLE_GPIO);
	
	/* Configure the Fault In PIO */
	UPD301_ConfigPrtCtlOCSdetPIO (u8PortNum, u8PIONum);
    /**UPD301-182 - Enable Debounce for PRT_CTL/OCS pin */
    /* Write Debounce count*/
    UPD_ConfigurePIODebounceCount(u8PortNum, UPD_PIO_DEBOUNCE_CNT_TYP_1_US, CONFIG_OCS_DEBOUNCE_US);
    
    /* Enable debounce*/
    UPD_GPIOSetDebounce (u8PortNum, u8PIONum, UPD_PIO_DEBOUNCE_CNT_TYP_1_US);
	
	/* Enable the PIO interrupt*/
	UINT16 u16Data = ((UPD_RegReadWord(u8PortNum, UPD_PIO_INT_EN)) | BIT(u8PIONum));
	UPD_RegWriteWord(u8PortNum, UPD_PIO_INT_EN, u16Data);
	
}
/*******************************************************************************/			 
void UPD301_ConfigPrtCtlOCSdetPIO (UINT8 u8PortNum, UINT8 u8PIONum)
{
  	UINT16 u16INTSTS = BIT(u8PIONum);
	/* Configure the FAULT_IN pio as input in open drain*/
	UPD_GPIOSetDirection (u8PortNum, u8PIONum, UPD_GPIO_SETDIR_INPUT);

	/* Falling interrupt configuration*/
	UPD_RegisterWrite (u8PortNum, UPD_PIO_INT_STS, (UINT8 *)&u16INTSTS, BYTE_LEN_2);
	UPD_GPIOSetIntrAlert (u8PortNum, u8PIONum, UPD_GPIO_FALLING_ALERT);
}
					 
/*******************************************************************************/
void UPD301_DriveOCSpin(UINT8 u8PortNum, UINT8 u8DriveVal)
{
	UINT8 u8PIONum = gasPortConfigurationData[u8PortNum].u8PrtctlOCSPio;
	if (CONFIG_DRIVE_PRTCTL_OCS_LOW == u8DriveVal)
	{
	  	UPD_GPIOSetIntrAlert (u8PortNum, u8PIONum, UPD_GPIO_CLEAR_INTR);
		UPD_GPIOSetDirection (u8PortNum, u8PIONum, UPD_GPIO_SETDIR_OUTPUT);
		UPD_GPIOSetBufferType (u8PortNum, u8PIONum, UPD_GPIO_SETBUF_PUSHPULL);
		UPD_GPIOSetClearOutput(u8PortNum, u8PIONum, UPD_GPIO_CLEAR);
	}
	else
	{
		UPD301_ConfigPrtCtlOCSdetPIO (u8PortNum, u8PIONum);
	}
	
}
#endif /*INCLUDE_POWER_FAULT_HANDLING*/
/*******************************************************************************/
void UPD301_PIOIntrHandler_ISR(UINT8 u8PortNum, UINT16 u16PIOIntSts)
{
    UINT16 u16PIORegVal;
    #if INCLUDE_POWER_FAULT_HANDLING
	if ((BIT(gasPortConfigurationData[u8PortNum].u8PrtctlOCSPio)) & u16PIOIntSts)
	{	
        /* Clear the OCS interrupt Configuration*/
        UPD_RegisterReadISR (u8PortNum, (UPD_CFG_PIO_BASE + gasPortConfigurationData[u8PortNum].u8PrtctlOCSPio),\
									(UINT8 *)&u16PIORegVal, BYTE_LEN_1);
        u16PIORegVal &= ~ UPD_GPIO_FALLING_ALERT;
		UPD_RegisterWriteISR (u8PortNum, (UPD_CFG_PIO_BASE + gasPortConfigurationData[u8PortNum].u8PrtctlOCSPio),\
										(UINT8 *)&u16PIORegVal, BYTE_LEN_1);  
    
		/* Notify DPM about the power fault*/
        DPM_SetPowerFaultISR(u8PortNum, DPM_POWER_FAULT_VBUS_OCS);

		#if (FALSE == INCLUDE_UPD_PIO_OVERRIDE_SUPPORT)
			/* Disable EN_VBUS gasPortConfigurationData[u8PortNum].u8VBUSEnPio*/
			UPD_RegisterReadISR (u8PortNum, (UPD_CFG_PIO_BASE + gasPortConfigurationData[u8PortNum].u8VBUSEnPio),\
									(UINT8 *)&u16PIORegVal, BYTE_LEN_1);
			u16PIORegVal &= ~ UPD_GPIO_DATAOUTPUT;
			UPD_RegisterWriteISR (u8PortNum, (UPD_CFG_PIO_BASE + gasPortConfigurationData[u8PortNum].u8VBUSEnPio),\
										(UINT8 *)&u16PIORegVal, BYTE_LEN_1);
		#endif
	}
	#endif
}
/*******************************************************************************/

#if INCLUDE_POWER_MANAGEMENT_CTRL
void SetMCUIdle()
{
    /*gu8SetMCUidle was set as UPD_MCU_IDLE by Zeus Stack,
    but lets verify whether we can go to idle, otherwise return from here*/
    if (FALSE == UPD_CheckUPDsActive())
    {     
        /*If current power role is source for port0 and if type-c is attached which
        sourcing more than 0v then ADC is running to monitor VDD33. so FW cant go to idle,
        so return from here*/
        if ((DPM_GET_CURRENT_POWER_ROLE (0) == PD_ROLE_SOURCE) && 
            (DPM_GetVBUSVoltage(0) > PWRCTRL_VBUS_0V))
        {
            gu8SetMCUidle = UPD_MCU_ACTIVE;
            return;
        }
    }
 
    CONFIG_HOOK_DISABLE_GLOBAL_INTERRUPT();
    
	/*Set NVIC SERCOM1 Interrupt before going to sleep for wake up*/    
    REGDW(NVIC_BASE_ADDR) |= INT_NVIC_SERCOM1;
    
    /*Enable Address Match to wake up from MCU Idle*/  
    REGB(I2C_SLAVE_INTENSET) |= I2C_SLAVE_INTFLAG_AMATCH;
    
    /*Disable Timer to avoid interrupt from Timer*/
    REGB(TC0_CTRLA) &= ~TC0_CTRLA_ENABLE; 
    
    HOOK_DEBUG_PORT_STR (3, "UPD301: Set UPD301 IDLE");
    
	/*If there is any pending interrupt it will not go to sleep*/
    SCB->SCR |=  (SCB_SCR_SLEEPDEEP_Msk )| (SCB_SCR_SEVONPEND_Msk);
    
    __DSB();
    __WFI();
    
    CONFIG_HOOK_ENABLE_GLOBAL_INTERRUPT();

}
      
void MCUResumeFromIdle()
{
     REGB(TC0_CTRLA) |= TC0_CTRLA_ENABLE;
}

#endif


void Reset_UPD350_Thru_MCU_GPIO()
{
#ifdef _IDEAL_
    /*Fix for UPD301-281 - The Pin based Reset has been modified to SW reset, thereby ensuring that
      the reset operation will not get affected, even on enabling strong pullups on RESET_N lines*/
    UPD_RegByteSetBit (0, UPD_HW_CTL, UPD_SRESET);
#else
    /* Reset the UPD350 for enabled ports */
    GPIO_SetDirection(UPD350_RESET,    GPIO_SETDIRECTION_IN);
    GPIO_SetPullMode(UPD350_RESET,    GPIO_PULLDOWN);
    
    /*Delay */
    for(UINT16 u16delayloop = 0u; u16delayloop <(6000);u16delayloop++)
    {
        __asm volatile("nop");
        __asm volatile("nop");

    }
    
    GPIO_SetPullMode(UPD350_RESET, GPIO_PULLOFF);
#endif
}


UINT8 DCDCSel_StrapDecode(void)
{
    UINT8 u8RetVal;
    
    gu8Port0DCDCSelType = GenericStrapDecode(PIN_PA03);
    
    switch(gu8Port0DCDCSelType)
    {
        case DCDC_LINEAR_DAC_TYPE:
            u8RetVal = DCDC_COMPATIBLE;
            break;
            
        default:
            gu8Port0DCDCSelType = DCDC_LINEAR_DAC_TYPE;
            u8RetVal = DCDC_INCOMPATIBLE;
            break;
    }
    
    return u8RetVal;
}


void UPDIntr_EnterCriticalSection(volatile hal_atomic_t* pCrtSecObj)
{
    if (gu32CriticalSectionCnt++ == 0)  
    {
        /*Interrupt is disabled if Critical section is not entered already*/
		CRITICAL_SECTION_ENTER(pCrtSecObj);
    }
}

void UPDIntr_ExitCriticalSection(volatile hal_atomic_t* pCrtSecObj)
{
    
    if (--gu32CriticalSectionCnt == 0)
    {
        /*Interrupt is Eanbled when there is no pending critical section nesting*/
		CRITICAL_SECTION_LEAVE(pCrtSecObj);
    }
}



void  UPD301_SinkCurrentControl(UINT8 u8PortNum, UINT16 u16ReqCurrent)
{
  
    DAC_SinkCurrentControl(u16ReqCurrent);
    
    /* Write GPIO to indicate the current limit */        
    if((u16ReqCurrent >= SNK_CURRENT_1P5A) && (u16ReqCurrent < SNK_CURRENT_3A))
    {
        /* 1.5A indication through 1.5A_IND pin*/
        GPIO_SetDirection(PIN_PA01, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinLevel(PIN_PA01, GPIO_DRIVEHIGH);
        GPIO_SetDirection(PIN_PA15, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinLevel(PIN_PA15, GPIO_DRIVELOW);
    }
    
    else if(u16ReqCurrent >= SNK_CURRENT_3A)
    {
        /* 3A indication through 3A_IND pin*/
        GPIO_SetDirection(PIN_PA15, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinLevel(PIN_PA15, GPIO_DRIVEHIGH);
        GPIO_SetDirection(PIN_PA01, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinLevel(PIN_PA01, GPIO_DRIVELOW);
    }
    
    else
    {
        GPIO_SetDirection(PIN_PA15, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinLevel(PIN_PA15, GPIO_DRIVELOW);
        GPIO_SetDirection(PIN_PA01, GPIO_SETDIRECTION_OUT);
        GPIO_SetPinLevel(PIN_PA01, GPIO_DRIVELOW);
    }
}
