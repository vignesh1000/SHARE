/*
* Copyright (c) 2017 Microchip Technology Inc.  All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital signal
* controller that is integrated into your product or third party product
* (pursuant to the sublicense terms in the accompanying license agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
* EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
* MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
* IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
* CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
* OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
* INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
* SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
* (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*/
/*******************************************************************************
  SERCOM UART driver module Header

  Company:
    Microchip Technology Inc.

  File Name:
    SERCOM_UART.h

  Summary:
    SERCOM UART driver for SW debug interface

  Description:
    This header file contains the function prototypes and definitions of the
    data types and constants that make up the SW debug interface through UART
*******************************************************************************/

#ifndef _SERCOM_UART_H_
#define _SERCOM_UART_H_

#include <REG_SAMD20.h>
#include <GPIO.h>

/*SERCOM 3 REGBASE*/
#ifdef _IDEAL_
#define SERCOM_UART_SELECTION		    0  /*  SERCOM 3 selection*/
#else
#define SERCOM_UART_SELECTION		    3  /*  SERCOM 3 selection*/
#endif
#define SERCOM_UART_REGBASE           SERCOM_CTRL_REGBASE(SERCOM_UART_SELECTION)


/* SERCOM 3 UART Registers*/
#define SERCOM_UART_CTRLA_REG         SERCOM_UART_REGBASE
#define SERCOM_UART_CTRLB_REG         SERCOM_UART_REGBASE + 0x04
#define SERCOM_UART_DBGCTRL_REG       SERCOM_UART_REGBASE + 0x08
#define SERCOM_UART_BAUD_REG          SERCOM_UART_REGBASE + 0x0A
#define SERCOM_UART_INTENCLR_REG      SERCOM_UART_REGBASE + 0x0C
#define SERCOM_UART_INTENSET_REG      SERCOM_UART_REGBASE + 0x0D
#define SERCOM_UART_INTFLAG_REG       SERCOM_UART_REGBASE + 0x0E
#define SERCOM_UART_STATUS_REG        SERCOM_UART_REGBASE + 0x10
#define SERCOM_UART_DATA_REG          SERCOM_UART_REGBASE + 0x18


/* Bit definition for CTRLA register */
#define SERCOM_UART_CTRLA_SWRST         BIT(0)
#define SERCOM_UART_CTRLA_ENABLE        BIT(1)
#define SERCOM_UART_CTRLA_CMODE         BIT(28)
#define SERCOM_UART_CTRLA_DORD          BIT(30)  /* DORD(BIT30) - 1 -MSB transmitted 1st
																  0 - LSB tranmitted 1st*/

/*RXPO[20:21] is 0x03 SERCOM PAD[3] is configured for UART */
#define SERCOM_UART_CTRLA_RXPO_SERCOM_PAD3      (BIT(20) | BIT(21))

/* TXPO 1 - SERCOM PAD[2], 0 - SECOM PAD[1] */       
#define SERCOM_UART_CTRLA_TXPO_SERCOM_PAD2          BIT(16)   

/*MODE[4:2] is 0x01 USART with internal clock is used */
#define SERCOM_UART_CTRLA_MODE_INT_CLK			BIT(2)
#define SERCOM_UART_CTRLA_MODE_EXT_CLK			(0 << 2)

/*FORM[3:0] Bits 27:24*/
#define SERCOM_UART_CTRLA_FORM_START_BIT_POS		24
#define SERCOM_UART_CTRLA_FORM_USART_FRAME			\
			(0 << SERCOM_UART_CTRLA_FORM_START_BIT_POS)	
			  
#define SERCOM_UART_CTRLA_FORM_USART_PARITY_FRAME	\
			(1 << SERCOM_UART_CTRLA_FORM_START_BIT_POS)


/* Bit definition for CTRLB register*/

#define SERCOM_UART_CTRLB_TXEN          BIT(17)
#define SERCOM_UART_CTRLB_RXEN          BIT(16)

/* PMODE parity mode*/
#define SERCOM_UART_CTRLB_PMODE_EVEN_PARITY		(0 << 13)
#define SERCOM_UART_CTRLB_PMODE_ODD_PARITY		(1 << 13)

/*SBMODE Stop Bit Mode*/
#define SERCOM_UART_CTRLB_SBMODE_ONE_STOP_BIT	(0 << 6)
#define SERCOM_UART_CTRLB_SBMODE_TWO_STOP_BIT	(0 << 6)
			  
/* CHSIZE[2:0] - Character Size*/		  
#define SERCOM_UART_CTRLB_CHSIZE_8BIT			0
#define SERCOM_UART_CTRLB_CHSIZE_9BIT			1
#define SERCOM_UART_CTRLB_CHSIZE_5BIT			5
#define SERCOM_UART_CTRLB_CHSIZE_6BIT			6
#define SERCOM_UART_CTRLB_CHSIZE_7BIT			7

/*Baud Rate */
#define SERCOM_UART_BAUDRATE            		921600
/* Baud rate calculation*/
#define SERCOM_UART_BAUD_REG_VALUE(u32BaudRate)      \
(uint16_t)(65536 - ((65536 * 16.0f * u32BaudRate) / CPU_FREQUENCY))


/* Bit definition for INTFLAG */

#define SERCOM_UART_INTFLAG_DRE			BIT(0)
#define SERCOM_UART_INTFLAG_RXC			BIT(2)


/* STATUS Register bit definitions */
#define SERCOM_UART_STATUS_SYNCBUSY     BIT(15)

/**************************************************************************************************
    Function:
        void SERCOMUART_Init (void);

    Summary:
        This API initializes Clock, SERCOM UART registers & SERCOM PIO mapping cofiguration.

    Devices Supported:
        UPD301A

    Description:
        This API is for nitialization of Clock (Peripheral Bus clock & GCLK), 
		SERCOM UART registers & SERCOM PIO mapping to functionality.

    Conditions:
        None.

    Input:
        None.

    Return:
        None.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/
void SERCOMUART_Init (void);

/**************************************************************************************************
    Function:
        void SERCOMUART_WriteChar (UINT8 u8WriteBuffer);

    Summary:
        This API is to print a character on UART Tx line.

    Devices Supported:
        UPD301A

    Description:
        This API is to print a character on UART Tx line.

    Conditions:
        None.

    Input:
        u8WriteBuffer - contains character to be printed.

    Return:
        None.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/

void SERCOMUART_WriteChar (UINT8 u8WriteChar);

/**************************************************************************************************
    Function:
        UINT8 SERCOMUART_ReadChar(void);

    Summary:
        This API is to read a character from UART Rx line.

    Devices Supported:
        UPD301A

    Description:
        This API is to read a character from UART Rx line.

    Conditions:
        None.

    Input:
        None.

    Return:
        UINT8 - Returns the character read.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/

UINT8 SERCOMUART_ReadChar(void);

/**************************************************************************************************
    Function:
        CHAR SERCOMUART_HexToAscii (UINT8 u8Val);

    Summary:
        This API converts Hex to ASCII.

    Devices Supported:
        UPD301A

    Description:
        This API converts Hex to ASCII.

    Conditions:
        None.

    Input:
        u8Val - variable to be convertor to ASCII character.

    Return:
        CHAR - Returns the ASCII character convetor.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/

CHAR SERCOMUART_HexToAscii (UINT8 u8Val);

/**************************************************************************************************
    Function:
        void SERCOMUART_WriteUINT8 (UINT8 u8Val);

    Summary:
        This API prints passed UNIT8 on UART TX line.

    Devices Supported:
        UPD301A

    Description:
        This API prints passed UNIT8 on UART TX line.

    Conditions:
        None.

    Input:
        u8Val - UINT8 variable to printed.

    Return:
        None.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/

void SERCOMUART_WriteUINT8 (UINT8 u8Val);

/**************************************************************************************************
    Function:
        void SERCOMUART_WriteUINT16 (UINT16 u16Val);

    Summary:
        This API prints passed UNIT16 on UART TX line.

    Devices Supported:
        UPD301A

    Description:
        This API prints passed UNIT16 on UART TX line.

    Conditions:
        None.

    Input:
        u16Val - UINT16 variable to printed.

    Return:
        None.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/

void SERCOMUART_WriteUINT16 (UINT16 u16Val);

/**************************************************************************************************
    Function:
        void SERCOMUART_WriteUINT32 (UINT32 u32Val);

    Summary:
        This API prints passed UINT32 on UART TX line.

    Devices Supported:
        UPD301A

    Description:
        This API prints passed UINT32 on UART TX line.

    Conditions:
        None.

    Input:
        u32Val - UINT32 variable to printed.

    Return:
        None.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/

void SERCOMUART_WriteUINT32 (UINT32 u32Val);

/**************************************************************************************************
    Function:
        void SERCOMUART_WriteString (const CHAR *pszMessage);

    Summary:
        The API prints string passed on UART Tx line.

    Devices Supported:
        UPD301A

    Description:
        The API prints string passed on UART Tx line.

    Conditions:
        None.

    Input:
        pszMessage - pointer to string bufffer.

    Return:
        None.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/

void SERCOMUART_WriteString (const CHAR *szMessage);

/**************************************************************************************************
    Function:
        void SERCOMUART_IntegerToString (INT32 i32nbr, CHAR *pchInt) ;

    Summary:
        The API converts Interger to string.

    Devices Supported:
        UPD301A

    Description:
        The API converts Interger to string.

    Conditions:
        None.

    Input:
        i32nbr 	- INT32 integter to be converted to string.
		pchInt	- Pointer to string buffer.

    Return:
        None.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/

void SERCOMUART_IntegerToString (INT32 i32nbr, CHAR *pchInt) ;

/**************************************************************************************************
    Function:
        void SERCOMUART_WriteINT32 (INT32 i32nbr);

    Summary:
        This API prints passed integer on UART Tx line.

    Devices Supported:
        UPD301A

    Description:
        This API prints passed integer on UART Tx line.

    Conditions:
        None.

    Input:
        i32nbr - Integer to be printed.

    Return:
        None.

    Remarks:
        This API is confined to CONFIG_HOOK_DEBUG_MSG preprocessor define.

**************************************************************************************************/

void SERCOMUART_WriteINT32 (INT32 i32nbr);


#endif
