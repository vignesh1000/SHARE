/*
	adc.h

	File Description
	This file contains one & only the Global variables that are NOT exposed to the end user
	or in DOS

	Copyright(C) 2015, Microchip Technology Inc. All Rights Reserved.

	This program code listing is proprietary to Microchip and may not be copied,  
	distributed, or used without a license to do so. Such license may have  
	Limited or Restricted Rights. Please refer to the license for further clarification.

	THIS SOFTWARE IS PROVIDED IN AN ?AS IS? CONDITION. NO WARRANTIES,
	WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
	TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
	PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
	IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
	CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*/

#ifndef _ADC_H_
#define _ADC_H_
#include <stdinc.h>

/**Enum for DAC Initilization status*/
typedef enum {
    eADC_INIT_ERROR = 0x00,
    eADC_INIT_SUCCESS
}eADC_INIT_RETURN;

/**Bit defines*/
#define BIT7	BIT(7)
#define BIT6	BIT(6)
#define BIT5	BIT(5)
#define BIT4	BIT(4)
#define BIT3	BIT(3)
#define BIT2	BIT(2)
#define BIT1	BIT(1)
#define BIT0	BIT(0)

/********************** Register Definitions of ADC module ******************************/
#define ADC_BASE_ADDRESS                0x42004000UL

/********************** Instance parameters for ADC peripheral **************************/
#define ADC_GCLK_INDEX                  23

/********************** Register : ADC_CTRLA  (Offset: 0x0) (R/W  8)  ******************/
#define ADC_CTRLA_ADDROFFSET            0x0u 
#define ADC_CTRLA_SWRST_Pos             0 
#define ADC_CTRLA_ENABLE_Pos            1 
#define ADC_CTRLA_RUNSTDBY_Pos          2    
#define ADC_CTRLA_ENABLE                (_U_(0x1) << ADC_CTRLA_ENABLE_Pos)


/********************** Register : REFCTRL : (Offset: 0x1) (R/W  8) *******************/
#define ADC_REFCTRL_ADDROFFSET          0x1u           
#define ADC_REFCTRL_REFCOMP_Pos         7
#define ADC_REFCTRL_REFSEL_Pos          0            
#define ADC_REFCTRL_REFSEL_Msk          (_U_(0xF) << ADC_REFCTRL_REFSEL_Pos)
#define ADC_REFCTRL_REFSEL(value)       (ADC_REFCTRL_REFSEL_Msk & ((value) << ADC_REFCTRL_REFSEL_Pos))

          
/********************** Register : AVGCTRL : (Offset: 0x2) (R/W  8) *********************/
#define ADC_AVGCTRL_ADDROFFSET          0x2u
#define ADC_AVGCTRL_ADJRES_Pos          4
#define ADC_AVGCTRL_ADJRES_Msk          (_U_(0x7) << ADC_AVGCTRL_ADJRES_Pos)
#define ADC_AVGCTRL_ADJRES(value)       (ADC_AVGCTRL_ADJRES_Msk & ((value) << ADC_AVGCTRL_ADJRES_Pos))
#define ADC_AVGCTRL_SAMPLENUM_Pos       0    
#define ADC_AVGCTRL_SAMPLENUM_Msk       (_U_(0xF) << ADC_AVGCTRL_SAMPLENUM_Pos)
#define ADC_AVGCTRL_SAMPLENUM(value)    (ADC_AVGCTRL_SAMPLENUM_Msk & ((value) << ADC_AVGCTRL_SAMPLENUM_Pos))


/********************** Register : SAMPCTRL : (Offset: 0x3) (R/W  8) ******************/
#define ADC_SAMPCTRL_ADDROFFSET         0x3u


/********************** Register : CTRLB : (Offset: 0x4) (R/W  16) ********************/
#define ADC_CTRLB_ADDROFFSET            0x4u
#define ADC_CTRLB_RESSEL_Pos            4 
#define ADC_CTRLB_CORREN_Pos            3
#define ADC_CTRLB_FREERUN_Pos           2
#define ADC_CTRLB_LEFTADJ_Pos           1
#define ADC_CTRLB_DIFFMODE_Pos          0 
#define ADC_CTRLB_PRESCALER_Pos         8
#define ADC_CTRLB_PRESCALER_Msk         (_U_(0x7) << ADC_CTRLB_PRESCALER_Pos)
#define ADC_CTRLB_PRESCALER(value)      (ADC_CTRLB_PRESCALER_Msk & ((value) << ADC_CTRLB_PRESCALER_Pos))


/********************** Register : SWRIG : (Offset: 0x0C) (R/W  8) **********************/
#define ADC_SWTRIG_ADDROFFSET           0x0c
#define ADC_SWTRIG_START_Pos            1            
#define ADC_SWTRIG_START                (_U_(0x1) << ADC_SWTRIG_START_Pos)


/********************** Register : INPUTCTRL : (Offset: 0x10) (R/W  32) ****************/
#define ADC_INPUTCTRL_ADDROFFSET        0x10u


/********************** Register : INPUTCTRL : (Offset: 0x18) (R/W  8) ****************/
#define ADC_INTFLAG_ADDROFFSET          0x18


/********************** Register : RESULT : (Offset: 0x1A) (R/W  16) *****************/
#define ADC_RESULT_OFFSET               0x1A

#define ADC_CALIB_ADDROFFSET            0x28

#define ADC_STATUS_B_SYNCBUSY           BIT7           
#define ADC_STATUS_ADDROFFSET           0x19      
#define ADC_INTFLAG_RESRDY_1            BIT0
#define ADC_CNTRLA_B_SWRST              BIT0            
#define ADC_CNTRLA_B_ENABLE             BIT1            
#define ADC_CNTRLA_B_RUNSTDBY           BIT2  
#define ADC_INTFLAG_RESRDY_1_pos        0

/**-----------Macro for synchronization wait between Interface clock and GCLK-----------*/
#define ADC_WAIT_FOR_SYNC()  	        while ((REGB(ADC_BASE_ADDRESS + ADC_STATUS_ADDROFFSET) & ADC_STATUS_B_SYNCBUSY) != FALSE)


/**-----------Check if ADC module is already enabled through CNTRLA register-----------*/
#define ADC_CNTRLA_ISENABLE()           ((REGB(ADC_BASE_ADDRESS + ADC_CTRLA_ADDROFFSET) & ADC_CNTRLA_B_ENABLE) != FALSE)


/**-----------Perform DAC Module reset-----------**************************************/
#define ADC_MODULE_RESET()              (REGB(ADC_BASE_ADDRESS + ADC_CTRLA_ADDROFFSET) |= ADC_CNTRLA_B_SWRST )


/**-Check whether the ADC conversion is over and result bit is set*********************/
#define ADC_WAIT_FOR_CONVERSION()        while((REGB(ADC_BASE_ADDRESS + ADC_INTFLAG_ADDROFFSET) & ADC_INTFLAG_RESRDY_1)  != TRUE )


/*********************   ADC Configurations       ************************************/
#define CONF_ADC_RUNSTDBY               0
#define CONF_ADC_ENABLE                 1
#define CONF_ADC_REFCOMP                0
#define CONF_ADC_REFSEL                 0x0
  
#define CONF_ADC_SAMPLENUM              0x4
#define CONF_ADC_SAMPLEN                0
#define CONF_ADC_PRESCALER_64           0x4
#define CONF_ADC_RESSEL                 0x1
#define CONF_ADC_CORREN                 0
#define CONF_ADC_FREERUN                1
#define CONF_ADC_LEFTADJ                0
#define CONF_ADC_DIFFMODE               0
#define CONF_ADC_MUXNEG                 0x19
#define ADC_INPUTCTRL_MUXNEG_Pos        8
#define CONF_ADC_MUXPOS                 0x1b
#define ADC_INPUTCTRL_MUXPOS_Pos        0 
#define CONF_ADC_ADJRES                 0x4
#define ADC_VOLTAGE_VARIATION           50
#define ADC_MINIMUM_IP_READ             2700
#define ADC_POLLING_INTERVAL_MS         50

#ifdef _IDEAL_

/*Begin Macro Defines*/
/**************************************************************************************************/
/*Peripheral Clock Mask Macros*/
#define PM_APBCMASK_ADC_POS             16
#define IDEAL_PM_APBCMASK_ADC           (_U_(0x1) << PM_APBCMASK_ADC_POS)

/*ADC Register Access MACROS*/
#define IDEAL_ADC_CTRLA_REG             ADC_BASE_ADDRESS + ADC_CTRLA_ADDROFFSET
#define IDEAL_ADC_REFCTRL_REG           ADC_BASE_ADDRESS + ADC_REFCTRL_ADDROFFSET
#define IDEAL_ADC_AVGCTRL_REG           ADC_BASE_ADDRESS + ADC_AVGCTRL_ADDROFFSET
#define IDEAL_ADC_SAMPCTRL_REG          ADC_BASE_ADDRESS + ADC_SAMPCTRL_ADDROFFSET
#define IDEAL_ADC_CTRLB_REG             ADC_BASE_ADDRESS + ADC_CTRLB_ADDROFFSET
#define IDEAL_ADC_INPUTCTRL_REG         ADC_BASE_ADDRESS + ADC_INPUTCTRL_ADDROFFSET
#define IDEAL_ADC_SWTRIG_REG            ADC_BASE_ADDRESS + ADC_SWTRIG_ADDROFFSET
#define IDEAL_ADC_RESULT_REG            ADC_BASE_ADDRESS + ADC_RESULT_OFFSET
#define IDEAL_ADC_INTENSET_REG          ADC_BASE_ADDRESS + 0x17
#define IDEAL_ADC_INTENCLR_REG          ADC_BASE_ADDRESS + 0x16
#define IDEAL_ADC_INTFLAG_REG           ADC_BASE_ADDRESS + ADC_INTFLAG_ADDROFFSET

/*ADC register value Macros*/
#define IDEAL_ADC_INTFLAG_RESRDY        0x01
#define IDEAL_ADC_INTFLAG_OVERRUN       0x02
#define IDEAL_CONF_SAMPLEN              0x3E
#define IDEAL_CONF_ADC_REFSEL           0x1
#define IDEAL_CONF_ADC_MUXPOS_V         0x00
#define IDEAL_CONF_ADC_MUXPOS_I         0x01
#define IDEAL_CONF_ADC_INPUTSCAN        0x02
#define ADC_INPUTCTRL_INPUTSCAN_Pos     16
#define IDEAL_ADC_SWTRIG_FLUSH          0x01
#define IDEAL_ADC_INPUTCTRL_MUXPOS_V    (IDEAL_CONF_ADC_MUXPOS_V << ADC_INPUTCTRL_MUXPOS_Pos)
#define IDEAL_ADC_INPUTCTRL_MUXPOS_I    (IDEAL_CONF_ADC_MUXPOS_I << ADC_INPUTCTRL_MUXPOS_Pos)

/*ADC calibration and resolution factor macros*/
#define IDEAL_ADC_STEP_RESOLUTION       0.000544367609
#define IDEAL_ADC_V_CALB_FACTOR         12
#define IDEAL_ADC_V_MUL_FACTOR          (IDEAL_ADC_V_CALB_FACTOR * IDEAL_ADC_STEP_RESOLUTION)
#define IDEAL_ADC_I_CALB_FACTOR         3.2
#define IDEAL_ADC_I_MUL_FACTOR          (IDEAL_ADC_I_CALB_FACTOR * IDEAL_ADC_STEP_RESOLUTION)
/**************************************************************************************************/
/*End Macro Defines*/

/*Begin Variable Declaration*/
/**************************************************************************************************/
/**
 * Enum Name        - E_ADC_INPUT_SEL 
 * Enum Description - Variables holding the input to measure (Voltage or current)
 */
/**************************************************************************************************/
typedef enum adc_input_sel
{
    ADC_INPUT_V,
    ADC_INPUT_I
      
}E_ADC_INPUT_SEL;

/*End Variable Declaration*/

/*Begin Function Declarations*/
/**************************************************************************************************/
/*
 * \Function Name          - Ideal_ADCInit 
 * \Function Description   - This function initializes the Clocks and registers for ADC
 * \return                 - (eADC_INIT_RETURN) The error status.
 */
/**************************************************************************************************/
eADC_INIT_RETURN Ideal_ADCInit (void);

/*End Function Declarations*/
#endif

extern volatile BOOL gbVariationVCC;

eADC_INIT_RETURN ADC_Initialization (void);
void ADC_Deinitialization(void);
void ADC_Disable(void);
void ADC_SynchronousRead_TimerCB(UINT8 u8PortNum, UINT8 u8DummyVariable);
void ADC_Read_Dummy(void);
void ADC_Run(void);

#endif
