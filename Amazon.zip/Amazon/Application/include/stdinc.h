#ifndef _STDINC_H_
#define _STDINC_H_


#include <generic_defs.h>
#include <ZeusStackConfig.h>
#include <debug.h>
#include <generic_timer.h>
#include <typeC_control.h>
#include <policy_manager.h>
#include <policy_engine.h>
#include <upd_interrupts.h>
#include <upd_hw.h>
#include <protocol_layer.h>
#include <cfg_globals.h>
#include <int_globals.h>
#include <policy_engine_fwup.h>

#endif